import React from 'react'
import ReactDOM from 'react-dom/client'
import '@fontsource/caveat/latin-700.css'
import '@fontsource/cormorant-garamond/latin-400.css'
import './styles.css'
import App from './App'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
