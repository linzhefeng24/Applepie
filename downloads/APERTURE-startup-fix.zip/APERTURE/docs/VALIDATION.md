# 验证记录

初始验证日期：2026-10-31；最新启动与发布修复验证：2026-11-01（Asia/Shanghai）。以下均在当前云实例实际执行，非仅列出建议命令。

| 检查 | 结果 | 证据 / 入口 |
|---|---|---|
| 原始 Release 下载 | 通过 | part1.zip 的 SHA256 与 GitHub 公布值一致 |
| Debian PostgreSQL 安装来源 | 通过 | 使用预装 Debian archive keyring 验证 InRelease 签名，再校验 Packages.xz 与两个 .deb 的 SHA256；脚本固定已验证哈希 |
| 原始数据聚合抽查 | 通过 | AAPL 2022-03-07 的开高低收、成交量与分钟数直接从 Parquet 独立重算，与 CSV 一致 |
| 完整精简数据校验 | 通过 | 32 标的、37,247 行；哈希、复合键唯一性、覆盖日期、行数、正 OHLC 与高低关系、非负成交量 |
| Scala 编译 | 通过 | 39 个 Scala 源文件；强类型业务响应与所有服务构建成功 |
| Scala 格式 | 通过 | `scalafmtCheckAll` |
| 前端严格类型与生产构建 | 通过 | `tsc -b && vite build`；使用锁文件 |
| 数值与配置单元测试 | **33 项通过** | `quant/tests/test_engine.py` |
| 真数据库 HTTP 集成测试 | 通过 | `scripts/verify-api.py` |
| Chromium 真实用户流程 | **2 项通过** | `frontend/tests/workflow.spec.ts`，生产构建、实际后端，无 API mock |
| 完整安装脚本 | 通过 | 实际执行 `scripts/setup.sh`，重复安装/构建/数据校验/数值测试全部成功 |
| 完整数据库与服务重启 | 通过 | `scripts/verify-restart.py` 保存临时报告，停止全部本项目服务和数据库，启动后验证内容一致并清理 |
| 重复启动 | 通过 | 启动脚本识别已运行的归属进程，不重复启动 |
| 原仓库保护 | 通过 | 原有跟踪文件未修改；新增独立 financial-terminal/，保留 materials/ |

## 数值测试内容

1. 最大回撤包含初始资本。
2. 三、四阶中心矩计算。
3. 五模型权重和、禁止卖空、权重上限与最小方差对照。
4. 不可行约束和负费用拒绝。
5. capped simplex 投影约束。
6. 缺失价格按交集处理，无前向填充。
7. 训练窗口与一整个收盘的信号延迟。
8. 改变未来收益不改变既往回测与调仓。
9. 首次从现金建仓计费。
10. 调仓间持仓随价格漂移。
11. 成本增加会降低相同策略净值。
12. 相同输入的优化结果确定性。

## API 集成测试内容

- 返回 32 个股票与最新源行情。
- AAPL 全部 1,164 条数据库日线逐行匹配 CSV。
- Scala 个股统计与 Python 独立统计在收益、波动、Sharpe、回撤、偏度和超额峰度上误差小于 1e-9。
- 五种优化可行并收敛；回测四种策略，净值与总收益一致；每条调仓记录满足信号日 < 执行日 < 首个收益日。
- 无效股票、反向日期、重复股票、不可行上限、样本不足和无效报告返回 400。
- 自选持久化、报告参数和结果保存/读取一致、删除清理。

## 浏览器测试内容

- 股票检索与自选、个股历年指标、双股比较和实际图表渲染。
- 五模型分析、保存报告、研究档案打开与 Markdown 下载。
- 真实样本外回测、净值图与调仓审计、CSV 下载。
- 空日期区间和无效日期。
- 390px 手机布局与侧栏导航。
- 无未捕获浏览器 JavaScript 错误。

截图：`docs/screenshots/overview.png`、`stock.png`、`lab.png`、`backtest.png`、`mobile.png`。

## 尚未验证或不在范围内

没有在新建云任务中独立验证快照恢复；环境发布由用户在产品中完成。GitHub 发布状态以仓库提交记录为准。没有实盘执行、全市场覆盖、付费 API、财报数据、多人权限隔离、压力测试或不同操作系统部署验证。源数据未知复权和公司行动的限制继续存在，不因软件测试通过而消失。

## 本地目录可移植性修复验证

- 将源码复制至带空格的新项目目录，从无关的工作目录执行安装与启动；测试数据目录和 PostgreSQL 数据目录也包含空格。
- 同时将三个 Scala 服务、数值服务、前端和 PostgreSQL 改到新端口，建立新数据库，真实 API 集成测试与 2 项 Chromium 流程均通过。
- 独立模拟失效的旧 Java classpath 缓存；启动脚本检测路径变化，自动重建并成功启动。
- 新增 6 项配置测试：环境变量覆盖、.env 覆盖、相对路径、带空格目录、PostgreSQL 版本无关定位、Python 虚拟环境符号链接和 .env 不执行命令（部分用例同时覆盖多个行为）。
- PostgreSQL 自动下载仍限定于 Debian 13 x86_64；其他 Linux 系统可配置已安装的 PostgreSQL 或外部数据库，未声称原生 Windows/macOS 安装脚本已验证。
- 搬目录测试复用了已验证的开发工具下载缓存，重新安装了前端依赖、生成了新的虚拟环境和数据库，重新构建了前后端；不等于在另一种操作系统验证。
- 已验证外部 PostgreSQL 模式的安装连接检查与停止行为；`stop-services.sh --database` 不会关闭外部数据库。

## 根目录一键启动入口

已在新的项目目录使用 `bash run.sh` 实际完成：首次项目依赖安装、新 PostgreSQL 初始化、前后端构建、全部服务就绪检查；第二次运行复用依赖和进程；`restart` 重启应用及本地数据库；重启后的真实 API/分析/回测/报告测试通过；`stop` 停止测试实例并保留数据。该测试复用了已验证的 PostgreSQL/sbt 下载缓存，基础 Java/Node/Python 来自主机。未声称可以在没有基础开发工具的电脑上安装这些系统工具。

## 缺少基础工具时的自动安装

已在本任务创建的干净 Ubuntu 24.04、Ubuntu 22.04 容器中，以普通用户和 sudo 安装权限测试基础依赖安装。容器预先只准备 sudo 和本次测试代理的 CA 信任；没有预装 Java、Node、Python 或 PostgreSQL。

- Ubuntu 24.04：自动安装 Java 21、项目专用 Node 24、系统 Python 3.12/venv、PostgreSQL 16，随后 `bash run.sh` 完成依赖安装、数据库初始化、前后端构建、服务启动；真实 API / 优化 / 回测 / 报告测试通过。
- Ubuntu 22.04：自动安装 Java 21、项目专用 Node 24、通过固定版本 uv 安装项目专用 Python 3.12、PostgreSQL；同样完成整个应用启动及真实 API 测试。
- 两个容器都成功停止应用和项目数据库。包签名、TLS 与 Node 官方 SHA256 校验保持开启；sudo 调用保留代理变量。
- Ubuntu 22.04 测试还模拟 WSL 的 `/mnt/d/Downloads/APERTURE` 路径和 WSL 环境标记，确认数据库目录位于 Linux 用户状态目录而非项目所在的 Windows 盘路径。容器不是真实 Windows/DrvFS，未把它称为真实 WSL 内核验证。
- 最新本机单元测试共 20 项，通过了 WSL 路径识别、默认数据库路径和显式目录覆盖规则。Ubuntu 完整测试包包含之前的 18/19 项；最后增加的配置用例另在本机执行通过。

系统软件源安装仍需要用户的 sudo 权限和网络；脚本不能绕过这些前提。尚未适配原生 Windows、macOS 或无 apt 的发行版自动安装。

## 无关第三方 APT 源错误的兼容性

新增 5 项源配置测试，覆盖 resolute 官方源、安全更新源、Ubuntu ports 架构、Debian keyring、非法字段拒绝，以及 update/install 共用隔离源和索引且保持验签。最新本机共 25 项测试通过。

安装器为当前调用生成官方来源配置，使用系统发行版 archive keyring，隔离 sourceparts 和 package lists；不修改 `/etc/apt/`，不读取 Docker/NodeSource 源，不启用未签名软件包。普通系统 apt 操作的第三方源问题不会被伪称为已修复。

Ubuntu 26.04 的系统 Python 过新时，自动使用项目专用的兼容 Python；已有损坏或不兼容虚拟环境会保留在 `.run/` 后重建，避免因 pandas 没有对应 wheel 而要求用户安装 C 编译器。

最终在干净 Ubuntu 26.04 resolute 容器中预置启用的 Docker 源，并指定不存在的 Docker keyring：安装器使用官方源完成 Java/Node/兼容 Python/PostgreSQL 安装；25 项单元测试、前后端构建、完整应用启动和真实 API/优化/回测/报告测试全部通过。停止后 Docker 源文件 SHA256 与安装前一致，测试容器退出码为 0。此次验证不要求联系 Docker 软件源，也未导入其密钥。

## 全局 Python / npm 私有源隔离

新增两个回归测试，验证子进程清除全局 pip 索引、额外索引、trusted-host 和安装目标，使用独立配置且保留显式 CA/代理；父进程环境不变；拒绝 HTTP 项目源。本机合计 27 项测试通过。

uv 引导安装与 quant/requirements.txt 依赖安装统一通过同一入口，默认 PyPI 官方 HTTPS，禁用全局配置读取，仅接受预编译 wheel。npm ci 使用项目独立的配置文件和官方 HTTPS registry，并保持严格 TLS。可用项目专用环境变量选择 HTTPS 镜像。

在干净 Ubuntu 26.04 容器中，同时预置：全局 `/etc/pip.conf` 指向不可访问 Nexus、额外私有 Python 索引、环境变量重复指定这些源、全局 npmrc 指向不可访问私有源，以及之前的错误 Docker 源。uv 安装、兼容 Python、项目全部 Python/npm 依赖、27 项单元测试、前后端构建、应用启动及真实 API / 优化 / 回测 / 报告验证全部通过。退出前核对 pip.conf、npmrc、Docker 源文件 SHA256 均未改变，测试退出码为 0。随后额外保留了用户显式的 pip 哈希校验策略，并用回归用例确认未被清除。

## 预编译 Scala 运行包与构建进度

正式下载包增加应用 JAR、40 个运行依赖和 SHA256/源码指纹清单。正常 setup/start 会校验并启用运行包，不下载 sbt/Maven；源码构建仍保留，日志实时输出、每 20 秒报告构建进程存活。通过受控失败测试确认：即便 tee 正常退出，sbt 的退出码 17 仍被正确返回。

在含空格和括号的新目录中测试正式运行包，故意阻止 Maven curl 下载、将 sbt 编译入口设为立即失败，并确保没有 sbt launcher：`bash run.sh` 成功启动；全部真实 API/数值/优化/回测/报告检查通过；Chromium 的 2 项完整用户流程也通过。最后再次验证每次启动的 JAR 校验与重启流程。测试复用了已安装的 Java/Node/Python/PostgreSQL 工具，未把它声称为在另一台原生 WSL 上验证。

新增 6 项运行包回归测试，覆盖打包与顺序、带空格目录搬移、源码变更、损坏 JAR、缺失清单及路径逃逸拒绝；最新合计 33 项单元测试通过。发布包中的完整源码没有移除。GitHub 自动源码 ZIP 不含生成的运行包，用户应选择正式 APERTURE.zip。


## 损坏 pip 引导恢复与 WSL Linux 缓存

不再依赖旧 uv-bootstrap 的 pip：标准库通过官方 PyPI HTTPS 元数据下载固定版本 uv wheel，验证 SHA256 后提取指定的原生 ELF 文件；每次复用也校验二进制。uv 直接创建兼容 Python 环境并安装依赖。WSL 的 Windows 盘项目将运行时和 Python 环境放在 Linux 用户目录，项目依赖环境按 requirements 内容复用，显式路径配置仍受尊重。

37 项单元测试通过，新增原生工具下载校验、损坏缓存重新获取、错误校验和拒绝、uv 不调用目标 Python 的 pip、哈希策略保留、WSL 环境目录及覆盖设置检查。额外实际测试损坏项目虚拟环境：保留备份并创建新的可用环境。

Ubuntu 26.04 容器中模拟 WSL 和 `/mnt/d/Downloads/APERTURE (3)/APERTURE` 路径，预先创建 Python 3.14 引导环境并删除 pip 的 packaging，确认复现用户同样的 ModuleNotFoundError。新版成功绕过它，安装独立 Python 3.12、依赖、数据库并构建启动全部服务；37 项测试和真实 API（五种优化方法、四种滚动回测、报告持久化等）通过，停止成功，容器退出码 0。还保留了错误 Docker 源及全局私有 pip/npm 源，安装没有修改这些配置。本测试模拟 WSL 路径选择，没有声称在原生 Windows NTFS 上验证。

提供仅包含启动脚本、配置及说明的 APERTURE-startup-fix.zip，可覆盖旧下载目录，保留 .env、数据库和 backend/runtime。完整 APERTURE.zip 同步更新。


## 启动补丁与测试文件一致性修复

用户日志确认上次小补丁遗漏 quant/tests：新安装器导出了 APERTURE_UV_BIN，旧测试继承该变量，误走原生 uv 分支，最终因没有预期 JSON 而报 StopIteration。这是发布补丁缺失配套测试导致的兼容性错误。

新增 scripts/package-startup-patch.py：从同一 Git HEAD 打包脚本、配置、运行时执行的全部 quant/tests 和依赖清单，强制检查关键测试文件存在，通过 ZIP 校验后再替换成品，避免再次手工筛选遗漏。

验证使用旧完整包（7d0e2b9）加遗漏测试的旧补丁（30ecf11）重建用户当前目录，继承 APERTURE_UV_BIN 后准确复现 StopIteration；覆盖修正版补丁后 37 项测试全部通过，预编译运行包检查通过。额外放置 .env 与数据库文件标记并确认覆盖后内容不变，JAR 清单哈希不变。此次修复仅补齐发布内容，没有绕过或删除失败测试。
