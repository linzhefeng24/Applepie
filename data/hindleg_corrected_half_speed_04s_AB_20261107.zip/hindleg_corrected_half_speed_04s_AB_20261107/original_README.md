# Hind-leg correction candidate, 2026-11-06

Reference: original simulated 0.2 s motion retimed to physical 0.4 s. Saved actual replay has 2,000 states at 5 kHz, and 4,000 excitation controls at 10 kHz.

## Changes

Only four attachment sites of the two hind tarsus-depressor tendons were changed, inside the original same-bone geometry uncertainty bounds. Maximum force, activation dynamics and native muscle curves remain unchanged. The geometry remains an estimate.

First optimized only hind-leg inputs for three completed iterations. Then jointly optimized all six legs over the whole 0.4 s with three temporal knots and seven coordinated muscle directions per leg (126 parameters). Commands remain bounded to [0,1]. Native contact, gravity, activation, passive muscle force and joint constraints are integrated in each rollout. The eleven retained nonmuscle controls are unchanged.

No height or velocity penalty. Soft pose penalties include outward hind-foot margin 0.25 mm, coxa guard [-12,22] deg, hind femur-twist error 12 deg, tarsus error 20 deg and body-up component 0.8. Endpoint angle residual is multiplied by 4. Two successive right-hind-only polish passes use a 0.05 mm foot-side margin, foot residual multipliers of 20 and 100, and reject sampled global angle RMS above 10.8 deg or terminal RMS above 14.3 deg. An alternative with a further right-hind femur guard of 15 deg (residual multiplier 20) was tested while rejecting sampled foot distances below 0.01 mm. Each pass has 21 additional parameters that adjust three temporal knots and seven muscle directions. These are penalties and sampled acceptance checks, not hard feasibility claims.

## Full-resolution comparison

| Metric | Before | Candidate |
|---|---:|---:|
| Full-path joint angle RMS (deg) | 10.9173 | 9.3284 |
| Hind-leg path RMS (deg) | 14.9170 | 11.0257 |
| Terminal all-joint RMS (deg) | 14.3649 | 11.8949 |
| Maximum terminal error (deg) | 56.7396 | 44.8639 |
| Minimum left/right outward foot distance (mm) | [0.09240344001100184, -0.3588426229572612] | [0.4564372765326252, 0.03972092773237699] |
| First left/right foot midline crossing (s) | [None, 0.14220000000000066] | [None, None] |

See validation_report.json for individual joints and exact step-by-step replay verification; geometry_report.json for site positions and bounds; old_geometry_new_control_ablation.json for an old-geometry replay of the new controls.

## Alternative B and remaining errors

Candidate B full-path angle RMS: 9.3720 deg; terminal RMS: 13.9594 deg; hind path RMS: 10.4664 deg. Both hind feet remain on their own side in all 2,000 checked states. B was independently replayed with zero full-state error; see alternative_validation_report.json.

Right-hind femur terminal absolute error: before 15.7503 deg; candidate A 32.1989 deg; candidate B 9.4289 deg. Its sampled whole-path peak decreased from about 58.24 deg in A to 26.41 deg in B. Thus A's lower overall RMS does not mean every joint improved. The maximum individual terminal error remains about 45 deg in both candidates. Neither candidate fully matches the reference.

The old-geometry replay of A's new controls yields path RMS 9.3856 deg and terminal RMS 12.0924 deg, with a small right-foot crossing of 0.0089 mm. Control changes explain most of the aggregate angle improvement; the bounded path adjustment corrects the sampled tarsus action reversal and changes this candidate's small remaining crossing.

## Video

https://github.com/linzhefeng24/Applepie/blob/main/videos/hindleg_correction_04s_comparison_005x_20261106.mp4

https://raw.githubusercontent.com/linzhefeng24/Applepie/main/videos/hindleg_correction_04s_comparison_005x_20261106.mp4

Four panels, two rows: reference / before on the top row; selected candidate A / stronger right-hind femur guard candidate B on the bottom row. Candidate A was selected for lower overall terminal angle RMS with no observed hind-foot crossing. Candidate B reduces right-hind femur error at the cost of a larger overall terminal error. Full physical 0.4 s at playback 0.05x (8 s). Cameras follow each body independently. Poses are rendered directly from saved states, without correction. This is a simulated reference, not an experimental fly recording.

This trial does not establish sustained normal walking and does not replace the globally selected model.
