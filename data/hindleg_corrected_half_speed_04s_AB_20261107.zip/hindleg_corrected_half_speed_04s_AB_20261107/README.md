# 后腿修正后的半速0.4秒肌肉轨迹：A、B

此包替代此前误选的“尚未修正后腿”研究导出。它对应四画面对比视频的下排两个版本，均为历史已有结果，未重新优化。

- `A/`：视频左下；原先选中的版本，总体末端关节误差较低。
- `B/`：视频右下；进一步约束右后腿股节，右后腿股节误差更小，但总体末端误差较大。
- 每个目录的 `activation_a_10000Hz.csv` 为实际激活a(t)，4001行×130肌肉，包含0和0.4秒。
- `excitation_u_10000Hz.csv` 为激励u(t)，4000行×130肌肉，每行作用于随后0.1ms。回放应输入u，不能把a直接当作u。
- CSV前两列是仿真时间与原始参考时间，随后为130个有名称的肌肉列。采用17位有效数字，无有损舍入。
- `muscle_trajectories.npz` 为数值版，另含141通道完整控制、初始完整状态及warmstart、5kHz实际/目标关节角与实际关节速度。为减小体积，未重复保存全身体状态轨迹；原始文件路径和哈希记在metadata中。
- `muscle_columns.csv` 给出列与模型索引对应；`corrected_model.xml`和`corrected_muscle_records.json`是对应模型。必须使用这个修正模型，不要混用上次未修正模型。

## 修正内容与原始结果

模型只在既定几何不确定范围内修改了两条后腿跗节降肌肌腱的四个附着点，肌肉最大力、激活动力学及原生肌肉曲线没有变化；之后重新调整激励。两版不再是完全相同的纯angle-only目标，还使用了后脚内侧越界及关节姿态等软约束；细节见original_README.md和原始报告。

参考仍为半速、物理0–0.4秒，覆盖原始0–0.2秒。A整体路径RMS约9.328°、末端11.895°；B分别约9.372°、13.959°。这是有限时长结果，未证明持续周期行走。

历史记录按5kHz保存。导出时按原模型、原控制、初态和warmstart重放至10kHz，并逐项核对原始采样点的完整状态、激活和激励；两版均完全一致。没有进行插值或重新求解。

XML保留原来的绝对网格资产路径，网格文件不在此包中，跨机器回放需要另备这些资产。

```python
import numpy as np
z = np.load('A/muscle_trajectories.npz')  # 或 B/
t, a = z['time_s'], z['activation']
tu, u = z['excitation_time_s'], z['excitation']
names = z['muscle_ids']
```

视频：https://github.com/linzhefeng24/Applepie/blob/main/videos/hindleg_correction_04s_comparison_005x_20261106.mp4
