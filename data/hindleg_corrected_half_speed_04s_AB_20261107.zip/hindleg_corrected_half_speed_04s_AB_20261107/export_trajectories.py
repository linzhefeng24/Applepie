"""Export both historical hind-leg corrections shown in the four-panel video."""
import os
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import csv,json,hashlib,shutil,zipfile
import numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent
OUT=Path('/workspace/exports/hindleg_corrected_half_speed_04s_AB_20261107');OUT.mkdir(exist_ok=True,parents=True)
MODEL=R/'candidate_muscles.xml';m=mujoco.MjModel.from_xml_path(str(MODEL))
records=json.loads((R/'candidate_records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids]
names=np.array([r['id'] for r in records]);assert len(ids)==130
ref=np.load(R.parent/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz');qa=ref['joint_qpos_indices'];vd=ref['joint_dof_indices']
off=1+m.nq+m.nv;reports={};checks={}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for variant,source,validation_file in [('A',R/'optimized_rollout.npz',R/'validation_report.json'),('B',R/'right_hind_femur_stage/optimized_rollout.npz',R/'alternative_validation_report.json')]:
    out=OUT/variant;out.mkdir(exist_ok=True)
    z=np.load(source);assert np.array_equal(names,z['muscle_ids'])
    validation=json.loads(validation_file.read_text());assert validation['model_sha256']==sha(MODEL)
    C=z['all_control_10000Hz'];initial=z['initial_state'];warm=z['initial_warmstart']
    S,_=rollout.rollout(m,mujoco.MjData(m),initial[None],C[None],initial_warmstart=warm[None]);S=S[0]
    error=float(abs(S[1::2]-z['full_state']).max());assert error<1e-9,error
    A=np.vstack([initial,S])[:,off:][:,adrs];U=C[:,ids]
    assert np.array_equal(A[2::2],z['activation']) and np.array_equal(U[1::2],z['excitation'])
    assert A.min()>=0 and A.max()<=1 and U.min()>=0 and U.max()<=1
    t=np.arange(4001)*.0001;tu=np.arange(4000)*.0001
    np.savez_compressed(out/'muscle_trajectories.npz',time_s=t,source_reference_time_s=.5*t,activation=A,
       excitation_time_s=tu,excitation=U,all_controls=C,initial_state=initial,initial_warmstart=warm,
       muscle_ids=names,actuator_indices=ids,activation_indices=adrs,
       recorded_time_s=z['time_s'],joint_angle_rad=z['joint_angle_rad'],target_joint_angle_rad=z['target_joint_angle'],
       joint_velocity_rad_s=z['qvel'][:,vd],joint_names=z['joint_names'],joint_qpos_indices=qa,joint_dof_indices=vd,
       physics_dt_s=np.array(.0001),reference_speed_factor=np.array(.5))
    for filename,times,values in [('activation_a_10000Hz.csv',t,A),('excitation_u_10000Hz.csv',tu,U)]:
        with (out/filename).open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['time_s','source_reference_time_s',*names.tolist()])
            for ti,row in zip(times,values):w.writerow([format(ti,'.17g'),format(.5*ti,'.17g'),*[format(float(v),'.17g') for v in row]])
        assert np.array_equal(np.loadtxt(out/filename,delimiter=',',skiprows=1)[:,2:],values)
    metrics=validation['corrected'];reports[variant]={k:metrics[k] for k in ['path_rmse_deg','hind_path_rmse_deg','terminal_rmse_deg','max_terminal_error_deg','first_midline_crossing_s','min_outward_foot_mm']}
    meta=dict(variant=variant,video_panel='bottom left' if variant=='A' else 'bottom right',source_rollout=str(source),
      source_rollout_sha256=sha(source),model_sha256=sha(MODEL),replay_max_full_state_error_at_original_samples=error,
      historical_5000Hz_samples_preserved_exactly=True,additional_samples='Original control replay at native 10000 Hz; no interpolation or reoptimization',
      activation_shape=list(A.shape),excitation_shape=list(U.shape),physical_duration_s=.4,reference_speed_factor=.5,
      activation_semantics='a(t), actual muscle state at time_s, includes t=0 and t=0.4',
      excitation_semantics='u[k], held on [excitation_time_s[k], excitation_time_s[k]+0.0001); replay this input, not a(t)',
      retained_nonmuscle_channels=11,all_controls_shape=list(C.shape),metrics=reports[variant],
      differs_from_uncorrected_export=True,requires_corrected_candidate_model=True,no_reoptimization=True,
      full_rigid_body_state_not_bundled=True,original_full_state_source=str(source),walking_validated=False,periodic_validated=False)
    (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');shutil.copy2(validation_file,out/'original_validation_report.json')
    checks[variant]=dict(replay_error=error,activation_min=float(A.min()),activation_max=float(A.max()),excitation_min=float(U.min()),excitation_max=float(U.max()))
shutil.copy2(MODEL,OUT/'corrected_model.xml');shutil.copy2(R/'candidate_records.json',OUT/'corrected_muscle_records.json')
for filename in ['geometry_report.json','candidate_selection.json','README.md']:
    shutil.copy2(R/filename,OUT/('original_'+filename))
shutil.copy2(R/'video/video_manifest.json',OUT/'original_video_manifest.json')
shutil.copy2(Path(__file__),OUT/'export_trajectories.py')
with (OUT/'muscle_columns.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['muscle_column_0based','csv_column_1based','muscle_id','actuator_name','actuator_index_0based','activation_index_0based'])
    for i,k in enumerate(ids):w.writerow([i,i+3,str(names[i]),mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_ACTUATOR,int(k)),int(k),int(adrs[i])])
video='https://github.com/linzhefeng24/Applepie/blob/main/videos/hindleg_correction_04s_comparison_005x_20261106.mp4'
(OUT/'README.md').write_text('''# 后腿修正后的半速0.4秒肌肉轨迹：A、B

此包替代此前误选的“尚未修正后腿”研究导出。它对应四画面对比视频的下排两个版本，均为历史已有结果，未重新优化。

- `A/`：视频左下；原先选中的版本，总体末端关节误差较低。
- `B/`：视频右下；进一步约束右后腿股节，右后腿股节误差更小，但总体末端误差较大。
- 每个目录的 `activation_a_10000Hz.csv` 为实际激活a(t)，4001行×130肌肉，包含0和0.4秒。
- `excitation_u_10000Hz.csv` 为激励u(t)，4000行×130肌肉，每行作用于随后0.1ms。回放应输入u，不能把a直接当作u。
- CSV前两列是仿真时间与原始参考时间，随后为130个有名称的肌肉列。采用17位有效数字，无有损舍入。
- `muscle_trajectories.npz` 为数值版，另含141通道完整控制、初始完整状态及warmstart、5kHz实际/目标关节角与实际关节速度。为减小体积，未重复保存全身体状态轨迹；原始文件路径和哈希记在metadata中。
- `muscle_columns.csv` 给出列与模型索引对应；`corrected_model.xml`和`corrected_muscle_records.json`是对应模型。必须使用这个修正模型，不要混用上次未修正模型。

## 修正内容与原始结果

模型只在既定几何不确定范围内修改了两条后腿跗节降肌肌腱的四个附着点，肌肉最大力、激活动力学及原生肌肉曲线没有变化；之后重新调整激励。两版不再是完全相同的纯angle-only目标，还使用了后脚内侧越界及关节姿态等软约束；细节见original_README.md和原始报告。

参考仍为半速、物理0–0.4秒，覆盖原始0–0.2秒。A整体路径RMS约9.328°、末端11.895°；B分别约9.372°、13.959°。这是有限时长结果，未证明持续周期行走。

历史记录按5kHz保存。导出时按原模型、原控制、初态和warmstart重放至10kHz，并逐项核对原始采样点的完整状态、激活和激励；两版均完全一致。没有进行插值或重新求解。

XML保留原来的绝对网格资产路径，网格文件不在此包中，跨机器回放需要另备这些资产。

```python
import numpy as np
z = np.load('A/muscle_trajectories.npz')  # 或 B/
t, a = z['time_s'], z['activation']
tu, u = z['excitation_time_s'], z['excitation']
names = z['muscle_ids']
```

视频：'''+video+'\n',encoding='utf-8')
(OUT/'export_validation.json').write_text(json.dumps(dict(variants=checks,metrics=reports,model_sha256=sha(MODEL),video_url=video),indent=2))
hashes={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'}
(OUT/'SHA256SUMS').write_text(''.join(f'{h}  {name}\n' for name,h in hashes.items()))
archive=OUT.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as f:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():f.write(p,arcname=OUT.name+'/'+str(p.relative_to(OUT)))
with zipfile.ZipFile(archive) as f:assert f.testzip() is None
print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,validation=checks,metrics=reports),indent=2))
