import os
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import json,numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent;ROOT=R.parent;S=ROOT/'hindleg_correction_20261106';OUT=ROOT/'hindleg_early_small_iterative_20261107'
m=mujoco.MjModel.from_xml_path(str(S/'candidate_muscles.xml'));fk=mujoco.MjData(m)
rec=json.loads((S/'candidate_records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in rec]);adrs=m.actuator_actadr[ids]
body=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');feet=[mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/claw_T3_'+side) for side in ['left','right']]
report={}
for variant in ['A','B']:
    original=dict(np.load(S/('optimized_rollout.npz' if variant=='A' else 'right_hind_femur_stage/optimized_rollout.npz')))
    for name in ['best_overall','final']:
        path=OUT/variant/(name+'_rollout.npz')
        if not path.exists():continue
        z=dict(np.load(path));C=z['all_control_10000Hz'];states,_=rollout.rollout(m,mujoco.MjData(m),z['initial_state'][None],C[None],initial_warmstart=z['initial_warmstart'][None]);states=states[0]
        err=float(abs(states[1::2]-z['full_state']).max());off=1+m.nq+m.nv
        assert err<1e-9 and np.isfinite(states).all() and np.allclose(states[:,0],np.arange(1,4001)*.0001,atol=1e-10,rtol=0)
        assert np.array_equal(C[2000:],original['all_control_10000Hz'][2000:])
        others=np.setdiff1d(np.arange(m.nu),ids);assert np.array_equal(C[:,others],original['all_control_10000Hz'][:,others])
        delta=float(abs(C[:,ids]-original['all_control_10000Hz'][:,ids]).max());assert delta<=.050000000001
        assert states[:,off:][:,adrs].min()>=0 and states[:,off:][:,adrs].max()<=1
        Y=[];up=[]
        for q in z['qpos']:
            fk.qpos[:]=q;mujoco.mj_kinematics(m,fk);rotation=fk.xmat[body].reshape(3,3)
            Y.append([sign*((fk.xpos[bid]-fk.xpos[body])@rotation)[1]*10 for sign,bid in zip([1,-1],feet)]);up.append(rotation[2,2])
        Y=np.array(Y)
        report[variant+'_'+name]=dict(replay_max_full_state_error=err,all_physics_times_verified=True,activation_in_bounds=True,
            maximum_excitation_change=delta,late_inputs_unchanged=True,nonmuscle_inputs_unchanged=True,
            minimum_hind_foot_outward_distance_mm=Y.min(axis=0).tolist(),hind_foot_crossing_samples=(Y<0).sum(axis=0).tolist(),minimum_body_up=float(min(up)),
            model_unchanged=True,no_intermediate_resets=True,extra_forces=False)
(OUT/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
