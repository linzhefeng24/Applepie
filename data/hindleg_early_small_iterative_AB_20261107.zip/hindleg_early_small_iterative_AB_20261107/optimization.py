"""Early small excitation changes; accept target-joint gains despite collateral error."""
import os
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import json,time,argparse,numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent;SOURCE=R.parent/'hindleg_correction_20261106';OUT=R.parent/'hindleg_early_small_iterative_20261107';OUT.mkdir(exist_ok=True)
m=mujoco.MjModel.from_xml_path(str(SOURCE/'candidate_muscles.xml'));data=[mujoco.MjData(m) for _ in range(4)];fk=mujoco.MjData(m)
rec=json.loads((SOURCE/'candidate_records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in rec]);adrs=m.actuator_actadr[ids]
ref=dict(np.load(R.parent/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));qa=ref['joint_qpos_indices'];vd=ref['joint_dof_indices'];names=ref['joint_names'].tolist();moment=np.empty((m.nu,m.nv))
parser=argparse.ArgumentParser();parser.add_argument('--variants',nargs='+',default=['A','B']);parser.add_argument('--resume',action='store_true');parser.add_argument('--sweeps',type=int,default=2);parser.add_argument('--stop-on-recovery',action='store_true');args=parser.parse_args()
history=json.loads((OUT/'history.json').read_text()) if args.resume else [];start=time.monotonic();results=json.loads((OUT/'summary.json').read_text()) if args.resume else {}
def simulate(commands,z):
    commands=np.asarray(commands)
    S,_=rollout.rollout(m,data,z['initial_state'][None],commands,initial_warmstart=z['initial_warmstart'][None],persistent_pool=True)
    assert np.isfinite(S).all() and np.allclose(S[:,-1,0],.4,atol=1e-10,rtol=0)
    return S
def metrics(state):
    q=state[1::2,1:1+m.nq][:,qa];e=q-ref['qpos'][1:,qa]
    return dict(path_rmse_deg=float(np.rad2deg(np.sqrt(np.mean(e**2)))),terminal_rmse_deg=float(np.rad2deg(np.sqrt(np.mean(e[-1]**2)))),
                max_terminal_error_deg=float(np.rad2deg(abs(e[-1]).max()))),e
def save(path,C,state,z):
    sampled=state[1::2];off=1+m.nq+m.nv
    np.savez_compressed(path,time_s=sampled[:,0],full_state=sampled,qpos=sampled[:,1:1+m.nq],qvel=sampled[:,1+m.nq:off],
        activation=sampled[:,off:][:,adrs],excitation=C[1::2][:,ids],all_control_10000Hz=C,initial_state=z['initial_state'],initial_warmstart=z['initial_warmstart'],
        joint_angle_rad=sampled[:,1:1+m.nq][:,qa],target_joint_angle=ref['qpos'][1:,qa],qerror_rad=sampled[:,1:1+m.nq][:,qa]-ref['qpos'][1:,qa],
        muscle_ids=np.array([r['id'] for r in rec]),joint_names=names)
def shape_for(state,j):
    D=[]
    for window in range(10):
        k=window*200+99;mujoco.mj_setState(m,fk,state[k],mujoco.mjtState.mjSTATE_FULLPHYSICS)
        mujoco.mj_fwdPosition(m,fk);mujoco.mj_fwdVelocity(m,fk)
        mujoco.mju_sparse2dense(moment,fk.actuator_moment,fk.moment_rownnz,fk.moment_rowadr,fk.moment_colind)
        g=np.array([mujoco.mju_muscleGain(fk.actuator_length[i],fk.actuator_velocity[i],m.actuator_lengthrange[i],m.actuator_acc0[i],m.actuator_gainprm[i,:9]) for i in ids])
        b=moment[ids,vd[j]]*g;D.append(np.where(abs(b)>.01*abs(b).max(),np.sign(b),0.))
    return np.array(D)
def modify(C,D,steps,lower,upper):
    c=C.copy()
    for w,delta in enumerate(steps):
        ix=np.arange(w*200,(w+1)*200);block=c[np.ix_(ix,ids)]
        c[np.ix_(ix,ids)]=np.clip(block+delta*D[w],lower[ix],upper[ix])
    return c
for label,path in [('A',SOURCE/'optimized_rollout.npz'),('B',SOURCE/'right_hind_femur_stage/optimized_rollout.npz')]:
    if label not in args.variants:continue
    out=OUT/label;out.mkdir(exist_ok=True);z=dict(np.load(path));base=z['all_control_10000Hz'];C=base.copy()
    lower=np.maximum(0.,base[:,ids]-.05);upper=np.minimum(1.,base[:,ids]+.05)
    current=simulate([C],z)[0];assert np.max(abs(current[1::2]-z['full_state']))<1e-9
    baseline,E=metrics(current);best=baseline.copy();bestC=C.copy();bestS=current.copy();accepted=0
    if args.resume and (out/'final_rollout.npz').exists():
        C=np.load(out/'final_rollout.npz')['all_control_10000Hz'].copy();current=simulate([C],z)[0]
        bestC=np.load(out/'best_overall_rollout.npz')['all_control_10000Hz'].copy();bestS=simulate([bestC],z)[0];best,_=metrics(bestS)
        accepted=sum(int(row['accepted']) for row in history if row['variant']==label)
    sweep_offset=max([row['sweep'] for row in history if row['variant']==label],default=0)
    # Two coordinate sweeps. Each sweep visits the four largest terminal errors once.
    recovered=False
    for sweep in range(sweep_offset,sweep_offset+args.sweeps):
        visited=set()
        for coordinate in range(4):
            current_metrics,E=metrics(current);order=np.argsort(abs(E[-1]))[::-1]
            chosen=None
            for j in order:
                if int(j) in visited:continue
                D=shape_for(current,int(j))
                visited.add(int(j))
                if np.any(D):chosen=int(j);break
            if chosen is None:break
            j=chosen;target_error=float(E[-1,j]);plans=[];tags=[];h=.01
            for w in range(10):
                for sign in [1,-1]:
                    steps=np.zeros(10);steps[w]=sign*h
                    plans.append(modify(C,D,steps,lower,upper));tags.append((w,sign))
            measured=[]
            for k in range(0,len(plans),8):
                ss=simulate(plans[k:k+8],z)
                for s in ss:measured.append(float(s[-1,1+qa[j]]-ref['qpos'][-1,qa[j]]))
            gradient=np.array([(measured[2*w]-measured[2*w+1])/(2*h) for w in range(10)])
            # Signed terminal response, not assumed local flexor/extensor direction.
            magnitude=float(abs(gradient).max());line_plans=[];scales=[]
            if magnitude>1e-9:
                for scale in [.01,.025,.05]:
                    steps=-np.sign(target_error)*gradient/magnitude*scale
                    line_plans.append(modify(C,D,steps,lower,upper));scales.append(scale)
            candidate_indices=sorted(range(len(measured)),key=lambda i:abs(measured[i]))[:2]
            line_plans.extend([plans[i] for i in candidate_indices]);scales.extend([f'coordinate_probe_{i}' for i in candidate_indices])
            ss=simulate(line_plans,z);errors=ss[:,-1,1+qa[j]]-ref['qpos'][-1,qa[j]];choice=int(np.argmin(abs(errors)))
            did_accept=bool(abs(errors[choice])<abs(target_error)-1e-8)
            if did_accept:C=line_plans[choice];current=ss[choice].copy();accepted+=1
            after,E=metrics(current)
            row=dict(variant=label,sweep=sweep+1,coordinate=coordinate+1,joint=names[j],accepted=did_accept,
               target_error_before_deg=float(np.rad2deg(target_error)),target_error_after_deg=float(np.rad2deg(E[-1,j])),
               selected_step=scales[choice] if did_accept else None,global_before=current_metrics,global_after=after,
               collateral_error_allowed=True,max_abs_u_change=float(abs(C[:,ids]-base[:,ids]).max()),wall_s=time.monotonic()-start)
            history.append(row);print(json.dumps(row),flush=True)
            # Overall archive does not veto joint-by-joint progress.
            if after['terminal_rmse_deg']<best['terminal_rmse_deg']:
                best=after.copy();bestC=C.copy();bestS=current.copy();save(out/'best_overall_rollout.npz',bestC,bestS,z)
            save(out/'latest_rollout.npz',C,current,z)
            (OUT/'history.json').write_text(json.dumps(history,indent=2))
            if args.stop_on_recovery and after['terminal_rmse_deg']<baseline['terminal_rmse_deg'] and after['path_rmse_deg']<baseline['path_rmse_deg']:
                recovered=True;break
        if recovered:break
    save(out/'best_overall_rollout.npz',bestC,bestS,z);save(out/'final_rollout.npz',C,current,z)
    assert np.array_equal(C[2000:],base[2000:]) and np.array_equal(C[:,np.setdiff1d(np.arange(m.nu),ids)],base[:,np.setdiff1d(np.arange(m.nu),ids)])
    assert abs(C[:,ids]-base[:,ids]).max()<=.050000000001
    final,_=metrics(current);results[label]=dict(baseline=baseline,best_overall=best,final=final,accepted_updates=accepted,early_window_s=[0,.2],max_allowed_absolute_excitation_change=.05,
       late_controls_exactly_unchanged=True,nonmuscle_controls_exactly_unchanged=True,model_unchanged=True,intermediate_global_worsening_allowed=True,
       optimized_objective='Current target joint terminal angle only; subsequent coordinates revisit other joints',height_penalty=False,velocity_penalty=False)
    (OUT/'summary.json').write_text(json.dumps(results,indent=2))
print('DONE',time.monotonic()-start,flush=True)
