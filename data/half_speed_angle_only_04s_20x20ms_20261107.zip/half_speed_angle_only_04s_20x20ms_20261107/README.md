# 半速参考、angle-only、0.4秒、20段×20ms：肌肉轨迹

这份导出来自指定的历史结果，没有重新优化，也没有换成PPO结果。

- `activation_a_10000Hz.csv`：实际肌肉激活状态 a(t)，4001行×130块肌肉，包含0和0.4秒。
- `excitation_u_10000Hz.csv`：优化得到的肌肉激励 u(t)，4000行×130块肌肉，每行在随后0.1ms内保持。a与u不同，重放动力学应输入u而不是把a当作u。
- 两份CSV前两列为仿真时间和原始参考时间，其余130列为有名称的肌肉列。数值采用17位有效数字，无有损舍入。
- `muscle_trajectories.npz`：无损数值版，另含完整141通道控制、初始状态、初始warmstart、完整身体状态和参考关节轨迹。
- `muscle_columns.csv`：列序与模型执行器/激活状态索引的对应关系，以及激活/去激活时间常数。
- `model.xml`、`metadata.json`：当时模型的快照、SHA256与数据定义。XML依赖外部网格资产；本包没有捆绑网格，不能仅靠XML在另一台机器直接运行。
- `original_report.json`、`original_validation.json`、`segment_history.json`：原始效果与分段记录。

历史文件原本每0.2ms保存一次a(t)。此次用原模型、原始u、原始初态及warmstart重放得到每0.1ms的激活，并验证所有原始采样点的完整状态一致；不是插值生成。

```python
import numpy as np
z = np.load('muscle_trajectories.npz')
t, a = z['time_s'], z['activation']             # (4001,), (4001, 130)
tu, u = z['excitation_time_s'], z['excitation'] # (4000,), (4000, 130)
names = z['muscle_ids']
```

参考为q_target(t)=q_original(t/2)，覆盖原始0–0.2秒。拟合只使用关节角目标，没有高度或速度惩罚。完整路径关节误差RMS约10.917°，末端约14.365°；这是有限时长的拟合结果，没有验证持续行走或周期首尾闭环。激活值不是神经元放电记录。
