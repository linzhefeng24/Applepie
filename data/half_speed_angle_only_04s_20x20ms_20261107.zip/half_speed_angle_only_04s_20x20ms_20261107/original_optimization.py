import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,time,importlib.util,numpy as np,mujoco
from mujoco import rollout
from scipy.optimize import lsq_linear
from reference import retime, SPEED, DURATION, SEGMENT
R=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('joint_problem',R.parent/'terminal_priority_20261105/problem.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod);p=mod.JointTrajectory();m=p.m
seed=dict(np.load(R.parent/'uniform_activation_20261105/optimized_rollout.npz'));sources=[seed['all_control_10000Hz'],np.load(R.parent/'sequential_segments_20261106/segment_20ms/rollout_5000Hz.npz')['all_control_10000Hz'],np.load(R.parent/'sequential_segments_20261106/segment_20ms_more/rollout_5000Hz.npz')['all_control_10000Hz']];sources.append(np.load(R.parent/'all_segments_refined_20261106/rollout_5000Hz.npz')['all_control_10000Hz']);sources=[np.repeat(c,2,axis=0) for c in sources];assert all(c.shape==(4000,m.nu) for c in sources);names=p.reference['joint_names'];muscleids=seed['muscle_ids'];sourceq=p.reference['qpos'];sourcev=p.src['qvel'];reference_times=np.arange(2001)*.0002;refq,refv=retime(m,sourceq,sourcev,reference_times);np.savez_compressed(R/'retimed_reference_5000Hz.npz',time_s=reference_times,source_time_s=SPEED*reference_times,qpos=refq,qvel=refv,joint_names=names,joint_qpos_indices=p.qadrs,joint_dof_indices=p.dofs,speed_factor=SPEED);assert np.max(abs(sourcev[0,p.dofs]))==0;initial=seed['initial_state'].copy();planned=sources[-1].copy();d=mujoco.MjData(m);mujoco.mj_setState(m,d,initial,mujoco.mjtState.mjSTATE_FULLPHYSICS);d.qacc_warmstart[:]=seed['initial_warmstart'];data=[mujoco.MjData(m) for _ in range(4)];logs=[];segments=[];saved=[];rng=np.random.default_rng(202611061);tstart=time.monotonic();amin=1.;amax=0.;max_prediction=0.;offset0=1+m.nq+m.nv
for seg in range(20):
 start=seg*200;stop=start+200;state=np.empty(len(initial));mujoco.mj_getState(m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);warm=d.qacc_warmstart.copy();target=refq[stop//2,p.qadrs];past=planned[:start].copy();future=planned[stop:].copy();evals=0
 def runcontrols(C):
  global evals
  C=np.asarray(C);S,_=rollout.rollout(m,data,state[None],C,initial_warmstart=warm[None],persistent_pool=True);assert np.isfinite(S).all() and np.allclose(S[:,-1,0],stop*.0001,atol=1e-9);evals+=len(C);E=S[:,-1,1:1+m.nq][:,p.qadrs]-target;return E,S
 SE,_=runcontrols(np.array([s[start:stop] for s in sources]));seedcost=np.mean(SE**2,axis=1);which=int(np.argmin(seedcost));base=sources[which][start:stop].copy();B=base[:,p.ids];lo=-B.max(axis=0);hi=1-B.min(axis=0);amp=np.zeros(130);e=SE[which].copy();bestamp=amp.copy();beste=e.copy();bestscore=(float(np.mean(e**2)),float(np.max(abs(e))));phase_count=0
 def evaluate(X):
  X=np.atleast_2d(X);C=np.broadcast_to(base,(len(X),*base.shape)).copy();C[:,:,p.ids]=np.clip(B[None]+X[:,None],0,1);return runcontrols(C)[0]
 def remember(X,E):
  global bestamp,beste,bestscore
  for x,ee in zip(np.atleast_2d(X),np.atleast_2d(E)):
   score=(float(np.mean(ee**2)),float(np.max(abs(ee))))
   if score<bestscore:bestscore=score;bestamp=x.copy();beste=ee.copy()
 def log(kind,**kw):
  row=dict(segment=seg+1,kind=kind,wall_s=time.monotonic()-tstart,**kw);logs.append(row);(R/'optimization_history.json').write_text(json.dumps(logs,indent=2));print(json.dumps(row),flush=True)
 def jacobian(ix,h=.02):
  probes=[];meta=[]
  for i in ix:
   hp=min(h,hi[i]-amp[i]);hm=min(h,amp[i]-lo[i]);plus=minus=-1
   if hp>1e-9:
    plus=len(probes);x=amp.copy();x[i]+=hp;probes.append(x)
   if hm>1e-9:
    minus=len(probes);x=amp.copy();x[i]-=hm;probes.append(x)
   meta.append((i,hp,hm,plus,minus))
  J=np.zeros((66,130))
  if not probes:return J
  P=evaluate(probes);remember(probes,P)
  for i,hp,hm,plus,minus in meta:
   if hp+hm>1e-9:J[:,i]=((P[plus] if plus>=0 else e)-(P[minus] if minus>=0 else e))/(hp+hm)
  return J
 def polish(rounds,label):
  global amp,e,phase_count
  stalled=0
  for it in range(rounds):
   if np.max(abs(e))<np.pi/180:break
   J=jacobian(range(130));ix=np.flatnonzero((hi-lo>1e-9)&(np.linalg.norm(J,axis=0)>1e-12));
   if not len(ix):log('no_local_response',phase=label);break
   ridge=max(np.linalg.norm(J[:,ix],'fro')/np.sqrt(len(ix))*.005,1e-8);A=np.vstack([J[:,ix],ridge*np.eye(len(ix))]);bb=np.r_[-e,np.zeros(len(ix))];fit=lsq_linear(A,bb,bounds=(np.maximum(lo[ix]-amp[ix],-.6),np.minimum(hi[ix]-amp[ix],.6)),method='bvls',tol=1e-9,max_iter=200);delta=np.zeros(130);delta[ix]=fit.x;X=np.clip(amp[None]+np.array([1,.5,.2,.05,.01])[:,None]*delta,lo,hi);EE=evaluate(X);remember(X,EE);k=int(np.argmin(np.mean(EE**2,axis=1)));before=float(np.sqrt(np.mean(e**2))*180/np.pi);accepted=bool(np.mean(EE[k]**2)<np.mean(e**2)-1e-13)
   if accepted:amp=X[k].copy();e=EE[k].copy()
   after=float(np.sqrt(np.mean(e**2))*180/np.pi);stalled=stalled+1 if before-after<.0002 else 0;phase_count+=1;log('joint_polish',phase=label,iteration=it+1,accepted=accepted,rmse_before_deg=before,rmse_after_deg=after,best_rmse_deg=float(np.sqrt(bestscore[0])*180/np.pi),worst_joint=str(names[np.argmax(abs(e))]),worst_error_deg=float(np.max(abs(e))*180/np.pi),rollouts=evals)
   if stalled>=3:break
 log('begin',seed_chosen=which,seed_rmse_deg=(np.sqrt(seedcost)*180/np.pi).tolist())
 polish(8,'initial')
 for cycle in range(3):
  # Keep moving through collateral-error states during a sweep; archive global candidates separately.
  queue=list(np.argsort(abs(e))[::-1][:8]);
  if cycle==0:
   priority=int(np.flatnonzero(names=='walker/tibia_T3_right')[0]);queue=[priority]+[j for j in queue if j!=priority]
  for j in queue:
   if abs(e[j])<.5*np.pi/180:continue
   parts=str(names[j]).rsplit('_',2);leg=('L' if parts[-1]=='left' else 'R')+{'T1':'F','T2':'M','T3':'H'}[parts[-2]];ix=np.arange(130) if cycle==2 else np.flatnonzero([str(x).startswith(leg+':') for x in muscleids]);J=jacobian(ix);gradient=J[j];order=ix[np.argsort(abs(gradient[ix]))[::-1]];direction=-np.sign(e[j]*gradient);X=[amp.copy()];labels=['unchanged']
   for subset in [order[:6],order[:12],order]:
    dest=amp.copy();dest[subset]=np.where(direction[subset]>=0,hi[subset],lo[subset])
    for scale in [.05,.2,.5,1.]:X.append(amp+scale*(dest-amp));labels.append('group_to_bound')
   for i in order[:8]:
    for b in [lo[i],hi[i]]:
     x=amp.copy();x[i]=b;X.append(x);labels.append('single_to_bound')
   if np.linalg.norm(gradient[ix])>1e-10:
    ridge=max(np.linalg.norm(gradient[ix])*.005,1e-8);A=np.vstack([gradient[None,ix],ridge*np.eye(len(ix))]);bb=np.r_[-e[j],np.zeros(len(ix))];fit=lsq_linear(A,bb,bounds=(lo[ix]-amp[ix],hi[ix]-amp[ix]),method='bvls',tol=1e-9,max_iter=200);delta=np.zeros(130);delta[ix]=fit.x
    for scale in [1,.5,.1]:X.append(np.clip(amp+scale*delta,lo,hi));labels.append('target_joint_GN')
   X=np.asarray(X);EE=evaluate(X);remember(X,EE);k=int(np.argmin(abs(EE[:,j])));chosen=X[k];ce=EE[k];cross=np.flatnonzero(EE[:,j]*e[j]<0)
   if len(cross):
    dest=X[int(cross[np.argmin(abs(EE[cross,j]))])];l=0.;h=1.
    for _ in range(9):
     f=(l+h)/2;x=amp+f*(dest-amp);ee=evaluate(x)[0];remember(x,ee)
     if abs(ee[j])<abs(ce[j]):chosen=x;ce=ee;k=-1
     if ee[j]*e[j]>0:l=f
     else:h=f
   before=e.copy();a_before=amp.copy();accepted=bool(abs(ce[j])<abs(e[j])-1e-9)
   if accepted:amp=chosen.copy();e=ce.copy()
   log('individual_joint',cycle=cycle+1,joint=str(names[j]),accepted=accepted,error_before_deg=float(before[j]*180/np.pi),error_after_deg=float(e[j]*180/np.pi),rmse_before_deg=float(np.sqrt(np.mean(before**2))*180/np.pi),rmse_after_deg=float(np.sqrt(np.mean(e**2))*180/np.pi),method='bisection' if k==-1 else labels[k],changed_muscles=[dict(id=str(muscleids[i]),before=float(a_before[i]),after=float(amp[i])) for i in np.flatnonzero(abs(a_before-amp)>1e-8)],rollouts=evals)
  polish(4,f'after_coordinate_cycle_{cycle+1}')
  # Alternate the collateral-error branch with the archived joint solution, and test bounded nonlocal directions.
  X=np.clip(bestamp[None]+rng.normal(size=(48,130))*np.repeat([.03,.1,.3],16)[:,None],lo,hi);EE=evaluate(X);remember(X,EE);amp=bestamp.copy();e=beste.copy();log('cycle_complete',cycle=cycle+1,best_rmse_deg=float(np.sqrt(bestscore[0])*180/np.pi),best_max_error_deg=float(np.max(abs(beste))*180/np.pi),rollouts=evals)
  if np.max(abs(e))<np.pi/180:break
 amp=bestamp.copy();e=beste.copy();predicted=evaluate(amp)[0];selected=base.copy();selected[:,p.ids]=np.clip(B+amp[None],0,1);planned[start:stop]=selected;assert np.array_equal(planned[:start],past) and np.array_equal(planned[stop:],future)
 for k in range(200):
  d.ctrl[:]=selected[k];mujoco.mj_step(m,d);amin=min(amin,float(d.act[p.adrs].min()));amax=max(amax,float(d.act[p.adrs].max()));assert not np.any(d.qfrc_applied) and not np.any(d.xfrc_applied)
  if k%2:
   ss=np.empty(len(initial));mujoco.mj_getState(m,d,ss,mujoco.mjtState.mjSTATE_FULLPHYSICS);saved.append(ss)
 actual=d.qpos[p.qadrs]-target;error=float(np.max(abs(actual-predicted)));assert error<1e-9;max_prediction=max(max_prediction,error);order=np.argsort(abs(actual))[::-1];row=dict(segment=seg+1,time_s=stop*.0001,source_reference_time_s=SPEED*stop*.0001,initial_best_seed_rmse_deg=float(np.sqrt(seedcost.min())*180/np.pi),endpoint_rmse_deg=float(np.sqrt(np.mean(actual**2))*180/np.pi),max_endpoint_error_deg=float(np.max(abs(actual))*180/np.pi),worst_joints=[dict(joint=str(names[i]),error_deg=float(actual[i]*180/np.pi),angle_deg=float(d.qpos[p.qadrs[i]]*180/np.pi),target_deg=float(target[i]*180/np.pi)) for i in order[:5]],endpoint_velocity_rmse_rad_s=float(np.sqrt(np.mean((d.qvel[p.dofs]-refv[stop//2,p.dofs])**2))),prediction_execution_error_rad=error,past_and_future_controls_unchanged=True,command_samples_at_bounds_fraction=float(np.mean((selected[:,p.ids]<1e-8)|(selected[:,p.ids]>1-1e-8))),rollouts=evals,polish_rounds=phase_count,wall_s=time.monotonic()-tstart);segments.append(row);(R/'segment_history.json').write_text(json.dumps(segments,indent=2));np.savez_compressed(R/'checkpoint.npz',full_state=np.asarray(saved),all_control_10000Hz=planned,initial_state=initial,initial_warmstart=seed['initial_warmstart']);log('segment_complete',**{k:v for k,v in row.items() if k not in ['segment','wall_s']})
ss=np.asarray(saved);q=ss[:,1:1+m.nq];v=ss[:,1+m.nq:offset0];times=ss[:,0];targets=refq[np.rint(times/.0002).astype(int)][:,p.qadrs];err=q[:,p.qadrs]-targets
np.savez_compressed(R/'rollout_5000Hz.npz',time_s=times,full_state=ss,qpos=q,qvel=v,activation=ss[:,offset0:][:,p.adrs],excitation=planned[1::2][:,p.ids],all_control_10000Hz=planned,initial_state=initial,initial_warmstart=seed['initial_warmstart'],joint_angle_rad=q[:,p.qadrs],target_joint_angle=targets,qerror_rad=err,joint_velocity_rad_s=v[:,p.dofs],target_joint_velocity_rad_s=refv[np.rint(times/.0002).astype(int)][:,p.dofs],velocity_error_rad_s=v[:,p.dofs]-refv[np.rint(times/.0002).astype(int)][:,p.dofs],source_reference_time_s=SPEED*times,muscle_ids=muscleids,joint_names=names)
assert 0<=amin<=amax<=1
report=dict(method='twenty half-speed-reference sequential fixed-prefix intervals; cyclic target-joint corrections allowing collateral error; bounded simultaneous polishing and nonlinear nonlocal trials; archived best endpoint aggregate error executed',duration_s=DURATION,original_reference_duration_s=.2,reference_speed_factor=SPEED,reference_definition='q_target(t)=q_original(t/2); qvel_target(t)=0.5*qvel_original(t/2)',seed_controls_time_stretched=True,retained_controls_time_stretched=True,segment_duration_s=SEGMENT,segments_completed=20,terminal_rmse_deg=float(np.sqrt(np.mean(err[-1]**2))*180/np.pi),path_rmse_deg=float(np.sqrt(np.mean(err**2))*180/np.pi),max_terminal_error_deg=float(np.max(abs(err[-1]))*180/np.pi),activation_min=amin,activation_max=amax,max_prediction_execution_error_rad=max_prediction,height_penalty=0,velocity_penalty=0,model_parameters_changed=False,initial_state_changed=False,only_current_segment_controls_modified=True,intermediate_state_resets=False,extra_forces=False,all_segment_max_errors_below_1deg=all(x['max_endpoint_error_deg']<1 for x in segments),walking_validated=False,wall_s=time.monotonic()-tstart,limitations=['Local finite search, not a certificate of global optimality.','Fixed uniform muscle offsets within each selected seed segment; no arbitrary within-segment time knots.','All states propagate; small endpoint angle error alone does not ensure matched velocity or subsequent stability.'])
(R/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
