"""Lossless export of the selected historical result; no optimization."""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import csv,json,hashlib,shutil,zipfile
import numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent
OUT=Path('/workspace/exports/half_speed_angle_only_04s_20x20ms_20261107')
OUT.mkdir(parents=True,exist_ok=True)
MODEL=R.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'
z=np.load(R/'rollout_5000Hz.npz');ref=np.load(R/'retimed_reference_5000Hz.npz')
report=json.loads((R/'report.json').read_text())
assert hashlib.sha256(MODEL.read_bytes()).hexdigest()==report['model_sha256']
records=json.loads((R.parent/'six_leg_model/activation_refine_20261104/records.json').read_text())['records']
ids=np.array([r['actuator_index'] for r in records],dtype=int)
assert [r['id'] for r in records]==z['muscle_ids'].tolist()
m=mujoco.MjModel.from_xml_path(str(MODEL));adrs=m.actuator_actadr[ids]
assert len(ids)==130 and np.all(m.actuator_dyntype[ids]==int(mujoco.mjtDyn.mjDYN_MUSCLE))
C=z['all_control_10000Hz'].copy();initial=z['initial_state'].copy();warm=z['initial_warmstart'].copy()
assert C.shape==(4000,141) and m.opt.timestep==.0001
S,_=rollout.rollout(m,mujoco.MjData(m),initial[None],C[None],initial_warmstart=warm[None])
S=S[0];replay_error=float(abs(S[1::2]-z['full_state']).max())
assert replay_error<1e-9,replay_error
off=1+m.nq+m.nv
states=np.vstack([initial,S]);A=states[:,off:][:,adrs];U=C[:,ids]
assert np.array_equal(A[2::2],z['activation'])
assert np.array_equal(U[1::2],z['excitation'])
assert np.isfinite(A).all() and np.isfinite(U).all()
assert A.min()>=0 and A.max()<=1 and U.min()>=0 and U.max()<=1
t=np.arange(4001)*.0001;tu=np.arange(4000)*.0001
assert abs(states[:,0]-t).max()<1e-10
np.savez_compressed(OUT/'muscle_trajectories.npz',time_s=t,source_reference_time_s=.5*t,
 activation=A,excitation_time_s=tu,excitation=U,all_controls=C,
 muscle_ids=z['muscle_ids'],actuator_indices=ids,activation_indices=adrs,
 actuator_names=np.array([mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_ACTUATOR,int(i)) for i in ids]),
 all_actuator_names=np.array([mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_ACTUATOR,i) for i in range(m.nu)]),
 full_state=states,initial_state=initial,initial_warmstart=warm,
 joint_qpos_indices=ref['joint_qpos_indices'],joint_dof_indices=ref['joint_dof_indices'],joint_names=z['joint_names'],
 reference_time_s=ref['time_s'],reference_qpos=ref['qpos'],reference_qvel=ref['qvel'],
 original_recorded_time_s=z['time_s'],original_recorded_activation=z['activation'],
 physics_dt_s=np.array(.0001),reference_speed_factor=np.array(.5))
def save_csv(path,times,values):
    with path.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['time_s','source_reference_time_s',*z['muscle_ids'].tolist()])
        for ti,row in zip(times,values):w.writerow([format(ti,'.17g'),format(.5*ti,'.17g'),*[format(float(v),'.17g') for v in row]])
save_csv(OUT/'activation_a_10000Hz.csv',t,A)
save_csv(OUT/'excitation_u_10000Hz.csv',tu,U)
with (OUT/'muscle_columns.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['muscle_column_0based','csv_column_1based','muscle_id','actuator_name','actuator_index_0based','activation_index_0based','tau_activation_s','tau_deactivation_s'])
    for i,k in enumerate(ids):w.writerow([i,i+3,str(z['muscle_ids'][i]),mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_ACTUATOR,int(k)),int(k),int(adrs[i]),*m.actuator_dynprm[k,:2]])
metadata=dict(selected_result='Half-speed reference, angle-only, 0.4 s, twenty sequential 20 ms segments',
 source_directory=str(R),source_rollout_sha256=hashlib.sha256((R/'rollout_5000Hz.npz').read_bytes()).hexdigest(),
 model_sha256=report['model_sha256'],reference_speed_factor=.5,physical_duration_s=.4,
 original_reference_interval_s=[0,.2],segments=20,segment_duration_s=.02,muscles=130,
 physics_frequency_Hz=10000,activation_shape=list(A.shape),excitation_shape=list(U.shape),
 activation_bounds=[float(A.min()),float(A.max())],excitation_bounds=[float(U.min()),float(U.max())],
 activation_semantics='a(t) is the actual native MuJoCo muscle activation state, sampled at time_s, including t=0 and t=0.4.',
 excitation_semantics='u[k] is the original optimized command held over [excitation_time_s[k], excitation_time_s[k]+0.0001). No command is defined at the endpoint t=0.4.',
 sampling_provenance='Historical stored activations at 5000 Hz preserved exactly. Additional 10000 Hz states obtained by replaying original controls, model, initial state and warmstart, without optimization or interpolation.',
 replay_max_full_state_error_at_original_samples=replay_error,
 no_reoptimization=True,model_parameters_changed=False,intermediate_state_resets=False,
 muscle_activation_is_not_neuron_spikes=True,walking_validated=False,periodic_validated=False,
 full_state_layout=dict(time=[0,1],qpos=[1,1+m.nq],qvel=[1+m.nq,off],activation=[off,off+m.na]),
 retained_nonmuscle_actuators=m.nu-len(ids),model_mesh_dependencies='Model XML retains existing absolute mesh paths under /workspace/fly-walking-run/output/model; external mesh assets are not bundled.',
 library_versions=dict(mujoco=mujoco.__version__,numpy=np.__version__),original_result_report=report)
(OUT/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
for src,name in [(MODEL,'model.xml'),(R/'report.json','original_report.json'),(R/'validation.json','original_validation.json'),(R/'segment_history.json','segment_history.json'),(R/'run.py','original_optimization.py'),(R/'reference.py','original_reference.py')]:shutil.copy2(src,OUT/name)
shutil.copy2(Path(__file__),OUT/'export_trajectories.py')
(OUT/'README.md').write_text('''# 半速参考、angle-only、0.4秒、20段×20ms：肌肉轨迹

这份导出来自指定的历史结果，没有重新优化，也没有换成PPO结果。

- `activation_a_10000Hz.csv`：实际肌肉激活状态 a(t)，4001行×130块肌肉，包含0和0.4秒。
- `excitation_u_10000Hz.csv`：优化得到的肌肉激励 u(t)，4000行×130块肌肉，每行在随后0.1ms内保持。a与u不同，重放动力学应输入u而不是把a当作u。
- 两份CSV前两列为仿真时间和原始参考时间，其余130列为有名称的肌肉列。数值采用17位有效数字，无有损舍入。
- `muscle_trajectories.npz`：无损数值版，另含完整141通道控制、初始状态、初始warmstart、完整身体状态和参考关节轨迹。
- `muscle_columns.csv`：列序与模型执行器/激活状态索引的对应关系，以及激活/去激活时间常数。
- `model.xml`、`metadata.json`：当时模型的快照、SHA256与数据定义。XML依赖外部网格资产；本包没有捆绑网格，不能仅靠XML在另一台机器直接运行。
- `original_report.json`、`original_validation.json`、`segment_history.json`：原始效果与分段记录。

历史文件原本每0.2ms保存一次a(t)。此次用原模型、原始u、原始初态及warmstart重放得到每0.1ms的激活，并验证所有原始采样点的完整状态一致；不是插值生成。

```python
import numpy as np
z = np.load('muscle_trajectories.npz')
t, a = z['time_s'], z['activation']             # (4001,), (4001, 130)
tu, u = z['excitation_time_s'], z['excitation'] # (4000,), (4000, 130)
names = z['muscle_ids']
```

参考为q_target(t)=q_original(t/2)，覆盖原始0–0.2秒。拟合只使用关节角目标，没有高度或速度惩罚。完整路径关节误差RMS约10.917°，末端约14.365°；这是有限时长的拟合结果，没有验证持续行走或周期首尾闭环。激活值不是神经元放电记录。
''',encoding='utf-8')
# CSV roundtrip and boundary checks.
assert np.array_equal(np.loadtxt(OUT/'activation_a_10000Hz.csv',delimiter=',',skiprows=1)[:,2:],A)
assert np.array_equal(np.loadtxt(OUT/'excitation_u_10000Hz.csv',delimiter=',',skiprows=1)[:,2:],U)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='SHA256SUMS'}
(OUT/'SHA256SUMS').write_text(''.join(f'{h}  {name}\n' for name,h in hashes.items()))
archive=OUT.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as f:
    for p in sorted(OUT.iterdir()):f.write(p,arcname=OUT.name+'/'+p.name)
with zipfile.ZipFile(archive) as f:assert f.testzip() is None
print(json.dumps(dict(directory=str(OUT),archive=str(archive),archive_bytes=archive.stat().st_size,replay_error=replay_error,activation_shape=A.shape,excitation_shape=U.shape),indent=2))
