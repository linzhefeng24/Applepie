import numpy as np,mujoco
SPEED=.5
DURATION=.4
SEGMENT=.02
SOURCE_DT=.0002

def retime(m,qpos,qvel,physical_times,speed=SPEED):
 times=np.asarray(physical_times,dtype=float);f=times*speed/SOURCE_DT;lo=np.floor(f+1e-10).astype(int);alpha=f-lo;alpha[np.abs(alpha)<1e-9]=0.;assert np.all(lo>=0) and np.all(lo+1<len(qpos));outq=qpos[lo].copy();outv=speed*((1-alpha[:,None])*qvel[lo]+alpha[:,None]*qvel[lo+1]);velocity=np.empty(m.nv)
 for i in np.flatnonzero(alpha>1e-9):
  mujoco.mj_differentiatePos(m,velocity,SOURCE_DT,qpos[lo[i]],qpos[lo[i]+1]);mujoco.mj_integratePos(m,outq[i],velocity,float(alpha[i]*SOURCE_DT))
 return outq,outv
