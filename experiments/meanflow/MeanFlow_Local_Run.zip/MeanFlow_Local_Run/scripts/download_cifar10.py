"""Download the official archive with checked byte ranges; verify torchvision MD5.

Standard torchvision download remains supported. This optional downloader is for
servers that throttle each connection. Uses inherited HTTPS proxy/CA, no bypass.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
from pathlib import Path
import time
import urllib.request

URL='https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz'
SIZE=170498071
MD5='c58f30108f718f92721af3b95e74349a'


def checksum(path):
    h=hashlib.md5()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('--root',default='data')
    p.add_argument('--workers',type=int,default=8);args=p.parse_args()
    if not 1<=args.workers<=16:raise ValueError('workers must be between 1 and 16')
    root=Path(args.root);root.mkdir(parents=True,exist_ok=True)
    target=root/'cifar-10-python.tar.gz'
    if target.exists() and checksum(target)==MD5:
        print('Existing archive verified.',flush=True)
    else:
        parts=root/'.cifar10-checked-parts';parts.mkdir(exist_ok=True)
        # Cached parts are accepted only for a fixed known byte range; whole
        # archive MD5 is always checked before extraction or use.
        chunk=8*1024*1024
        ranges=[(start,min(start+chunk,SIZE)-1) for start in range(0,SIZE,chunk)]
        def fetch(item):
            start,end=item;dest=parts/f'{start}-{end}'
            if dest.exists() and dest.stat().st_size==end-start+1:return dest
            for attempt in range(3):
                try:
                    req=urllib.request.Request(URL,headers={'Range':f'bytes={start}-{end}'})
                    with urllib.request.urlopen(req,timeout=60) as response:
                        expected=f'bytes {start}-{end}/{SIZE}'
                        if response.status!=206 or response.headers.get('Content-Range')!=expected:
                            raise RuntimeError('Server did not honor exact range')
                        tmp=dest.with_suffix('.tmp')
                        with tmp.open('wb') as f:
                            while True:
                                data=response.read(256*1024)
                                if not data:break
                                f.write(data)
                    if tmp.stat().st_size!=end-start+1:raise RuntimeError('Incomplete range')
                    tmp.replace(dest);print(f'Completed bytes {start}-{end}',flush=True);return dest
                except Exception:
                    if attempt==2:raise
                    time.sleep(attempt+1)
        with ThreadPoolExecutor(max_workers=args.workers) as pool:paths=list(pool.map(fetch,ranges))
        tmp=target.with_suffix('.assembled')
        with tmp.open('wb') as f:
            for path in paths:
                with path.open('rb') as piece:
                    for block in iter(lambda:piece.read(1024*1024),b''):f.write(block)
        if tmp.stat().st_size!=SIZE or checksum(tmp)!=MD5:
            tmp.unlink(missing_ok=True)
            raise RuntimeError('Archive verification failed; do not use downloaded parts')
        tmp.replace(target);print('Official CIFAR archive checksum verified.',flush=True)
    from torchvision.datasets.utils import extract_archive
    extract_archive(str(target),str(root))
    from torchvision.datasets import CIFAR10
    dataset=CIFAR10(str(root),train=True,download=False)
    print(f'Verified {len(dataset)} real training examples.',flush=True)


if __name__=='__main__':main()
