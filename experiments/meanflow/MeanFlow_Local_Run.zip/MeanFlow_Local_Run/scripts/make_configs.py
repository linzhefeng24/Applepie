"""Generate independent, explicit experiment configs; never launch training."""
from pathlib import Path
import copy
import yaml

root=Path(__file__).resolve().parents[1]
base=yaml.safe_load((root/'configs/cifar10_baseline.yaml').read_text())
for mode in ['generalized','scaled_generalized','reweighted']:
    for name,a1,a2 in [('positive',.5,-1.),('negative',-.5,1.),('two_parameter',.3,0.)]:
        cfg=copy.deepcopy(base);cfg.update(mode=mode,a1=a1,a2=a2)
        (root/f'configs/cifar10_{mode}_{name}.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False))
for mode in ['baseline','scaled_generalized','reweighted']:
    cfg=copy.deepcopy(base);cfg.update(mode=mode,norm_p=0.,a1=0. if mode=='baseline' else .5,a2=0. if mode=='baseline' else -1.)
    (root/f'configs/cifar10_squared_{mode}.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False))
cfg=copy.deepcopy(base);cfg.update(mode='generalized',a1=0.,a2=0.)
(root/'configs/cifar10_fitted.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False))
print('Generated candidate, exact-control, squared-loss and fitted configs.')
