"""Cross-platform setup: python scripts/setup_local.py --backend cpu|cu126|cu128."""
import argparse
from pathlib import Path
import subprocess
import sys
import venv

p=argparse.ArgumentParser()
p.add_argument('--backend',required=True,choices=['cpu','cu126','cu128'])
args=p.parse_args()
if not (3,10)<=sys.version_info[:2]<=(3,12):
    raise SystemExit('Use Python 3.10–3.12; validation was performed with Python 3.12.')
root=Path(__file__).resolve().parents[1]
python=root/'.venv'/('Scripts/python.exe' if sys.platform=='win32' else 'bin/python')
if not python.is_file():venv.EnvBuilder(with_pip=True).create(root/'.venv')
def run(*cmd):subprocess.run([str(python),'-m','pip',*cmd],check=True)
run('install','torch==2.7.1','torchvision==0.22.1','--index-url',f'https://download.pytorch.org/whl/{args.backend}')
run('install','-r',str(root/'requirements.txt'))
subprocess.run([str(python),'-c',
    "import torch; print('torch:',torch.__version__); print('CUDA available:',torch.cuda.is_available()); print('GPU:',torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'none')"],check=True)
print('Run from',root)
print('Python executable:',python)
print('First check: <python executable> -m pytest -q')
