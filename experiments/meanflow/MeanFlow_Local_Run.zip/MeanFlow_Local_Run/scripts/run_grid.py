"""Plan a reproducible grid. Training runs only with --execute."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--steps',type=int,required=True)
p.add_argument('--seeds',default='0,1,2');p.add_argument('--device',default='cuda')
p.add_argument('--out',default='runs/grid');p.add_argument('--execute',action='store_true')
p.add_argument('--configs',nargs='+',default=['cifar10_baseline','cifar10_generalized_positive',
    'cifar10_generalized_negative','cifar10_generalized_two_parameter',
    'cifar10_scaled_generalized_positive','cifar10_reweighted_positive'])
args=p.parse_args()
if args.steps<1:raise ValueError('steps must be positive')
seeds=[int(s) for s in args.seeds.split(',')]
out=Path(args.out);out.mkdir(parents=True,exist_ok=True);jobs=[]
for name in args.configs:
    config=root/'configs'/f'{name}.yaml'
    if not config.is_file():raise FileNotFoundError(config)
    for seed in seeds:
        cmd=[sys.executable,'-m','mfexp.train','--config',str(config),'--seed',str(seed),
             '--steps',str(args.steps),'--device',args.device,'--out',str(out/f'{name}_seed{seed}')]
        jobs.append(cmd)
(out/'plan.json').write_text(json.dumps({'requested_steps':args.steps,'jobs':jobs,
    'executed':args.execute,'paper_budget':args.steps==800000},indent=2)+'\n')
for cmd in jobs:
    print(' '.join(cmd),flush=True)
    if args.execute:subprocess.run(cmd,cwd=root,check=True)
