"""Collect measured run outcomes without inventing missing FID values."""
import argparse
import csv
import json
from pathlib import Path
import statistics

p=argparse.ArgumentParser();p.add_argument('--root',default='runs');p.add_argument('--out',default='runs/summary.csv')
args=p.parse_args();rows=[]
for metadata in sorted(Path(args.root).rglob('metadata.json')):
    run=metadata.parent;meta=json.loads(metadata.read_text());cfg=meta['config']
    logs=[json.loads(s) for s in (run/'train.jsonl').read_text().splitlines()] if (run/'train.jsonl').exists() else []
    evals=list(run.rglob('evaluation.json'));evaluation=json.loads(evals[-1].read_text()) if evals else {}
    rows.append({'run':str(run),'data':cfg['data'],'model':cfg['model'],'mode':cfg['mode'],
        'a1':cfg['a1'],'a2':cfg['a2'],'seed':cfg['seed'],'device':meta['device'],
        'optimizer_steps':logs[-1]['step'] if logs else 0,
        'mean_step_seconds':statistics.mean(r['seconds'] for r in logs) if logs else '',
        'last_loss':logs[-1]['loss'] if logs else '',
        'fid':evaluation.get('fid'),'fid_samples':evaluation.get('samples'),
        'full_fid_50k':evaluation.get('full_fid_50k',False),'parameters':meta['parameters']})
out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
with out.open('w',newline='') as f:
    if rows:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print(f'Collected {len(rows)} measured runs into {out}; blank FID means not evaluated.')
