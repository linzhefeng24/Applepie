# 本地运行：MeanFlow 归一化对照实验

这个包只包含实验代码、配置、测试与固定版本官方 PyTorch 源码；不含数据集、虚拟环境、训练检查点或 JAX 仓库。先将 ZIP 完整解压，再在 `MeanFlow_Local_Run` 目录打开终端。

推荐 Python 3.12。CPU 足够检查程序；正式 CIFAR-10 U-Net 训练需要合适的 GPU。以下命令中的 `python` 指安装的 Python 3.12；Windows 可用 `py -3.12` 替代。

## 1. 安装

只有 CPU 或先测试程序：

```bash
python scripts/setup_local.py --backend cpu
```

NVIDIA GPU：根据驱动支持选择官方 CUDA wheel，例如：

```bash
python scripts/setup_local.py --backend cu126
```

支持 CUDA 12.8 的机器可用 `--backend cu128`，包括需要新架构支持的显卡。安装脚本不安装或更新 NVIDIA 驱动。必须确认安装完成后输出 `CUDA available: True`，不能把 CPU wheel 当作 GPU 环境。

激活环境（只需选择对应系统的一行）：

```powershell
# Windows PowerShell
.\.venv\Scripts\Activate.ps1
```

```bash
# Linux / macOS
source .venv/bin/activate
```

如果 PowerShell 不允许激活，无需修改系统执行策略，可以把后续命令中的 `python` 替换为 `.\.venv\Scripts\python.exe`。Linux/macOS 可替换为 `.venv/bin/python`。

Mac 的完整训练性能/兼容性未验证；本包没有实现 MPS 专用路径，先使用 CPU smoke check。

## 2. 先确认代码能跑

```bash
python -m pytest -q
python -m mfexp.train --config configs/smoke.yaml --out runs/local_smoke --device cpu
python -m mfexp.diagnose --checkpoint runs/local_smoke/checkpoint.pt --out runs/local_fit --examples 12 --device cpu
```

这些使用小网络与合成图片，只验证流程，不代表训练质量。相同输出目录不会被悄悄覆盖；重复测试请换一个 `--out`。

## 3. 下载 CIFAR-10

```bash
python -c "from torchvision.datasets import CIFAR10; CIFAR10('data', train=True, download=True)"
```

官方服务器单连接较慢时，可以使用同来源的分块下载；始终校验官方归档 checksum：

```bash
python scripts/download_cifar10.py --root data --workers 4
```

配置中的 `data_root: data` 是相对于当前项目工作目录的路径。如已下载到别处，可以修改配置。启动训练前请 `cd` 到本包根目录。

## 4. 训练对照实验

首先检查 `configs/cifar10_baseline.yaml`：默认是 800K optimizer steps、有效 batch 1024，通过 microbatch 32 累积实现。正式训练成本很大；先用少量步数筛查是否有显存或数据问题。

```bash
# 原始 MeanFlow：f(h)=h
python -m mfexp.train --config configs/cifar10_baseline.yaml --out runs/baseline_s0 --device cuda --steps 1000

# 两参数候选：a1=0.3, a2=0
python -m mfexp.train --config configs/cifar10_generalized_two_parameter.yaml --out runs/generalized_s0 --device cuda --steps 1000
```

以上 1000 步仅为筛选，不是论文完整训练。省略 `--steps` 才使用 YAML 的 800K 步预算。

显存不够时，在各配置中同样减小 `microbatch_size`，保持有效 `batch_size` 一致。这个运行器是单进程梯度累积，不是多 GPU DDP；多卡不会自动加速。

其他组别：

- `cifar10_generalized_positive.yaml`：a1=0.5，a2=−1。
- `cifar10_generalized_negative.yaml`：a1=−0.5，a2=1。
- `cifar10_scaled_generalized_*.yaml`：显式缩放同一个物理位移模型。
- `cifar10_reweighted_*.yaml`：匹配上述缩放模型的半梯度。
- `cifar10_squared_*.yaml`：不带自适应残差权重的机制消融。

四个模式的关系见 `EXPERIMENT_DETAILS.md`。梯度匹配对照的 loss 数值不要求相同。

## 5. 用检查点拟合 a1、a2

```bash
python -m mfexp.diagnose --checkpoint runs/baseline_s0/checkpoint.pt --out runs/fit_s0 --examples 128 --device cuda
```

前半样本拟合、后半留出检验。输出 `coefficients.json`、`report.json` 和逐样本梯度统计。诊断会对 JVP 继续反向传播，比普通训练更费显存；它逐样本计算，避免把 batch 梯度当作逐样本梯度。

用冻结的系数另起训练：

```bash
python -m mfexp.train --config configs/cifar10_fitted.yaml --coefficients runs/fit_s0/coefficients.json --out runs/fitted_s0 --device cuda --steps 1000
```

## 6. 生成样本 / FID

```bash
# 查看少量图片，不计算 FID
python -m mfexp.evaluate --checkpoint runs/baseline_s0/checkpoint.pt --out runs/baseline_s0/samples --samples 64 --device cuda

# 正式 FID-50K
python -m mfexp.evaluate --checkpoint runs/baseline_s0/checkpoint.pt --out runs/baseline_s0/fid --samples 50000 --device cuda --fid
```

FID 首次需要下载 Inception 权重。未请求 FID 的输出明确记为 `fid:null`。EMA 在第 16 步首次更新，极短 smoke run 请加 `--raw`，不要使用未更新的 EMA。

## 当前已验证的范围

Linux + Python 3.12 + CPU PyTorch 2.7.1：24 项测试、官方约 55.9M U-Net 在真实 CIFAR-10 的训练步与逐样本梯度诊断通过。未完成完整训练或 FID-50K。Windows/CUDA/Mac 的完整运行尚未实测，不声称已有性能提升。
