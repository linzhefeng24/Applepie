import pytest
import torch
from mfexp.normalization import Normalization


@pytest.mark.parametrize('a1,a2',[(0,0),(.5,-1),(-.5,1),(.3,0)])
def test_derivatives_and_diagonal(a1,a2):
    norm=Normalization(a1,a2)
    h=torch.tensor([0.,1e-8,.2,.9,1.],dtype=torch.float64,requires_grad=True)
    fp=torch.autograd.grad(norm.f(h).sum(),h)[0]
    torch.testing.assert_close(fp,norm.fp(h))
    assert norm.f(h)[0]==0 and norm.scale(h)[0]==1 and norm.fp(h)[0]==1
    torch.testing.assert_close(h*norm.fp(h),norm.f(h)*norm.q(h))


@pytest.mark.parametrize('a1,a2',[(-4,4),(0,-2),(-2,0)])
def test_reject_interior_or_endpoint_zeros(a1,a2):
    with pytest.raises(ValueError):Normalization(a1,a2)


def test_analytic_trajectory_identity():
    norm=Normalization(.3,-.4)
    t=torch.tensor([.1,.4,.9],dtype=torch.float64,requires_grad=True)
    r=torch.tensor([.02,.2,.5],dtype=torch.float64)
    h=t-r;S=t*t-r*r;w=S/norm.f(h)
    dw=torch.autograd.grad(w.sum(),t)[0]
    torch.testing.assert_close(norm.fp(h)*w+norm.f(h)*dw,2*t)
