import copy
from types import SimpleNamespace
import pytest
import torch
from mfexp.models import TinyNet,build_model
from mfexp.normalization import Normalization
from mfexp.objective import interval_objective,sample_one_step
from mfexp.upstream import activate

torch.set_num_threads(2)


def batch():
    torch.manual_seed(4)
    return torch.randn(3,3,4,4,dtype=torch.float64),torch.randn(3,3,4,4,dtype=torch.float64),\
        torch.tensor([.1,.6,.95],dtype=torch.float64),torch.tensor([.1,.2,.01],dtype=torch.float64)


def grads(net,loss):return torch.autograd.grad(loss,tuple(net.parameters()))


@pytest.mark.parametrize('p',[0.,.75])
def test_baseline_matches_actual_official_loss_and_gradients(monkeypatch,p):
    activate();import models.meanflow as official
    x,e,t,r=batch()
    args=SimpleNamespace(ema_decay=.9999,ema_decays=[],norm_eps=.001,norm_p=p)
    reference=official.MeanFlow(TinyNet,args,{}) .double()
    net=copy.deepcopy(reference.net)
    monkeypatch.setattr(official,'sample_two_timesteps',lambda *a,**kw:(t,r))
    monkeypatch.setattr(torch,'randn_like',lambda *a,**kw:e)
    expected=reference.forward_with_loss(x,None)
    actual,_=interval_objective(net,x,e,t,r,mode='baseline',norm_p=p,norm_eps=.001)
    torch.testing.assert_close(actual,expected)
    for ga,gb in zip(grads(net,actual),grads(reference.net,expected)):
        torch.testing.assert_close(ga,gb,rtol=1e-9,atol=1e-10)


@pytest.mark.parametrize('p',[0.,.75])
@pytest.mark.parametrize('a1,a2',[(.5,-1),(-.5,1),(.3,0)])
def test_scaled_representation_and_reweighted_control_have_identical_gradients(p,a1,a2):
    x,e,t,r=batch();norm=Normalization(a1,a2)
    first=TinyNet().double();second=copy.deepcopy(first)
    loss1,_=interval_objective(first,x,e,t,r,norm,'scaled_generalized',p,.001)
    loss2,_=interval_objective(second,x,e,t,r,norm,'reweighted',p,.001)
    for ga,gb in zip(grads(first,loss1),grads(second,loss2)):
        torch.testing.assert_close(ga,gb,rtol=1e-8,atol=1e-10)


def test_zero_coefficients_are_baseline_even_on_diagonal():
    x,e,t,r=batch();net=TinyNet().double()
    l1,_=interval_objective(net,x,e,t,r,mode='baseline')
    l2,_=interval_objective(net,x,e,t,r,mode='generalized')
    torch.testing.assert_close(l1,l2)


def test_full_gradient_is_distinct_from_stopped_target():
    x,e,t,r=batch();net=TinyNet().double()
    l1,_=interval_objective(net,x,e,t,r,Normalization(.3,0),'generalized',norm_p=0,stop_target=True)
    l2,_=interval_objective(net,x,e,t,r,Normalization(.3,0),'generalized',norm_p=0,stop_target=False)
    torch.testing.assert_close(l1,l2)
    gs=grads(net,l1);gf=grads(net,l2)
    assert sum((a-b).square().sum().item() for a,b in zip(gs,gf))>1e-8


def test_generalized_sampling_uses_f1_not_just_raw_output():
    net=TinyNet().double();noise=torch.randn(2,3,4,4,dtype=torch.float64);norm=Normalization(.3,0)
    t=torch.ones(2,dtype=torch.float64)
    expected=noise-norm.f1*net(noise,(t,t))
    torch.testing.assert_close(sample_one_step(net,noise,norm,'generalized'),expected)


def test_official_unet_jvp_and_backward():
    net=build_model('official_tiny',dropout=.2,edm_aug=False).train()
    torch.manual_seed(0)
    x=torch.randn(1,3,32,32);e=torch.randn_like(x);t=torch.tensor([.7]);r=torch.tensor([.2])
    loss,_=interval_objective(net,x,e,t,r,Normalization(.3,0),'generalized',norm_p=.75)
    loss.backward()
    assert torch.isfinite(loss)
    assert all(torch.isfinite(p.grad).all() for p in net.parameters() if p.grad is not None)
