import copy
import pytest
import torch
from mfexp.models import TinyNet,build_model
from mfexp.normalization import Normalization,expand_time
from mfexp.objective import interval_objective
from mfexp.diagnostics import per_example_statistics,relative_error,fit_polynomial


def test_per_example_relative_formula_matches_direct_generalized_gradients():
    torch.manual_seed(7);net=TinyNet().double()
    x=torch.randn(2,3,4,4,dtype=torch.float64);e=torch.randn_like(x)
    t=torch.tensor([.7,.3],dtype=torch.float64);r=torch.tensor([.1,.3],dtype=torch.float64)
    rows=per_example_statistics(net,x,e,t,r)
    norm=Normalization(.3,.1)
    for i in range(2):
        ls,_=interval_objective(net,x[i:i+1],e[i:i+1],t[i:i+1],r[i:i+1],norm,
                              'scaled_generalized',norm_p=0,stop_target=True)
        lf,_=interval_objective(net,x[i:i+1],e[i:i+1],t[i:i+1],r[i:i+1],norm,
                              'scaled_generalized',norm_p=0,stop_target=False)
        gs=torch.autograd.grad(ls,tuple(net.parameters()));gf=torch.autograd.grad(lf,tuple(net.parameters()))
        direct=sum((a-b).square().sum() for a,b in zip(gf,gs))/sum(a.square().sum() for a in gf)
        predicted=relative_error([rows[i]],norm.a1,norm.a2)
        assert direct.item()==pytest.approx(predicted,abs=1e-9)
    assert net.training  # diagnostics restored the caller's mode


def test_fit_recovers_known_two_parameter_update_scaling():
    rows=[]
    a1,a2=.4,-.3
    for h in torch.linspace(.05,1,60).tolist():
        q=1+a1*h+a2*h*h
        rows.append({'h':h,'usable':True,'full_grad_norm_sq':q*q,
                     'sg_grad_norm_sq':1.,'full_dot_sg':q})
    fit=fit_polynomial(rows[::2]);hold=rows[1::2]
    assert fit['a1']==pytest.approx(a1,abs=1e-4)
    assert fit['a2']==pytest.approx(a2,abs=1e-4)
    assert relative_error(hold,fit['a1'],fit['a2'])<1e-9
    assert relative_error(hold)>1e-4


def test_zero_full_gradient_is_not_silently_divided():
    assert relative_error([{'usable':False}]) is None
    with pytest.raises(ValueError):fit_polynomial([{'usable':False}])


def test_official_architecture_supports_mixed_derivative_diagnostics():
    torch.manual_seed(9)
    net=build_model('official_tiny',dropout=0.,edm_aug=False)
    x=torch.randn(1,3,32,32);e=torch.randn_like(x)
    rows=per_example_statistics(net,x,e,torch.tensor([.7]),torch.tensor([.1]))
    assert rows[0]['usable'] and rows[0]['full_grad_norm_sq']>0
    assert relative_error(rows) is not None
