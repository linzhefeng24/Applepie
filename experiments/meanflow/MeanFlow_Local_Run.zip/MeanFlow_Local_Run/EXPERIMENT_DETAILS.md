# MeanFlow normalization controls / 区间归一化对照实验

已下载作者的官方代码，并在独立实验目录实现以下研究问题：

\[
h\,f'(h)/f(h)=1+a_1h+a_2h^2,\qquad
f(h)=h\exp(a_1h+a_2h^2/2).
\]

目标是比较实际训练效果，并测量停止目标梯度相对于完整求导的相对误差。不预先假设完整梯度更有利于生成，也不声称该归一化已优于 MeanFlow。

## 1. 已获取的官方实现

- JAX/ImageNet: <https://github.com/Gsunshine/meanflow>，下载时 commit `d70cb55d298ee03c53bf6da67bec281082e4e2d9`。
- 官方 PyTorch/CIFAR-10: <https://github.com/Gsunshine/py-meanflow>，固定 commit `1f6d72d94247c8fdeb89489acca1a8007a6baf6c`。

后者由前者 README 明确链接。本实验使用官方 `SongUNet`、时间采样器与 EDM augmentation，未修改官方 checkout。交付包包含 `upstream/py-meanflow` 的原始源码快照、许可证与 SHA256 清单；默认优先使用该快照，也可用 `MEANFLOW_UPSTREAM` 或配置 `upstream` 指定 checkout。每个运行记录实际 commit，`pin_matches=false` 时不应宣称基于固定版本复现。

官方 PyTorch README 区分 `cifar10_v0.sh`（论文设置）与后来的 `v1`（改进采样）；本项目默认 **v0**。它不是此前讨论的第三方 image-restoration “Version 2”。

## 2. 实验分组：不要混淆两个问题

| mode | 网络直接输出 | 目的 |
|---|---|---|
| `baseline` | 原始平均速度 u | a1=a2=0，官方 MeanFlow 基线 |
| `generalized` | 新归一化场 w | 相同原始架构，真正训练不同输出表示 |
| `scaled_generalized` | 底层输出 u，包装 w=exp(-phi)u | 固定物理位移 S=h*u，验证重参数化机制 |
| `reweighted` | 原始 u | 匹配上一组的半梯度，排除简单重加权解释 |

其中 `phi=a1*h+a2*h^2/2`、`q=1+a1*h+a2*h^2`。广义回归目标为：

\[
w_{tgt}=[e^{-\phi}\widetilde v-h D w_\theta]/q,\qquad
\widetilde v=\epsilon-x.
\]

目标停止梯度。JVP 对 `(z,t,r)` 的方向是 `(v,1,0)`；网络按官方实现接收 `(t,t-r)`。`h=0` 使用解析极限，代码不计算 0/0、不通过夹紧 h 改写定义。

训练用每图误差平方 **求和**，与官方代码一致，不替换成像素均值。自适应损失权重也停止梯度。

### 精确重加权对照

固定底层 u 网络时，广义误差与基线误差满足 `error_w=error_u/f'`。为了匹配 `scaled_generalized` 的梯度，`reweighted` 使用系数

\[
e^{-2\phi}/q
\]

并用 `sum(error_u^2)/(f')^2` 构造同一份自适应权重，保留相同 epsilon。这连同 p=0 与 p=0.75 均由梯度测试验证。只乘一个时间系数、却让两边各自计算不同的自适应权重，不是精确对照。

**梯度匹配不要求 loss 数值相同。**精确对照针对显式缩放后的同一个物理模型，不表示两个独立训练的原始网络天然等价。

采样为 `z_r=z_t-f(h)*w`；完整一步必须使用 `f(1)=exp(a1+a2/2)`。除非 a1+a2/2=0，不能直接写 `noise-w`。代码已覆盖这一点。

## 3. 安装与测试

```bash
cd MeanFlow_Local_Run
bash scripts/bootstrap.sh
.venv/bin/python -m pytest -q
```

bootstrap 安装 **CPU** PyTorch 2.7.1 / torchvision 0.22.1，供当前环境验证。GPU 机器应从 PyTorch 官方选择适配驱动的 CUDA wheel，不要直接用 CPU wheel 启动完整实验。脚本保留 TLS 与软件源验证，不修改系统代理或信任设置。

`requirements.txt` 给出依赖范围，当前实际 CPU 验证环境另记录在 `requirements-cpu.lock`。官方 PyTorch 源及其 EDM 派生文件含 CC BY-NC-SA 授权；请保留上游 LICENSE 和文件头。这里不将官方源码重新声明为 MIT。

## 4. 最小可运行检查

```bash
.venv/bin/python -m mfexp.train --config configs/smoke.yaml \
  --out runs/my_smoke --device cpu
.venv/bin/python -m mfexp.diagnose --checkpoint runs/my_smoke/checkpoint.pt \
  --out runs/my_diagnostic --examples 12 --device cpu
.venv/bin/python -m mfexp.evaluate --checkpoint runs/my_smoke/checkpoint.pt \
  --out runs/my_samples --samples 8 --batch-size 4 --device cpu --raw
```

`smoke.yaml` 用 synthetic images 与小网络，**只测试程序，不是 CIFAR-10 性能实验**。EMA 按官方每 16 步更新，短于 16 步时必须显式用 `--raw` 采样。

## 5. CIFAR-10 数据与正式训练

标准下载方式：

```bash
.venv/bin/python -c "from torchvision.datasets import CIFAR10; CIFAR10('data',train=True,download=True)"
```

若 Toronto 每连接限速，可用同一官方 HTTPS 来源的分块下载器；完成后始终验证官方 archive MD5，再提取并验证数据文件：

```bash
.venv/bin/python scripts/download_cifar10.py --workers 8
```

下载若受执行沙箱阻止，需要使用平台支持的审批权限；不应取消代理、关闭 TLS 或改预期校验和。

```bash
# 原始基线
.venv/bin/python -m mfexp.train --config configs/cifar10_baseline.yaml \
  --out runs/cifar10_baseline_seed0 --device cuda

# 两参数候选 a1=0.3, a2=0；其他候选和精确对照也有独立 YAML
.venv/bin/python -m mfexp.train --config configs/cifar10_generalized_two_parameter.yaml \
  --out runs/cifar10_two_parameter_seed0 --device cuda
```

默认约 55M 官方 U-Net，dropout=.2，Adam lr=.0006、betas=(.9,.999)、weight decay=0，effective batch=1024、microbatch=32，EMA=.99995，p=.75、epsilon=.001。时间为 v0 logit-normal(-2,2)，非对角比例 .75，训练 800K optimizer steps，10K warmup，含官方 EDM augmentation。候选只改 mode 与 a1/a2。

这是**单进程梯度累积**运行器，未实现官方 8-GPU DDP/compile 路径。microbatch 会改变 dropout RNG 分配，但所有候选使用同一规则；不同机器和算子不保证逐位复现。步数式 warmup 与官方按 epoch 调度的精确离散长度可能不同，metadata 记录实际设置。不能把少量 smoke step 称为完整论文复现。

### 网格：先生成计划，只有 --execute 才运行

```bash
.venv/bin/python scripts/run_grid.py --steps 10000 --seeds 0,1,2
# 确认资源后执行；10000 是筛选预算，不是论文完整预算。
.venv/bin/python scripts/run_grid.py --steps 10000 --seeds 0,1,2 --execute
```

断点恢复使用相同配置及 `--resume runs/.../checkpoint.pt`，可以提高 `--steps`；不得悄悄改变已有 a1/a2。每步训练种子固定，诊断/采样不改变后续训练随机序列。

## 6. 相对梯度误差与两参数拟合

`mfexp.diagnose` 固定 checkpoint，恢复物理位移 S=h*u。若 checkpoint 原始输出是 w，则先用 u=(f/h)w 恢复，再分析。诊断关闭 dropout，不更新模型。

对每个样本分别计算：

\[
\nabla_\theta\dot S_\theta^\top(\dot S_\theta-\widetilde v),\qquad
(\partial_\theta u_\theta)^\top(\dot S_\theta-\widetilde v).
\]

第一项对应原始完整梯度（这里对输出的参数导数取雅可比转置乘残差），第二项对应原始 SG 梯度。程序通过向量—雅可比积求这两个向量，不显式构建巨大雅可比。

候选的逐样本平方相对误差为：

\[
\frac{\|g_{full}^{(0)}-[1+a_1h+a_2h^2]g_{sg}^{(0)}\|^2}
{\|g_{full}^{(0)}\|^2}.
\]

对角 h=0 可稳定测量（q=1），但没有系数辨识信息；CLI 拟合使用非对角样本。完整梯度平方范数低于阈值的样本标记为 unusable 并单独记录，不无声除零。

```bash
.venv/bin/python -m mfexp.diagnose \
  --checkpoint runs/cifar10_baseline_seed0/checkpoint.pt \
  --out runs/fit_seed2026 --examples 128 --device cuda
```

固定数据索引、噪声和时间种子，前半样本拟合，后半为独立 holdout。优化 a1/a2 使用受约束二次目标，精确检查 `min_{[0,1]} q >= .05`，参数默认限制 [-4,4]。输出系数、条件数、逐样本统计和 holdout 相对误差。样本量小或时间覆盖不足时，系数可能碰到边界，不代表普遍最优。

**不能用 holdout 选系数之后再把同一 holdout 当作独立最终证据。**CLI 列出的候选 holdout 数值是探索性报告，后续结论应使用新数据/新种子。

```bash
.venv/bin/python -m mfexp.train --config configs/cifar10_fitted.yaml \
  --coefficients runs/fit_seed2026/coefficients.json \
  --out runs/cifar10_fitted_seed0 --device cuda
```

若完整梯度比 SG 更接近目标，却导致更差 FID，也应报告；此处的 full 指当前条件速度样本 loss 的完整梯度，不是可直接获得的真实总体流 oracle。

## 7. 采样与 FID

```bash
.venv/bin/python -m mfexp.evaluate \
  --checkpoint runs/cifar10_baseline_seed0/checkpoint.pt \
  --out runs/cifar10_baseline_seed0/eval --device cuda --fid --samples 50000
```

使用 EMA、固定种子、1 NFE。参考集为 50K CIFAR-10 train，与官方 PyTorch eval_loop 一致；生成图像采用官方相同的 [0,1] 裁剪及 8-bit floor 量化。后端为 torchmetrics/torch-fidelity，首次运行需要 Inception 权重下载。不应把其他实现的 FID 无条件与论文数字逐位比较。

未传 `--fid` 就只保存 sample grid，明确写 `fid:null`。少于 50K 的 FID 不标记为完整 FID-50K。当前未完成 FID-50K 或完整训练。

## 8. 文件与实验记录

- `mfexp/normalization.py`: f、f'、q 及区间内严格正值检查。
- `mfexp/objective.py`: 广义训练、精确对照与一步采样。
- `mfexp/diagnostics.py`: 逐样本梯度、相对误差、受约束拟合。
- `mfexp/train.py`: CIFAR 数据、梯度累积、EMA、检查点、JSONL 日志。
- `mfexp/evaluate.py`: 采样与可选 FID。
- `tests/`: 官方 loss/gradient 一致性、对照梯度一致性、解析及自动微分验证。
- `runs/`: 当前实例的验证日志；不是论文性能结果。

输出包含配置、源 commit、参数量、实际训练步数、设备和数据类型。研究问题尚未完成后续文献查新，代码不宣称新颖性或性能提升。
