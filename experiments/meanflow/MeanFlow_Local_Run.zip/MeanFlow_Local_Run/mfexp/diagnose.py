import argparse
import json
from pathlib import Path
import torch
from .train import load_config,create_net,seed_all
from .data import dataset_from_config
from .diagnostics import per_example_statistics,relative_error,fit_polynomial
from .normalization import Normalization
from .upstream import activate
from types import SimpleNamespace


def main():
    p=argparse.ArgumentParser(description='Fit on calibration samples; report disjoint holdout error. No weight updates.')
    p.add_argument('--checkpoint',required=True);p.add_argument('--out',required=True)
    p.add_argument('--examples',type=int,default=16);p.add_argument('--seed',type=int,default=2026)
    p.add_argument('--device',default='cpu');p.add_argument('--download',action='store_true')
    p.add_argument('--coefficients',help='Evaluate an already frozen coefficient JSON; do not refit')
    args=p.parse_args()
    torch.set_num_threads(4)
    if args.examples<4:raise ValueError('Need at least four examples for calibration/holdout split')
    state=torch.load(args.checkpoint,map_location=args.device,weights_only=False)
    cfg=state['config'];mode=cfg.get('mode','baseline');norm=Normalization(cfg.get('a1',0.),cfg.get('a2',0.))
    raw=create_net(cfg).to(args.device);raw.load_state_dict(state['net'])
    # Recover u=S/h from a raw-w checkpoint before measuring fixed physical S.
    class PhysicalU(torch.nn.Module):
        def __init__(self,net):super().__init__();self.net=net
        def forward(self,z,times,aug_cond=None):
            value=self.net(z,times,aug_cond)
            h=times[1].reshape(-1,1,1,1)
            return value*norm.scale(h) if mode=='generalized' else value
    net=PhysicalU(raw);dataset=dataset_from_config(cfg,args.download)
    if args.examples>len(dataset):raise ValueError('Requested more distinct examples than available')
    seed_all(args.seed)
    indices=torch.randperm(len(dataset),generator=torch.Generator().manual_seed(args.seed))[:args.examples]
    x=torch.stack([dataset[int(i)] for i in indices]).to(args.device)
    noise=torch.randn_like(x)
    activate(cfg.get('upstream'));from models.time_sampler import sample_two_timesteps
    sampler=SimpleNamespace(tr_sampler='v0',P_mean_t=cfg.get('time_mean_t',-2.),P_std_t=cfg.get('time_std_t',2.),
        P_mean_r=cfg.get('time_mean_r',-2.),P_std_r=cfg.get('time_std_r',2.),ratio=1.)
    t,r=sample_two_timesteps(sampler,len(x),x.device)
    # Explicitly condition diagnostics on h>0; diagonal statistics can be
    # measured through per_example_statistics, but contain no coefficient signal.
    rows=per_example_statistics(net,x,noise,t,r)
    for row,index in zip(rows,indices):row['dataset_index']=int(index)
    cut=len(rows)//2;calibration,holdout=rows[:cut],rows[cut:]
    fit=json.loads(Path(args.coefficients).read_text()) if args.coefficients else fit_polynomial(calibration)
    frozen_a1,frozen_a2=fit['a1'],fit['a2']
    report={'checkpoint':str(Path(args.checkpoint).resolve()),'checkpoint_step':state['step'],
        'velocity':'conditional epsilon-x; unweighted squared-loss diagnostic; dropout disabled',
        'split_seed':args.seed,'calibration_examples':cut,'holdout_examples':len(holdout),
        'calibration_usable':sum(row['usable'] for row in calibration),
        'holdout_usable':sum(row['usable'] for row in holdout),
        'minimum_full_gradient_norm_sq':1e-16,
        'fit':fit,'holdout_baseline_error_sq':relative_error(holdout),
        'holdout_fitted_error_sq':relative_error(holdout,frozen_a1,frozen_a2),
        'holdout_candidates':[{'a1':a1,'a2':a2,'relative_error_sq':relative_error(holdout,a1,a2)}
                               for a1,a2 in [(0.,0.),(.5,-1.),(-.5,1.),(.3,0.)]],
        'warning':'Fit is local to this fixed checkpoint, not a guaranteed optimal training schedule.'}
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    (out/'coefficients.json').write_text(json.dumps(fit,indent=2)+'\n')
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    (out/'per_example.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in rows))
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
