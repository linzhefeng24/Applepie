from dataclasses import dataclass
import math
import torch


@dataclass(frozen=True)
class Normalization:
    """f(h)=h exp(a1*h+a2*h^2/2), with h*f'/f=1+a1*h+a2*h^2.

    f/h is evaluated by exp(phi), including at h=0. No 0/0 or clamping
    changes the analytic diagonal limit.
    """
    a1: float = 0.0
    a2: float = 0.0
    min_q: float = 0.05

    def __post_init__(self):
        if not all(math.isfinite(v) for v in (self.a1, self.a2, self.min_q)):
            raise ValueError('Normalization coefficients must be finite')
        if self.min_q <= 0:
            raise ValueError('min_q must be positive')
        if self.q_minimum() < self.min_q-1e-8:
            raise ValueError(f"min h*f'/f={self.q_minimum():.6g} < {self.min_q}")
        if abs(self.a1)+abs(self.a2)/2 > 30:
            raise ValueError('Excessive exponential scaling; choose moderate coefficients')

    def q_minimum(self):
        hs = [0.0, 1.0]
        if self.a2 > 0 and 0 < -self.a1/(2*self.a2) < 1:
            hs.append(-self.a1/(2*self.a2))
        return min(1+self.a1*h+self.a2*h*h for h in hs)

    def phi(self, h): return self.a1*h + 0.5*self.a2*h.square()
    def scale(self, h): return self.phi(h).exp()  # f/h; equals 1 at h=0
    def q(self, h): return 1+self.a1*h+self.a2*h.square()
    def f(self, h): return h*self.scale(h)
    def fp(self, h): return self.scale(h)*self.q(h)
    def derivative_coefficient(self, h): return h/self.q(h)  # f/f'

    def target(self, velocity, derivative, h):
        return (velocity/self.scale(h)-h*derivative)/self.q(h)

    @property
    def f1(self): return math.exp(self.a1+0.5*self.a2)


def expand_time(t, x):
    return t.reshape(t.shape[0], *([1]*(x.ndim-1)))
