from pathlib import Path
import torch
from torch.utils.data import Dataset


class FakeImages(Dataset):
    """Deterministic synthetic images for plumbing checks, NOT a benchmark."""
    def __init__(self,size=128):self.size=size
    def __len__(self):return self.size
    def __getitem__(self,i):
        return torch.rand(3,32,32,generator=torch.Generator().manual_seed(i))*2-1


class CIFARImages(Dataset):
    def __init__(self,root,download=False,flip=True):
        from torchvision.datasets import CIFAR10
        self.dataset=CIFAR10(str(root),train=True,download=download)
        self.flip=flip
    def __len__(self):return len(self.dataset)
    def __getitem__(self,i):
        x=torch.from_numpy(self.dataset.data[i].copy()).permute(2,0,1).float()/127.5-1
        if self.flip and torch.rand(())<.5:x=x.flip(-1)
        return x


def dataset_from_config(cfg,download=False):
    if cfg['data']=='fake':return FakeImages(cfg.get('fake_size',128))
    if cfg['data']=='cifar10':return CIFARImages(cfg['data_root'],download,flip=cfg.get('horizontal_flip',True))
    raise ValueError(cfg['data'])


def deterministic_batch(dataset,step,batch_size,seed):
    """Shuffled, drop-last epochs; batch order is independent of model RNG.

    Rebuilding an epoch's permutation is cheap for 50K indices, and makes
    resume independent of DataLoader prefetch state.
    """
    if len(dataset)<batch_size:raise ValueError('Dataset smaller than effective batch')
    steps_per_epoch=len(dataset)//batch_size;epoch,offset=divmod(step,steps_per_epoch)
    ids=torch.randperm(len(dataset),generator=torch.Generator().manual_seed(seed+epoch))
    ids=ids[offset*batch_size:(offset+1)*batch_size]
    return torch.stack([dataset[int(i)] for i in ids])
