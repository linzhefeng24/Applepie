import argparse
import copy
import json
from pathlib import Path
import random
import time
from types import SimpleNamespace
import numpy as np
import torch
import yaml
from .data import dataset_from_config,deterministic_batch
from .models import build_model
from .normalization import Normalization
from .objective import interval_objective,sample_one_step
from .upstream import activate,provenance


def seed_all(seed):
    random.seed(seed);np.random.seed(seed%(2**32));torch.manual_seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)


def load_config(path):
    cfg=yaml.safe_load(Path(path).read_text())
    if not isinstance(cfg,dict):raise ValueError('Config must be a mapping')
    return cfg


def create_net(cfg):
    return build_model(cfg.get('model','official'),cfg.get('dropout',.2),
                       cfg.get('edm_aug',True),cfg.get('upstream'))


def atomic_save(value,path):
    tmp=path.with_suffix(path.suffix+'.tmp');torch.save(value,tmp);tmp.replace(path)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--config',required=True);parser.add_argument('--out',required=True)
    parser.add_argument('--steps',type=int);parser.add_argument('--seed',type=int)
    parser.add_argument('--device',default='auto');parser.add_argument('--download',action='store_true')
    parser.add_argument('--resume');parser.add_argument('--coefficients',help='a1/a2 JSON from fit diagnostic')
    args=parser.parse_args();cfg=load_config(args.config)
    if args.steps is not None:cfg['steps']=args.steps
    if args.seed is not None:cfg['seed']=args.seed
    if args.coefficients:
        fit=json.loads(Path(args.coefficients).read_text())
        cfg['a1']=fit['a1'];cfg['a2']=fit['a2'];cfg['fit_source']=str(Path(args.coefficients).resolve())
    if args.device=='auto':
        if not torch.cuda.is_available():raise RuntimeError('No CUDA GPU. Use --device cpu only for explicit small checks.')
        device=torch.device('cuda')
    else:device=torch.device(args.device)
    if cfg['steps']<1:raise ValueError('steps must be positive')
    torch.set_num_threads(cfg.get('cpu_threads',4))
    seed=cfg.get('seed',0);seed_all(seed)
    norm=Normalization(cfg.get('a1',0.),cfg.get('a2',0.),cfg.get('min_q',.05))
    mode=cfg.get('mode','baseline')
    if mode=='baseline' and (norm.a1 or norm.a2):raise ValueError('Baseline requires a1=a2=0')
    activate(cfg.get('upstream'))
    from models.time_sampler import sample_two_timesteps
    sampler=SimpleNamespace(tr_sampler=cfg.get('tr_sampler','v0'),
        P_mean_t=cfg.get('time_mean_t',-2.),P_std_t=cfg.get('time_std_t',2.),
        P_mean_r=cfg.get('time_mean_r',-2.),P_std_r=cfg.get('time_std_r',2.),ratio=cfg.get('off_diagonal_ratio',.75))
    net=create_net(cfg).to(device);ema=copy.deepcopy(net).eval().requires_grad_(False)
    optim=torch.optim.Adam(net.parameters(),lr=cfg.get('lr',.0006),
                            betas=tuple(cfg.get('betas',[.9,.999])),weight_decay=0)
    dataset=dataset_from_config(cfg,args.download)
    batch=cfg['batch_size'];micro=cfg.get('microbatch_size',batch)
    if micro<1 or batch<1:raise ValueError('Batch sizes must be positive')
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    checkpoint=out/'checkpoint.pt'
    if checkpoint.exists() and not args.resume:raise FileExistsError('Output checkpoint exists; use --resume or a new --out')
    start=0
    if args.resume:
        state=torch.load(args.resume,map_location=device,weights_only=False)
        ignored={'steps','log_every','checkpoint_every','cpu_threads','fit_source'}
        for key in (set(state['config'])|set(cfg))-ignored:
            if state['config'].get(key)!=cfg.get(key):raise ValueError(f'Resume config mismatch: {key}')
        net.load_state_dict(state['net']);ema.load_state_dict(state['ema']);optim.load_state_dict(state['optimizer']);start=state['step']
    augment=None
    if cfg.get('edm_aug',True):
        from models.augment import AugmentPipe
        augment=AugmentPipe(p=.12,xflip=1e8,yflip=0,scale=1,rotate_frac=0,aniso=1,translate_frac=1)
    metadata={'config':cfg,'source':provenance(cfg.get('upstream')),'torch':torch.__version__,
        'device':str(device),'parameters':sum(p.numel() for p in net.parameters()),
        'data_examples':len(dataset),'full_paper_recipe_requested':cfg.get('recipe')=='paper_v0',
        'warning':'fake/tiny runs are software smoke checks, never FID reproduction',
        'optimizer_backend':'single process, microbatch gradient accumulation; no DDP'}
    (out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    net.train();begin=time.perf_counter();total_examples=0
    for step in range(start,cfg['steps']):
        # Isolate training randomness by optimizer step; diagnostic/sampling calls
        # cannot alter the next training batch/noise/time/dropout RNG sequence.
        seed_all(seed*1000003+step)
        if device.type=='cuda':torch.cuda.synchronize()
        tic=time.perf_counter()
        x=deterministic_batch(dataset,step,batch,seed).to(device)
        if augment is not None:x,aug=augment(x)
        else:aug=None
        noise=torch.randn_like(x);t,r=sample_two_timesteps(sampler,batch,device)
        warmup=cfg.get('warmup_steps',10000)
        lr=cfg.get('lr',.0006)*min(1.,(step+1)/warmup) if warmup else cfg.get('lr',.0006)
        for group in optim.param_groups:group['lr']=lr
        optim.zero_grad(set_to_none=True);loss_sum=0.;raw_sum=0.
        for lo in range(0,batch,micro):
            hi=min(lo+micro,batch);fraction=(hi-lo)/batch
            loss,stats=interval_objective(net,x[lo:hi],noise[lo:hi],t[lo:hi],r[lo:hi],norm,mode,
                cfg.get('norm_p',.75),cfg.get('norm_eps',.001),None if aug is None else aug[lo:hi],
                stop_target=not cfg.get('full_gradient',False))
            if not torch.isfinite(loss):raise FloatingPointError(f'Non-finite loss at step {step}')
            (loss*fraction).backward();loss_sum+=loss.item()*fraction;raw_sum+=stats['squared_error'].item()*fraction
        grad_sq=sum(p.grad.detach().double().square().sum() for p in net.parameters() if p.grad is not None).item()
        if not np.isfinite(grad_sq):raise FloatingPointError(f'Non-finite gradient at step {step}')
        optim.step()
        if (step+1)%16==0:
            decay=cfg.get('ema_decay',.99995)**16
            with torch.no_grad():
                for pe,p in zip(ema.parameters(),net.parameters()):
                    pe.copy_((pe.double()+(1-decay)*(p.double()-pe.double())).to(pe.dtype))
        if device.type=='cuda':torch.cuda.synchronize()
        elapsed=time.perf_counter()-tic;total_examples+=batch
        row={'step':step+1,'loss':loss_sum,'unweighted_squared_error':raw_sum,
            'grad_norm':grad_sq**.5,'seconds':elapsed,'lr':lr,'off_diagonal':(t>r).float().mean().item()}
        with (out/'train.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        if (step+1)%cfg.get('log_every',100)==0 or step==start:print(json.dumps(row),flush=True)
        if (step+1)%cfg.get('checkpoint_every',10000)==0 or step+1==cfg['steps']:
            atomic_save({'net':net.state_dict(),'ema':ema.state_dict(),'optimizer':optim.state_dict(),
                'config':cfg,'source':metadata['source'],'step':step+1},checkpoint)
    summary={'optimizer_steps_this_run':max(0,cfg['steps']-start),'examples_this_run':total_examples,
        'wall_seconds':time.perf_counter()-begin,'model':cfg['model'],'data':cfg['data'],
        'fid_computed':False,'gpu_training':device.type=='cuda'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))


if __name__=='__main__':main()
