"""Generate one-step samples and optionally compute torchmetrics FID.

Uses 50K CIFAR training images as real reference, like upstream eval_loop.py.
Inception implementation/preprocessing affects FID; report backend metadata.
Never reports FID when --fid is absent.
"""
import argparse
import json
from pathlib import Path
import torch
from torchvision.utils import save_image
from .train import create_net,seed_all
from .normalization import Normalization
from .objective import sample_one_step


def main():
    p=argparse.ArgumentParser();p.add_argument('--checkpoint',required=True);p.add_argument('--out',required=True)
    p.add_argument('--samples',type=int,default=50000);p.add_argument('--batch-size',type=int,default=64)
    p.add_argument('--device',default='cuda');p.add_argument('--seed',type=int,default=12345)
    p.add_argument('--fid',action='store_true');p.add_argument('--download',action='store_true')
    p.add_argument('--raw',action='store_true',help='Use training weights, not EMA; useful for <16-step smoke runs')
    args=p.parse_args()
    torch.set_num_threads(4)
    if args.samples<1 or args.batch_size<1:raise ValueError('Positive sample and batch counts required')
    device=torch.device(args.device);state=torch.load(args.checkpoint,map_location=device,weights_only=False)
    cfg=state['config'];net=create_net(cfg).to(device).eval()
    if not args.raw and state['step']<16:raise ValueError('EMA not updated before step 16; use --raw for smoke samples')
    net.load_state_dict(state['net' if args.raw else 'ema']);norm=Normalization(cfg.get('a1',0.),cfg.get('a2',0.))
    seed_all(args.seed);out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    metric=None
    if args.fid:
        from torchmetrics.image.fid import FrechetInceptionDistance
        from torchvision.datasets import CIFAR10
        metric=FrechetInceptionDistance(normalize=True).to(device)
        real=CIFAR10(cfg['data_root'],train=True,download=args.download)
        for lo in range(0,len(real),args.batch_size):
            batch=torch.from_numpy(real.data[lo:lo+args.batch_size].copy()).permute(0,3,1,2).float().to(device)/255
            metric.update(batch,real=True)
    generated=0
    with torch.no_grad():
        while generated<args.samples:
            n=min(args.batch_size,args.samples-generated)
            noise=torch.randn(n,3,32,32,device=device)
            samples=sample_one_step(net,noise,norm,cfg.get('mode','baseline'))
            images=((samples*.5+.5).clamp(0,1)*255).floor()/255
            if generated==0:save_image(images[:64],out/'samples.png',nrow=8)
            if metric is not None:metric.update(images,real=False)
            generated+=n
    report={'samples':generated,'nfe':1,'checkpoint_step':state['step'],
        'weights':'raw' if args.raw else 'ema','fid':float(metric.compute()) if metric is not None else None,
        'fid_backend':'torchmetrics / torch-fidelity Inception' if metric is not None else None,
        'real_reference':'CIFAR-10 train, 50000, no augmentation' if metric is not None else None,
        'full_fid_50k':bool(metric is not None and generated==50000),'seed':args.seed,'device':str(device)}
    (out/'evaluation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))


if __name__=='__main__':main()
