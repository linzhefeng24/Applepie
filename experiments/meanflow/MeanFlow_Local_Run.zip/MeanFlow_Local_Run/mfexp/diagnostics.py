"""Per-example relative SG error at a FIXED physical displacement S=h*u.

All gradients are for unweighted 1/2 squared residual, conditional v=e-x.
No claim about the inaccessible exact marginal velocity or gradient quality.
Dropout is disabled; current model parameters are not changed.
"""
import numpy as np
import torch
from .normalization import Normalization,expand_time


def dot_grad(xs,ys):
    value=None
    for x,y in zip(xs,ys):
        if x is None or y is None:continue
        term=(x.detach().double()*y.detach().double()).sum()
        value=term if value is None else value+term
    return 0. if value is None else value.item()


def per_example_statistics(net,x,noise,t,r,minimum_norm_sq=1e-16):
    params=tuple(p for p in net.parameters() if p.requires_grad)
    was_training=net.training;net.eval();rows=[]
    try:
        for i in range(len(x)):
            xx=x[i:i+1];ee=noise[i:i+1];tt=t[i:i+1];rr=r[i:i+1]
            hh=tt-rr;hb=expand_time(hh,xx);tb=expand_time(tt,xx)
            z=(1-tb)*xx+tb*ee;v=ee-xx
            def fn(zz,ts,rs):return net(zz,(ts,ts-rs),None)
            u,du=torch.func.jvp(fn,(z,tt,rr),(v,torch.ones_like(tt),torch.zeros_like(rr)))
            s_dot=u+hb*du;residual=(s_dot-v).detach()
            full=torch.autograd.grad(s_dot,params,grad_outputs=residual,retain_graph=True,allow_unused=True)
            sg=torch.autograd.grad(u,params,grad_outputs=residual,allow_unused=True)
            full_sq=dot_grad(full,full);sg_sq=dot_grad(sg,sg);cross=dot_grad(full,sg)
            usable=full_sq>minimum_norm_sq
            rows.append({'h':hh.item(),'t':tt.item(),'r':rr.item(),
                'full_grad_norm_sq':full_sq,'sg_grad_norm_sq':sg_sq,
                'full_dot_sg':cross,'usable':usable,
                'baseline_relative_error_sq':(full_sq-2*cross+sg_sq)/full_sq if usable else None,
                'cosine':cross/(full_sq*sg_sq)**.5 if full_sq*sg_sq>0 else None})
    finally:net.train(was_training)
    return rows


def relative_error(rows,a1=0.,a2=0.):
    Normalization(a1,a2)
    values=[]
    for row in rows:
        if not row['usable']:continue
        h=row['h'];q=1+a1*h+a2*h*h
        f=row['full_grad_norm_sq'];s=row['sg_grad_norm_sq'];c=row['full_dot_sg']
        values.append(max(0.,(f-2*q*c+q*q*s)/f))
    return float(np.mean(values)) if values else None


def fit_polynomial(rows,min_q=.05,ridge=0.,bound=4.):
    """Fit q=1+a1*h+a2*h^2 using mean PER-EXAMPLE relative error.

    Exact positivity check uses the quadratic's possible interior minimum.
    Only calibration rows may be supplied; evaluate on disjoint holdout rows.
    """
    from scipy.optimize import minimize
    valid=[r for r in rows if r['usable']]
    if not valid:raise ValueError('No nonzero full gradients available')
    h=np.array([r['h'] for r in valid]);X=np.stack([h,h*h],axis=1)
    b=np.array([r['sg_grad_norm_sq']/r['full_grad_norm_sq'] for r in valid])
    c=np.array([r['full_dot_sg']/r['full_grad_norm_sq'] for r in valid])
    H=(X.T*b)@X/len(h);rhs=X.T@(c-b)/len(h)
    def objective(a):
        return float(a@H@a-2*a@rhs+ridge*(a@a))
    def jac(a):return 2*(H@a-rhs+ridge*a)
    def positivity(a):
        hs=[0.,1.]
        if a[1]>0 and 0 < -a[0]/(2*a[1]) < 1:hs.append(-a[0]/(2*a[1]))
        return min(1+a[0]*v+a[1]*v*v for v in hs)-min_q
    result=minimize(objective,np.zeros(2),jac=jac,method='SLSQP',
                    bounds=[(-bound,bound)]*2,constraints=[{'type':'ineq','fun':positivity}],
                    options={'ftol':1e-12,'maxiter':500})
    if not result.success:raise RuntimeError(result.message)
    a1,a2=map(float,result.x)
    if positivity(result.x)<-1e-8:raise RuntimeError('Invalid normalization fit')
    return {'a1':a1,'a2':a2,'min_q':min_q,'ridge':ridge,'coefficient_bound':bound,
            'calibration_examples':len(valid),'normal_matrix_condition':float(np.linalg.cond(H)),
            'calibration_baseline_error_sq':relative_error(valid),
            'calibration_fitted_error_sq':relative_error(valid,a1,a2)}
