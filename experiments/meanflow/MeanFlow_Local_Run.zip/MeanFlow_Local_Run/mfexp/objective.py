import torch
from .normalization import Normalization, expand_time

MODES=('baseline','generalized','scaled_generalized','reweighted')


def interval_objective(net,x,noise,t,r,norm=None,mode='baseline',norm_p=.75,
                       norm_eps=.001,aug_cond=None,stop_target=True):
    """Official conditional-velocity objective with generalized f.

    t,r are (B,). Raw net output is w in generalized mode, u otherwise.
    scaled_generalized defines w=exp(-phi)*u explicitly; reweighted is
    its exact semi-gradient control, including detached adaptive weighting.
    The latter compares identical physical S=h*u, not two separately trained
    raw-output networks. Values of the two control losses need not match.
    """
    if mode not in MODES:raise ValueError(mode)
    if norm_p<0 or norm_eps<=0:raise ValueError('Invalid adaptive weighting')
    if not stop_target and mode=='reweighted':
        raise ValueError('reweighted is a semi-gradient control, not a full-gradient control')
    norm=norm or Normalization()
    if not bool(((r>=0)&(t>=r)&(t<=1)).all()):raise ValueError('Require 0 <= r <= t <= 1')
    h=expand_time(t-r,x);te=expand_time(t,x)
    z=(1-te)*x+te*noise;velocity=noise-x
    active=Normalization() if mode in ('baseline','reweighted') else norm

    def fn(zz,tt,rr):
        raw=net(zz,(tt,tt-rr),aug_cond)
        if mode=='scaled_generalized':raw=raw/norm.scale(expand_time(tt-rr,zz))
        return raw

    pred,derivative=torch.func.jvp(fn,(z,t,r),(velocity,torch.ones_like(t),torch.zeros_like(r)))
    target=active.target(velocity,derivative,h)
    error=pred-(target.detach() if stop_target else target)
    squared=error.square().flatten(1).sum(1)  # official sum, not pixel mean
    if mode=='reweighted':
        scale=norm.scale(t-r);q=norm.q(t-r);fp=scale*q
        adaptive=(squared.detach()/fp.square()+norm_eps).pow(-norm_p)
        coefficient=scale.square().reciprocal()/q
    else:
        adaptive=(squared.detach()+norm_eps).pow(-norm_p)
        coefficient=torch.ones_like(squared)
    loss=(coefficient*adaptive*squared).mean()
    return loss,{'squared_error':squared.detach().mean(),
                 'adaptive_weight':adaptive.detach().mean(),
                 'off_diagonal':(t>r).float().mean().detach()}


@torch.no_grad()
def sample_one_step(net,noise,norm=None,mode='baseline'):
    norm=norm or Normalization()
    t=torch.ones(noise.shape[0],device=noise.device,dtype=noise.dtype)
    raw=net(noise,(t,t),None)
    # scaled_generalized predicts raw u; the wrapper's exp(-phi) cancels f/h.
    displacement=raw*norm.f1 if mode=='generalized' else raw
    return noise-displacement
