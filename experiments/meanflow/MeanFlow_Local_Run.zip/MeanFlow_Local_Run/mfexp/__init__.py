"""Controlled experiments for generalized MeanFlow interval normalization."""
