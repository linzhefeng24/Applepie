"""Import the authors' unchanged PyTorch CIFAR implementation."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

PYTORCH_COMMIT = '1f6d72d94247c8fdeb89489acca1a8007a6baf6c'
JAX_COMMIT = 'd70cb55d298ee03c53bf6da67bec281082e4e2d9'


def activate(path=None):
    bundled=Path(__file__).resolve().parents[1]/'upstream/py-meanflow'
    default=bundled if bundled.is_dir() else Path(__file__).resolve().parents[2]/'py-meanflow'
    root=Path(path or os.environ.get('MEANFLOW_UPSTREAM',default)).resolve()
    if not (root/'meanflow/models/unet.py').is_file():
        raise FileNotFoundError(f'Official source missing at {root}; run scripts/bootstrap.sh')
    sys.path.insert(0,str(root/'meanflow')) if str(root/'meanflow') not in sys.path else None
    return root


def provenance(path=None):
    root=activate(path)
    snapshot=root/'UPSTREAM_SNAPSHOT.json'
    if snapshot.is_file():
        manifest=json.loads(snapshot.read_text());commit=manifest['commit']
        for name,expected in manifest['sha256'].items():
            if hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected:
                raise RuntimeError(f'Bundled upstream source checksum mismatch: {name}')
    else:
        commit=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
    return {'repository':'https://github.com/Gsunshine/py-meanflow','path':str(root),
            'commit':commit,'expected_commit':PYTORCH_COMMIT,'pin_matches':commit==PYTORCH_COMMIT}
