import torch
from torch import nn
from .upstream import activate


class TinyNet(nn.Module):
    """Smoke-test network only; never described as the paper architecture."""
    def __init__(self):
        super().__init__()
        self.layers=nn.Sequential(nn.Conv2d(5,12,3,padding=1),nn.SiLU(),
                                  nn.Conv2d(12,12,3,padding=1),nn.SiLU(),nn.Conv2d(12,3,3,padding=1))

    def forward(self,z,times,aug_cond=None):
        t,h=times
        ts=t[:,None,None,None].expand(-1,1,*z.shape[-2:])
        hs=h[:,None,None,None].expand_as(ts)
        return self.layers(torch.cat([z,ts,hs],dim=1))


def build_model(kind='official',dropout=.2,edm_aug=True,upstream=None):
    if kind=='tiny':return TinyNet()
    activate(upstream)
    from models.unet import SongUNet
    configs=dict(img_resolution=32,in_channels=3,out_channels=3,channel_mult_noise=2,
                 resample_filter=[1,3,3,1],channel_mult=[2,2,2],encoder_type='standard',
                 decoder_type='standard',dropout=dropout,augment_dim=6 if edm_aug else 0)
    if kind=='official_tiny':
        configs.update(model_channels=16,channel_mult=[1,2,2],num_blocks=1)
    elif kind!='official':raise ValueError(kind)
    return SongUNet(**configs)
