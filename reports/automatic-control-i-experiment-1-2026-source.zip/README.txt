Compile with XeLaTeX twice. Requires ctex and Noto Serif CJK SC font.
Keep the figs directory next to the .tex file.
