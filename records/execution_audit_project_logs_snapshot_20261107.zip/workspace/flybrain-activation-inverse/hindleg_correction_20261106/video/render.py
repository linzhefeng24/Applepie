import os
os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/tmp/hind-correction-mesa',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',LP_NUM_THREADS='4')
from pathlib import Path
import json,numpy as np,mujoco,imageio
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;root=R.parent.parent;m=mujoco.MjModel.from_xml_path(str(R.parent/'candidate_muscles.xml'));d=mujoco.MjData(m);old=dict(np.load(root/'half_speed_angle_only_20261106/rollout_5000Hz.npz'));new=dict(np.load(R.parent/'optimized_rollout.npz'));other=dict(np.load(R.parent/'right_hind_femur_stage/optimized_rollout.npz'));ref=dict(np.load(root/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));qa=ref['joint_qpos_indices'];renderer=mujoco.Renderer(m,height=360,width=480);opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
frames=120;measurements=[]
with imageio.get_writer(R/'hindleg_correction_comparison_005x.mp4',fps=15,codec='libx264',quality=8,macro_block_size=2) as writer:
 for frame in range(frames):
  t=frame/(frames-1)*.4;ri=round(t/.0002);panels=[]
  for label,z in [('Reference (simulation, retimed 0.5x)',None),('Before: sequential angle-only',old),('After A: lower terminal angle RMS',new),('After B: stronger hind femur guard',other)]:
   if z is None:d.qpos[:]=ref['qpos'][ri];d.qvel[:]=ref['qvel'][ri]
   elif frame==0:d.qpos[:]=z['initial_state'][1:1+m.nq];d.qvel[:]=z['initial_state'][1+m.nq:1+m.nq+m.nv]
   else:
    k=int(np.argmin(abs(z['time_s']-t)));d.qpos[:]=z['qpos'][k];d.qvel[:]=z['qvel'][k]
   d.time=t;mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=opt);renderer.scene.flags[mujoco.mjtRndFlag.mjRND_REFLECTION]=False;renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW]=False;im=Image.fromarray(renderer.render());dr=ImageDraw.Draw(im);dr.rectangle((0,0,480,66),fill='black');dr.text((7,5),label,fill='white');dr.text((7,24),f't={t:.3f}s | playback 0.05x | full trial 0.4s',fill='white');err=float(np.sqrt(np.mean((d.qpos[qa]-ref['qpos'][ri,qa])**2))*180/np.pi);dr.text((7,43),f'Joint angle RMS: {err:.2f} deg',fill='white');panels.append(np.asarray(im));measurements.append(dict(time_s=t,panel=label,angle_rmse_deg=err))
  combined=np.concatenate([np.concatenate(panels[:2],axis=1),np.concatenate(panels[2:],axis=1)],axis=0);writer.append_data(combined)
  if frame in [0,60,119]:Image.fromarray(combined).save(R/f'frame_{frame:03d}.png')
  if frame%30==0:print('rendered',frame,flush=True)
renderer.close();(R/'render_measurements.json').write_text(json.dumps(measurements,indent=2));print('FINISHED',flush=True)
