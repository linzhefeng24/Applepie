import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLBACKEND='Agg',MPLCONFIGDIR='/tmp/hindleg-mpl')
from pathlib import Path
import numpy as np,matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;old=dict(np.load(R.parent/'half_speed_angle_only_20261106/rollout_5000Hz.npz'));new=dict(np.load(R/'optimized_rollout.npz'));ref=dict(np.load(R.parent/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));t=old['time_s'];names=old['joint_names'];qa=ref['joint_qpos_indices'];fig,ax=plt.subplots(5,2,figsize=(12,15),sharex=True)
for col,side in enumerate(['left','right']):
 for row,typ in enumerate(['coxa','femur_twist','femur','tarsus']):
  j=int(np.flatnonzero(names==f'walker/{typ}_T3_{side}')[0]);a=ax[row,col];a.plot(ref['time_s'],np.degrees(ref['qpos'][:,qa[j]]),'k--',label='reference');a.plot(t,np.degrees(old['joint_angle_rad'][:,j]),label='before');a.plot(t,np.degrees(new['joint_angle_rad'][:,j]),label='candidate');a.set_title(f'{side} hind {typ}');a.set_ylabel('angle (deg)');a.grid(alpha=.3)
 for label in ['old','corrected']:
  z=np.load(R/(label+'_foot_diagnostics.npz'));ax[4,col].plot(z['time_s'],z['outward_foot_mm'][:,col],label=label)
 ax[4,col].axhline(0,color='k',ls='--');ax[4,col].axhline(.05,color='gray',ls=':');ax[4,col].set_title(f'{side} hind foot: outward distance from body midline');ax[4,col].set_ylabel('mm');ax[4,col].set_xlabel('physical time (s)');ax[4,col].grid(alpha=.3)
ax[0,0].legend();ax[4,0].legend();fig.tight_layout();fig.savefig(R/'hindleg_correction_comparison.png',dpi=160)
