import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,copy,time,xml.etree.ElementTree as ET,numpy as np,mujoco
from scipy.spatial import ConvexHull
from scipy.optimize import differential_evolution
R=Path(__file__).resolve().parent;ROOT=R.parent;BASE=ROOT/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml';m=mujoco.MjModel.from_xml_path(str(BASE));d=mujoco.MjData(m);records=json.loads((ROOT/'six_leg_model/activation_refine_20261104/records.json').read_text())['records'];patches=json.loads((ROOT/'six_leg_model/activation_refine_20261104/attachment_candidates.json').read_text());old=dict(np.load(ROOT/'half_speed_angle_only_20261106/rollout_5000Hz.npz'));ref=dict(np.load(ROOT/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));source=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');Q=source['qpos'];poses=np.concatenate([Q[::100],old['qpos'][::20],ref['qpos'][::20]]);tree=ET.parse(BASE);report=[];newrecords=copy.deepcopy(records);clock=time.monotonic()
def hull_for(body):
 bid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,body);geoms=[g for g in range(m.ngeom) if m.geom_bodyid[g]==bid and m.geom_type[g]==int(mujoco.mjtGeom.mjGEOM_MESH)];g=next((g for g in geoms if mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,g)==body),geoms[0]);mesh=m.geom_dataid[g];v=m.mesh_vert[m.mesh_vertadr[mesh]:m.mesh_vertadr[mesh]+m.mesh_vertnum[mesh]].astype(float);rot=np.empty(9);mujoco.mju_quat2Mat(rot,m.geom_quat[g]);return ConvexHull(v@rot.reshape(3,3).T+m.geom_pos[g]).equations
for leg,side in [('LH','left'),('RH','right')]:
 row=next(x for x in records if x['id']==leg+':tarsus_depressor');nr=next(x for x in newrecords if x['id']==row['id']);ai=row['actuator_index'];jid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,f'walker/tarsus_T3_{side}');bids=[mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,p['body']) for p in row['points']];assert len(bids)==2;X=np.empty((len(poses),2,3));B=np.empty((len(poses),2,3,3));AX=np.empty((len(poses),3));AN=np.empty_like(AX)
 for k,q in enumerate(poses):
  d.qpos[:]=q;mujoco.mj_kinematics(m,d);X[k]=d.xpos[bids];B[k]=d.xmat[bids].reshape(2,3,3);AX[k]=d.xaxis[jid];AN[k]=d.xanchor[jid]
 def evaluate(p0,p1):
  w0=X[:,0]+np.einsum('nij,j->ni',B[:,0],p0);w1=X[:,1]+np.einsum('nij,j->ni',B[:,1],p1);delta=w1-w0;length=np.linalg.norm(delta,axis=1);grad=np.sum(delta/length[:,None]*np.cross(AX,w1-AN),axis=1);return length,grad
 pools=[]
 for point in row['points']:
  patch=patches[point['site']];original=np.array(patch['initial_position_cm']);eq=hull_for(point['body']);choices=np.unique(np.array([point['pos_cm'],original.tolist()]+patch['candidate_positions_cm']),axis=0);choices=np.array([p for p in choices if np.linalg.norm(p-original)<=patch['maximum_displacement_cm']+1e-10 and np.max(eq[:,:3]@p+eq[:,3])<=1e-8]);assert len(choices);pools.append(choices)
 initial=[np.array(p['pos_cm']) for p in row['points']];L0,G0=evaluate(*initial);ranked=[]
 for p0 in pools[0]:
  for p1 in pools[1]:
   L,G=evaluate(p0,p1);disp=sum(np.linalg.norm(p-np.array(patches[pt['site']]['initial_position_cm']))**2/patches[pt['site']]['maximum_displacement_cm']**2 for p,pt in zip([p0,p1],row['points']));score=float(np.min(G))-.00003*disp;ranked.append((score,float(np.min(G)),disp,p0.copy(),p1.copy(),L,G))

 eqs=[hull_for(p['body']) for p in row['points']];centers=[np.array(patches[p['site']]['initial_position_cm']) for p in row['points']];radii=[patches[p['site']]['maximum_displacement_cm'] for p in row['points']]
 def objective(x):
  points=[x[:3],x[3:]];violation=sum(max(0.,float(np.max(eq[:,:3]@p+eq[:,3])))+max(0.,float(np.linalg.norm(p-c)-radius)) for p,c,radius,eq in zip(points,centers,radii,eqs));L,G=evaluate(*points);disp=sum(np.linalg.norm(p-c)**2/radius**2 for p,c,radius in zip(points,centers,radii));return -float(np.min(G))+.00003*disp+100*violation
 bounds=[(float(pool[:,axis].min()),float(pool[:,axis].max())) for pool in pools for axis in range(3)]
 opt=differential_evolution(objective,bounds,popsize=10,maxiter=100,tol=.0001,polish=True,rng=20261106)
 p0,p1=opt.x[:3],opt.x[3:];feasible=all(np.max(eq[:,:3]@p+eq[:,3])<=1e-8 and np.linalg.norm(p-c)<=radius+1e-8 for p,c,radius,eq in zip([p0,p1],centers,radii,eqs))
 if feasible:
  L,G=evaluate(p0,p1);disp=sum(np.linalg.norm(p-c)**2/radius**2 for p,c,radius in zip([p0,p1],centers,radii));ranked.append((float(G.min())-.00003*disp,float(G.min()),disp,p0.copy(),p1.copy(),L,G))
 ranked.sort(key=lambda x:x[0],reverse=True);choice=None
 for item in ranked:
  _,gmin,disp,p0,p1,L,G=item
  if gmin<=.00002:continue
  gains=np.array([-mujoco.mju_muscleGain(float(l),0,m.actuator_lengthrange[ai],m.actuator_acc0[ai],m.actuator_gainprm[ai,:9]) for l in L]);bias=np.array([abs(mujoco.mju_muscleBias(float(l),m.actuator_lengthrange[ai],m.actuator_acc0[ai],m.actuator_biasprm[ai,:9])) for l in L]);f0=m.actuator_gainprm[ai,2]
  if np.min(gains)<.1*f0 or np.max(bias)>2*f0:continue
  choice=item;break
 status='no feasible bounded point-shift candidate' if choice is None else 'bounded same-bone geometry candidate selected'
 if choice is not None:
  _,gmin,disp,p0,p1,L,G=choice
  for point,p in zip(nr['points'],[p0,p1]):point['pos_cm']=p.tolist();node=tree.getroot().find(f".//site[@name='{point['site']}']");assert node is not None;node.set('pos',' '.join(f'{x:.17g}' for x in p))
 else:gmin=float(G0.min());p0,p1=initial;L,G=L0,G0
 item=dict(id=row['id'],status=status,initial_points=row['points'],candidate_points=nr['points'],sampled_pose_count=len(poses),initial_min_dlength_dq_cm=float(G0.min()),candidate_min_dlength_dq_cm=gmin,initial_wrong_direction_fraction=float(np.mean(G0<=0)),candidate_wrong_direction_fraction=float(np.mean(G<=0)),max_point_displacement_from_prior_center_cm=max(float(np.linalg.norm(p-np.array(patches[pt['site']]['initial_position_cm']))) for p,pt in zip([p0,p1],row['points'])),point_uncertainty_radius_cm=patches[row['points'][0]['site']]['maximum_displacement_cm'],strength_and_activation_parameters_unchanged=True,anatomically_measured=False);report.append(item);print(json.dumps(item),flush=True)
path=R/'candidate_muscles.xml';tree.write(path,encoding='unicode');test=mujoco.MjModel.from_xml_path(str(path));assert np.array_equal(test.actuator_gainprm,m.actuator_gainprm) and np.array_equal(test.actuator_dynprm,m.actuator_dynprm) and np.array_equal(test.actuator_lengthrange,m.actuator_lengthrange);(R/'geometry_report.json').write_text(json.dumps(dict(changes=report,model_path=str(path),strengths_unchanged=True,activation_dynamics_unchanged=True,fit_pose_domain='reference poses every 20 ms plus prior failed trajectory every 4 ms and original 6s every 20 ms',estimated_geometry_only=True,wall_s=time.monotonic()-clock),indent=2));(R/'candidate_records.json').write_text(json.dumps(dict(records=newrecords),indent=2));print('DONE',flush=True)
