import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import numpy as np,mujoco,json
from mujoco import rollout
R=Path(__file__).resolve().parent;z=dict(np.load(R/'optimized_rollout.npz'));ref=dict(np.load(R.parent/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));m=mujoco.MjModel.from_xml_path(str(R.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));d=mujoco.MjData(m);S,_=rollout.rollout(m,d,z['initial_state'],z['all_control_10000Hz'],initial_warmstart=z['initial_warmstart']);S=S[0,1::2];q=S[:,1:1+m.nq];error=q[:,ref['joint_qpos_indices']]-ref['qpos'][1:,ref['joint_qpos_indices']];thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');feet=[mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,f'walker/claw_T3_{s}') for s in ['left','right']];Y=[]
for pose in q:
 d.qpos[:]=pose;mujoco.mj_kinematics(m,d);rot=d.xmat[thorax].reshape(3,3);Y.append([sign*((d.xpos[bid]-d.xpos[thorax])@rot)[1]*10 for sign,bid in zip([1,-1],feet)])
Y=np.array(Y);out=dict(description='Optimized six-leg controls replayed with the old tendon geometry; all other model parameters unchanged.',path_rmse_deg=float(np.sqrt(np.mean(error**2))*180/np.pi),terminal_rmse_deg=float(np.sqrt(np.mean(error[-1]**2))*180/np.pi),min_outward_foot_mm=Y.min(axis=0).tolist(),final_outward_foot_mm=Y[-1].tolist());(R/'old_geometry_new_control_ablation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
