import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,time,numpy as np,mujoco
from mujoco import rollout
from scipy.optimize import lsq_linear
R=Path(__file__).resolve().parent;ROOT=R.parent;m=mujoco.MjModel.from_xml_path(str(R/'candidate_muscles.xml'));records=json.loads((R/'candidate_records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];old=dict(np.load(ROOT/'half_speed_angle_only_20261106/rollout_5000Hz.npz'));ref=dict(np.load(ROOT/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));base=dict(np.load(R/'six_leg_stage/optimized_rollout.npz'))['all_control_10000Hz'].copy();initial=old['initial_state'].copy();warm=old['initial_warmstart'].copy();names=old['joint_names'];qadrs=ref['joint_qpos_indices'];dofs=ref['joint_dof_indices'];data=[mujoco.MjData(m) for _ in range(4)];work=mujoco.MjData(m);fk=mujoco.MjData(m);mom=np.zeros((m.nu,m.nv));G=7;B=np.zeros((130,G));basislabels=[];types=['coxa_abduct','coxa_twist','coxa','femur_twist','femur','tibia','tarsus'];basisreport=[]
# Minimum-norm muscle combinations counter multi-axis hip coupling instead of using one antagonist by name.
for leg,side,col in [('RH','right',0)]:
 ix=np.array([i for i,r in enumerate(records) if r['leg']==leg]);jj=np.array([int(np.flatnonzero(names==f'walker/{typ}_T{1 if leg.endswith("F") else 2 if leg.endswith("M") else 3}_{side}')[0]) for typ in types]);DD=[]
 for f in range(0,2001,100):
  work.qpos[:]=ref['qpos'][f];work.qvel[:]=ref['qvel'][f];work.act[:]=0;work.ctrl[:]=base[min(f*2,3999)];mujoco.mj_forward(m,work);mujoco.mju_sparse2dense(mom,work.actuator_moment,work.moment_rownnz,work.moment_rowadr,work.moment_colind);F=[]
  for a in [0,1]:work.act[adrs]=a;mujoco.mj_fwdActuation(m,work);F.append(work.actuator_force[ids].copy())
  DD.append((mom[ids[ix]][:,dofs[jj]]*(F[1][ix]-F[0][ix])[:,None]).T*1e-7)
 D=np.mean(DD,axis=0);scale=np.maximum(np.linalg.norm(D,axis=1),1e-12);N=D/scale[:,None];bb=N.T@np.linalg.inv(N@N.T+.03*np.eye(7));bb/=np.maximum(np.max(abs(bb),axis=0,keepdims=True),1e-9);B[np.ix_(ix,np.arange(col,col+7))]=bb;basislabels.extend([leg+':'+typ for typ in types]);basisreport.append(dict(leg=leg,joints=[str(names[j]) for j in jj],muscles=[records[i]['id'] for i in ix],mean_activation_torque_map_Nm=D.tolist(),normalized_condition_number=float(np.linalg.cond(N)),basis=bb.tolist()))
(R/'control_basis.json').write_text(json.dumps(basisreport,indent=2));knots=np.linspace(0,.4,3);K=len(knots);blocktime=(np.arange(20)+.5)*.02;W=np.stack([np.interp(blocktime,knots,np.eye(K)[i]) for i in range(K)],axis=1);block=np.arange(4000)//200;sample=np.arange(99,4000,100);target=ref['qpos'][(sample+1)//2][:,qadrs];weights=np.ones(66);weights[44:]=1.5;hip=np.array([int(np.flatnonzero(names==f'walker/coxa_T3_{s}')[0]) for s in ['left','right']]);twist=np.array([int(np.flatnonzero(names==f'walker/femur_twist_T3_{s}')[0]) for s in ['left','right']]);ankle=np.array([int(np.flatnonzero(names==f'walker/tarsus_T3_{s}')[0]) for s in ['left','right']]);weights[np.r_[hip,twist]]=3;thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');feet=[mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,f'walker/claw_T3_{s}') for s in ['left','right']];rng=np.random.default_rng(20261106);history=[];clock=time.monotonic();evaluations=0
np.savez_compressed(R/'control_parameterization.npz',B=B,knots_s=knots,W=W,basis_labels=np.array(basislabels),angle_joint_weights=weights)
def controls(X):
 X=np.atleast_2d(X).reshape(-1,K,G);offset=np.einsum('tk,bkg,mg->btm',W,X,B);C=np.broadcast_to(base,(len(X),*base.shape)).copy();C[:,:,ids]=np.clip(base[None,:,ids]+offset[:,block],0,1);return C

def evaluate(X,save=None):
 global evaluations
 X=np.atleast_2d(X);C=controls(X);S,_=rollout.rollout(m,data,initial[None],C,initial_warmstart=warm[None],persistent_pool=True);evaluations+=len(X);assert np.isfinite(S).all() and np.allclose(S[:,-1,0],.4,atol=1e-8);q=S[:,sample,1:1+m.nq];error=q[:,:,qadrs]-target;Y=np.empty((len(X),len(sample),2));UP=np.empty((len(X),len(sample)))
 for i in range(len(X)):
  for k in range(len(sample)):
   fk.qpos[:]=q[i,k];mujoco.mj_kinematics(m,fk);rot=fk.xmat[thorax].reshape(3,3);UP[i,k]=rot[2,2]
   for j,sign in enumerate([1,-1]):Y[i,k,j]=sign*((fk.xpos[feet[j]]-fk.xpos[thorax])@rot)[1]*10
 foot=20*np.maximum(0,.05-Y);hiplimit=10*np.maximum(0,np.maximum(-12*np.pi/180-q[:,:,qadrs[hip]],q[:,:,qadrs[hip]]-22*np.pi/180));twistlimit=6*np.maximum(0,abs(error[:,:,twist])-12*np.pi/180);anklelimit=4*np.maximum(0,abs(error[:,:,ankle])-20*np.pi/180);tilt=3*np.maximum(0,.8-UP);E=np.concatenate([(error*weights[None,None]).reshape(len(X),-1),(4*error[:,-1,:]*weights[None]).reshape(len(X),-1),foot.reshape(len(X),-1),hiplimit.reshape(len(X),-1),twistlimit.reshape(len(X),-1),anklelimit.reshape(len(X),-1),tilt.reshape(len(X),-1)],axis=1);stats=[]
 for i in range(len(X)):stats.append(dict(loss=float(np.mean(E[i]**2)),angle_rmse_deg=float(np.sqrt(np.mean(error[i]**2))*180/np.pi),hind_angle_rmse_deg=float(np.sqrt(np.mean(error[i,:,44:]**2))*180/np.pi),terminal_angle_rmse_deg=float(np.sqrt(np.mean(error[i,-1]**2))*180/np.pi),min_hind_outward_foot_mm=float(Y[i].min()),min_coxa_deg=float(q[i,:,qadrs[hip]].min()*180/np.pi),max_hind_femur_twist_error_deg=float(np.max(abs(error[i,:,twist]))*180/np.pi),min_up_z=float(UP[i].min()),foot_penalty_mse=float(np.mean(foot[i]**2)),hip_penalty_mse=float(np.mean(hiplimit[i]**2))))
 if save is not None:
  assert len(X)==1;h=np.arange(1,4000,2);s=S[0,h];off=1+m.nq+m.nv;ff=np.rint(s[:,0]/.0002).astype(int);np.savez_compressed(save,time_s=s[:,0],full_state=s,qpos=s[:,1:1+m.nq],qvel=s[:,1+m.nq:off],activation=s[:,off:][:,adrs],excitation=C[0,h][:,ids],all_control_10000Hz=C[0],initial_state=initial,initial_warmstart=warm,joint_angle_rad=s[:,1:1+m.nq][:,qadrs],target_joint_angle=ref['qpos'][ff][:,qadrs],qerror_rad=s[:,1:1+m.nq][:,qadrs]-ref['qpos'][ff][:,qadrs],muscle_ids=old['muscle_ids'],joint_names=names,control_parameters=X[0],sampled_outward_foot_mm=Y[0]);assert np.all((S[0,:,off:][:,adrs]>=0)&(S[0,:,off:][:,adrs]<=1))
 return E,stats
X=[np.zeros(K*G)];E,stats=evaluate(X);x=np.array(X[0]);e=E[0].copy();current=stats[0];baseline=stats[0];print('INITIAL',json.dumps(current),flush=True)
for it in range(3):
 probes=[];meta=[]
 for i in range(len(x)):
  hp=min(.04,3-x[i]);hm=min(.04,x[i]+3);ip=im=-1
  if hp>1e-9:ip=len(probes);xx=x.copy();xx[i]+=hp;probes.append(xx)
  if hm>1e-9:im=len(probes);xx=x.copy();xx[i]-=hm;probes.append(xx)
  meta.append((i,hp,hm,ip,im))
 PE,PS=evaluate(probes);J=np.zeros((len(e),len(x)))
 for i,hp,hm,ip,im in meta:J[:,i]=((PE[ip] if ip>=0 else e)-(PE[im] if im>=0 else e))/(hp+hm)
 ridge=max(np.linalg.norm(J,'fro')/np.sqrt(len(x))*.01,1e-7);fit=lsq_linear(np.vstack([J,ridge*np.eye(len(x))]),np.r_[-e,np.zeros(len(x))],bounds=(np.maximum(-3-x,-.7),np.minimum(3-x,.7)),method='bvls',max_iter=300,tol=1e-9);candidates=np.clip(x[None]+np.array([1,.5,.2,.05,.01])[:,None]*fit.x,-3,3);candidates=np.vstack([candidates,np.clip(x[None]+rng.normal(0,.08,(20,len(x))),-3,3)]);CE,CS=evaluate(candidates);score=lambda s:s['loss'] if s['angle_rmse_deg']<=10.8 and s['terminal_angle_rmse_deg']<=14.3 else float('inf');ix=int(np.argmin([score(s) for s in CS]));probeix=int(np.argmin([score(s) for s in PS]));oldloss=current['loss'];accepted=False
 if score(PS[probeix])<current['loss']:x=np.asarray(probes[probeix]).copy();e=PE[probeix].copy();current=PS[probeix];accepted=True
 if score(CS[ix])<current['loss']:x=candidates[ix].copy();e=CE[ix].copy();current=CS[ix];accepted=True
 history.append(dict(iteration=it+1,accepted=accepted,loss_before=oldloss,**current,rollouts=evaluations,wall_s=time.monotonic()-clock));(R/'optimization_history.json').write_text(json.dumps(history,indent=2));evaluate(x,save=R/'optimized_rollout.npz');print(json.dumps(history[-1]),flush=True)
 if current['min_hind_outward_foot_mm']>=.025:break
report=dict(method='whole-trajectory bounded muscle-pattern optimization with same-bone candidate attachment repair; all twenty intervals adjustable jointly',duration_s=.4,segment_duration_s=.02,velocity_penalty=0,height_penalty=0,foot_side_margin_mm=.05,coxa_guard_deg=[-12,22],femur_twist_error_guard_deg=12,tarsus_error_guard_deg=20,tilt_guard_min_up_z=.8,control_parameters=K*G,terminal_angle_residual_multiplier=4,all_six_leg_inputs_adjustable=False,right_hind_only_post_polish=True,accepted_candidate_sampled_path_rmse_cap_deg=10.8,accepted_candidate_terminal_rmse_cap_deg=14.3,temporal_knots_s=knots.tolist(),initial_state_unchanged=True,fore_and_middle_inputs_unchanged=False,muscle_force_and_activation_parameters_unchanged=True,geometry_estimated_not_measured=True,six_leg_stage_initial=baseline,final=current,native_rollouts=evaluations,walking_validated=False,wall_s=time.monotonic()-clock,limitations=['Finite low-dimensional control basis, not a global optimum.','Pose guards are optimization penalties; full-resolution verification must check whether they are achieved.','New attachment points are bounded estimates, not anatomical measurements.']);(R/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
