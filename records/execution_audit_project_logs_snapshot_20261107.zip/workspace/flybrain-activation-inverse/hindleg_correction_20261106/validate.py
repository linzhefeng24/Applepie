import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,numpy as np,mujoco,hashlib,xml.etree.ElementTree as ET
from scipy.spatial import ConvexHull
R=Path(__file__).resolve().parent;candidate=Path(sys.argv[1]) if len(sys.argv)>1 else R/'optimized_rollout.npz';prefix=sys.argv[2] if len(sys.argv)>2 else '';ROOT=R.parent;modelpath=ROOT/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml';m=mujoco.MjModel.from_xml_path(str(R/'candidate_muscles.xml'));m0=mujoco.MjModel.from_xml_path(str(modelpath));ref=dict(np.load(ROOT/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));old=dict(np.load(ROOT/'half_speed_angle_only_20261106/rollout_5000Hz.npz'));records=json.loads((R/'candidate_records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];qa=ref['joint_qpos_indices'];names=old['joint_names'];thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');feet=[mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,f'walker/claw_T3_{s}') for s in ['left','right']];out={};fk=mujoco.MjData(m)
for label,file in [('old',ROOT/'half_speed_angle_only_20261106/rollout_5000Hz.npz'),('geometry_only',R/'geometry_only_replay.npz'),('corrected',candidate)]:
 z=dict(np.load(file));errors=z['qpos'][:,qa]-ref['qpos'][1:,qa];Y=[];up=[]
 for q in z['qpos']:
  fk.qpos[:]=q;mujoco.mj_kinematics(m,fk);rot=fk.xmat[thorax].reshape(3,3);Y.append([sign*((fk.xpos[bid]-fk.xpos[thorax])@rot)[1]*10 for sign,bid in zip([1,-1],feet)]);up.append(rot[2,2])
 Y=np.array(Y);joints={str(n):dict(path_rmse_deg=float(np.sqrt(np.mean(errors[:,j]**2))*180/np.pi),terminal_error_deg=float(errors[-1,j]*180/np.pi),final_angle_deg=float(z['qpos'][-1,qa[j]]*180/np.pi)) for j,n in enumerate(names)};cross=[float(z['time_s'][np.flatnonzero(Y[:,i]<0)[0]]) if np.any(Y[:,i]<0) else None for i in range(2)]
 out[label]=dict(root_displacement_mm=((z['qpos'][-1,:3]-z['initial_state'][1:4])*10).tolist(),path_rmse_deg=float(np.sqrt(np.mean(errors**2))*180/np.pi),hind_path_rmse_deg=float(np.sqrt(np.mean(errors[:,44:]**2))*180/np.pi),terminal_rmse_deg=float(np.sqrt(np.mean(errors[-1]**2))*180/np.pi),max_terminal_error_deg=float(np.max(abs(errors[-1]))*180/np.pi),min_outward_foot_mm=Y.min(axis=0).tolist(),final_outward_foot_mm=Y[-1].tolist(),first_midline_crossing_s=cross,min_up_z=float(min(up)),joints=joints)
 np.savez_compressed(R/(prefix+label+'_foot_diagnostics.npz'),time_s=z['time_s'],outward_foot_mm=Y,up_z=up)
 if label=='corrected':
  d=mujoco.MjData(m);mujoco.mj_setState(m,d,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.qacc_warmstart[:]=z['initial_warmstart'];err=0;amin=1;amax=0;applied=0
  for k,ctrl in enumerate(z['all_control_10000Hz']):
   d.ctrl[:]=ctrl;mujoco.mj_step(m,d);amin=min(amin,float(d.act[adrs].min()));amax=max(amax,float(d.act[adrs].max()));applied=max(applied,float(abs(d.qfrc_applied).max()),float(abs(d.xfrc_applied).max()))
   if k%2:
    state=np.empty(z['full_state'].shape[1]);mujoco.mj_getState(m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);err=max(err,float(abs(state-z['full_state'][k//2]).max()))
  unchanged=np.setdiff1d(np.arange(m.nu),ids);validation=dict(max_full_state_replay_error=err,activation_bounds=[amin,amax],excitation_bounds=[float(z['all_control_10000Hz'][:,ids].min()),float(z['all_control_10000Hz'][:,ids].max())],max_external_applied_force=applied,initial_state_exactly_unchanged=bool(np.array_equal(z['initial_state'],old['initial_state'])),retained_nonmuscle_control_max_change=float(abs(z['all_control_10000Hz'][:,unchanged]-old['all_control_10000Hz'][:,unchanged]).max()),strength_exactly_unchanged=bool(np.array_equal(m.actuator_gainprm,m0.actuator_gainprm) and np.array_equal(m.actuator_biasprm,m0.actuator_biasprm)),activation_dynamics_exactly_unchanged=bool(np.array_equal(m.actuator_dynprm,m0.actuator_dynprm)),height_penalty=0)
  assert err<1e-9 and amin>=0 and amax<=1 and applied==0 and validation['retained_nonmuscle_control_max_change']==0 and validation['initial_state_exactly_unchanged'] and validation['strength_exactly_unchanged'] and validation['activation_dynamics_exactly_unchanged'];out['validation']=validation
# Dense pose checks include held-out old trajectory frames and the new rollout.
mom=np.zeros((m.nu,m.nv));checks={}
for label,q in [('reference',ref['qpos']),('old_failed',old['qpos']),('new',z['qpos'])]:
 values=[]
 for pose in q:
  fk.qpos[:]=pose;fk.qvel[:]=0;mujoco.mj_forward(m,fk);mujoco.mju_sparse2dense(mom,fk.actuator_moment,fk.moment_rownnz,fk.moment_rowadr,fk.moment_colind);row=[]
  for leg,side in [('LH','left'),('RH','right')]:
   a=next(r['actuator_index'] for r in records if r['id']==leg+':tarsus_depressor');j=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,f'walker/tarsus_T3_{side}');row.append(mom[a,m.jnt_dofadr[j]])
  values.append(row)
 values=np.array(values);checks[label]=dict(poses=len(q),min_dlength_dq_cm=values.min(axis=0).tolist(),wrong_direction_count=(values<=0).sum(axis=0).tolist())
fk.qpos[:]=z['qpos'][-1];fk.qvel[:]=z['qvel'][-1];fk.act[adrs]=z['activation'][-1];fk.ctrl[:]=z['all_control_10000Hz'][-1];mujoco.mj_forward(m,fk);mujoco.mju_sparse2dense(mom,fk.actuator_moment,fk.moment_rownnz,fk.moment_rowadr,fk.moment_colind);actualforce=fk.actuator_force[ids].copy();F=[]
for level in [0,1]:
 fk.act[adrs]=level;mujoco.mj_fwdActuation(m,fk);F.append(fk.actuator_force[ids].copy())
capacity={}
for side in ['left','right']:
 for typ in ['coxa','femur_twist','femur','tibia','tarsus']:
  name=f'walker/{typ}_T3_{side}';j=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,name);do=m.jnt_dofadr[j];tau0=mom[ids,do]*F[0]*1e-7;tau1=mom[ids,do]*F[1]*1e-7;capacity[name]=dict(actual_muscle_torque_Nm=float(mom[ids,do]@actualforce*1e-7),instantaneous_activation_torque_interval_Nm=[float(np.minimum(tau0,tau1).sum()),float(np.maximum(tau0,tau1).sum())])
out['terminal_muscle_capacity']=capacity;out['dense_geometry_checks']=checks;out['same_physics_parameter_checks']={key:bool(np.array_equal(getattr(m,key),getattr(m0,key))) for key in ['body_mass','body_inertia','body_ipos','dof_damping','jnt_stiffness','jnt_range','geom_friction','geom_solref','geom_solimp','geom_contype','geom_conaffinity','actuator_lengthrange','actuator_gear','actuator_ctrllimited','actuator_ctrlrange','actuator_actlimited','actuator_actrange','actuator_gaintype','actuator_biastype','actuator_dyntype']};assert all(out['same_physics_parameter_checks'].values());changed=[];patches=json.loads((ROOT/'six_leg_model/activation_refine_20261104/attachment_candidates.json').read_text());bounds=[]
for before,after in zip(ET.parse(modelpath).getroot().iter(),ET.parse(R/'candidate_muscles.xml').getroot().iter()):
 assert before.tag==after.tag
 if before.attrib!=after.attrib:
  assert before.tag=='site' and {k:v for k,v in before.attrib.items() if k!='pos'}=={k:v for k,v in after.attrib.items() if k!='pos'};changed.append(after.get('name'));site=after.get('name');patch=patches[site];p=np.array([float(x) for x in after.get('pos').split()]);displacement=float(np.linalg.norm(p-np.array(patch['initial_position_cm'])));assert displacement<=patch['maximum_displacement_cm']+1e-10;sid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_SITE,site);bid=m.site_bodyid[sid];body=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,bid);geoms=[g for g in range(m.ngeom) if m.geom_bodyid[g]==bid and m.geom_type[g]==int(mujoco.mjtGeom.mjGEOM_MESH)];gg=next((g for g in geoms if mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,g)==body),geoms[0]);mesh=m.geom_dataid[gg];verts=m.mesh_vert[m.mesh_vertadr[mesh]:m.mesh_vertadr[mesh]+m.mesh_vertnum[mesh]].astype(float);rot=np.empty(9);mujoco.mju_quat2Mat(rot,m.geom_quat[gg]);eq=ConvexHull(verts@rot.reshape(3,3).T+m.geom_pos[gg]).equations;hullerror=float(np.max(eq[:,:3]@p+eq[:,3]));assert hullerror<=1e-8;bounds.append(dict(site=site,body=body,displacement_from_prior_center_cm=displacement,uncertainty_radius_cm=patch['maximum_displacement_cm'],max_hull_violation_cm=hullerror))
assert set(changed)=={'sixleg_106_LH_p0','sixleg_106_LH_p1','sixleg_126_RH_p0','sixleg_126_RH_p1'};out['independent_geometry_bounds_checks']=bounds;out['only_xml_attribute_changes']=changed;out['baseline_model_sha256']=hashlib.sha256(modelpath.read_bytes()).hexdigest();assert out['baseline_model_sha256']=='ca8f1e77f49565cb6d665cae850373b7a22b3bb0910a181253a96c4bdc2e0bea';out['model_sha256']=hashlib.sha256((R/'candidate_muscles.xml').read_bytes()).hexdigest();(R/(prefix+'validation_report.json')).write_text(json.dumps(out,indent=2));print(json.dumps({k:{kk:vv for kk,vv in v.items() if kk!='joints'} if isinstance(v,dict) else v for k,v in out.items()},indent=2))
