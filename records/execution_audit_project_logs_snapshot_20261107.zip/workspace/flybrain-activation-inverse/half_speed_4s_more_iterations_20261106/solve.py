import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,time,numpy as np,mujoco
from mujoco import rollout
from scipy.optimize import lsq_linear
R=Path(__file__).resolve().parent;ROOT=R.parent;P=ROOT/'hindleg_correction_20261106'
m=mujoco.MjModel.from_xml_path(str(P/'candidate_muscles.xml'));records=json.loads((P/'candidate_records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];ref=dict(np.load(R/'reference_5000Hz.npz'));qa=ref['joint_qpos_indices'];names=np.load(ROOT/'half_speed_4s_20ms_20261106/A/optimized_rollout.npz')['joint_names'];N=200;SAMPLE=np.array([39,79,119,159,199]);pool=[mujoco.MjData(m) for _ in range(4)];fk=mujoco.MjData(m);state_size=mujoco.mj_stateSize(m,mujoco.mjtState.mjSTATE_FULLPHYSICS);off=1+m.nq+m.nv
thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');feet=[mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,f'walker/claw_T3_{s}') for s in ['left','right']];hip=np.array([int(np.flatnonzero(names==f'walker/coxa_T3_{s}')[0]) for s in ['left','right']]);twist=np.array([int(np.flatnonzero(names==f'walker/femur_twist_T3_{s}')[0]) for s in ['left','right']]);ankle=np.array([int(np.flatnonzero(names==f'walker/tarsus_T3_{s}')[0]) for s in ['left','right']]);femur=int(np.flatnonzero(names=='walker/femur_T3_right')[0]);weights=np.ones(66);weights[44:]=1.5;weights[np.r_[hip,twist]]=3
assert m.opt.timestep==.0001
for label,source in [('A',ROOT/'half_speed_4s_20ms_20261106/A/optimized_rollout.npz')]:
 D=R/label;D.mkdir(exist_ok=True);z=dict(np.load(source));base=z['all_control_10000Hz'];chosen=base.copy();d=mujoco.MjData(m);mujoco.mj_setState(m,d,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.qacc_warmstart[:]=z['initial_warmstart'];rng=np.random.default_rng(110600+(label=='B'));allstates=[];boundaries=[z['initial_state'].copy()];boundarywarm=[z['initial_warmstart'].copy()];hist=[];offsets=[];calls=0;clock=time.monotonic();cachedJ=None;cached_mask=None;cached_contacts=None;cached_q=None
 checkpoint=dict(np.load(D/'optimized_rollout.npz'));resume_segment=len(checkpoint['boundary_states'])-1;chosen=checkpoint['all_control_10000Hz'].copy();allstates=[a.copy() for a in checkpoint['full_state']];boundaries=[a.copy() for a in checkpoint['boundary_states']];boundarywarm=[a.copy() for a in checkpoint['boundary_warmstarts']];offsets=[a.copy() for a in checkpoint['segment_offsets']];hist=json.loads((D/'segments.json').read_text())[:resume_segment];calls=hist[-1]['rollouts'] if hist else 0;clock=time.monotonic()-(hist[-1]['wall_s'] if hist else 0);rng.standard_normal(sum(len(r['rounds']) for r in hist)*6*130);test=mujoco.MjData(m);mujoco.mj_setState(m,test,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS);test.qacc_warmstart[:]=z['initial_warmstart'];prefix_error=0.;buf=np.empty(state_size)
 for k in range(resume_segment*N):
  test.ctrl[:]=chosen[k];mujoco.mj_step(m,test)
  if k%2:
   mujoco.mj_getState(m,test,buf,mujoco.mjtState.mjSTATE_FULLPHYSICS);prefix_error=max(prefix_error,float(abs(buf-checkpoint['full_state'][k//2]).max()))
 assert prefix_error<1e-9;mujoco.mj_setState(m,d,boundaries[-1],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.qacc_warmstart[:]=boundarywarm[-1];(D/'segments.json').write_text(json.dumps(hist,indent=2));(D/'resume_validation.json').write_text(json.dumps(dict(resume_segment=resume_segment,resume_time_s=float(d.time),prefix_max_full_state_error=prefix_error,full_physical_and_activation_state_restored_exactly=True,solver_warmstart_restored=True),indent=2));print('RESUMED',resume_segment,'PREFIX REPLAY ERROR',prefix_error,flush=True)
 for segment in range(resume_segment,200):
  start=segment*N;ctrlbase=base[start:start+N];lower=-np.max(ctrlbase[:,ids],axis=0);upper=1-np.min(ctrlbase[:,ids],axis=0);initial=boundaries[-1];warm=boundarywarm[-1];target=ref['qpos'][(start+SAMPLE+1)//2][:,qa];targetf=(start+SAMPLE+1)//2;rounds=[]
  def evaluate(X):
   global calls
   X=np.atleast_2d(X);C=np.broadcast_to(ctrlbase,(len(X),N,m.nu)).copy();C[:,:,ids]=np.clip(ctrlbase[None,:,ids]+X[:,None,:],0,1);SS,_=rollout.rollout(m,pool,initial[None],C,initial_warmstart=warm[None],persistent_pool=True);calls+=len(X);assert np.isfinite(SS).all();q=SS[:,SAMPLE,1:1+m.nq];err=q[:,:,qa]-target;Y=np.empty((len(X),len(SAMPLE),2));UP=np.empty((len(X),len(SAMPLE)))
   for a in range(len(X)):
    for k in range(len(SAMPLE)):
     fk.qpos[:]=q[a,k];mujoco.mj_kinematics(m,fk);rot=fk.xmat[thorax].reshape(3,3);UP[a,k]=rot[2,2]
     for j,sign in enumerate([1,-1]):Y[a,k,j]=sign*((fk.xpos[feet[j]]-fk.xpos[thorax])@rot)[1]*10
   parts=[(err*weights[None,None]).reshape(len(X),-1),(4*err[:,-1]*weights).reshape(len(X),-1),(100*np.maximum(0,.05-Y)).reshape(len(X),-1),(10*np.maximum(0,np.maximum(-12*np.pi/180-q[:,:,qa[hip]],q[:,:,qa[hip]]-22*np.pi/180))).reshape(len(X),-1),(6*np.maximum(0,abs(err[:,:,twist])-12*np.pi/180)).reshape(len(X),-1),(4*np.maximum(0,abs(err[:,:,ankle])-20*np.pi/180)).reshape(len(X),-1),(3*np.maximum(0,.8-UP)).reshape(len(X),-1)]
   if label=='B':parts.append((20*np.maximum(0,abs(err[:,:,femur])-15*np.pi/180)).reshape(len(X),-1))
   E=np.concatenate(parts,axis=1);stats=[dict(loss=float(np.mean(E[a]**2)),endpoint_rmse_deg=float(np.sqrt(np.mean(err[a,-1]**2))*180/np.pi),max_endpoint_error_deg=float(np.max(abs(err[a,-1]))*180/np.pi),worst_joint=str(names[np.argmax(abs(err[a,-1]))]),min_sampled_outward_foot_mm=float(Y[a].min()),max_sampled_RH_femur_error_deg=float(abs(err[a,:,femur]).max()*180/np.pi)) for a in range(len(X))];return E,stats,C,SS
  x=np.zeros(130);EE,stats,_,_=evaluate(x);e=EE[0];cur=stats[0];before=cur.copy();stagnant=0
  contacts=tuple(sorted(set(int(d.contact[c].geom[g]) for c in range(d.ncon) for g in [0,1] if m.geom_bodyid[int(d.contact[c].geom[1-g])]==0)));mask=tuple(abs(e[396:])>1e-12);qcurrent=initial[1:1+m.nq][qa];fresh=(cachedJ is None or segment%4==0 or contacts!=cached_contacts or mask!=cached_mask or np.max(abs(qcurrent-cached_q))>15*np.pi/180);J=None if fresh else cachedJ.copy();refreshed=False;full_gradients=0
  for iteration in range(32):
   if iteration>0 and iteration%8==0:J=None
   PE=PS=probes=None
   if J is None:
    h=np.where(upper-x>=x-lower,np.minimum(.04,upper-x),-np.minimum(.04,x-lower));probes=x[None]+np.diag(h);PE,PS,_,_=evaluate(probes);J=((PE-e)/h[:,None]).T;full_gradients+=1;refreshed=True
   ridge=max(np.linalg.norm(J,'fro')/np.sqrt(130)*.01,1e-7);trust=.5 if stagnant==0 else .2;fit=lsq_linear(np.vstack([J,ridge*np.eye(130)]),np.r_[-e,np.zeros(130)],bounds=(np.maximum(lower-x,-trust),np.minimum(upper-x,trust)),method='bvls',max_iter=200,tol=1e-8)
   candidates=[np.clip(x+f*fit.x,lower,upper) for f in [1,.5,.2,.05]]
   # Target the current worst two endpoint angles using measured native sensitivities.
   endpoint_error=e[330:396]/(4*weights);worst=np.argsort(abs(endpoint_error))[-2:]
   for j in worst:
    gradient=J[330+j]/(4*weights[j]);threshold=.05*np.max(abs(gradient));active=abs(gradient)>max(threshold,1e-10);toward=x.copy();toward[active]=np.where(endpoint_error[j]*gradient[active]>0,lower[active],upper[active])
    for fraction in [.25,1.]:candidates.append(x+fraction*(toward-x))
   for sigma in [.03,.12,.35]:candidates.extend(np.clip(x+rng.normal(0,sigma,(2,130)),lower,upper))
   XX=np.array(candidates);CE,CS,_,_=evaluate(XX);ci=int(np.argmin([a['loss'] for a in CS]));oldx=x.copy();olde=e.copy();improved=False
   if PS is not None:
    pi=int(np.argmin([a['loss'] for a in PS]))
    if PS[pi]['loss']<cur['loss']-1e-12:x=probes[pi].copy();e=PE[pi].copy();cur=PS[pi];improved=True
   if CS[ci]['loss']<cur['loss']-1e-12:x=XX[ci].copy();e=CE[ci].copy();cur=CS[ci];improved=True
   if improved:
    dx=x-oldx;de=e-olde;den=float(dx@dx)
    if den>1e-10:J+=np.outer(de-J@dx,dx)/den
   stagnant=0 if improved else stagnant+1;rounds.append(dict(iteration=iteration+1,accepted=improved,full_input_jacobians=full_gradients,**cur))
   if cur['max_endpoint_error_deg']<1 and iteration>=11:break
   if stagnant>=3 and (iteration+1)%8!=0 and full_gradients<2:J=None;stagnant=0
   if iteration>=11 and full_gradients>=2:
    recent=rounds[-6:];gain=(recent[0]['loss']-recent[-1]['loss'])/max(abs(recent[0]['loss']),1e-12)
    if gain<1e-6 and not any(a['accepted'] for a in recent[-3:]):break
  cachedJ=J.copy() if J is not None else None;cached_contacts=contacts;cached_mask=mask;cached_q=qcurrent.copy()
  _,_,CC,SS=evaluate(x);chosen[start:start+N]=CC[0];maxerr=0
  for k in range(N):
   d.ctrl[:]=CC[0,k];mujoco.mj_step(m,d);s=np.empty(state_size);mujoco.mj_getState(m,d,s,mujoco.mjtState.mjSTATE_FULLPHYSICS);maxerr=max(maxerr,float(abs(s-SS[0,k]).max()))
   if k%2:allstates.append(s.copy())
  assert maxerr<1e-9;assert np.all((d.act[adrs]>=0)&(d.act[adrs]<=1));boundaries.append(s.copy());boundarywarm.append(d.qacc_warmstart.copy());offsets.append(x.copy());row=dict(segment=segment+1,start_s=start*.0001,end_s=(start+N)*.0001,before=before,after=cur,rounds=rounds,candidate_commit_max_state_error=maxerr,rollouts=calls,wall_s=time.monotonic()-clock);hist.append(row);(D/'segments.json').write_text(json.dumps(hist,indent=2));print(label,'SEGMENT',segment+1,json.dumps(dict(**cur,rounds=len(rounds),rollouts=calls,wall_s=time.monotonic()-clock)),flush=True)
  if (segment+1)%5!=0 and segment!=199:continue
  states=np.array(allstates);ff=np.rint(states[:,0]/.0002).astype(int);hindex=np.arange(1,len(states)*2,2);(np.savez_compressed if segment==199 else np.savez)(D/'optimized_rollout.npz',time_s=states[:,0],full_state=states,qpos=states[:,1:1+m.nq],qvel=states[:,1+m.nq:off],activation=states[:,off:][:,adrs],excitation=chosen[hindex][:,ids],all_control_10000Hz=chosen,initial_state=z['initial_state'],initial_warmstart=z['initial_warmstart'],joint_angle_rad=states[:,1:1+m.nq][:,qa],target_joint_angle=ref['qpos'][ff][:,qa],qerror_rad=states[:,1:1+m.nq][:,qa]-ref['qpos'][ff][:,qa],muscle_ids=z['muscle_ids'],joint_names=names,segment_offsets=np.array(offsets),boundary_states=np.array(boundaries),boundary_warmstarts=np.array(boundarywarm))
 report=dict(label=label,duration_s=4,segment_duration_s=.02,segments_completed=len(hist),free_muscle_input_parameters_per_segment=130,total_segment_input_parameters=26000,initial_state_unchanged=True,reference_speed_factor=.5,selected_original_interval_s=[0,2],geometry_unchanged=True,max_force_unchanged=True,height_penalty=0,velocity_penalty=0,native_dt_s=.0001,path_objective_sampling_s=.004,endpoint_residual_multiplier=4,right_hind_femur_guard=(label=='B'),foot_residual_multiplier=100,foot_margin_mm=.05,optimization='sequential per-20ms 12-to-32-round bounded finite-difference Gauss-Newton with Broyden/cached input Jacobians, periodic full refresh, targeted worst-joint boundary trials, actual line search and multiscale random candidates; physical and activation state continuously propagated; no shared temporal knots',objective_and_acceptance_unchanged_from_previous=True,resumed_from_segment=resume_segment,minimum_rounds_per_segment=12,maximum_rounds_per_segment=32,jacobian_refresh_every_rounds=8,targeted_worst_joint_search=True,source=str(source),native_rollouts=calls,wall_s=time.monotonic()-clock);(D/'report.json').write_text(json.dumps(report,indent=2));print('FINISHED',label,json.dumps(report),flush=True)
