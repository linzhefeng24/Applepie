# Independent 10 ms segment optimization, 2026-11-06

The same half-speed 0.4 s simulated reference is used. Each variant completes forty consecutive 10 ms segments, integrated with the unchanged native 0.1 ms step. All 130 muscle channels have an independently optimized additive excitation offset in each segment, applied to the previous variant control profile and clipped to [0,1]. Eleven retained nonmuscle controls, model geometry, force and activation parameters are unchanged.

Each segment uses up to eight bounded Gauss-Newton iterations with one-sided native rollout finite differences pointing into the available command range, actual line search, and random candidates. Path angles are sampled every 2 ms; the segment-end angle residual has multiplier four. A tracks all joint angles; B adds a 15 deg right-hind femur error guard with multiplier 20. Both retain soft hind-foot, coxa, twist, tarsus and body-up penalties. Height penalty and velocity penalty are zero.

The committed physical and activation state, including solver warm start, is carried into the next segment. Native candidate and commit trajectories match exactly; complete independent replays verify the final 0.4 s episodes. No intermediate posture resets or external rescue forces are used. Saved controls are at 10 kHz and saved states at 5 kHz.

This changes temporal parameterization and optimization schedule in addition to segment length, so it is not a controlled test of segment duration alone. Old A/B results are preserved, and the new trial does not replace the selected model or controller.

| Metric (deg) | A previous | A 10 ms | B previous | B 10 ms |
|---|---:|---:|---:|---:|
| Full-path angle RMS | 9.3284 | 13.3662 | 9.3720 | 17.5904 |
| Terminal angle RMS | 11.8949 | 18.2020 | 13.9594 | 27.4981 |
| Maximum terminal absolute error | 44.8639 | 82.3284 | 45.9941 | 114.6889 |
| Maximum absolute error over full path | 58.6033 | 82.3284 | 52.6306 | 114.6889 |

See comparison.json and each segments.json for all forty endpoint errors and every optimization round, plus *_validation_report.json for replay and bound checks. joint_capacity_diagnostics.json records fixed-pose conditional force intervals; these are not proofs of whole-trajectory infeasibility.

Video: https://github.com/linzhefeng24/Applepie/blob/main/videos/ten_ms_segments_AB_04s_vs_20ms_005x_20261106.mp4

Download: https://raw.githubusercontent.com/linzhefeng24/Applepie/main/videos/ten_ms_segments_AB_04s_vs_20ms_005x_20261106.mp4

Layout: top row reference / previous A / previous B; bottom row same reference / new A / new B. Full physical 0.4 s, played over 8 s at 0.05x. Native poses are rendered without correction; cameras follow each body independently. Sustained normal walking is not established.
