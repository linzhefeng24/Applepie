import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,time,numpy as np,mujoco
from mujoco import rollout
from scipy.optimize import lsq_linear
R=Path(__file__).resolve().parent;ROOT=R.parent;P=ROOT/'hindleg_correction_20261106'
m=mujoco.MjModel.from_xml_path(str(P/'candidate_muscles.xml'));records=json.loads((P/'candidate_records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];ref=dict(np.load(ROOT/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));qa=ref['joint_qpos_indices'];names=np.load(P/'optimized_rollout.npz')['joint_names'];N=100;SAMPLE=np.array([19,39,59,79,99]);pool=[mujoco.MjData(m) for _ in range(4)];fk=mujoco.MjData(m);state_size=mujoco.mj_stateSize(m,mujoco.mjtState.mjSTATE_FULLPHYSICS);off=1+m.nq+m.nv
thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');feet=[mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,f'walker/claw_T3_{s}') for s in ['left','right']];hip=np.array([int(np.flatnonzero(names==f'walker/coxa_T3_{s}')[0]) for s in ['left','right']]);twist=np.array([int(np.flatnonzero(names==f'walker/femur_twist_T3_{s}')[0]) for s in ['left','right']]);ankle=np.array([int(np.flatnonzero(names==f'walker/tarsus_T3_{s}')[0]) for s in ['left','right']]);femur=int(np.flatnonzero(names=='walker/femur_T3_right')[0]);weights=np.ones(66);weights[44:]=1.5;weights[np.r_[hip,twist]]=3
assert m.opt.timestep==.0001
for label,source in [('A',P/'optimized_rollout.npz'),('B',P/'right_hind_femur_stage/optimized_rollout.npz')]:
 D=R/label;D.mkdir(exist_ok=True);z=dict(np.load(source));base=z['all_control_10000Hz'];chosen=base.copy();d=mujoco.MjData(m);mujoco.mj_setState(m,d,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.qacc_warmstart[:]=z['initial_warmstart'];rng=np.random.default_rng(110600+(label=='B'));allstates=[];boundaries=[z['initial_state'].copy()];boundarywarm=[z['initial_warmstart'].copy()];hist=[];offsets=[];calls=0;clock=time.monotonic()
 for segment in range(40):
  start=segment*N;ctrlbase=base[start:start+N];lower=-np.max(ctrlbase[:,ids],axis=0);upper=1-np.min(ctrlbase[:,ids],axis=0);initial=boundaries[-1];warm=boundarywarm[-1];target=ref['qpos'][(start+SAMPLE+1)//2][:,qa];targetf=(start+SAMPLE+1)//2;rounds=[]
  def evaluate(X):
   global calls
   X=np.atleast_2d(X);C=np.broadcast_to(ctrlbase,(len(X),N,m.nu)).copy();C[:,:,ids]=np.clip(ctrlbase[None,:,ids]+X[:,None,:],0,1);SS,_=rollout.rollout(m,pool,initial[None],C,initial_warmstart=warm[None],persistent_pool=True);calls+=len(X);assert np.isfinite(SS).all();q=SS[:,SAMPLE,1:1+m.nq];err=q[:,:,qa]-target;Y=np.empty((len(X),len(SAMPLE),2));UP=np.empty((len(X),len(SAMPLE)))
   for a in range(len(X)):
    for k in range(len(SAMPLE)):
     fk.qpos[:]=q[a,k];mujoco.mj_kinematics(m,fk);rot=fk.xmat[thorax].reshape(3,3);UP[a,k]=rot[2,2]
     for j,sign in enumerate([1,-1]):Y[a,k,j]=sign*((fk.xpos[feet[j]]-fk.xpos[thorax])@rot)[1]*10
   parts=[(err*weights[None,None]).reshape(len(X),-1),(4*err[:,-1]*weights).reshape(len(X),-1),(100*np.maximum(0,.05-Y)).reshape(len(X),-1),(10*np.maximum(0,np.maximum(-12*np.pi/180-q[:,:,qa[hip]],q[:,:,qa[hip]]-22*np.pi/180))).reshape(len(X),-1),(6*np.maximum(0,abs(err[:,:,twist])-12*np.pi/180)).reshape(len(X),-1),(4*np.maximum(0,abs(err[:,:,ankle])-20*np.pi/180)).reshape(len(X),-1),(3*np.maximum(0,.8-UP)).reshape(len(X),-1)]
   if label=='B':parts.append((20*np.maximum(0,abs(err[:,:,femur])-15*np.pi/180)).reshape(len(X),-1))
   E=np.concatenate(parts,axis=1);stats=[dict(loss=float(np.mean(E[a]**2)),endpoint_rmse_deg=float(np.sqrt(np.mean(err[a,-1]**2))*180/np.pi),max_endpoint_error_deg=float(np.max(abs(err[a,-1]))*180/np.pi),worst_joint=str(names[np.argmax(abs(err[a,-1]))]),min_sampled_outward_foot_mm=float(Y[a].min()),max_sampled_RH_femur_error_deg=float(abs(err[a,:,femur]).max()*180/np.pi)) for a in range(len(X))];return E,stats,C,SS
  x=np.zeros(130);EE,stats,_,_=evaluate(x);e=EE[0];cur=stats[0];before=cur.copy();stagnant=0
  for iteration in range(8):
   h=np.where(upper-x>=x-lower,np.minimum(.04,upper-x),-np.minimum(.04,x-lower));probes=x[None]+np.diag(h);PE,PS,_,_=evaluate(probes);J=((PE-e)/h[:,None]).T;ridge=max(np.linalg.norm(J,'fro')/np.sqrt(130)*.01,1e-7);trust=.5 if stagnant==0 else .2;fit=lsq_linear(np.vstack([J,ridge*np.eye(130)]),np.r_[-e,np.zeros(130)],bounds=(np.maximum(lower-x,-trust),np.minimum(upper-x,trust)),method='bvls',max_iter=200,tol=1e-8);XX=np.vstack([np.clip(x[None]+np.array([1,.5,.2,.05])[:,None]*fit.x,lower,upper),np.clip(x[None]+rng.normal(0,.12,(12,130)),lower,upper)]);CE,CS,_,_=evaluate(XX);pi=int(np.argmin([a['loss'] for a in PS]));ci=int(np.argmin([a['loss'] for a in CS]));improved=False
   if PS[pi]['loss']<cur['loss']-1e-12:x=probes[pi].copy();e=PE[pi].copy();cur=PS[pi];improved=True
   if CS[ci]['loss']<cur['loss']-1e-12:x=XX[ci].copy();e=CE[ci].copy();cur=CS[ci];improved=True
   stagnant=0 if improved else stagnant+1;rounds.append(dict(iteration=iteration+1,accepted=improved,**cur))
   if cur['max_endpoint_error_deg']<1 or (stagnant>=3 and iteration>=3):break
  _,_,CC,SS=evaluate(x);chosen[start:start+N]=CC[0];maxerr=0
  for k in range(N):
   d.ctrl[:]=CC[0,k];mujoco.mj_step(m,d);s=np.empty(state_size);mujoco.mj_getState(m,d,s,mujoco.mjtState.mjSTATE_FULLPHYSICS);maxerr=max(maxerr,float(abs(s-SS[0,k]).max()))
   if k%2:allstates.append(s.copy())
  assert maxerr<1e-9;assert np.all((d.act[adrs]>=0)&(d.act[adrs]<=1));boundaries.append(s.copy());boundarywarm.append(d.qacc_warmstart.copy());offsets.append(x.copy());row=dict(segment=segment+1,start_s=start*.0001,end_s=(start+N)*.0001,before=before,after=cur,rounds=rounds,candidate_commit_max_state_error=maxerr,rollouts=calls,wall_s=time.monotonic()-clock);hist.append(row);(D/'segments.json').write_text(json.dumps(hist,indent=2));print(label,'SEGMENT',segment+1,json.dumps(dict(**cur,rounds=len(rounds),rollouts=calls,wall_s=time.monotonic()-clock)),flush=True)
  states=np.array(allstates);ff=np.rint(states[:,0]/.0002).astype(int);hindex=np.arange(1,len(states)*2,2);np.savez_compressed(D/'optimized_rollout.npz',time_s=states[:,0],full_state=states,qpos=states[:,1:1+m.nq],qvel=states[:,1+m.nq:off],activation=states[:,off:][:,adrs],excitation=chosen[hindex][:,ids],all_control_10000Hz=chosen,initial_state=z['initial_state'],initial_warmstart=z['initial_warmstart'],joint_angle_rad=states[:,1:1+m.nq][:,qa],target_joint_angle=ref['qpos'][ff][:,qa],qerror_rad=states[:,1:1+m.nq][:,qa]-ref['qpos'][ff][:,qa],muscle_ids=z['muscle_ids'],joint_names=names,segment_offsets=np.array(offsets),boundary_states=np.array(boundaries),boundary_warmstarts=np.array(boundarywarm))
 report=dict(label=label,duration_s=.4,segment_duration_s=.01,segments_completed=len(hist),free_muscle_input_parameters_per_segment=130,total_segment_input_parameters=5200,initial_state_unchanged=True,geometry_unchanged=True,max_force_unchanged=True,height_penalty=0,velocity_penalty=0,native_dt_s=.0001,path_objective_sampling_s=.002,endpoint_residual_multiplier=4,right_hind_femur_guard=(label=='B'),foot_residual_multiplier=100,foot_margin_mm=.05,optimization='sequential per-10ms bounded finite-difference Gauss-Newton plus random candidates; physical and activation state continuously propagated; no shared temporal knots',source=str(source),native_rollouts=calls,wall_s=time.monotonic()-clock);(D/'report.json').write_text(json.dumps(report,indent=2));print('FINISHED',label,json.dumps(report),flush=True)
