import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,numpy as np,mujoco,sys
R=Path(__file__).resolve().parent;P=R.parent/'hindleg_correction_20261106';label=sys.argv[1] if len(sys.argv)>1 else 'A';z=dict(np.load(R/label/'optimized_rollout.npz'));ref=dict(np.load(R.parent/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));records=json.loads((P/'candidate_records.json').read_text())['records'];m=mujoco.MjModel.from_xml_path(str(P/'candidate_muscles.xml'));d=mujoco.MjData(m);ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];qa=ref['joint_qpos_indices'];dofs=ref['joint_dof_indices'];mom=np.zeros((m.nu,m.nv));out=[]
for frame in np.arange(49,len(z['qpos']),50):
 err=z['qerror_rad'][frame];j=int(np.argmax(abs(err)));d.qpos[:]=z['qpos'][frame];d.qvel[:]=z['qvel'][frame];d.act[adrs]=z['activation'][frame];u=z['all_control_10000Hz'][frame*2+1];d.ctrl[:]=u;mujoco.mj_forward(m,d);mujoco.mju_sparse2dense(mom,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);F=[];actual=d.actuator_force[ids].copy()
 for level in [0,1]:d.act[adrs]=level;mujoco.mj_fwdActuation(m,d);F.append(d.actuator_force[ids].copy())
 tau0=mom[ids,dofs[j]]*F[0]*1e-7;tau1=mom[ids,dofs[j]]*F[1]*1e-7;gain=tau1-tau0;want=-np.sign(err[j]);related=np.flatnonzero(abs(gain)>1e-14);muscles=[dict(id=records[i]['id'],u=float(u[ids[i]]),a=float(z['activation'][frame,i]),torque_gain_Nm=float(gain[i]),toward=bool(want*gain[i]>0)) for i in related];out.append(dict(time_s=float(z['time_s'][frame]),joint=str(z['joint_names'][j]),error_deg=float(err[j]*180/np.pi),instantaneous_activation_torque_interval_Nm=[float(np.minimum(tau0,tau1).sum()),float(np.maximum(tau0,tau1).sum())],actual_muscle_torque_Nm=float(mom[ids,dofs[j]]@actual*1e-7),muscles=muscles))
(R/label/'joint_capacity_diagnostics.json').write_text(json.dumps(out,indent=2));print(json.dumps(out[-1],indent=2))
