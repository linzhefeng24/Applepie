"""Build six-leg MuJoCo muscle mechanics with explicit evidence/estimate separation."""
from pathlib import Path
import json,copy,hashlib,xml.etree.ElementTree as E
import numpy as np,mujoco
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent
SRC=Path('/workspace/fly-walking-run/output/model/walking.xml')
PRIORS=Path('/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json')
legacy=json.loads((PROJECT/'model/geometry.json').read_text());priors=json.loads(PRIORS.read_text());prior={r['id']:r for r in priors['muscles']};old={r['id']:r for r in legacy['records']}
fmroot=PROJECT/'flymimic_adoption';fm=json.loads((fmroot/'manifest.json').read_text());fm_xml=fmroot/'models'/fm['selected_xml'];source_m=mujoco.MjModel.from_xml_path(str(fm_xml));source_d=mujoco.MjData(source_m)
source_dir=next(Path('/workspace/fly-platforms/FlyMimic/code').iterdir());source_q=np.load(source_dir/'flymimic/assets/mocap/qpos/0002.npy')[0]
source_d.qpos[:7]=source_q;mujoco.mj_kinematics(source_m,source_d)
base_m=mujoco.MjModel.from_xml_path(str(SRC));base_d=mujoco.MjData(base_m)
reference=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');base_d.qpos[:]=reference['qpos'][0];mujoco.mj_kinematics(base_m,base_d)
legs=['LF','RF','LM','RM','LH','RH'];tokens=dict(zip(legs,['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right']))
def bid(m,n):
 i=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,n)
 if i<0:raise ValueError(n)
 return i

def endpoint(m,d,b,child):
 c=bid(m,child);return d.xmat[b].reshape(3,3).T@(d.xpos[c]-d.xpos[b])

def frame(m,d,b,axis,up):
 e=axis/np.linalg.norm(axis);localup=d.xmat[b].reshape(3,3).T@up
 z=localup-e*(localup@e)
 if np.linalg.norm(z)<1e-5:
  localup=d.xmat[b].reshape(3,3).T@np.array([0.,1.,0.]);z=localup-e*(localup@e)
 z/=np.linalg.norm(z);y=np.cross(z,e);return np.column_stack([e,y,z])

src_bones={
 'LFCoxa':('LFCoxa','LFTrochanter','coxa','femur'),
 'LFTrochanter':('LFTrochanter','LFTibia','femur','tibia'),
 'LFFemur':('LFTrochanter','LFTibia','femur','tibia'),
 'LFTibia':('LFTibia','LFTarsus1','tibia','tarsus')}
registration=[]
def port_point(pt,leg):
 sb=pt['body'];p=np.asarray(pt['local_position_native']);tok=tokens[leg]
 if sb=='Thorax':
  # Anchor thoracic sites relative to each coxa insertion. Mirror RF explicitly.
  s=bid(source_m,'Thorax');sc=bid(source_m,'LFCoxa');t=bid(base_m,'walker/thorax');tc=bid(base_m,'walker/coxa_'+tok)
  sp=source_d.xpos[s]+source_d.xmat[s].reshape(3,3)@p
  delta=sp-source_d.xpos[sc]
  s_axis=endpoint(source_m,source_d,sc,'LFTrochanter');t_axis=endpoint(base_m,base_d,tc,'walker/femur_'+tok)
  ratio=np.linalg.norm(t_axis)/np.linalg.norm(s_axis)
  # Align animal heading/up using head and thorax, not similarly named Euler angles.
  sh=source_d.xpos[bid(source_m,'Head')]-source_d.xpos[s];th=base_d.xpos[bid(base_m,'walker/head')]-base_d.xpos[t]
  def animal(a):
   z=np.array([0.,0.,1.]);x=a-z*(a@z);x/=np.linalg.norm(x);return np.column_stack([x,np.cross(z,x),z])
  S=animal(sh);T=animal(th);coeff=S.T@delta
  if leg=='RF':coeff[1]*=-1
  target=base_d.xpos[tc]+T@coeff*ratio
  local=base_d.xmat[t].reshape(3,3).T@(target-base_d.xpos[t])
  return 'walker/thorax',local,{'method':'thoracic coxa-anchored anatomical frame registration','scale_native':float(ratio),'measured_target_attachment':False}
 if sb not in src_bones:raise ValueError('Unexpected upstream site body '+sb)
 sroot,schild,troot,tchild=src_bones[sb];s=bid(source_m,sroot);sbody=bid(source_m,sb);tname='walker/'+troot+'_'+tok;t=bid(base_m,tname)
 sp=source_d.xpos[sbody]+source_d.xmat[sbody].reshape(3,3)@p
 p=source_d.xmat[s].reshape(3,3).T@(sp-source_d.xpos[s])
 sa=endpoint(source_m,source_d,s,schild);ta=endpoint(base_m,base_d,t,'walker/'+tchild+'_'+tok)
 S=frame(source_m,source_d,s,sa,np.array([0.,0.,1.]));T=frame(base_m,base_d,t,ta,np.array([0.,0.,1.]));coeff=S.T@p
 if leg=='RF':coeff[1]*=-1
 ratio=np.linalg.norm(ta)/np.linalg.norm(sa);local=T@coeff*ratio
 return tname,local,{'method':'proximal/distal bone-axis and dorsal frame similarity registration','scale_native':float(ratio),'measured_target_attachment':False}

mapping={
'LFC_tergopleural_promotor_a':['tergopleural_promotor'], 'LFC_tergopleural_promotor_b':['tergopleural_promotor'],
'LFC_pleural_remotor_and_abductor':['pleural_remotor_and_abductor'],'LFC_pleural_promotor':['pleural_promotor'],
'LFC_sternal_anterior_rotator':['sternal_anterior_rotator'],'LFC_sternal_posterior_rotator':['sternal_posterior_rotator'],'LFC_sternal_adductor':['sternal_adductor'],
'LFF_trochanter_flexor_a':['trochanter_flexor'],'LFF_trochanter_flexor_b':['trochanter_flexor'],
'LFF_sterno-tergo-trochanter_extensor_a':['sternotrochanter_extensor','tergotrochanter_extensor'],
'LFF_sterno-tergo-trochanter_extensor_b':['sternotrochanter_extensor','tergotrochanter_extensor'],
'LFF_accesory_trochanter_flexor':['accessory_trochanter_flexor'],'LFF_trochanter_extensor':['trochanter_extensor'],
'LFTibia_flex_93434':['tibia_flexor'],'LFTibia_extensor_93932':['tibia_extensor']}
rows=[]
for leg in legs:
 used=set()
 if leg in ['LF','RF']:
  # Within each category/group share a single pre-existing volume budget.
  group_counts={}
  for rec in fm['records']:
   cats=tuple(sorted(mapping[rec['upstream_name']]));group_counts[cats]=group_counts.get(cats,0)+1
  for rec in fm['records']:
   cats=tuple(sorted(mapping[rec['upstream_name']]));ids=[leg+':'+c for c in cats];used.update(ids);points=[];reg=[]
   for pt in rec['path']:
    name,pos,info=port_point(pt,leg);points.append({'body':name,'pos_cm':pos.tolist()});reg.append(info)
   rows.append({'id':leg+':FlyMimic:'+rec['upstream_name'],'leg':leg,'catalog_ids':ids,'points':points,'source_actuator':rec['actuator_attributes'],'geometry_status':'FlyMimic LF template registered to flybody; target attachments estimated' if leg=='LF' else 'bilateral symmetry and bone registration estimate from LF; not measured RF anatomy','registration':reg,'source_group_budget_fraction':1/group_counts[cats],'source_family':'FlyMimic','uncertainty':'Cross-specimen and frame transfer; merged extensor names remain an unresolved functional group' if len(ids)>1 else 'Cross-specimen geometry transfer; representative MTU/category granularity differs'})
 for id,rec in old.items():
  if rec['leg']!=leg or id in used:continue
  rows.append({'id':id,'leg':leg,'catalog_ids':[id],'points':[{'body':p['body'],'pos_cm':p['pos_cm']} for p in rec['points']],'source_family':'existing multi-study six-leg evidence and bounded geometry hypothesis','geometry_status':rec['geometry_role'],'source_group_budget_fraction':1.,'uncertainty':rec['uncertainty'],'long_tendon_claw_dof_missing':rec['long_tendon_claw_dof_missing']})

xml=E.parse(SRC);root=xml.getroot();compiler=root.find('compiler');compiler.set('meshdir',str(SRC.parent));compiler.set('texturedir',str(SRC.parent));root.find('option').set('timestep','0.0001')
bodies={b.get('name'):b for b in root.iter('body')};tendon=root.find('tendon');act=root.find('actuator')
removed=[]
for a in list(act):
 if any(s in a.get('name','') for s in ['coxa','femur','tibia','tarsus']) and a.tag!='adhesion':removed.append(a.get('name'));act.remove(a)
assert len(removed)==48
for idx,r in enumerate(rows):
 name='sixleg_'+str(idx)+'_'+r['leg'];r['tendon_name']=name;r['actuator_name']=name+'_muscle';t=E.SubElement(tendon,'spatial',name=name,limited='false',width='.0002',rgba='0.1 0.4 0.9 1')
 for k,p in enumerate(r['points']):
  s=name+'_p'+str(k);E.SubElement(bodies[p['body']],'site',name=s,pos=' '.join(map(str,p['pos_cm'])),size='.0001',rgba='0 0 0 0');E.SubElement(t,'site',site=s);p['site']=s
pre=ROOT/'geometry_only.xml';xml.write(pre,encoding='unicode');model=mujoco.MjModel.from_xml_path(str(pre));d=mujoco.MjData(model)
tids=np.array([mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_TENDON,r['tendon_name']) for r in rows]);L=[]
for q in reference['qpos'][np.linspace(0,len(reference['qpos'])-1,128,dtype=int)]:
 d.qpos[:]=q;mujoco.mj_kinematics(model,d);mujoco.mj_comPos(model,d);mujoco.mj_tendon(model,d);L.append(d.ten_length[tids]*.01)
L=np.asarray(L)
for j,r in enumerate(rows):
 ps=[prior[id] for id in r['catalog_ids']];fraction=r['source_group_budget_fraction']
 V=sum(p['estimated']['muscle_volume_m3']['initial'] for p in ps)*fraction
 l0lo=max(p['estimated']['optimal_fiber_length_m']['working'][0] for p in ps);l0hi=min(p['estimated']['optimal_fiber_length_m']['working'][1] for p in ps)
 l0initial=np.mean([p['estimated']['optimal_fiber_length_m']['initial'] for p in ps]);l0=float(np.clip(max(l0initial,np.ptp(L[:,j])/1.4),l0lo,l0hi))
 # Preserve a positive fiber domain on sampled teacher poses; no torque is used.
 slack=max(0.,min(float(L[:,j].min())-.25*l0,float(L[0,j])-l0))
 area=V/l0;area_hi=sum(p['estimated']['physiological_cross_sectional_area_m2']['working'][1] for p in ps)*fraction
 area=min(area,area_hi);V=area*l0;stress=min(p['estimated']['specific_stress_Pa']['initial'] for p in ps);F0=area*stress
 if 'source_actuator' in r:
  gain=list(map(float,r['source_actuator']['gainprm'].split()));gain[2]=F0*1e5
  tau=list(map(float,r['source_actuator']['dynprm'].split()))[:2]
  r['curve_source']='upstream MuJoCo normalized gain/bias curve, strength recalibrated from existing bounded PCSA/volume/stress priors'
 else:
  # Same native MuJoCo Hill family as FlyMimic; use each category's prior vmax.
  gain=[.5,1.5,F0*1e5,1.,0.,2.,float(np.mean([p['estimated']['vmax_optimal_fiber_lengths_per_s']['initial'] for p in ps])),1.3,1.4,0.]
  tau=[float(np.mean([p['estimated']['activation_tau_s']['initial'] for p in ps])),float(np.mean([p['estimated']['deactivation_tau_s']['initial'] for p in ps]))]
  r['curve_source']='FlyMimic/MuJoCo muscle equation family; curve values and activation rates are engineering priors, not measured per-muscle curves'
 r.update(fiber_length0_m=l0,tendon_slack_length_m=slack,muscle_volume_m3=V,PCSA_m2=area,F0_N=F0,specific_stress_Pa=stress,activation_time_constants_s=tau,gainprm_native=gain,normalized_fiber_length_sample_min=float(np.min((L[:,j]-slack)/l0)),normalized_fiber_length_sample_max=float(np.max((L[:,j]-slack)/l0)))
 E.SubElement(act,'general',name=r['actuator_name'],tendon=r['tendon_name'],ctrllimited='true',ctrlrange='0 1',dyntype='muscle',gaintype='muscle',biastype='muscle',dynprm=' '.join(map(str,tau)),gainprm=' '.join(map(str,gain)),biasprm=' '.join(map(str,gain)),lengthrange=f'{(slack+gain[0]*l0)*100:.15g} {(slack+gain[1]*l0)*100:.15g}',gear='1')
path=ROOT/'six_leg_muscles.xml';xml.write(path,encoding='unicode');m=mujoco.MjModel.from_xml_path(str(path));mujoco.mj_saveModel(m,str(ROOT/'six_leg_muscles.mjb'),None)
for r in rows:r['actuator_index']=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_ACTUATOR,r['actuator_name']);r['tendon_index']=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_TENDON,r['tendon_name'])
covered={id for r in rows for id in r['catalog_ids']};assert covered==set(prior),(len(covered),len(prior))
meta={'schema':'six_leg_flymimic_family_v1','status':'operational six-leg working model; anatomical estimates require validation','units':{'length':'cm','mass':'g','time':'s','force':'dyne','hinge_torque':'dyne*cm','force_native_to_N':1e-5,'hinge_torque_native_to_Nm':1e-7},'model':str(path),'runtime':'/workspace/fly-platforms/reproduction/venv-flymimic/bin/python','mujoco':mujoco.__version__,'base_model':str(SRC),'upstream_template':str(fm_xml),'muscle_channels':len(rows),'catalog_slots_covered':len(covered),'per_leg':{leg:sum(r['leg']==leg for r in rows) for leg in legs},'native_leg_motors_removed':removed,'retained_other_actuators':m.nu-len(rows),'strength_policy':'Each catalog/group initial volume and stress budget, split over representative MTUs; no source native-force-to-SI guess and no recorded torques used','geometry_calibration_uses':'128 reference postures only, no torque targets','kinematic_limitations':['Original flybody leg joint structure retained; transferred paths are geometry hypotheses, not the unchanged source skeleton.','No independently movable claw joint added; long-tendon categories are routing proxies.','No imported identified motor-unit weights.'],'records':rows,'source_hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [SRC,PRIORS,PROJECT/'model/geometry.json',fm_xml]}}
evidence=json.loads(Path('/workspace/flybrain-muscle-rebuild/brain.json').read_text())
catalog={r['id']:r for r in evidence['muscle_table']['catalog']}
for r in rows:
 r['anatomy_source_ids']=sorted({s for id in r['catalog_ids'] for s in catalog[id].get('anatomy_sources',[])})
 r['evidence_catalog_path']='/workspace/flybrain-muscle-rebuild/brain.json#muscle_table.catalog'
if (ROOT/'middle_hind_uncertainty.json').exists():
 meta['middle_hind_uncertainty']={'uncertainty_file':str(ROOT/'middle_hind_uncertainty.json'),'range_table':str(ROOT/'middle_hind_parameter_ranges.csv'),'implementation':str(ROOT/'uncertainty.py'),'muscles':80,'measured_unknown_values_remain_null':True,'initial_values_are_estimates':True,'calibration_performed':False}
 for r in rows:
  if r['leg'] in ['LM','RM','LH','RH']:r['uncertainty_record_id']=r['id'];r['parameter_status']='unknown measured values; bounded estimates and current simulation initial values stored separately'
(ROOT/'manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));print(json.dumps({k:meta[k] for k in ['muscle_channels','catalog_slots_covered','per_leg','retained_other_actuators']},indent=2))
