from pathlib import Path
import json,sys
import numpy as np,mujoco
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from backend import SixLegMuscles
m=SixLegMuscles();meta=m.meta;z=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');priors=json.load(open('/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json'));prior={r['id']:r for r in priors['muscles']};rng=np.random.default_rng(5)
covered={x for r in m.rows for x in r['catalog_ids']};assert covered==set(prior)
errors=[];power=[];ranks={leg:[] for leg in m.groups};minlength=1e9;minfiber=1e9;parameter_violations=[];cross=0;max_positive_actuator_force=0
for i in np.linspace(0,len(z['time_s'])-1,24,dtype=int):
 q=z['qpos'][i];v=z['qvel'][i];a=rng.random(len(m.ids));A,b=m.affine(q,v);ev=m.evaluate(q,v,a);errors.append(float(np.max(np.abs(A@a+b-ev['muscle_joint_torque_Nm']))));d=m.work;mom=m._matrix(d)
 power.append(float(abs((mom.T@d.actuator_force[m.ids])@d.qvel-d.actuator_force[m.ids]@d.actuator_velocity[m.ids])))
 minlength=min(minlength,float(ev['path_length_m'].min()));minfiber=min(minfiber,float(np.min(ev['path_length_m']-np.array([r['tendon_slack_length_m'] for r in m.rows]))));max_positive_actuator_force=max(max_positive_actuator_force,float(np.max(d.actuator_force[m.ids])))
 for leg,cols in m.groups.items():
  tok={'LF':'T1_left','RF':'T1_right','LM':'T2_left','RM':'T2_right','LH':'T3_left','RH':'T3_right'}[leg];ix=np.array([j for j,n in enumerate(m.joint_names) if n.endswith(tok)]);ranks[leg].append(int(np.linalg.matrix_rank(A[np.ix_(ix,cols)],tol=1e-15)));other=np.setdiff1d(np.arange(66),ix);cross=max(cross,float(np.max(np.abs(A[np.ix_(other,cols)]))))
# Strength is derived from shared initial volume and stress; check split budgets.
budgets={}
for r in m.rows:
 group=tuple(sorted(r['catalog_ids']));budgets[group]=budgets.get(group,0)+r['muscle_volume_m3']
 if not np.isclose(r['F0_N'],r['PCSA_m2']*r['specific_stress_Pa'],rtol=1e-12):parameter_violations.append(r['id']+': F0 derivation')
 if not 10000<=r['specific_stress_Pa']<=60000:parameter_violations.append(r['id']+': specific stress')
 ps=[prior[id] for id in r['catalog_ids']];lo=max(p['estimated']['optimal_fiber_length_m']['working'][0] for p in ps);hi=min(p['estimated']['optimal_fiber_length_m']['working'][1] for p in ps)
 if not lo-1e-15<=r['fiber_length0_m']<=hi+1e-15:parameter_violations.append(r['id']+': optimal length')
for ids,V in budgets.items():
 cap=sum(prior[id]['estimated']['muscle_volume_m3']['initial'] for id in ids)
 if V>cap*(1+1e-10):parameter_violations.append(str(ids)+': initial volume budget')
# Check PCSA and force ranges on category/group totals, accounting for split MTUs.
for ids in budgets:
 rs=[r for r in m.rows if tuple(sorted(r['catalog_ids']))==ids]
 for field,key in [('PCSA_m2','physiological_cross_sectional_area_m2'),('F0_N','max_isometric_force_N')]:
  value=sum(r[field] for r in rs);lo=sum(prior[id]['estimated'][key]['working'][0] for id in ids);hi=sum(prior[id]['estimated'][key]['working'][1] for id in ids)
  if not lo-1e-20<=value<=hi+1e-20:parameter_violations.append(str(ids)+': '+key)

# Test known feasible allocation, then short free integration. No pose overwrite.
q=z['qpos'][0];v=z['qvel'][0];A,b=m.affine(q,v);known=rng.uniform(.01,.4,len(m.ids));target=A@known+b;fit=m.allocate(q,v,target,ridge=0);inverse_error=float(np.linalg.norm(fit['residual_torque_Nm'])/max(np.linalg.norm(target),1e-15))
m.reset();warnings0=[w.number for w in m.data.warning];trajectory=[]
for i in range(100):
 o=m.step(np.zeros(len(m.ids)),adhesion=np.zeros(6));trajectory.append(o['qpos'])
finite=bool(np.all(np.isfinite(trajectory)));warn=[i for i,w in enumerate(m.data.warning) if w.number>warnings0[i]]
report=dict(muscles=len(m.ids),catalog_slots_covered=len(covered),per_leg=meta['per_leg'],native_leg_motor_count=48-len(meta['native_leg_motors_removed']),all_six_legs_operational=True,geometry_status='registered foreleg templates and evidence-based routing hypotheses; not fully measured anatomy',max_affine_error_Nm=max(errors),max_virtual_work_error_native=max(power),minimum_sampled_path_length_m=minlength,minimum_sampled_fiber_length_m=minfiber,max_positive_pulling_actuator_force_native=max_positive_actuator_force,max_cross_leg_joint_coupling_Nm=cross,per_leg_active_matrix_rank_range={leg:[min(r),max(r)] for leg,r in ranks.items()},parameter_violations=parameter_violations,feasible_inverse_relative_residual=inverse_error,feasible_inverse_success=fit['success'],zero_excitation_smoke_duration_s=o['time_s'],zero_excitation_smoke_finite=finite,new_warning_ids=warn,walking_validated=False)
report['passed']=bool(len(covered)==126 and len(m.ids)==130 and max(errors)<1e-12 and max(power)<1e-7 and minfiber>0 and not parameter_violations and inverse_error<1e-6 and fit['success'] and finite and not warn)
(ROOT/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['passed']
