from pathlib import Path
import sys,json
import numpy as np,mujoco
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));from backend import SixLegMuscles
m=SixLegMuscles();q=m.initial_q.copy();v=np.zeros(m.model.nv);A,b=m.affine(q,v);d=m.work
mujoco.mj_kinematics(m.model,d)
def bid(n):return mujoco.mj_name2id(m.model,mujoco.mjtObj.mjOBJ_BODY,n)
thorax=bid('walker/thorax');head=bid('walker/head');heading=d.xpos[head]-d.xpos[thorax];heading[2]=0;heading/=np.linalg.norm(heading)
tokens={'LF':'T1_left','RF':'T1_right','LM':'T2_left','RM':'T2_right','LH':'T3_left','RH':'T3_right'}
def coordinate(leg,kind):
 tok=tokens[leg];body=lambda seg:d.xpos[bid('walker/'+seg+'_'+tok)]
 if kind=='promotion':return float((body('femur')-d.xpos[thorax])@heading)
 if kind=='tibia_folding':return -float(np.linalg.norm(body('tarsus')-body('femur')))
 return -float(np.linalg.norm(body('tibia')-body('coxa')))
results=[]
for leg,channelids in m.groups.items():
 tok=tokens[leg];jcols=np.array([i for i,n in enumerate(m.joint_names) if n.endswith(tok)])
 for cat,kind,sign in [('tergopleural_promotor','promotion',1),('pleural_promotor','promotion',1),('pleural_remotor_and_abductor','promotion',-1),('tibia_flexor','tibia_folding',1),('tibia_extensor','tibia_folding',-1),('trochanter_flexor','trochanter_folding',1),('trochanter_extensor','trochanter_folding',-1)]:
  grad=np.zeros(66)
  for j in jcols:
   adr=m.qadrs[j];h=1e-6;d.qpos[:]=q;d.qpos[adr]+=h;mujoco.mj_kinematics(m.model,d);plus=coordinate(leg,kind);d.qpos[:]=q;d.qpos[adr]-=h;mujoco.mj_kinematics(m.model,d);minus=coordinate(leg,kind);grad[j]=(plus-minus)/(2*h)
  d.qpos[:]=q;mujoco.mj_kinematics(m.model,d)
  for k in channelids:
   r=m.rows[k]
   if leg+':'+cat not in r['catalog_ids']:continue
   score=float(sign*grad@A[:,k]);norm=float(np.linalg.norm(grad)*np.linalg.norm(A[:,k]));cos=score/max(norm,1e-30)
   results.append({'id':r['id'],'functional_category':cat,'coordinate_proxy':kind,'directional_cosine':cos,'status':'compatible_at_reference' if cos>1e-6 else 'opposes_proxy_at_reference' if cos< -1e-6 else 'uninformative_at_reference','interpretation':'local geometric action proxy; not measured in vivo and not a proof across all poses'})
report={'reference_state':'first recorded teacher pose','counts':{s:sum(r['status']==s for r in results) for s in ['compatible_at_reference','opposes_proxy_at_reference','uninformative_at_reference']},'records':results,'automatic_rerouting_or_parameter_change':False}
(ROOT/'direction_audit.json').write_text(json.dumps(report,indent=2));print(report['counts'])
