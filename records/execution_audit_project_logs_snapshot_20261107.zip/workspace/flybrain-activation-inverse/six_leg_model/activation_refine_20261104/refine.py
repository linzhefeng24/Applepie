import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,copy,time,hashlib,xml.etree.ElementTree as E
import numpy as np,mujoco
from scipy.optimize import lsq_linear
from scipy.spatial import ConvexHull
ROOT=Path(__file__).resolve().parent;PREV=ROOT.parent/'activation_fit_20261104';sys.path.insert(0,str(PREV));from fit import Problem,sha

def vertices(m,b):
 ids=np.flatnonzero((m.geom_bodyid==b)&(m.geom_type==int(mujoco.mjtGeom.mjGEOM_MESH)))
 if not len(ids):return None
 bodyname=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,b);g=next((int(i) for i in ids if mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,int(i))==bodyname),int(ids[0]));mesh=m.geom_dataid[g];a=m.mesh_vertadr[mesh];V=m.mesh_vert[a:a+m.mesh_vertnum[mesh]].astype(float);R=np.empty(9);mujoco.mju_quat2Mat(R,m.geom_quat[g]);return V@R.reshape(3,3).T+m.geom_pos[g]

def prepare():
 P=Problem();m=P.b.model;d=P.b.work;Q=P.z['qpos'];W=P.z['qvel'];indices=np.unique(np.r_[0,P.split['train'],P.split['validation'],P.split['test']]);bodies=sorted({pt['body'] for r in P.b.rows for pt in r['points']});bids=np.array([mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,b) for b in bodies]);nb=len(bids);nf=len(indices)
 X=np.empty((nf,nb,3));R=np.empty((nf,nb,3,3));JP=np.empty((nf,nb,3,m.nv));JR=np.empty_like(JP)
 for f,i in enumerate(indices):
  d.qpos[:]=Q[i];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);X[f]=d.xpos[bids];R[f]=d.xmat[bids].reshape(nb,3,3)
  for k,b in enumerate(bids):mujoco.mj_jacBody(m,d,JP[f,k],JR[f,k],int(b))
 np.savez(ROOT/'kinematics.npz',indices=indices,bodies=np.array(bodies),X=X,R=R,JP=JP,JR=JR,qvel=W[indices])
 patches={}
 for r in P.b.rows:
  radius=min(P.prior[id]['estimated']['attachment_location_uncertainty_m']['initial_radius'] for id in r['catalog_ids'])*100
  for pt in r['points']:
   p=np.array(pt['pos_cm']);V=vertices(m,mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,pt['body']));choices=[];inside=False
   if V is not None:
    eq=ConvexHull(V).equations;inside=bool(np.max(eq[:,:3]@p+eq[:,3])<1e-9);within=V[np.linalg.norm(V-p,axis=1)<=radius]
    if len(within):
     selected={int(np.argmin(np.linalg.norm(within-p,axis=1)))}
     for axis in range(3):selected.update([int(np.argmin(within[:,axis])),int(np.argmax(within[:,axis]))])
     for target in within[sorted(selected)]:
      for alpha in ([.35,.7] if inside else [1.]):choices.append((p+alpha*(target-p)).tolist())
   patches[pt['site']]={'initial_position_cm':p.tolist(),'body':pt['body'],'maximum_displacement_cm':radius,'initial_inside_mesh_convex_hull':inside,'candidate_positions_cm':choices,'candidate_rule':'same-body local mesh patch; convex interpolation only when initial lies in convex hull'}
 (ROOT/'attachment_candidates.json').write_text(json.dumps(patches,indent=2));print('cached',nf,'poses',nb,'bodies',len(patches),'attachment patches',flush=True)

def prepare_full():
 P=Problem();m=P.b.model;d=P.b.work;K=np.load(ROOT/'kinematics.npz');bodies=K['bodies'].tolist();bids=np.array([mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,b) for b in bodies]);Q=P.z['qpos'];N=len(Q);X=np.lib.format.open_memmap(ROOT/'full_X.npy',mode='w+',dtype='f8',shape=(N,len(bids),3));R=np.lib.format.open_memmap(ROOT/'full_R.npy',mode='w+',dtype='f8',shape=(N,len(bids),3,3))
 for i,q in enumerate(Q):
  d.qpos[:]=q;mujoco.mj_kinematics(m,d);X[i]=d.xpos[bids];R[i]=d.xmat[bids].reshape(len(bids),3,3)
 X.flush();R.flush();print('full posture-domain cache ready',N,flush=True)

class Refine:
 def __init__(self):
  self.P=Problem();self.K={k:v for k,v in np.load(ROOT/'kinematics.npz').items()};self.body={b:i for i,b in enumerate(self.K['bodies'].tolist())};self.frame={int(i):f for f,i in enumerate(self.K['indices'])};self.train=np.array([self.frame[int(i)] for i in self.P.split['train']]);self.test=np.array([self.frame[int(i)] for i in self.P.split['test']]);self.val=np.array([self.frame[int(i)] for i in self.P.split['validation']]);self.initial=copy.deepcopy(json.load(open(PREV/'optimized_model_records.json'))['records']);self.gain=np.load(PREV/'optimized_parameters.npz')['gain'];self.lr=np.load(PREV/'optimized_parameters.npz')['lengthrange'];self.patches=json.load(open(ROOT/'attachment_candidates.json'));self.fullX=np.load(ROOT/'full_X.npy',mmap_mode='r');self.fullR=np.load(ROOT/'full_R.npy',mmap_mode='r')
 def mechanics(self,row,positions,leg):
  g=self.P.groups[leg];dofs=self.P.b.dofs[g['joints']];points=[];jac=[]
  for pt in row['points']:
   bi=self.body[pt['body']];p=np.asarray(positions[pt['site']]);offset=np.einsum('fij,j->fi',self.K['R'][:,bi],p);points.append(self.K['X'][:,bi]+offset);jp=self.K['JP'][:,bi][:,:,dofs];jr=self.K['JR'][:,bi][:,:,dofs];jac.append(jp+np.cross(jr.transpose(0,2,1),offset[:,None,:]).transpose(0,2,1))
  length=np.zeros(len(self.K['indices']));J=np.zeros((len(length),11));segments=[]
  for i in range(len(points)-1):
   delta=points[i+1]-points[i];L=np.linalg.norm(delta,axis=1)
   if np.any(L<1e-8):raise ValueError('zero segment')
   unit=delta/L[:,None];length+=L;J+=np.einsum('fi,fij->fj',unit,jac[i+1]-jac[i]);segments.append(unit[0])
  velocity=np.einsum('fi,fi->f',J,self.K['qvel'][:,dofs]);return length,velocity,J,np.asarray(segments)
 def column(self,row,k,positions,leg,gain=None,lr=None):
  length,velocity,J,segments=self.mechanics(row,positions,leg);gain=self.gain[k] if gain is None else gain;lr=self.lr[k] if lr is None else lr
  if np.any(length*.01-row['tendon_slack_length_m']<=0):raise ValueError('nonpositive sampled fiber')
  force=np.array([mujoco.mju_muscleGain(l,v,lr,self.P.base['acc0'][k],gain) for l,v in zip(length,velocity)]);bias=np.array([mujoco.mju_muscleBias(l,lr,self.P.base['acc0'][k],gain) for l in length]);return J*force[:,None]*1e-7,J*bias[:,None]*1e-7,J,segments
 def positive_full_domain(self,row,positions):
  length=np.zeros(len(self.fullX));last=None
  for pt in row['points']:
   bi=self.body[pt['body']];point=self.fullX[:,bi]+np.einsum('fij,j->fi',self.fullR[:,bi],positions[pt['site']])
   if last is not None:length+=np.linalg.norm(point-last,axis=1)
   last=point
  return bool(np.min(length*.01-row['tendon_slack_length_m'])>1e-8)
 def score(self,A,b,leg,where):
  g=self.P.groups[leg];target=self.P.target[self.K['indices'][where]][:,g['joints']];scale=self.P.scales[leg];N=A.shape[2];error=0.;activ=0.
  for f,y in zip(where,target):
   fit=lsq_linear(np.vstack([A[f]/scale,np.sqrt(1e-6)*np.eye(N)]),np.r_[(y-b[f])/scale,np.zeros(N)],bounds=(0,1),method='bvls',tol=1e-9,max_iter=300)
   if not fit.success:return 1e9
   a=np.clip(fit.x,0,1);error+=float(np.sum((A[f]@a+b[f]-y)**2));activ+=float(a@a)
  return error/max(float(np.sum(target**2)),1e-30)+1e-6*activ/len(where)

def optimize_leg(leg):
 C=Refine();P=C.P;g=P.groups[leg];ks=g['muscles'];rows=copy.deepcopy(C.initial);positions={pt['site']:pt['pos_cm'] for r in rows for pt in r['points']};nf=len(C.K['indices']);A=np.empty((nf,11,len(ks)));B=np.zeros((nf,11));passive={};initialJ={};initialsegments={};history=[];start=time.monotonic();identity_error=0.
 for j,k in enumerate(ks):
  col,bb,J,seg=C.column(rows[k],k,positions,leg);A[:,:,j]=col;B+=bb;passive[k]=bb;initialJ[k]=J[0].copy();initialsegments[k]=seg
  exact,eb=P.operator(int(C.K['indices'][0]),leg,C.gain,C.lr);identity_error=max(identity_error,float(np.max(np.abs(col[0]-exact[:,j]))))
 assert identity_error<1e-12,identity_error
 initial_score=C.score(A,B,leg,C.train);best=initial_score;accepted=0;trials=0
 # Per-point geometry candidates preserve source-region/routing uncertainty.
 for sweep in range(2):
  for j,k in enumerate(ks):
   if j%5==0:print('progress',leg,'sweep',sweep,'muscle',j,'residual',float(np.sqrt(best)),'elapsed',time.monotonic()-start,flush=True)
   r=rows[k]
   for pt in r['points']:
    site=pt['site'];patch=C.patches[site];oldpos=positions[site];oldcol=A[:,:,j].copy();oldbias=passive[k].copy();chosen=oldpos;chosen_data=None;local_best=best
    for cand in patch['candidate_positions_cm']:
     if np.linalg.norm(np.array(cand)-patch['initial_position_cm'])>patch['maximum_displacement_cm']*(1+1e-9):continue
     positions[site]=cand
     try:col,bb,J,segments=C.column(r,k,positions,leg)
     except ValueError:continue
     if np.min(np.sum(segments*initialsegments[k],axis=1))<np.cos(np.pi/6):continue
     den=np.linalg.norm(J[0])*np.linalg.norm(initialJ[k])
     if den>1e-14 and J[0]@initialJ[k]/den<np.cos(np.pi/6):continue
     major=int(np.argmax(np.abs(initialJ[k])))
     if J[0,major]*initialJ[k][major]<0:continue
     A[:,:,j]=col;candidate_bias=B-oldbias+bb;trials+=1;cost=C.score(A,candidate_bias,leg,C.train)
     # Weak movement penalty does not declare the initial hypothesis measured.
     move=np.linalg.norm(np.array(cand)-patch['initial_position_cm'])/max(patch['maximum_displacement_cm'],1e-12);cost+=1e-4*move*move
     if cost<local_best-1e-8 and C.positive_full_domain(r,positions):local_best=cost;chosen=cand;chosen_data=(col.copy(),bb.copy())
    positions[site]=chosen
    if chosen_data is not None:A[:,:,j]=chosen_data[0];B=B-oldbias+chosen_data[1];passive[k]=chosen_data[1];best=C.score(A,B,leg,C.train);accepted+=1
    else:A[:,:,j]=oldcol
   # Per-muscle length/slack/velocity calibration, retaining volume/F0 coupling.
   for field,values in [('L0',[.85,1.,1.15]),('slack',[-.1,0.,.1]),('vmax',[.7,1.,1.3])]:
    original=copy.deepcopy(r);oldgain=C.gain[k].copy();oldlr=C.lr[k].copy();oldcol=A[:,:,j].copy();oldbias=passive[k].copy();chosen=None;local_best=best
    for value in values:
     cand=copy.deepcopy(original);gain=oldgain.copy();lr=oldlr.copy();ps=[P.prior[id] for id in r['catalog_ids']];frac=r.get('source_group_budget_fraction',1.)
     if field=='L0':
      cand['fiber_length0_m']=original['fiber_length0_m']*value;lo=max(p['estimated']['optimal_fiber_length_m']['working'][0] for p in ps);hi=min(p['estimated']['optimal_fiber_length_m']['working'][1] for p in ps)
      if not lo<=cand['fiber_length0_m']<=hi:continue
      cand['PCSA_m2']=cand['muscle_volume_m3']/cand['fiber_length0_m'];cand['F0_N']=cand['PCSA_m2']*cand['specific_stress_Pa'];gain[2]=cand['F0_N']*1e5
      low=sum(p['estimated']['physiological_cross_sectional_area_m2']['working'][0] for p in ps)*frac;high=sum(p['estimated']['physiological_cross_sectional_area_m2']['working'][1] for p in ps)*frac
      if not low<=cand['PCSA_m2']<=high:continue
      low=sum(p['estimated']['max_isometric_force_N']['working'][0] for p in ps)*frac;high=sum(p['estimated']['max_isometric_force_N']['working'][1] for p in ps)*frac
      if not low<=cand['F0_N']<=high:continue
     elif field=='slack':
      cand['tendon_slack_length_m']=max(0.,original['tendon_slack_length_m']+value*original['fiber_length0_m'])
      if cand['tendon_slack_length_m']>min(p['estimated']['tendon_slack_length_m']['working'][1] for p in ps):continue
     else:gain[6]=np.clip(gain[6]*value,5,100)
     lr=np.array([(cand['tendon_slack_length_m']+gain[x]*cand['fiber_length0_m'])*100 for x in [0,1]])
     try:col,bb,_,_=C.column(cand,k,positions,leg,gain,lr)
     except ValueError:continue
     A[:,:,j]=col;candidate_bias=B-oldbias+bb;trials+=1;cost=C.score(A,candidate_bias,leg,C.train)
     if cost<local_best-1e-8 and C.positive_full_domain(cand,positions):local_best=cost;chosen=(cand,gain,lr,col.copy(),bb.copy())
    if chosen is not None:
     r,gain,lr,col,bb=chosen;rows[k]=r;C.gain[k]=gain;C.lr[k]=lr;A[:,:,j]=col;B=B-oldbias+bb;passive[k]=bb;best=local_best;accepted+=1
    else:A[:,:,j]=oldcol
  print('refine',leg,'sweep',sweep,'train residual',np.sqrt(best),'trials',trials,'accepted',accepted,flush=True);history.append({'sweep':sweep,'train_objective':best,'accepted_updates':accepted})
 for k in ks:
  rows[k]['gainprm_native']=C.gain[k].tolist()+[0.]
  for pt in rows[k]['points']:pt['pos_cm']=positions[pt['site']]
 out={'leg':leg,'initial_train_objective':initial_score,'final_train_objective':best,'train_relative_error_approx':float(np.sqrt(best)),'validation_relative_error_approx':float(np.sqrt(C.score(A,B,leg,C.val))),'test_relative_error_approx':float(np.sqrt(C.score(A,B,leg,C.test))),'accepted_updates':accepted,'trial_evaluations':trials,'history':history,'native_identity_max_error_Nm':identity_error,'elapsed_s':time.monotonic()-start,'records':[rows[k] for k in ks],'gain':C.gain[ks].tolist(),'lengthrange':C.lr[ks].tolist()}
 (ROOT/f'{leg}_result.json').write_text(json.dumps(out,indent=2));return leg

def optimize():
 from concurrent.futures import ProcessPoolExecutor,as_completed
 with ProcessPoolExecutor(max_workers=3) as pool:
  futures=[pool.submit(optimize_leg,leg) for leg in ['LF','RF','LM','RM','LH','RH']]
  for f in as_completed(futures):print('completed',f.result(),flush=True)

if __name__=='__main__':{'prepare':prepare,'prepare_full':prepare_full,'optimize':optimize}[sys.argv[1]]()
