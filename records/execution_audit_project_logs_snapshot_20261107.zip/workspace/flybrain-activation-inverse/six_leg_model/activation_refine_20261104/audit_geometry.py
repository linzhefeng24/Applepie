import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,numpy as np,mujoco
from scipy.spatial import ConvexHull
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));from refine import vertices
m=mujoco.MjModel.from_xml_path(str(ROOT/'refined_muscles.xml'));rows=json.load(open(ROOT/'records.json'))['records'];patches=json.load(open(ROOT/'attachment_candidates.json'));equations={};changed_outside=[];unchanged_outside=[];volume_changed=[]
previous={r['id']:r for r in json.load(open(ROOT.parent/'activation_fit_20261104/optimized_model_records.json'))['records']}
for r in rows:
 if r['muscle_volume_m3']!=previous[r['id']]['muscle_volume_m3']:volume_changed.append(r['id'])
 for pt in r['points']:
  b=pt['body']
  if b not in equations:
   v=vertices(m,mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,b));equations[b]=ConvexHull(v).equations if v is not None else None
  eq=equations[b]
  if eq is None:continue
  p=np.asarray(pt['pos_cm']);outside=bool(np.max(eq[:,:3]@p+eq[:,3])>1e-8);changed=np.linalg.norm(p-patches[pt['site']]['initial_position_cm'])>1e-10
  if outside:(changed_outside if changed else unchanged_outside).append(pt['site'])
report={'changed_attachment_sites_outside_body_mesh_convex_hull':changed_outside,'unchanged_initial_hypotheses_outside_convex_hull':unchanged_outside,'muscle_volumes_changed':volume_changed,'shared_compartment_volumes_unchanged_from_previous_validated_candidate':not volume_changed,'convex_hull_is_attachment_region_proxy_not_tissue_segmentation':True,'passed':not changed_outside and not volume_changed}
(ROOT/'geometry_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['passed']
