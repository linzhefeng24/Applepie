from pathlib import Path
import json,copy,hashlib,os
ROOT=Path(__file__).resolve().parent;C=Path('/workspace/flybrain-muscle-rebuild/brain.json');M=Path('/workspace/flybrain-recovered/brain.json')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
brain=json.loads(C.read_text());assert brain==json.loads(M.read_text());before=copy.deepcopy(brain);backup=ROOT/'brain_before_refinement.json'
if not backup.exists():backup.write_bytes(C.read_bytes())
files=['fit_report.json','optimization.json','records.json','validation.json','geometry_validation.json','activation_validation.json','dynamics_validation.json','attachment_candidates.json','activation_feasibility_default.json','activation_feasibility_fast_prior.json','forward_default.json','forward_fast_prior.json']
content={p[:-5]:json.loads((ROOT/p).read_text()) for p in files};assert content['validation']['passed'] and content['geometry_validation']['passed'] and content['activation_validation']['passed'];assert all(x['passed'] for x in content['dynamics_validation'].values())
assets=[]
for name in ['activation_6s_5000Hz.npz','activation_6s_5000Hz.csv.gz','parameters.npz','excitation_default.npz','excitation_fast_prior.npz','forward_default.npz','forward_fast_prior.npz','comparison.png','activations.png','fast_prior_forward.mp4']:
 p=ROOT/name
 if p.exists():assets.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
run={'id':'six_leg_activation_refine_20261104','date':'2026-11-04','role':'bounded per-muscle geometry/physiology refinement and kinetic sensitivity; not measured biology','previous_experiment_id':'six_leg_activation_fit_20261104','default_model_replaced':False,'source_q_and_torque_trajectory_changed':False,'activation_array':{'path':str(ROOT/'activation_6s_5000Hz.npz'),'shape':[30000,130],'sample_rate_Hz':5000,'measured':False},**content,'candidate_model_xml':{'format':'MuJoCo XML','text':(ROOT/'refined_muscles.xml').read_text(),'sha256':sha(ROOT/'refined_muscles.xml')},'method_document':{'format':'markdown','text':(ROOT/'README.md').read_text()},'artifacts':assets,'remaining_limitations':['Torque residual remains about 57%; all labels conditional.','Six-leg free dynamics does not reproduce normal reference walking.','Fast time constants are prior-bound sensitivity assumptions, not identified measurements.','Sixteen unchanged foreleg registration hypotheses remain outside the target mesh convex hull.','Attachment convex hull and direction cones are engineering proxies, not real tissue segmentation.']}
runs=brain.setdefault('muscle_activation_inference_experiments',{'schema':'muscle_activation_inference_experiments_v1','runs':[]})['runs'];runs[:]=[r for r in runs if r['id']!=run['id']];runs.append(run)
ready=brain['neuromusculoskeletal_model']['current_readiness'];ready['latest_activation_inference_experiment_id']=run['id'];ready['latest_candidate_walk_check_passed']=False;ready['default_parameter_model_replaced_by_candidate']=False;ready['latest_candidate_torque_relative_residual_L2']=content['fit_report']['refined_relative_torque_residual_L2']
brain['version']='3.4.2-six-leg-per-muscle-refinement';brain['date']='2026-11-04'
for k,v in before.items():
 if k not in ['version','date','neuromusculoskeletal_model','muscle_activation_inference_experiments']:assert brain[k]==v,k
old=copy.deepcopy(before['neuromusculoskeletal_model']);new=copy.deepcopy(brain['neuromusculoskeletal_model']);old.pop('current_readiness');new.pop('current_readiness');assert old==new
blob=(json.dumps(brain,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
for p in [C,M]:tmp=p.with_name(p.name+'.refine.tmp');tmp.write_bytes(blob);os.replace(tmp,p)
assert C.read_bytes()==M.read_bytes();report={'brain_version':brain['version'],'bytes':len(blob),'sha256':sha(C),'prior_evidence_preserved':True,'mirrors_identical':True,'new_experiment_id':run['id'],'default_model_replaced':False};(ROOT/'brain_integration.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
