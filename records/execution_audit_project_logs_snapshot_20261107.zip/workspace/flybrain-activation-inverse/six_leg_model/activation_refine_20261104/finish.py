import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,copy,xml.etree.ElementTree as E
import numpy as np,mujoco
ROOT=Path(__file__).resolve().parent;PREV=ROOT.parent/'activation_fit_20261104';sys.path.insert(0,str(ROOT));from refine import Refine
sys.path.insert(0,str(PREV));from fit import Problem,sha

def merge_cache():
 P=Problem();rows=copy.deepcopy(P.b.rows);gain=np.load(PREV/'optimized_parameters.npz')['gain'];lr=np.load(PREV/'optimized_parameters.npz')['lengthrange'];reports=[]
 for leg,g in P.groups.items():
  result=json.load(open(ROOT/f'{leg}_result.json'));reports.append({k:v for k,v in result.items() if k not in ['records','gain','lengthrange']})
  for k,row,ga,lengthrange in zip(g['muscles'],result['records'],result['gain'],result['lengthrange']):rows[k]=row;gain[k]=ga;lr[k]=lengthrange
 tree=E.parse(PREV/'optimized_muscles.xml');sites={s.get('name'):s for s in tree.iter('site')};acts={a.get('name'):a for a in tree.getroot().find('actuator')};positions={}
 for k,row in enumerate(rows):
  for pt in row['points']:sites[pt['site']].set('pos',' '.join(map(str,pt['pos_cm'])));positions[pt['site']]=pt['pos_cm']
  a=acts[row['actuator_name']];a.set('gainprm',' '.join(map(str,gain[k].tolist()+[0.])));a.set('biasprm',a.get('gainprm'));a.set('lengthrange',' '.join(map(str,lr[k])))
 tree.write(ROOT/'refined_muscles.xml',encoding='unicode');m=mujoco.MjModel.from_xml_path(str(ROOT/'refined_muscles.xml'));d=mujoco.MjData(m);n=len(P.target);M=len(rows);Q=P.z['qpos'];W=P.z['qvel'];J=np.empty((m.ntendon,m.nv));tids=np.array([r['tendon_index'] for r in rows]);L=np.lib.format.open_memmap(ROOT/'length_native.npy',mode='w+',dtype='f8',shape=(n,M));V=np.lib.format.open_memmap(ROOT/'velocity_native.npy',mode='w+',dtype='f8',shape=(n,M));mom=np.lib.format.open_memmap(ROOT/'moment_native.npy',mode='w+',dtype='f8',shape=(n,11,M))
 for i in range(n):
  d.qpos[:]=Q[i];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);mujoco.mju_sparse2dense(J,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));MJ=J[tids];L[i]=d.ten_length[tids];V[i]=MJ@W[i]
  for leg,g in P.groups.items():ks=np.asarray(g['muscles']);js=np.asarray(g['joints']);mom[i,:,ks]=MJ[np.ix_(ks,P.b.dofs[js])]
 L.flush();V.flush();mom.flush();np.savez(ROOT/'parameters.npz',gain=gain,lengthrange=lr,acc0=m.actuator_acc0[P.b.ids])
 for k,row in enumerate(rows):row['normalized_fiber_length_sample_min']=float((L[:,k].min()*.01-row['tendon_slack_length_m'])/row['fiber_length0_m']);row['normalized_fiber_length_sample_max']=float((L[:,k].max()*.01-row['tendon_slack_length_m'])/row['fiber_length0_m']);row['normalized_fiber_length_domain']='all 30000 fixed reference poses'
 (ROOT/'records.json').write_text(json.dumps({'records':rows},indent=2));(ROOT/'optimization.json').write_text(json.dumps({'legs':reports,'geometry_changed':True,'shared_parameters_across_time':True,'training_frames':48,'validation_frames':24,'test_frames':24,'selection_uses_training_torques_only':True,'test_postures_used_for_positive_fiber_domain_check':True,'activation_kinetics_optimized':False,'prior_model_and_reference_overwritten':False},indent=2))
 # Independent checks: mesh-region/radius, direction cones, actual native force.
 C=Refine();patches=C.patches;maxdist=0.;changed=0;violations=[];max_segment_angle=0.;max_moment_angle=0.
 for k,row in enumerate(rows):
  initial=C.initial[k];initial_positions={pt['site']:pt['pos_cm'] for pt in initial['points']};_,_,Ji,Si=C.mechanics(initial,initial_positions,row['leg']);_,_,Jf,Sf=C.mechanics(row,positions,row['leg']);norm=np.linalg.norm(Ji[0])*np.linalg.norm(Jf[0]);angle=np.degrees(np.arccos(np.clip(Ji[0]@Jf[0]/norm,-1,1))) if norm>1e-14 else 0.;max_moment_angle=max(max_moment_angle,float(angle));sa=np.degrees(np.arccos(np.clip(np.sum(Si*Sf,axis=1),-1,1)));max_segment_angle=max(max_segment_angle,float(sa.max()))
  if angle>30.00001 or sa.max()>30.00001:violations.append(row['id']+': angle cone')
  for pt in row['points']:
   p=patches[pt['site']];dist=np.linalg.norm(np.asarray(pt['pos_cm'])-p['initial_position_cm']);maxdist=max(maxdist,float(dist/max(p['maximum_displacement_cm'],1e-15)));changed+=int(dist>1e-10)
   if dist>p['maximum_displacement_cm']*(1+1e-8):violations.append(pt['site']+': displacement')
  ps=[P.prior[id] for id in row['catalog_ids']];fraction=row.get('source_group_budget_fraction',1.)
  for field,parameter in [('PCSA_m2','physiological_cross_sectional_area_m2'),('F0_N','max_isometric_force_N')]:
   lo=sum(p['estimated'][parameter]['working'][0] for p in ps)*fraction;hi=sum(p['estimated'][parameter]['working'][1] for p in ps)*fraction
   if not lo-1e-20<=row[field]<=hi+1e-20:violations.append(row['id']+': '+parameter)
  if not np.isclose(row['F0_N'],row['PCSA_m2']*row['specific_stress_Pa'],rtol=1e-12):violations.append(row['id']+': force relation')
 minfiber=float(np.min(L*.01-np.array([r['tendon_slack_length_m'] for r in rows])[None,:]));actual_error=[];rng=np.random.default_rng(4);dense=np.zeros((m.nu,m.nv))
 for i in P.split['test'][:4]:
  d.qpos[:]=Q[i];d.qvel[:]=W[i];a=rng.uniform(0,1,M);d.act[P.b.adrs]=a;mujoco.mj_forward(m,d);mujoco.mju_sparse2dense(dense,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);real=(dense[P.b.ids].T@d.actuator_force[P.b.ids])[P.b.dofs]*1e-7;pred=np.zeros(66)
  for leg,g in P.groups.items():
   ks=g['muscles'];f=np.array([mujoco.mju_muscleGain(L[i,k],V[i,k],lr[k],m.actuator_acc0[P.b.ids[k]],gain[k])*a[k]+mujoco.mju_muscleBias(L[i,k],lr[k],m.actuator_acc0[P.b.ids[k]],gain[k]) for k in ks]);pred[g['joints']]=mom[i,:,ks].T@f*1e-7
  actual_error.append(float(np.max(np.abs(pred-real))))
 report={'model_compiles':True,'changed_attachment_sites':changed,'max_attachment_displacement_fraction_of_allowed_radius':maxdist,'maximum_reference_segment_angle_change_deg':max_segment_angle,'maximum_reference_moment_direction_change_deg':max_moment_angle,'minimum_full_reference_fiber_length_m':minfiber,'native_vs_cached_force_max_error_Nm':max(actual_error),'constraint_violations':violations,'source_trajectory_unchanged':sha('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz')==P.meta['source_sha256'],'original_model_unchanged':sha(ROOT.parent/'six_leg_muscles.xml')==P.meta['model_xml_sha256'],'model_anatomy_status':'bounded local attachment hypotheses; not directly measured attachment reconstruction'};report['passed']=bool(not violations and minfiber>0 and max(actual_error)<1e-12 and report['source_trajectory_unchanged'] and report['original_model_unchanged']);(ROOT/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['passed']

def setup_problem():
 P=Problem();P.L=np.load(ROOT/'length_native.npy',mmap_mode='r');P.V=np.load(ROOT/'velocity_native.npy',mmap_mode='r');P.mom=np.load(ROOT/'moment_native.npy',mmap_mode='r');params={k:v for k,v in np.load(ROOT/'parameters.npz').items()};P.base['acc0']=params['acc0'];return P,params

def chunk(bounds):
 P,params=setup_problem();start,stop=bounds;n=stop-start;aa=np.empty((n,130),dtype='f4');pred=np.zeros((n,66));status=np.empty((n,6),dtype='i1')
 for local,i in enumerate(range(start,stop)):
  for j,(leg,g) in enumerate(P.groups.items()):a,y,ok=P.solve(i,leg,params['gain'],params['lengthrange']);aa[local,g['muscles']]=a;pred[local,g['joints']]=y;status[local,j]=ok
  if local%2000==0:print('solve chunk',start,'frame',i,flush=True)
 path=ROOT/f'part_{start}.npz';np.savez_compressed(path,activation=aa,prediction=pred,status=status);return start,stop,str(path)

def solve():
 from concurrent.futures import ProcessPoolExecutor,as_completed
 P,params=setup_problem();n=len(P.target);aa=np.empty((n,130),dtype='f4');pred=np.zeros((n,66));status=np.empty((n,6),dtype='i1');cuts=np.linspace(0,n,5,dtype=int)
 with ProcessPoolExecutor(max_workers=4) as pool:
  futures=[pool.submit(chunk,(int(cuts[i]),int(cuts[i+1]))) for i in range(4)]
  for f in as_completed(futures):start,stop,path=f.result();p=np.load(path);aa[start:stop]=p['activation'];pred[start:stop]=p['prediction'];status[start:stop]=p['status']
 prev=np.load(PREV/'activation_6s_5000Hz.npz');previous=prev['predicted_torque_Nm'];initial=prev['baseline_predicted_torque_Nm'];np.savez_compressed(ROOT/'activation_6s_5000Hz.npz',time_s=P.z['time_s'],muscle_ids=prev['muscle_ids'],joint_names=prev['joint_names'],reference_joint_angle_rad=prev['reference_joint_angle_rad'],reference_joint_velocity_rad_s=prev['reference_joint_velocity_rad_s'],activation=aa,target_torque_Nm=P.target,predicted_torque_Nm=pred,previous_predicted_torque_Nm=previous,initial_predicted_torque_Nm=initial,solver_success=status)
 report={'frames':n,'muscles':130,'sample_rate_Hz':5000,'duration_s':6.,'previous_relative_torque_residual_L2':float(np.linalg.norm(previous-P.target)/np.linalg.norm(P.target)),'refined_relative_torque_residual_L2':float(np.linalg.norm(pred-P.target)/np.linalg.norm(P.target)),'solver_failures':int(np.sum(status==0)),'upper_bound_activation_fraction':float(np.mean(aa>=1-1e-6)),'lower_bound_activation_fraction':float(np.mean(aa<=1e-6)),'split_relative_residual_L2':{},'per_leg':{},'independent_frame_solutions':True,'temporal_regularization':False,'reference_targets_changed':False}
 for name,indices in P.split.items():report['split_relative_residual_L2'][name]=float(np.linalg.norm(pred[indices]-P.target[indices])/np.linalg.norm(P.target[indices]))
 for leg,g in P.groups.items():js=g['joints'];report['per_leg'][leg]={'previous_relative_residual_L2':float(np.linalg.norm(previous[:,js]-P.target[:,js])/np.linalg.norm(P.target[:,js])),'refined_relative_residual_L2':float(np.linalg.norm(pred[:,js]-P.target[:,js])/np.linalg.norm(P.target[:,js]))}
 (ROOT/'fit_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':{'merge':merge_cache,'solve':solve}[sys.argv[1]]()
