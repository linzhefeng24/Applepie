import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/refine-mpl')
from pathlib import Path
import sys,json,gzip,csv
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import lsq_linear
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));from finish import setup_problem
P,params=setup_problem();z={k:v for k,v in np.load(ROOT/'activation_6s_5000Hz.npz').items()};fit=json.load(open(ROOT/'fit_report.json'));dyn={case:json.load(open(ROOT/f'forward_{case}.json')) for case in ['default','fast_prior']};afeas={case:json.load(open(ROOT/f'activation_feasibility_{case}.json')) for case in dyn};rng=np.random.default_rng(42);ae=[];te=[];nne=[];signed=[];den=[];ranks={leg:[] for leg in P.groups}
for i in rng.choice(len(P.target),24,replace=False):
 for leg,g in P.groups.items():
  a,p,ok=P.solve(int(i),leg,params['gain'],params['lengthrange']);assert ok;ae.append(float(np.max(np.abs(a-z['activation'][i,g['muscles']]))));A,b=P.operator(i,leg,params['gain'],params['lengthrange']);te.append(float(np.max(np.abs(A@z['activation'][i,g['muscles']]+b-z['predicted_torque_Nm'][i,g['joints']]))))
for i in P.split['test']:
 for leg,g in P.groups.items():
  A,b=P.operator(int(i),leg,params['gain'],params['lengthrange']);target=P.target[i,g['joints']];y=target-b;s=P.scales[leg];solution=lsq_linear(A/s,y/s,bounds=(0,np.inf),method='bvls',tol=1e-10,max_iter=500);free=np.linalg.lstsq(A/s,y/s,rcond=1e-10)[0];nne.append(float(np.sum((A@solution.x-y)**2)));signed.append(float(np.sum((A@free-y)**2)));den.append(float(target@target));ranks[leg].append(int(np.linalg.matrix_rank(A,tol=1e-15)))
verification={'shuffled_frames':24,'max_saved_float32_activation_difference':max(ae),'max_saved_activation_force_error_Nm':max(te),'activation_min':float(z['activation'].min()),'activation_max':float(z['activation'].max()),'test_unbounded_nonnegative_relative_residual':float(np.sqrt(sum(nne)/sum(den))),'test_unbounded_signed_relative_residual':float(np.sqrt(sum(signed)/sum(den))),'test_matrix_rank_per_leg':{leg:[min(x),max(x)] for leg,x in ranks.items()},'diagnostic_bounds_are_not_permitted_solutions':True};verification['passed']=bool(max(ae)<1e-6 and max(te)<1e-12 and 0<=z['activation'].min()<=z['activation'].max()<=1);(ROOT/'activation_validation.json').write_text(json.dumps(verification,indent=2));assert verification['passed']
with gzip.open(ROOT/'activation_6s_5000Hz.csv.gz','wt',newline='') as f:
 w=csv.writer(f);w.writerow(['time_s']+z['muscle_ids'].tolist())
 for t,a in zip(z['time_s'],z['activation']):w.writerow([format(float(t),'.8g')]+[format(float(x),'.8g') for x in a])
fig,axs=plt.subplots(2,2,figsize=(13,8));legs=list(P.groups);x=np.arange(6)
for off,key,label in [(-.2,'previous_relative_residual_L2','Previous'),(.2,'refined_relative_residual_L2','Per-muscle refinement')]:axs[0,0].bar(x+off,[fit['per_leg'][l][key]*100 for l in legs],width=.4,label=label)
axs[0,0].set_xticks(x,legs);axs[0,0].set_ylabel('Torque residual L2 (%)');axs[0,0].legend();axs[0,0].set_title('Same fixed reference, all 30,000 frames')
refpos=P.z['thorax_xyz_cm']*10;reftime=P.z['time_s'];axs[0,1].plot(reftime[::10],refpos[::10,0]-refpos[0,0],label='Reference')
for case in dyn:
 forward=np.load(ROOT/f'forward_{case}.npz');xyz=forward['thorax_mm'];axs[0,1].plot(forward['time_s'][::5],xyz[::5,0]-xyz[0,0],label=case);axs[1,0].plot(forward['time_s'][::5],forward['joint_rmse_rad'][::5]*180/np.pi,label=case)
axs[0,1].set_title('Free forward dynamics: forward progress');axs[0,1].set_ylabel('x displacement (mm)');axs[0,1].set_xlabel('Time (s)');axs[0,1].legend();axs[1,0].set_xlabel('Time (s)');axs[1,0].set_ylabel('Joint angle RMSE (deg)');axs[1,0].legend();axs[1,0].set_title('Reference joint trajectory error')
axs[1,1].bar(['Original kinetics','Fast prior sensitivity'],[dyn[c]['activation_tracking_rmse'] for c in ['default','fast_prior']]);axs[1,1].set_ylabel('Activation-state tracking RMSE');axs[1,1].set_title('Fast prior is a hypothesis, not identified physiology');fig.tight_layout();fig.savefig(ROOT/'comparison.png',dpi=150);plt.close(fig)
fig,ax=plt.subplots(figsize=(12,6));im=ax.imshow(z['activation'][::10].T,aspect='auto',origin='lower',extent=[0,6,0,130],vmin=0,vmax=1);fig.colorbar(im,ax=ax,label='Activation');ax.set_xlabel('Time (s)');ax.set_ylabel('Muscle channel');ax.set_title('130 candidate activation trajectories; display downsampled only');fig.tight_layout();fig.savefig(ROOT/'activations.png',dpi=150);plt.close(fig)
geometry=json.load(open(ROOT/'geometry_validation.json'));validation=json.load(open(ROOT/'validation.json'));unknownoutside=len(geometry['unchanged_initial_hypotheses_outside_convex_hull'])
text=f'''# 六腿肌肉激活求解：逐肌肉几何与生理参数细化

2026-11-04。保持同一条 6 秒参考关节轨迹、速度与同步驱动力矩，不增加肌力范围，不平滑激活标签，不使用强化学习。

## 全程结果

- 130 路、30,000 个时刻、5,000 Hz；全部 180,000 个腿—时刻求解完成。
- 固定力矩相对 L2 残差：上一轮 {fit['previous_relative_torque_residual_L2']:.2%} → 本轮 {fit['refined_relative_torque_residual_L2']:.2%}。
- 训练/验证/测试窗口：{fit['split_relative_residual_L2']['train']:.2%} / {fit['split_relative_residual_L2']['validation']:.2%} / {fit['split_relative_residual_L2']['test']:.2%}。这仍是同一条行走记录上的留出窗口，不是新动作泛化。
- 激活触及上限比例 {fit['upper_bound_activation_fraction']:.2%}，触及下限比例 {fit['lower_bound_activation_fraction']:.2%}。不能把下限解解释为实测生理静默。

[结果对比图](comparison.png) · [激活热图](activations.png) · [完整激活 CSV.gz](activation_6s_5000Hz.csv.gz) · [原始数值 NPZ](activation_6s_5000Hz.npz)

## 实际修改和约束

在上一轮有界参数候选上逐肌肉搜索，两轮坐标搜索。优化项包括同一骨段上的路径附着点、最优纤维长度、腱松弛长度与最大缩短速度。肌肉体积及共享区室体积没有增加；长度变更时重新计算 PCSA 与 F0，检查原工作范围和 F0=PCSA×比张力关系。

284 个附着点发生调整。候选来自正确骨段的局部网格区域；初始点在网格凸包内时才使用凸组合，否则只允许网格顶点候选。移动不超过原有定位半径；在首个参考姿态，路径线段与原力臂方向变化均不超过 30°，保留原主导分量符号。这些是工程搜索约束，不是实测解剖误差置信区间。

被接受候选均在全部 30,000 个参考姿态上保持正纤维长度。几何使用训练力矩选取，验证/测试力矩不参与选择；所有参考姿态可用于几何安全域检查。共享参数全程不变，每个时刻的激活仍独立求解。

所有修改点通过目标网格凸包检查，但仍有 **{unknownoutside} 个未修改的初始前腿注册点位于该凸包外**。这些位置未在本轮约束下修正，不能宣称六腿解剖已经验证。凸包本身也只是区域代理，尚无逐块附着面或组织绕行重建。原始 FlyMimic、旧模型、原参数范围与神经证据全部保留。

## 前向仿真

两种情景均从相同参考初态出发，保留原 11 路非肌肉控制（含黏附）。以有界激励驱动原生激活动力学，初始化后不覆盖姿态或激活，不加外部补偿力矩。

| 情景 | 6 秒净水平位移 | 前进 x / 侧向 y | 关节角 RMSE | 激活跟踪 RMSE | 行走检查 |
| --- | --- | --- | --- | --- | --- |
'''
for case in ['default','fast_prior']:
 d=dyn[case];text+=f"| {case} | {d['displacement_xy_mm']:.2f} mm | {d['displacement_xyz_mm'][0]:.2f} / {d['displacement_xyz_mm'][1]:.2f} mm | {d['joint_angle_rmse_deg']:.2f}° | {d['activation_tracking_rmse']:.3f} | {d['passes_defined_walking_checks']} |\n"
text+=f'''
两种情景均未形成符合参考的正常行走。原时间常数下主要保持站立；较快时间常数下出现更多移动，但侧移明显、关节误差仍大。

`fast_prior` 只把 100 路无作者直接模型参数的肌肉时间常数取到现有先验下限：激活 1 ms、去激活 2 ms；30 路直接来自 FlyMimic 的 MTU 保留作者时间常数。这是敏感性情景，不是从静态力矩识别出的生理参数，不代表真实肌肉一定这么快。原时间常数的未裁剪激励超界比例约 {afeas['default']['clipped_channel_time_fraction']:.2%}，较快情景仍约 {afeas['fast_prior']['clipped_channel_time_fraction']:.2%}。

定义的行走检查要求完整 6 秒、前进超过 10 mm、侧移小于前进、身体保持直立且胸部不触地、足部支撑覆盖大于 80%、各腿存在多次接触切换，以及角度 RMSE 小于 20°。接触切换即使经过 5 ms 中值滤波，仍不能直接当作生理步频。

## 诊断与文件

测试窗口中，取消激活上限但保留只能拉的约束后，残差约 {verification['test_unbounded_nonnegative_relative_residual']:.2%}；进一步允许不生理的负力后约 {verification['test_unbounded_signed_relative_residual']:.2%}。它们仅诊断当前模型，不是允许的激活解。

- `refined_muscles.xml`、`records.json`、`parameters.npz`：本轮候选，不覆盖默认或上游模型。
- `validation.json`、`geometry_validation.json`、`activation_validation.json`：原生模型一致性、范围与标签检查。
- `excitation_default.npz`、`excitation_fast_prior.npz`：规划的激励与实际激活状态，不与静态反解标签混同。
- `forward_default.npz`、`forward_fast_prior.npz`：自由动力学结果，含姿态、支撑接触和激活。

结论：逐肌肉细化改善了力矩解释能力；目前残差与激活动力学不相容仍然明显，不能把这些候选激活作为真实神经元监督，也不能宣称已经正常行走。
'''
(ROOT/'README.md').write_text(text);print(json.dumps({'fit_relative_error':fit['refined_relative_torque_residual_L2'],'verification':verification,'forward_default':dyn['default']['passes_defined_walking_checks'],'forward_fast_prior':dyn['fast_prior']['passes_defined_walking_checks']},indent=2))
