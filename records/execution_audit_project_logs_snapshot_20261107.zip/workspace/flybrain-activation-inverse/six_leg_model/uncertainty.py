"""Apply bounded middle/hind physiological candidates in memory; no file overwrite."""
from pathlib import Path
import json,copy
import numpy as np
ROOT=Path(__file__).resolve().parent
class ParameterBoundsError(ValueError):pass

def apply_candidate(backend,changes):
    """changes: {muscle_id: {free_parameter_name: value}}.

    Derived F0/PCSA, structural model choices and attachment coordinates cannot
    be changed through this physiological-only entry point.
    """
    spec=json.loads((ROOT/'middle_hind_uncertainty.json').read_text())
    specs={r['id']:r for r in spec['records']}
    prior=json.loads(Path(spec['source_prior_file']).read_text());pr={r['id']:r for r in prior['muscles']}
    rows=copy.deepcopy(backend.rows);by_id={r['id']:r for r in rows}
    gain_indices={'vmax_L0_per_s':6,'native_active_length_min':4,'native_active_length_max':5,'native_passive_force_at_length_max':7,'native_eccentric_force_ratio':8}
    for muscle,updates in changes.items():
        if muscle not in specs:raise ParameterBoundsError('Only declared middle/hind muscles are accepted: '+muscle)
        row=by_id[muscle];old=next(r for r in backend.rows if r['id']==muscle)
        for name,value in updates.items():
            s=specs[muscle]['parameters'].get(name)
            if s is None or s['role']!='free_bounded':raise ParameterBoundsError('Not an independently tunable supported parameter: '+name)
            value=float(value);lo,hi=s['working_range']
            if not np.isfinite(value) or not lo<=value<=hi:raise ParameterBoundsError(f'{muscle}/{name} outside [{lo},{hi}]')
            if name in gain_indices:row['gainprm_native'][gain_indices[name]]=value
            elif name in ['activation_tau_s','deactivation_tau_s']:row['activation_time_constants_s'][0 if name=='activation_tau_s' else 1]=value
            else:row[name]=value
        row['PCSA_m2']=row['muscle_volume_m3']/row['fiber_length0_m'];row['F0_N']=row['PCSA_m2']*row['specific_stress_Pa'];row['gainprm_native'][2]=row['F0_N']*1e5
        for name in ['PCSA_m2','F0_N']:
            lo,hi=specs[muscle]['parameters'][name]['working_range']
            if not lo<=row[name]<=hi:raise ParameterBoundsError('Derived '+name+' outside working range: '+muscle)
        minimum_path=old['normalized_fiber_length_sample_min']*old['fiber_length0_m']+old['tendon_slack_length_m']
        if minimum_path<=row['tendon_slack_length_m']:raise ParameterBoundsError('Nonpositive fiber length in declared calibration posture domain')
        maximum_path=old['normalized_fiber_length_sample_max']*old['fiber_length0_m']+old['tendon_slack_length_m']
        row['normalized_fiber_length_sample_min']=(minimum_path-row['tendon_slack_length_m'])/row['fiber_length0_m']
        row['normalized_fiber_length_sample_max']=(maximum_path-row['tendon_slack_length_m'])/row['fiber_length0_m']
        if not row['gainprm_native'][4]<1<row['gainprm_native'][5]:raise ParameterBoundsError('Native active length curve must straddle optimal length')
    usage={}
    for row in rows:
        weights=[pr[id]['estimated']['muscle_volume_m3']['initial'] for id in row['catalog_ids']];total=sum(weights)
        for id,w in zip(row['catalog_ids'],weights):
            c=pr[id]['compartment'];usage[c]=usage.get(c,0)+row['muscle_volume_m3']*w/total
    for c,V in usage.items():
        if V>prior['compartments'][c]['muscle_volume_budget_m3'][1]*(1+1e-10):raise ParameterBoundsError('Shared volume budget exceeded: '+c)
    # Validate everything before mutating model arrays.
    for row in rows:
        if row['id'] not in changes:continue
        a=row['actuator_index'];g=row['gainprm_native'];backend.model.actuator_gainprm[a]=g;backend.model.actuator_biasprm[a]=g;backend.model.actuator_dynprm[a,:2]=row['activation_time_constants_s'];backend.model.actuator_lengthrange[a]=[(row['tendon_slack_length_m']+g[i]*row['fiber_length0_m'])*100 for i in [0,1]]
    backend.rows=rows;backend.meta=copy.deepcopy(backend.meta);backend.meta['records']=rows
    return {'changed_muscles':len(changes),'derived_force_rule':'F0=(V/L0)*sigma','shared_compartment_usage_m3':usage,'files_overwritten':False}
