"""Expose unknown middle/hind muscle parameters without changing runtime mechanics."""
from pathlib import Path
import json,csv,hashlib
ROOT=Path(__file__).resolve().parent
prior_path=Path('/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json')
P=json.loads(prior_path.read_text());priors={r['id']:r for r in P['muscles']}
M=json.loads((ROOT/'manifest.json').read_text());records=[];flat=[]
def unknown(value,bounds,unit,basis,role='free_bounded',sources=None):
 return {'measured_value':None,'status':'unknown; estimated working interval, not an experimentally measured confidence interval','working_range':bounds,'unit':unit,'simulation_initial_value':value,'range_basis':basis,'role':role,'source_ids':sources or []}
for row in M['records']:
 if row['leg'] not in ['LM','RM','LH','RH']:continue
 assert len(row['catalog_ids'])==1
 p=priors[row['catalog_ids'][0]];e=p['estimated'];sources=p['evidence'];params={}
 specs=[('muscle_volume_m3','muscle_volume_m3','m^3'),('fiber_length0_m','optimal_fiber_length_m','m'),('specific_stress_Pa','specific_stress_Pa','Pa'),('PCSA_m2','physiological_cross_sectional_area_m2','m^2'),('F0_N','max_isometric_force_N','N'),('tendon_slack_length_m','tendon_slack_length_m','m')]
 for runtime,key,unit in specs:
  spec=e[key];basis=spec.get('basis',spec.get('derived','body-size and shared tissue-budget working prior; not measured muscle segmentation'))
  params[runtime]=unknown(row[runtime],spec['working'],unit,basis,'derived_bounded' if runtime in ['PCSA_m2','F0_N'] else 'free_bounded',sources)
 for name,key,index in [('activation_tau_s','activation_tau_s',0),('deactivation_tau_s','deactivation_tau_s',1)]:
  params[name]=unknown(row['activation_time_constants_s'][index],e[key]['working'],'s',e[key]['basis'],sources=sources)
 params['vmax_L0_per_s']=unknown(row['gainprm_native'][6],e['vmax_optimal_fiber_lengths_per_s']['working'],'L0/s',e['vmax_optimal_fiber_lengths_per_s']['basis'],sources=sources)
 # Native MuJoCo curve parameters, not a relabeling of old Gaussian/Hill parameters.
 for key,index,bounds,basis in [
 ('native_active_length_min',4,[0.,.75],'weak native-curve sensitivity window; must be below 1, not a measured Drosophila length endpoint'),
 ('native_active_length_max',5,[1.25,2.5],'weak native-curve sensitivity window; must exceed 1; not old Gaussian width'),
 ('native_passive_force_at_length_max',7,[.5,3.5],'dimensionless multiple of F0 at native length endpoint; exploratory engineering range, not measured passive muscle stiffness'),
 ('native_eccentric_force_ratio',8,[1.1,2.],'engineering eccentric-force plateau prior; not measured for this muscle')]:
  params[key]=unknown(row['gainprm_native'][index],bounds,'dimensionless',basis,sources=['flymimic2025'])
 params['pennation_angle_rad']={'measured_value':None,'status':'unknown structural parameter; baseline explicitly fixes it to zero following the rigid aligned-fiber simplification','working_range':e['pennation_angle_rad']['working'],'unit':'rad','simulation_initial_value':0.,'role':'structural_sensitivity_not_implemented','range_basis':e['pennation_angle_rad']['basis']}
 params['tendon_strain_at_F0']={'measured_value':None,'status':'unknown; rigid-tendon baseline does not estimate a finite compliance','working_range':e['tendon_compliance']['strain_at_F0'],'unit':'dimensionless','simulation_initial_value':None,'baseline_assumption':'rigid tendon, zero strain; separate model choice, outside finite-compliance sensitivity interval','role':'structural_sensitivity_not_implemented','range_basis':e['tendon_compliance']['basis']}
 params['fiber_count']={'measured_value':None,'working_range':None,'status':'unidentified; no numeric range fabricated from body size alone','role':'unresolved_discrete_structure','simulation_initial_value':None,'estimation_strategy':'aggregate PCSA/volume model until fiber segmentation is available'}
 params['mn_to_fiber_weights']={'measured_value':None,'working_range':None,'status':'unresolved topology and capacity allocation; no equal-strength assignment from neuron counts','role':'unresolved_neural_structure','simulation_initial_value':None,'normalization_constraints':e['mn_to_fiber_weights']['constraints']}
 paths=[]
 for pt in row['points']:
  paths.append({'site':pt['site'],'body':pt['body'],'measured_position_m':None,'estimated_initial_position_m':[x*.01 for x in pt['pos_cm']],'search_radius_m':e['attachment_location_uncertainty_m']['initial_radius'],'radius_working_range_m':e['attachment_location_uncertainty_m']['working_radius'],'status':'unknown attachment; mesh candidate is an engineering hypothesis, not a verified attachment center','constraints':['remain attached to the same anatomical body','remain within permitted mesh/attachment region once segmented','preserve independently established anatomical action where known','one fixed geometry across all timestamps'],'source_ids':sources})
 record={'id':row['id'],'leg':row['leg'],'catalog_ids':row['catalog_ids'],'compartment':p['compartment'],'known_constraints':{'presence_evidence':p['presence_evidence'],'anatomical_action':p['direction'],'no_single_axis_motor_assumption':True},'parameters':params,'attachment_points':paths,'couplings':['PCSA=volume/L0 for the explicitly zero-pennation baseline','F0=PCSA*specific_stress; never tune F0 independently','shared compartment volume budgets include all six legs','moment_arm(q)=-d path_length(q)/dq; do not optimize moment arms independently','fiber length positive over declared calibration posture domain','different legs and muscles may have different parameter values','unknown topology is not resolved by fitting torque alone'],'estimation_workflow':['anatomy and path hypotheses with evidence labels','bounded shared-parameter calibration across multiple movements and load/contact conditions','inner bounded activation inference followed by forward-dynamics validation','hold out complete motion bouts/behaviors, not only adjacent time samples'],'source_ids':sources}
 records.append(record)
 for name,spec in params.items():
  ran=spec.get('working_range');flat.append({'muscle_id':row['id'],'leg':row['leg'],'parameter':name,'measured_value':'','initial':spec.get('simulation_initial_value'),'lower':ran[0] if ran else None,'upper':ran[1] if ran else None,'unit':spec.get('unit',''),'role':spec['role'],'basis':spec.get('range_basis',spec['status'])})
out={'schema':'middle_hind_flymimic_method_uncertainty_v1','muscles':len(records),'legs':['LM','RM','LH','RH'],'policy':'unknown measured values remain null; simulation uses separately recorded estimates; ranges are working priors, not proven biological limits','source_prior_file':str(prior_path),'source_prior_sha256':hashlib.sha256(prior_path.read_bytes()).hexdigest(),'mechanical_model':'native MuJoCo/FlyMimic muscle family with rigid-tendon baseline','records':records}
(ROOT/'middle_hind_uncertainty.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
with (ROOT/'middle_hind_parameter_ranges.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
assert len(records)==80 and all(sum(r['leg']==l for r in records)==20 for l in out['legs'])
for r in records:
 for name,s in r['parameters'].items():
  assert s.get('measured_value') is None
  if s['role'] in ['free_bounded','derived_bounded']:
   lo,hi=s['working_range'];assert lo<=s['simulation_initial_value']<=hi,(r['id'],name)
print('Defined 80 middle/hind muscle records,',len(flat),'parameter entries; measured unknowns remain null.')
