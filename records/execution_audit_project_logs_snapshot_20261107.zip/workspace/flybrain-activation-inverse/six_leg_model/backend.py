"""Six-leg native MuJoCo muscle family on the existing free-body fly skeleton."""
from pathlib import Path
import json
import numpy as np,mujoco
from scipy.optimize import lsq_linear
ROOT=Path(__file__).resolve().parent
class SixLegMuscles:
 def __init__(self, model_path=None, records_path=None):
  if mujoco.__version__!='3.3.2':raise RuntimeError('Use pinned MuJoCo 3.3.2 environment')
  self.meta=json.loads((ROOT/'manifest.json').read_text());self.model=mujoco.MjModel.from_xml_path(str(model_path or ROOT/'six_leg_muscles.xml'));self.data=mujoco.MjData(self.model);self.work=mujoco.MjData(self.model)
  if records_path is not None:
   records=json.loads(Path(records_path).read_text());self.meta['records']=records['records'] if isinstance(records,dict) else records
  self.rows=self.meta['records'];self.ids=np.array([r['actuator_index'] for r in self.rows]);self.adrs=self.model.actuator_actadr[self.ids];self._moment=np.zeros((self.model.nu,self.model.nv))
  z=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');self.initial_q=z['qpos'][0].copy();self.initial_v=z['qvel'][0].copy();self.dofs=z['joint_dof_indices'].copy();self.qadrs=z['joint_qpos_indices'].copy();self.joint_names=z['joint_names'].tolist()
  self.groups={leg:np.array([i for i,r in enumerate(self.rows) if r['leg']==leg]) for leg in ['LF','RF','LM','RM','LH','RH']}
  self.reset()
 def _set(self,d,q,qv,a):
  q=np.asarray(q,dtype=float);qv=np.asarray(qv,dtype=float);a=np.asarray(a,dtype=float)
  if q.shape!=(self.model.nq,) or qv.shape!=(self.model.nv,) or a.shape!=(len(self.ids),) or not all(np.all(np.isfinite(x)) for x in [q,qv,a]) or np.any(a<0) or np.any(a>1):raise ValueError('Invalid full-body q/qvel or bounded activation vector')
  mujoco.mj_resetData(self.model,d);d.qpos[:]=q;d.qvel[:]=qv;d.act[self.adrs]=a;mujoco.mj_forward(self.model,d)
 def _matrix(self,d):
  mujoco.mju_sparse2dense(self._moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);return self._moment[self.ids].copy()
 def reset(self,q=None,qvel=None,activation=None):
  if q is None:q=self.initial_q
  if qvel is None:qvel=self.initial_v
  if activation is None:activation=np.zeros(len(self.ids))
  self._set(self.data,q,qvel,activation);return self.observe()
 def observe(self):
  d=self.data;mom=self._matrix(d);f=d.actuator_force[self.ids].copy();g=mom.T@f
  return dict(time_s=float(d.time),qpos=d.qpos.copy(),qvel=d.qvel.copy(),activation=d.act[self.adrs].copy(),excitation=d.ctrl[self.ids].copy(),tension_N=-f*1e-5,muscle_generalized_force_native=g,muscle_joint_torque_Nm=g[self.dofs]*1e-7,path_length_m=d.actuator_length[self.ids].copy()*.01,path_velocity_m_s=d.actuator_velocity[self.ids].copy()*.01)
 def affine(self,q,qvel):
  self._set(self.work,q,qvel,np.zeros(len(self.ids)));d=self.work;f0=d.actuator_force[self.ids].copy();moment=self._matrix(d);d.act[self.adrs]=1;mujoco.mj_fwdActuation(self.model,d);gain=d.actuator_force[self.ids]-f0
  return moment[:,self.dofs].T*gain[None,:]*1e-7,(moment.T@f0)[self.dofs]*1e-7
 def evaluate(self,q,qvel,activation):
  self._set(self.work,q,qvel,activation);d=self.work;moment=self._matrix(d);f=d.actuator_force[self.ids].copy();return dict(muscle_joint_torque_Nm=(moment.T@f)[self.dofs]*1e-7,tension_N=-f*1e-5,path_length_m=d.actuator_length[self.ids].copy()*.01)
 def allocate(self,q,qvel,target_torque_Nm,ridge=1e-6):
  target=np.asarray(target_torque_Nm,dtype=float)
  if target.shape!=(len(self.dofs),) or not np.all(np.isfinite(target)):raise ValueError('Target must be 66 finite hinge torques in Nm')
  A,b=self.affine(q,qvel);scale=max(np.sqrt(np.mean(target**2)),1e-12);C=np.vstack([A/scale,np.sqrt(ridge)*np.eye(len(self.ids))]);y=np.r_[(target-b)/scale,np.zeros(len(self.ids))];fit=lsq_linear(C,y,bounds=(0,1),method='bvls',tol=1e-9,max_iter=500);pred=A@fit.x+b
  return dict(activation=fit.x,predicted_torque_Nm=pred,residual_torque_Nm=pred-target,success=bool(fit.success),status=int(fit.status))
 def step(self,excitation,adhesion=None,substeps=1):
  u=np.asarray(excitation,dtype=float)
  if u.shape!=(len(self.ids),) or not np.all(np.isfinite(u)) or np.any(u<0) or np.any(u>1):raise ValueError('Expected 130 excitations within [0,1]')
  if isinstance(substeps,bool) or not isinstance(substeps,(int,np.integer)) or substeps<1:raise ValueError('substeps must be a positive integer')
  self.data.ctrl[self.ids]=u
  if adhesion is not None:
   a=np.asarray(adhesion,dtype=float);body=np.flatnonzero(self.model.actuator_trntype==int(mujoco.mjtTrn.mjTRN_BODY))
   if a.shape!=(6,) or np.any(a<0) or np.any(a>1) or not np.all(np.isfinite(a)):raise ValueError('Expected 6 bounded adhesion commands')
   self.data.ctrl[body]=a
  for _ in range(substeps):mujoco.mj_step(self.model,self.data)
  mujoco.mj_forward(self.model,self.data)
  if not np.all(np.isfinite(self.data.qpos)):raise FloatingPointError('Nonfinite state')
  return self.observe()
