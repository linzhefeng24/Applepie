import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,hashlib,numpy as np
from backend import SixLegMuscles
from uncertainty import apply_candidate,ParameterBoundsError
ROOT=Path(__file__).resolve().parent
protected=[ROOT/'six_leg_muscles.xml',ROOT/'six_leg_muscles.mjb',Path('/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json')]
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
b=SixLegMuscles();u=json.loads((ROOT/'middle_hind_uncertainty.json').read_text());a=np.full(len(b.ids),.3);q=b.initial_q;v=b.initial_v;before=b.evaluate(q,v,a)['tension_N'];changes={r['id']:{'specific_stress_Pa':r['parameters']['specific_stress_Pa']['simulation_initial_value']*.9} for r in u['records']};result=apply_candidate(b,changes);after=b.evaluate(q,v,a)['tension_N'];indices=[i for i,r in enumerate(b.rows) if r['leg'] in ['LM','RM','LH','RH']];front=[i for i,r in enumerate(b.rows) if r['leg'] in ['LF','RF']]
np.testing.assert_allclose(after[indices],before[indices]*.9,rtol=1e-10,atol=1e-15);np.testing.assert_array_equal(after[front],before[front])
invalid_rejected=False
try:apply_candidate(b,{u['records'][0]['id']:{'specific_stress_Pa':1e9}})
except ParameterBoundsError:invalid_rejected=True
assert invalid_rejected
same=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in hashes.items());assert same
out={'uncertain_middle_hind_muscles':len(u['records']),'parameter_entries':sum(len(r['parameters']) for r in u['records']),'measured_unknowns_remain_null':all(s.get('measured_value') is None for r in u['records'] for s in r['parameters'].values()),'bounded_native_parameters_applied_in_memory':True,'stress_change_produces_expected_force_change':True,'foreleg_force_unchanged':True,'invalid_candidate_rejected':invalid_rejected,'original_models_and_prior_files_unchanged':same,'optimization_performed':False,'passed':True}
(ROOT/'uncertainty_validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
