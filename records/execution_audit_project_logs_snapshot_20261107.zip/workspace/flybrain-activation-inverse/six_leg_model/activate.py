from pathlib import Path
import json,hashlib,copy
ROOT=Path(__file__).resolve().parent;project=ROOT.parent
meta=json.loads((ROOT/'manifest.json').read_text());validation=json.loads((ROOT/'validation.json').read_text());assert validation['passed']
selection={'schema':'muscle_model_selection_v2','selected_family':'FlyMimic-six-leg','selected_backend':str(ROOT/'backend.py'),'manifest':str(ROOT/'manifest.json'),'native_model':str(ROOT/'six_leg_muscles.xml'),'operational_scope':['LF','RF','LM','RM','LH','RH'],'muscle_channels':130,'catalog_slots_covered':126,'full_body_integration':'operational working model on flybody joint frames; geometry transfer and unknown attachments remain estimated','legacy_default_for_new_experiments':False,'native_LF_reference':str(project/'flymimic_adoption/manifest.json'),'geometry_policy':'LF/RF upstream anatomical templates registered by bone frames; other categories retain existing leg-specific geometry hypotheses','physiology_policy':'native MuJoCo/FlyMimic muscle equation family; bounded volume/PCSA/stress priors for force; unknown parameters explicitly estimated','walking_validated':False}
if 'middle_hind_uncertainty' in meta:selection['middle_hind_uncertainty']=meta['middle_hind_uncertainty']
(project/'muscle_model_selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2))
canon=Path('/workspace/flybrain-muscle-rebuild/brain.json');mirror=Path('/workspace/flybrain-recovered/brain.json');brain=json.loads(canon.read_text());assert brain==json.loads(mirror.read_text());before=copy.deepcopy(brain)
backup=ROOT/'brain_before_six_leg_selection.json'
if not backup.exists():backup.write_bytes(canon.read_bytes())
brain['muscle_model_selection']=selection
for k,v in before.items():
 if k!='muscle_model_selection':assert brain[k]==v
blob=json.dumps(brain,ensure_ascii=False,indent=2)+'\n';canon.write_text(blob);mirror.write_text(blob)
preservation={'all_preexisting_nonselection_sections_unchanged':True,'original_126_catalog_slots_preserved':len(brain['muscle_table']['catalog'])==126,'canonical_and_mirror_identical':canon.read_bytes()==mirror.read_bytes(),'previous_foreleg_backend_retained':True,'older_optimized_geometry_retained':True,'no_neuron_to_MTU_gains_assigned':True,'source_hashes_still_match':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in meta['source_hashes'].items())}
(ROOT/'preservation_report.json').write_text(json.dumps(preservation,indent=2));assert all(preservation.values());print('Selected six-leg working model; original evidence and historical experiments preserved.')
