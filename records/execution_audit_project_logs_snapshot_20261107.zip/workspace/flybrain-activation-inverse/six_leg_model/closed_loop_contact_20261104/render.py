import os
os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/tmp/refine-mesa',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import numpy as np,mujoco,imageio
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parent;m=mujoco.MjModel.from_xml_path(str(ROOT/'bounded_refined_muscles.xml'));d=mujoco.MjData(m);z=np.load(ROOT/'bounded_default/rollout.npz');Q=z['qpos'];V=z['qvel'];T=z['time_s'];renderer=mujoco.Renderer(m,height=240,width=320);opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
with imageio.get_writer(ROOT/'bounded_default/closed_loop.mp4',fps=15,codec='libx264',quality=8) as writer:
 for t in np.arange(0,T[-1],1/15):
  i=int(np.argmin(np.abs(T-t)));d.qpos[:]=Q[i];d.qvel[:]=V[i];d.time=T[i];mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=opt);im=Image.fromarray(renderer.render());draw=ImageDraw.Draw(im);draw.rectangle((0,0,320,28),fill='black');draw.text((4,4),f'Closed-loop: not walking | {T[i]:.2f}s | 1x',fill='white');writer.append_data(np.asarray(im))
renderer.close();print('Rendered saved free dynamics without re-simulating.')
