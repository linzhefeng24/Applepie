from pathlib import Path
import subprocess,sys,json,time
from concurrent.futures import ProcessPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parent
cases=[('d160','default',160,1.2,20,2,.001),('d320','default',320,1.5,20,2,.001),('d80','default',80,1.2,20,2,.001),('f160','fast_prior',160,1.2,20,2,.001),('f320','fast_prior',320,1.5,20,2,.001),('f480','fast_prior',480,2.,30,2,.0001),('fbody','fast_prior',160,1.5,30,5,.0001),('ftorque','fast_prior',320,1.5,30,2,.01)]
def run(case):
 name,kin,omega,zeta,body,bw,tw=case;args=[sys.executable,str(ROOT/'run.py'),'--name','screen_'+name,'--seconds','.6','--kinetics',kin,'--omega',str(omega),'--zeta',str(zeta),'--body-omega',str(body),'--body-weight',str(bw),'--torque-weight',str(tw)]
 with (ROOT/('screen_'+name+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 p=ROOT/('screen_'+name)/'report.json'
 if p.exists():d=json.loads(p.read_text());d['screen_case']=name;d['process_returncode']=r.returncode;return d
 return {'screen_case':name,'error':'no report','process_returncode':r.returncode}
if __name__=='__main__':
 results=[]
 with ProcessPoolExecutor(max_workers=3) as pool:
  futures=[pool.submit(run,c) for c in cases]
  for f in as_completed(futures):
   d=f.result();results.append(d);(ROOT/'screen_results.json').write_text(json.dumps(results,indent=2));print(d['screen_case'],d.get('joint_angle_rmse_deg'),d.get('displacement_xyz_mm'),d.get('qp_failure_count'),d.get('failure'),flush=True)
