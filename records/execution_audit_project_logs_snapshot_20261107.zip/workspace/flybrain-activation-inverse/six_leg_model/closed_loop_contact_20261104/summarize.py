from pathlib import Path
import numpy as np,json,csv,gzip
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
names=['bounded_default','bounded_ff_default','bounded_ff_fast','bounded_fast_track','adh_off_fast','adh_phase_fast','adh_phase_qfast','adh_phase_default','final_phase_default']
rows=[]
base=np.load(R/'bounded_open_loop/rollout.npz')
fig,axs=plt.subplots(2,1,figsize=(10,7),constrained_layout=True)
axs[0].plot(base['time_s'],base['joint_rmse_rad']*180/np.pi,label='Open loop, same bounded muscle model')
for name in names:
 p=R/name/'report.json'
 if not p.exists():continue
 report=json.loads(p.read_text());z=np.load(p.parent/'rollout.npz');t=z['time_s'];b=np.interp(t,base['time_s'],base['joint_rmse_rad']);matched=float(np.sqrt(np.mean(b*b))*180/np.pi)
 rows.append(dict(case=name,duration_s=report['simulated_duration_s'],joint_rmse_deg=report['joint_angle_rmse_deg'],previous_open_loop_same_times_rmse_deg=matched,forward_mm=report['displacement_xyz_mm'][0],lateral_mm=report['displacement_xyz_mm'][1],fell=report['failure'] is not None,normal_walking=report['passes_defined_walking_checks']))
 if name in ['bounded_default','bounded_ff_default','final_phase_default']:
  axs[0].plot(t,z['joint_rmse_rad']*180/np.pi,label=name);axs[1].plot(t,z['thorax_mm'][:,0]-z['thorax_mm'][0,0],label=name)
axs[0].set(ylabel='Joint angle RMSE (deg)');axs[1].set(xlabel='Time (s)',ylabel='Forward displacement (mm)')
for ax in axs:ax.legend();ax.grid(alpha=.3)
fig.savefig(R/'comparison.png',dpi=150);plt.close(fig)
(R/'comparison.json').write_text(json.dumps(rows,indent=2))
with (R/'comparison.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
p=R/'bounded_default/activation_5000Hz.npz';z=np.load(p)
with gzip.open(p.with_suffix('.csv.gz'),'wt') as f:
 w=csv.writer(f);w.writerow(['time_s']+['a:'+str(x) for x in z['muscle_ids']]+['u:'+str(x) for x in z['muscle_ids']]);w.writerows(np.column_stack([z['time_s'],z['activation'],z['excitation']]))
print(json.dumps(rows,indent=2))
