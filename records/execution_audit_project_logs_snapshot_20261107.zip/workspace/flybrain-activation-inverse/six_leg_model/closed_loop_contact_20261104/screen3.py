from pathlib import Path
import subprocess,sys,json
from concurrent.futures import ProcessPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parent
cases=[('ud80','default',80,1.2,6,False),('uf80','fast_prior',80,1.2,6,False),('uf120','fast_prior',120,1.5,6,False),('uf160','fast_prior',160,1.5,6,False),('if120','fast_prior',120,1.5,6,True),('id80','default',80,1.2,6,True)]
def run(c):
 name,kin,w,z,hold,init=c;args=[sys.executable,str(ROOT/'run.py'),'--name','screen3_'+name,'--seconds','.6','--kinetics',kin,'--omega',str(w),'--zeta',str(z),'--body-weight','1','--body-hold',str(hold),'--body-guard','--uniform-angle-weights','--torque-weight','.001']
 if init:args+=['--initialize-contact-load']
 with (ROOT/('screen3_'+name+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 p=ROOT/('screen3_'+name)/'report.json'
 if p.exists():d=json.loads(p.read_text());d['screen_case']=name;return d
 return {'screen_case':name,'error':'no report','returncode':r.returncode}
if __name__=='__main__':
 results=[]
 with ProcessPoolExecutor(max_workers=2) as pool:
  for f in as_completed([pool.submit(run,c) for c in cases]):
   d=f.result();results.append(d);(ROOT/'screen3_results.json').write_text(json.dumps(results,indent=2));print(d['screen_case'],d.get('joint_angle_rmse_deg'),d.get('displacement_xyz_mm'),d.get('qp_failure_count'),d.get('failure'),flush=True)
