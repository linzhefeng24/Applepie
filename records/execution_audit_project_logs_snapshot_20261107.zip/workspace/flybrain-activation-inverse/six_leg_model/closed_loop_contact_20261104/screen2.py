from pathlib import Path
import subprocess,sys,json
from concurrent.futures import ProcessPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parent
cases=[('dh80','default',80,1.2,20,1,6,0,False),('dp160','default',160,1.5,20,1,10,.015,True),('dp80','default',80,1.2,20,1,10,.02,True),('fh160','fast_prior',160,1.2,20,1,6,0,False),('fh320','fast_prior',320,1.5,20,1,10,.002,False),('fh120','fast_prior',120,1.5,20,1,20,0,False),('fp240','fast_prior',240,1.5,20,1,6,.006,True),('fh240','fast_prior',240,2.,20,1,10,0,False)]
def run(c):
 name,kin,w,z,bw,bweight,hold,preview,adh=c;args=[sys.executable,str(ROOT/'run.py'),'--name','screen2_'+name,'--seconds','.6','--kinetics',kin,'--omega',str(w),'--zeta',str(z),'--body-omega',str(bw),'--body-weight',str(bweight),'--body-hold',str(hold),'--body-guard','--preview',str(preview),'--torque-weight','.001']
 if adh:args+=['--adhesion-preview']
 with (ROOT/('screen2_'+name+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 p=ROOT/('screen2_'+name)/'report.json'
 if p.exists():d=json.loads(p.read_text());d['screen_case']=name;return d
 return {'screen_case':name,'error':'no report','returncode':r.returncode}
if __name__=='__main__':
 results=[]
 with ProcessPoolExecutor(max_workers=3) as pool:
  for f in as_completed([pool.submit(run,c) for c in cases]):
   d=f.result();results.append(d);(ROOT/'screen2_results.json').write_text(json.dumps(results,indent=2));print(d['screen_case'],d.get('joint_angle_rmse_deg'),d.get('displacement_xyz_mm'),d.get('qp_failure_count'),d.get('failure'),flush=True)
