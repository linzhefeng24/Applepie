from pathlib import Path
import subprocess,sys,json
from concurrent.futures import ProcessPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parent
cases=[('off_fast','fast_prior',120,1.5,'off',True),('phase_fast','fast_prior',120,1.5,'phase',True),('phase_qfast','fast_prior',120,1.5,'phase',False),('phase_default','default',80,1.2,'phase',True)]
def run(c):
 name,kin,w,z,mode,ff=c;args=[sys.executable,str(ROOT/'run.py'),'--name','adh_'+name,'--seconds','.6','--kinetics',kin,'--omega',str(w),'--zeta',str(z),'--body-weight','1','--body-hold','6','--body-guard','--uniform-angle-weights','--adhesion-mode',mode,'--adhesion-scale','.3']
 if ff:args+=['--native-torque-feedforward']
 with (ROOT/('adh_'+name+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 p=ROOT/('adh_'+name)/'report.json'
 if p.exists():d=json.loads(p.read_text());d['screen_case']=name;return d
 return {'screen_case':name,'error':'no report','returncode':r.returncode}
if __name__=='__main__':
 results=[]
 with ProcessPoolExecutor(max_workers=3) as pool:
  for f in as_completed([pool.submit(run,c) for c in cases]):
   d=f.result();results.append(d);(ROOT/'adhesion_screen_results.json').write_text(json.dumps(results,indent=2));print(d['screen_case'],d.get('joint_angle_rmse_deg'),d.get('displacement_xyz_mm'),d.get('qp_failure_count'),d.get('failure'),flush=True)
