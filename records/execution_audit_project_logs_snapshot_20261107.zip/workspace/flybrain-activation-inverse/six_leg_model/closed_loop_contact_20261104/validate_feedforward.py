import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,numpy as np,mujoco
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));from controller import MuscleContactTracker
R=ROOT.parent/'activation_refine_20261104';rows=json.load(open(R/'records.json'))['records'];m=mujoco.MjModel.from_xml_path(str(ROOT/'bounded_refined_muscles.xml'));old=mujoco.MjModel.from_xml_path('/workspace/fly-walking-run/output/model/walking.xml');old.opt.timestep=m.opt.timestep;d=mujoco.MjData(m);od=mujoco.MjData(old);z=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');src={k:z[k] for k in ['qpos','qvel','ctrl','act','leg_tau_drive_Nm']};ids=np.array([r['actuator_index'] for r in rows]);adrs=m.actuator_actadr[ids];dofs=z['joint_dof_indices'];qa=z['joint_qpos_indices'];names=z['joint_names'].tolist();legs=['LF','RF','LM','RM','LH','RH'];tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];groups=[(np.array([j for j,n in enumerate(names) if n.endswith(tok)]),np.array([i for i,r in enumerate(rows) if r['leg']==leg])) for leg,tok in zip(legs,tokens)];c=MuscleContactTracker(m,src,rows,ids,dofs,qa,groups);keep=[];legold=[]
for i in range(old.nu):
 name=mujoco.mj_id2name(old,mujoco.mjtObj.mjOBJ_ACTUATOR,i);j=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_ACTUATOR,name)
 if j>=0:keep.append((i,j))
 else:legold.append(i)
old.actuator_gainprm[legold]=0;old.actuator_biasprm[legold]=0;errors=[];forces=[]
for t in [0,3210,12345]:
 mujoco.mj_resetData(m,d);mujoco.mj_resetData(old,od);d.qpos[:]=src['qpos'][t];od.qpos[:]=d.qpos;d.qvel[:]=src['qvel'][t];od.qvel[:]=d.qvel;d.act[adrs]=np.random.default_rng(t+5).uniform(0,1,len(ids));od.act[:]=src['act'][t];od.ctrl[:]=src['ctrl'][t]
 for i,j in keep:
  d.ctrl[j]=src['ctrl'][t,i]
  if m.actuator_actadr[j]>=0:d.act[m.actuator_actadr[j]]=src['act'][t,old.actuator_actadr[i]]
 mujoco.mj_forward(m,d);B,tau=c.force_map(d);c.probe.set_state(d);target=np.mean(src['leg_tau_drive_Nm'][t:t+11],axis=0)*1e7;delta=np.zeros(m.nv);delta[dofs]=target-tau[dofs];a,lam,_=c.probe.evaluate(delta);od.qfrc_applied[dofs]=target;mujoco.mj_forward(old,od);errors.append(float(np.linalg.norm(a-od.qacc)/max(np.linalg.norm(od.qacc),1e-12)));forces.append(float(np.linalg.norm(lam-od.efc_force)/max(np.linalg.norm(od.efc_force),1e-12)))
# Airborne: internal muscle force changes cannot accelerate the walker COM.
mujoco.mj_resetData(m,d);d.qpos[:]=src['qpos'][0];d.qvel[:]=src['qvel'][0];d.qpos[c.rootq+2]+=1.;d.act[adrs]=.3;mujoco.mj_forward(m,d);B,_=c.force_map(d);c.probe.set_state(d);a0,_,_=c.probe.evaluate(np.zeros(m.nv));a1,_,_=c.probe.evaluate(B@np.random.default_rng(9).uniform(-.1,.1,len(ids)));jac=np.zeros((3,m.nv));thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');mujoco.mj_jacSubtreeCom(m,d,jac,thorax);com=float(np.linalg.norm(jac@(a1-a0)));ground=sum(int(m.geom_bodyid[int(d.contact[i].geom1)]==0 or m.geom_bodyid[int(d.contact[i].geom2)]==0) for i in range(d.ncon))
report={'native_torque_feedforward_vs_original_plant_same_state_max_qacc_relative_error':max(errors),'native_torque_feedforward_vs_original_plant_same_state_max_contact_force_relative_error':max(forces),'same_state_feedforward_comparison_samples':3,'airborne_ground_contacts':ground,'airborne_internal_muscle_force_COM_acceleration_change_cm_s2':com,'external_forces_used_only_in_disposable_validation_probes':True};report['passed']=bool(max(errors)<1e-7 and max(forces)<1e-7 and ground==0 and com<1e-6);(ROOT/'feedforward_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['passed']
