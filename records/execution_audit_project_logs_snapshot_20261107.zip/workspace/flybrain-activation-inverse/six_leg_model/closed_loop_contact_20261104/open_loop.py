import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,time
import numpy as np,mujoco
from scipy.ndimage import median_filter
OUT=Path(__file__).resolve().parent/'bounded_open_loop';OUT.mkdir(exist_ok=True);ROOT=Path(__file__).resolve().parent.parent/'activation_refine_20261104';PREV=ROOT.parent/'activation_fit_20261104';sys.path.insert(0,str(PREV));from fit import Problem

def configure(m,rows,case,P):
 ids=np.array([r['actuator_index'] for r in rows]);changed=[]
 if case=='fast_prior':
  for k,r in enumerate(rows):
   if r['source_family']=='FlyMimic':continue
   priors=[P.prior[id] for id in r['catalog_ids']];m.actuator_dynprm[ids[k],0]=max(p['estimated']['activation_tau_s']['working'][0] for p in priors);m.actuator_dynprm[ids[k],1]=max(p['estimated']['deactivation_tau_s']['working'][0] for p in priors);changed.append(r['id'])
 return ids,changed

def activation(case):
 P=Problem();rows=json.load(open(ROOT/'records.json'))['records'];m=mujoco.MjModel.from_xml_path(str(OUT.parent/'bounded_refined_muscles.xml'));ids,changed=configure(m,rows,case,P);labels=np.load(ROOT/'activation_6s_5000Hz.npz');ref=labels['activation'];dt=m.opt.timestep;N=round(6/dt);a=ref[0].astype(float);uout=np.empty((N,len(a)),dtype='f4');actual=np.empty_like(ref);clipped=0;error=0.;count=0
 for t in range(N):
  phase=min((t+1)*dt/.0002,len(ref)-1);lo=int(phase);fraction=phase-lo;target=(1-fraction)*ref[lo]+fraction*ref[min(lo+1,len(ref)-1)];delta=target-a;factor=.5+1.5*a;tau=np.where(delta>0,m.actuator_dynprm[ids,0]*factor,m.actuator_dynprm[ids,1]/factor);raw=a+delta*tau/dt;u=np.clip(raw,0,1);uout[t]=u;clipped+=int(np.sum((raw<0)|(raw>1)))
  if t%2==0:actual[t//2]=a;error+=float(np.sum((a-ref[t//2])**2));count+=len(a)
  # Exact explicit native dynamics, independently checked against MuJoCo.
  factor=.5+1.5*a;rate=(u-a)/np.where(u>a,m.actuator_dynprm[ids,0]*factor,m.actuator_dynprm[ids,1]/factor);a=np.clip(a+dt*rate,0,1)
 np.savez_compressed(ROOT/f'excitation_{case}.npz',time_s=np.arange(N)*dt,excitation=uout,activation_5kHz=actual,activation_time_constants_s=m.actuator_dynprm[ids,:2],muscle_ids=labels['muscle_ids'])
 report={'minimum_activation_all_physics_steps':amin,'maximum_activation_all_physics_steps':amax,'case':case,'activation_tracking_rmse':float(np.sqrt(error/count)),'clipped_channel_time_fraction':clipped/uout.size,'changed_time_constant_muscles':len(changed),'changed_ids':changed,'case_interpretation':'minimum allowed engineering-prior time constants, sensitivity only; not physiological identification' if changed else 'unchanged previous activation kinetics','force_geometry_and_labels_unchanged':True};(ROOT/f'activation_feasibility_{case}.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

def forward(case):
 P=Problem();rows=json.load(open(ROOT/'records.json'))['records'];m=mujoco.MjModel.from_xml_path(str(OUT.parent/'bounded_refined_muscles.xml'));ids,changed=configure(m,rows,case,P);d=mujoco.MjData(m);old=P.b.model;oldact=np.array([mujoco.mj_name2id(old,mujoco.mjtObj.mjOBJ_ACTUATOR,mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_ACTUATOR,j)) for j in range(m.nu)]);retained=[(int(i),j) for j,i in enumerate(oldact) if i>=0 and j not in set(ids)]
 # P.b is already the muscle model; use the original walking model for its 59 channels.
 old=mujoco.MjModel.from_xml_path('/workspace/fly-walking-run/output/model/walking.xml');retained=[]
 for i in range(old.nu):
  j=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_ACTUATOR,mujoco.mj_id2name(old,mujoco.mjtObj.mjOBJ_ACTUATOR,i))
  if j>=0:retained.append((i,j))
 assert len(retained)==11
 source={k:P.z[k] for k in ['qpos','qvel','act','ctrl']};labels=np.load(ROOT/'activation_6s_5000Hz.npz');refa=labels['activation'];planned=np.load(ROOT/f'excitation_{case}.npz');u=planned['excitation'];adrs=m.actuator_actadr[ids];d.qpos[:]=source['qpos'][0];d.qvel[:]=source['qvel'][0];d.act[adrs]=refa[0]
 for i,j in retained:
  d.ctrl[j]=source['ctrl'][0,i]
  if old.actuator_actadr[i]>=0 and m.actuator_actadr[j]>=0:d.act[m.actuator_actadr[j]]=source['act'][0,old.actuator_actadr[i]]
 mujoco.mj_forward(m,d);thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');ground={i for i in range(m.ngeom) if m.geom_bodyid[i]==0};tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];geomleg={}
 for i in range(m.ngeom):
  name=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or ''
  if name.startswith('walker/') and any(t in name for t in ['tarsus','claw']):
   for k,token in enumerate(tokens):
    if token in name:geomleg[i]=k
 buffers={k:[] for k in ['time_s','qpos','qvel','thorax_mm','up_z','thorax_ground_contact','support_dyne','joint_rmse_rad','activation_actual','activation_target']};warning0=[w.number for w in d.warning];fall_count=0;failure=None;amin=1.;amax=0.;cf=np.zeros(6);clock=time.monotonic();dt=m.opt.timestep
 for step in range(len(u)):
  i=min(step//2,len(refa)-1);d.ctrl[ids]=u[step]
  for src,dest in retained:d.ctrl[dest]=source['ctrl'][i,src]
  if step%10==0:
   mujoco.mj_forward(m,d);support=np.zeros(6);touch=False
   for ci in range(d.ncon):
    c=d.contact[ci];g1,g2=int(c.geom1),int(c.geom2);other=g2 if g1 in ground else g1 if g2 in ground else None
    if other is None or c.efc_address<0:continue
    if int(m.geom_bodyid[other])==thorax:touch=True
    if other in geomleg:mujoco.mj_contactForce(m,d,ci,cf);support[geomleg[other]]+=max(0.,cf[0])
   up=float(d.xmat[thorax].reshape(3,3)[2,2]);fall_count=fall_count+1 if touch or up<.5 else 0
   values=dict(time_s=float(d.time),qpos=d.qpos.copy(),qvel=d.qvel.copy(),thorax_mm=d.xpos[thorax].copy()*10,up_z=up,thorax_ground_contact=touch,support_dyne=support,joint_rmse_rad=float(np.sqrt(np.mean((d.qpos[P.b.qadrs]-source['qpos'][i,P.b.qadrs])**2))),activation_actual=d.act[adrs].copy(),activation_target=refa[i].copy())
   for key,value in values.items():buffers[key].append(value)
   if fall_count>=5:failure={'time_s':float(d.time),'reason':'sustained fall for 5ms'};break
  mujoco.mj_step(m,d);amin=min(amin,float(d.act[adrs].min()));amax=max(amax,float(d.act[adrs].max()))
  if any(d.warning[j].number>warning0[j] for j in [int(mujoco.mjtWarning.mjWARN_BADQPOS),int(mujoco.mjtWarning.mjWARN_BADQVEL),int(mujoco.mjtWarning.mjWARN_BADQACC)]) or not np.all(np.isfinite(d.qpos)):failure={'time_s':float(d.time),'reason':'numerical warning or nonfinite state'};break
  if step%10000==0:print('forward',case,'time',d.time,'wall',time.monotonic()-clock,flush=True)
 a={k:np.asarray(v) for k,v in buffers.items()};np.savez_compressed(OUT/'rollout.npz',**a);xyz=a['thorax_mm'];displacement=xyz[-1]-xyz[0];weight=m.body_subtreemass[thorax]*np.linalg.norm(m.opt.gravity);stance=median_filter(a['support_dyne']>weight*.01,size=(5,1),mode='nearest');transitions=np.sum(stance[1:]!=stance[:-1],axis=0);support=float(np.mean(np.any(stance,axis=1)));joint_error=float(np.sqrt(np.mean(a['joint_rmse_rad']**2))*180/np.pi)
 report={'minimum_activation_all_physics_steps':amin,'maximum_activation_all_physics_steps':amax,'case':case,'simulated_duration_s':float(d.time),'failure':failure,'displacement_xyz_mm':displacement.tolist(),'displacement_xy_mm':float(np.linalg.norm(displacement[:2])),'min_thorax_up_z':float(a['up_z'].min()),'thorax_ground_contact_samples':int(a['thorax_ground_contact'].sum()),'joint_angle_rmse_deg':joint_error,'activation_tracking_rmse':float(np.sqrt(np.mean((a['activation_actual']-a['activation_target'])**2))),'foot_support_fraction':support,'per_leg_contact_transitions':dict(zip(P.groups,transitions.tolist())),'max_external_generalized_force_native':float(np.max(np.abs(d.qfrc_applied))),'pose_overwrites_after_initialization':False,'activation_overwrites_after_initialization':False,'nonmuscle_control_channels_retained':len(retained),'kinetic_sensitivity_case':bool(changed),'wall_seconds':time.monotonic()-clock}
 report['passes_defined_walking_checks']=bool(failure is None and d.time>=5.999 and displacement[0]>10 and abs(displacement[1])<abs(displacement[0]) and report['min_thorax_up_z']>.7 and not report['thorax_ground_contact_samples'] and support>.8 and min(transitions)>=4 and joint_error<20);(OUT/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':{'activation':activation,'forward':forward}[sys.argv[1]](sys.argv[2])
