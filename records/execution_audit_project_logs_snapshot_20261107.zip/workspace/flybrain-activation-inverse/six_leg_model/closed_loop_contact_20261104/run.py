import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,argparse,time,hashlib
import numpy as np,mujoco
from scipy.ndimage import median_filter
ROOT=Path(__file__).resolve().parent;REFINE=ROOT.parent/'activation_refine_20261104';PREV=ROOT.parent/'activation_fit_20261104';sys.path.insert(0,str(ROOT));from controller import MuscleContactTracker
parser=argparse.ArgumentParser();parser.add_argument('--name',default='trial');parser.add_argument('--seconds',type=float,default=.2);parser.add_argument('--omega',type=float,default=160.);parser.add_argument('--zeta',type=float,default=1.2);parser.add_argument('--body-omega',type=float,default=20.);parser.add_argument('--body-weight',type=float,default=2.);parser.add_argument('--torque-weight',type=float,default=.001);parser.add_argument('--kinetics',choices=['default','fast_prior'],default='default');parser.add_argument('--iterations',type=int,default=1);parser.add_argument('--adhesion-mode',choices=['reference','phase','off'],default='reference');parser.add_argument('--adhesion-scale',type=float,default=.3);parser.add_argument('--adhesion-lead',type=float,default=.008);parser.add_argument('--native-torque-feedforward',action='store_true');parser.add_argument('--uniform-angle-weights',action='store_true');parser.add_argument('--initialize-contact-load',action='store_true');parser.add_argument('--record-physics',action='store_true');parser.add_argument('--body-guard',action='store_true');parser.add_argument('--body-hold',type=float,default=1.);parser.add_argument('--preview',type=float,default=0.);parser.add_argument('--adhesion-preview',action='store_true');parser.add_argument('--control-dt',type=float,default=.002);args=parser.parse_args();OUT=ROOT/args.name;OUT.mkdir(exist_ok=True)
source_file=Path('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');raw=np.load(source_file);source={k:raw[k] for k in ['time_s','qpos','qvel','qacc','act','ctrl','leg_tau_drive_Nm','joint_dof_indices','joint_qpos_indices','joint_names']};source['foot_support_normal_dyne']=raw['foot_support_normal_dyne'];source_sha=hashlib.sha256(source_file.read_bytes()).hexdigest();meta=json.load(open(ROOT.parent/'manifest.json'));rows=json.load(open(REFINE/'records.json'))['records'];m=mujoco.MjModel.from_xml_path(str(ROOT/'bounded_refined_muscles.xml'));d=mujoco.MjData(m);ids=np.array([r['actuator_index'] for r in rows]);adrs=m.actuator_actadr[ids]
if args.kinetics=='fast_prior':
 priors={r['id']:r for r in json.load(open('/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json'))['muscles']}
 for k,r in enumerate(rows):
  if r['source_family']=='FlyMimic':continue
  pp=[priors[id] for id in r['catalog_ids']];m.actuator_dynprm[ids[k],0]=max(p['estimated']['activation_tau_s']['working'][0] for p in pp);m.actuator_dynprm[ids[k],1]=max(p['estimated']['deactivation_tau_s']['working'][0] for p in pp)
old=mujoco.MjModel.from_xml_path('/workspace/fly-walking-run/output/model/walking.xml');retained=[]
for i in range(old.nu):
 j=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_ACTUATOR,mujoco.mj_id2name(old,mujoco.mjtObj.mjOBJ_ACTUATOR,i))
 if j>=0:retained.append((i,j))
assert len(retained)==11 and m.nu-len(ids)==11
labels=np.load(REFINE/'activation_6s_5000Hz.npz');initial_activation=labels['activation'][0].copy();d.qpos[:]=source['qpos'][0];d.qvel[:]=source['qvel'][0];d.act[adrs]=initial_activation
for i,j in retained:
 d.ctrl[j]=source['ctrl'][0,i]
 if m.actuator_actadr[j]>=0 and old.actuator_actadr[i]>=0:d.act[m.actuator_actadr[j]]=source['act'][0,old.actuator_actadr[i]]
dofs=source['joint_dof_indices'];qadrs=source['joint_qpos_indices'];joint_names=source['joint_names'].tolist();leg_names=['LF','RF','LM','RM','LH','RH'];tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];groups=[(np.array([j for j,n in enumerate(joint_names) if n.endswith(tok)]),np.array([k for k,r in enumerate(rows) if r['leg']==leg])) for leg,tok in zip(leg_names,tokens)]
controller=MuscleContactTracker(m,source,rows,ids,dofs,qadrs,groups,args.omega,args.zeta,args.body_omega,args.body_weight,args.torque_weight,args.control_dt,args.iterations);controller.accweights[[2,3,4,5]]*=args.body_hold;controller.preview_frames=round(args.preview/.0002);controller.body_guard=args.body_guard;controller.native_torque_feedforward=args.native_torque_feedforward
if args.uniform_angle_weights:controller.accweights[6:]=1/(args.omega**2*.2)
mujoco.mj_forward(m,d)
initialization=None
if args.initialize_contact_load:
 controller.initializing=True;previous_iterations=controller.iterations;controller.iterations=3
 _,initialization=controller.solve(d,0);d.act[adrs]=initialization['target_activation'];mujoco.mj_forward(m,d);controller.initializing=False;controller.iterations=previous_iterations
thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');ground={i for i in range(m.ngeom) if m.geom_bodyid[i]==0};geomleg={}
for i in range(m.ngeom):
 name=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or ''
 if name.startswith('walker/') and any(s in name for s in ['tarsus','claw']):
  for k,tok in enumerate(tokens):
   if tok in name:geomleg[i]=k
adh_ids=np.array([next(j for i,j in retained if m.actuator_trntype[j]==int(mujoco.mjtTrn.mjTRN_BODY) and tok in (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,int(m.actuator_trnid[j,0])) or '')) for tok in tokens]);adh_leg={int(j):k for k,j in enumerate(adh_ids)};refstance=median_filter(source['foot_support_normal_dyne']>m.body_subtreemass[thorax]*np.linalg.norm(m.opt.gravity)*.02,size=(25,1),mode='nearest')
assert 0<=args.adhesion_scale<=1
logs={k:[] for k in ['time_s','qpos','qvel','thorax_mm','up_z','joint_rmse_rad','activation','excitation','adhesion_command','adhesion_activation','planned_activation','muscle_torque_Nm','reference_torque_Nm','support_dyne','thorax_ground','max_ground_penetration_cm','friction_ratio','controller_wall_s','controller_initial_cost','controller_final_cost','contact_response_consistency','contact_response_norm','contact_gap_constraints','friction_constraints','ground_slack_cm','body_slack_normalized','joint_slack_rad','qp_ok','nonlinear_prediction_error']};details=[];warnings0=[w.number for w in d.warning];clock=time.monotonic();failure=None;fallcount=0;cf=np.zeros(6);moment=np.zeros((m.nu,m.nv));main_state_changed=False;control_fail=0;activation_min_seen=float(d.act[adrs].min());activation_max_seen=float(d.act[adrs].max());controls=round(args.seconds/args.control_dt);physics_times=[];physics_activations=[];physics_excitation=[];physics_angles=[]
for step in range(controls):
 frame=min(round(d.time/.0002),len(source['time_s'])-1)
 for i,j in retained:
  control_frame=min(frame+round(args.preview/.0002),len(source['time_s'])-1) if args.adhesion_preview and m.actuator_trntype[j]==int(mujoco.mjtTrn.mjTRN_BODY) else frame
  d.ctrl[j]=source['ctrl'][control_frame,i]
  if j in adh_leg and args.adhesion_mode!='reference':
   phase_frame=min(frame+round(args.adhesion_lead/.0002),len(source['time_s'])-1);d.ctrl[j]=0. if args.adhesion_mode=='off' else args.adhesion_scale*refstance[phase_frame,adh_leg[j]]

 mujoco.mj_forward(m,d);q_before=d.qpos.copy();v_before=d.qvel.copy();a_before=d.act.copy();u,info=controller.solve(d,int(frame));assert np.array_equal(q_before,d.qpos) and np.array_equal(v_before,d.qvel) and np.array_equal(a_before,d.act)
 d.ctrl[ids]=u;support=np.zeros(6);touch=False;maxpenetration=0.;maxfriction=0.
 for ci in range(d.ncon):
  c=d.contact[ci];g1,g2=int(c.geom1),int(c.geom2);other=g2 if g1 in ground else g1 if g2 in ground else None
  if other is None:continue
  maxpenetration=max(maxpenetration,max(0.,-float(c.dist)))
  if c.efc_address<0:continue
  if int(m.geom_bodyid[other])==thorax:touch=True
  if other in geomleg:mujoco.mj_contactForce(m,d,ci,cf);support[geomleg[other]]+=max(0.,cf[0])
  addr=int(c.efc_address);dim=int(c.dim);force=d.efc_force[addr:addr+dim]
  if dim>1 and force[0]>1e-7:maxfriction=max(maxfriction,float(np.linalg.norm(force[1:]/np.maximum(np.array(c.friction[:dim-1]),1e-10))/force[0]))
 up=float(d.xmat[thorax].reshape(3,3)[2,2]);fallcount=fallcount+1 if touch or up<.5 else 0;mujoco.mju_sparse2dense(moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);tau=(moment[ids].T@d.actuator_force[ids])[dofs]*1e-7;qpok=all(s in ['solved','solved inaccurate'] for s in info['qp_statuses']);control_fail+=int(not qpok)
 data=dict(time_s=float(d.time),qpos=d.qpos.copy(),qvel=d.qvel.copy(),thorax_mm=d.xpos[thorax].copy()*10,up_z=up,joint_rmse_rad=float(np.sqrt(np.mean((d.qpos[qadrs]-source['qpos'][frame,qadrs])**2))),activation=d.act[adrs].copy(),excitation=u.copy(),adhesion_command=d.ctrl[adh_ids].copy(),adhesion_activation=d.act[m.actuator_actadr[adh_ids]].copy(),planned_activation=info['target_activation'],muscle_torque_Nm=tau,reference_torque_Nm=source['leg_tau_drive_Nm'][frame],support_dyne=support,thorax_ground=touch,max_ground_penetration_cm=maxpenetration,friction_ratio=maxfriction,controller_wall_s=info['wall_s'],controller_initial_cost=info['initial_cost'],controller_final_cost=info['final_cost'],contact_response_consistency=info['max_dynamics_consistency_relative_error'],contact_response_norm=info['ground_contact_force_sensitivity_norm'],contact_gap_constraints=info['ground_gap_constraints'],friction_constraints=info['friction_linear_constraints'],ground_slack_cm=info['max_ground_prediction_slack_cm'],body_slack_normalized=info['max_body_prediction_slack_normalized'],joint_slack_rad=info['max_joint_prediction_slack_rad'],qp_ok=qpok,nonlinear_prediction_error=max(info['nonlinear_acceleration_prediction_relative_errors'],default=0.))
 for key,value in data.items():logs[key].append(value)
 if step%50==0:print(args.name,'control',step,'t',d.time,'qerr_deg',data['joint_rmse_rad']*180/np.pi,'xyz_mm',data['thorax_mm'],'qp',info['qp_statuses'],'wall',time.monotonic()-clock,flush=True)
 if fallcount>=max(1,round(.006/args.control_dt)):failure={'reason':'sustained thorax contact or inverted posture','time_s':float(d.time)};break
 for sub in range(controller.substeps):
  if args.record_physics and sub%2==0:physics_times.append(float(d.time));physics_activations.append(d.act[adrs].astype('f4').copy());physics_excitation.append(u.astype('f4').copy());physics_angles.append(d.qpos[qadrs].astype('f4').copy())
  mujoco.mj_step(m,d)
  activation_min_seen=min(activation_min_seen,float(d.act[adrs].min()));activation_max_seen=max(activation_max_seen,float(d.act[adrs].max()))
 if not np.all(np.isfinite(d.qpos)) or any(d.warning[i].number>warnings0[i] for i in [int(mujoco.mjtWarning.mjWARN_BADQPOS),int(mujoco.mjtWarning.mjWARN_BADQVEL),int(mujoco.mjtWarning.mjWARN_BADQACC)]):failure={'reason':'nonfinite state or numerical warning','time_s':float(d.time)};break
assert np.max(np.abs(d.qfrc_applied))==0 and np.max(np.abs(d.xfrc_applied))==0
arr={k:np.asarray(v) for k,v in logs.items()};np.savez_compressed(OUT/'rollout.npz',**arr);xyz=arr['thorax_mm'];displacement=xyz[-1]-xyz[0];weight=m.body_subtreemass[thorax]*np.linalg.norm(m.opt.gravity);stance=median_filter(arr['support_dyne']>weight*.01,size=(max(1,round(.005/args.control_dt)),1),mode='nearest');transitions=np.sum(stance[1:]!=stance[:-1],axis=0);support=float(np.mean(np.any(stance,axis=1)));qerror=float(np.sqrt(np.mean(arr['joint_rmse_rad']**2))*180/np.pi);tauerr=float(np.linalg.norm(arr['muscle_torque_Nm']-arr['reference_torque_Nm'])/max(np.linalg.norm(arr['reference_torque_Nm']),1e-20))
if args.record_physics:np.savez_compressed(OUT/'activation_5000Hz.npz',time_s=np.asarray(physics_times),activation=np.asarray(physics_activations),excitation=np.asarray(physics_excitation),joint_angle_rad=np.asarray(physics_angles),muscle_ids=np.array([r['id'] for r in rows]),joint_names=np.array(joint_names))
report={'config':vars(args),'contact_load_initialization_used':args.initialize_contact_load,'model_path':str(ROOT/'bounded_refined_muscles.xml'),'model_sha256':hashlib.sha256((ROOT/'bounded_refined_muscles.xml').read_bytes()).hexdigest(),'source_sha256':source_sha,'muscle_channels':len(ids),'native_activation_state_limits_enforced':True,'minimum_activation_all_physics_steps':activation_min_seen,'maximum_activation_all_physics_steps':activation_max_seen,'simulated_duration_s':float(d.time),'failure':failure,'displacement_xyz_mm':displacement.tolist(),'displacement_xy_mm':float(np.linalg.norm(displacement[:2])),'joint_angle_rmse_deg':qerror,'last_joint_angle_rmse_deg':float(arr['joint_rmse_rad'][-1]*180/np.pi),'minimum_thorax_up_z':float(arr['up_z'].min()),'minimum_thorax_height_mm':float(xyz[:,2].min()),'thorax_ground_contact_samples':int(arr['thorax_ground'].sum()),'foot_support_fraction':support,'per_leg_contact_transitions':dict(zip(leg_names,transitions.tolist())),'torque_relative_error_along_actual_motion':tauerr,'qp_failure_count':control_fail,'maximum_actual_ground_penetration_um':float(arr['max_ground_penetration_cm'].max()*1e4),'maximum_actual_friction_cone_ratio':float(arr['friction_ratio'].max()),'maximum_ground_prediction_slack_um':float(arr['ground_slack_cm'].max()*1e4),'maximum_body_prediction_slack_normalized':float(arr['body_slack_normalized'].max()),'maximum_joint_prediction_slack_rad':float(arr['joint_slack_rad'].max()),'max_native_dynamics_response_consistency_relative_error':float(arr['contact_response_consistency'].max()),'max_ground_force_sensitivity_norm':float(arr['contact_response_norm'].max()),'mean_controller_wall_s':float(arr['controller_wall_s'].mean()),'wall_seconds':time.monotonic()-clock,'pose_or_activation_overwrites_after_initialization':False,'external_or_residual_torque_applied':False,'native_leg_motors_present':False,'explicit_contact_force_change_in_controller':True,'ground_and_joint_prediction_constraints_use_logged_slack':True}
report['passes_defined_walking_checks']=bool(failure is None and d.time>=5.999 and displacement[0]>10 and abs(displacement[1])<abs(displacement[0]) and report['minimum_thorax_up_z']>.7 and not report['thorax_ground_contact_samples'] and support>.8 and min(transitions)>=4 and qerror<20)
(OUT/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
