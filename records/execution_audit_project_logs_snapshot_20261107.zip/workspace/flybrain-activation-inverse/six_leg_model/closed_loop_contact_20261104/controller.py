import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,time,itertools
import numpy as np,mujoco,osqp
from scipy import sparse
from scipy.optimize import lsq_linear
sys.path.insert(0,'/workspace/flybrain-activation-inverse/code')
from contact_response_fd import NativeContactResponse,leg_basis
from contact_response import constraint_jacobian

class MuscleContactTracker:
 def __init__(self,m,source,rows,ids,dofs,qadrs,groups,leg_omega=160.,zeta=1.2,body_omega=20.,body_weight=2.,torque_weight=.001,h=.002,iterations=1):
  self.m=m;self.source=source;self.rows=rows;self.ids=ids;self.adrs=m.actuator_actadr[ids];self.dofs=dofs;self.qadrs=qadrs;self.groups=groups;self.omega=leg_omega;self.zeta=zeta;self.body_omega=body_omega;self.body_weight=body_weight;self.torque_weight=torque_weight;self.h=h;self.iterations=iterations;self.substeps=round(h/m.opt.timestep);self.probe=NativeContactResponse(m);self.moment=np.empty((m.nu,m.nv));self.err=np.empty(m.nv)
  root=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'walker/');self.rootq=int(m.jnt_qposadr[root]);self.rootv=int(m.jnt_dofadr[root]);self.body=np.arange(self.rootv,self.rootv+6);self.task=np.r_[self.body,dofs];self.qscale=np.maximum(np.std(source['qpos'][:,qadrs],axis=0),.2);self.accweights=np.r_[np.full(3,body_weight/(body_omega**2*.1)),np.full(3,body_weight/(body_omega**2*.3)),1/(leg_omega**2*self.qscale)]
  self.torque_scale=np.empty(len(dofs))
  for js,ks in groups:self.torque_scale[js]=max(float(np.sqrt(np.mean(source['leg_tau_drive_Nm'][:,js]**2)))*1e7,1e-5)
  self.plus=mujoco.MjData(m);self.minus=mujoco.MjData(m);self.jacp=np.empty((3,m.nv));self.jacr=np.empty((3,m.nv));self.last_u=np.zeros(len(ids));self.preview_frames=0;self.body_hold=1.;self.body_guard=False;self.initializing=False;self.native_torque_feedforward=False
 def advance_activation(self,a,u):
  a=a.copy();dt=self.m.opt.timestep;ta=self.m.actuator_dynprm[self.ids,0];td=self.m.actuator_dynprm[self.ids,1]
  for _ in range(self.substeps):
   f=.5+1.5*a;tau=np.where(u>a,ta*f,td/f);a=np.clip(a+dt*(u-a)/tau,0,1)
  return a
 def excitation_for(self,a,target):
  lo=np.zeros(len(a));hi=np.ones(len(a))
  for _ in range(14):
   u=(lo+hi)*.5;result=self.advance_activation(a,u);low=result<target;lo=np.where(low,u,lo);hi=np.where(low,hi,u)
  return (lo+hi)*.5
 def force_map(self,d):
  mujoco.mju_sparse2dense(self.moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);moment=self.moment[self.ids].copy();gain=np.array([mujoco.mju_muscleGain(d.actuator_length[i],d.actuator_velocity[i],self.m.actuator_lengthrange[i],self.m.actuator_acc0[i],self.m.actuator_gainprm[i,:9]) for i in self.ids]);B=moment.T*gain[None,:];tau=moment.T@d.actuator_force[self.ids];return B,tau
 def reference(self,d,frame):
  frame=min(frame+self.preview_frames,len(self.source['qpos'])-1);qr=self.source['qpos'][frame];vr=self.source['qvel'][frame].copy();end=min(frame+round(self.h/.0002),len(self.source['qvel'])-1);ar=(self.source['qvel'][end]-self.source['qvel'][frame])/max((end-frame)*.0002,.0002);mujoco.mj_differentiatePos(self.m,self.err,1.,d.qpos,qr)
  qa=self.rootq;va=self.rootv;Ra=np.empty(9);Rr=np.empty(9);mujoco.mju_quat2Mat(Ra,d.qpos[qa+3:qa+7]);mujoco.mju_quat2Mat(Rr,qr[qa+3:qa+7]);R=Ra.reshape(3,3).T@Rr.reshape(3,3);wr=R@vr[va+3:va+6];ar[va+3:va+6]=R@ar[va+3:va+6]-np.cross(d.qvel[va+3:va+6],wr);vr[va+3:va+6]=wr
  feedforward_acceleration=ar.copy()
  ar[self.dofs]+=self.omega**2*self.err[self.dofs]+2*self.zeta*self.omega*(vr[self.dofs]-d.qvel[self.dofs]);ar[self.body]+=self.body_omega**2*self.err[self.body]+2*self.zeta*self.body_omega*(vr[self.body]-d.qvel[self.body]);tau_ref=np.mean(self.source['leg_tau_drive_Nm'][frame:end+1],axis=0)*1e7
  self.last_pd_correction=ar-feedforward_acceleration
  return ar,tau_ref
 def contact_bias(self,d):
  # Actual collision geometry at q +/- epsilon*v; only used for local gap bias.
  eps=1e-5
  for data,sign in [(self.plus,1.),(self.minus,-1.)]:
   data.qpos[:]=d.qpos;mujoco.mj_integratePos(self.m,data.qpos,d.qvel,sign*eps);mujoco.mj_kinematics(self.m,data);mujoco.mj_collision(self.m,data)
  def gap(data,c):
   choices=[data.contact[i] for i in range(data.ncon) if int(data.contact[i].geom1)==int(c.geom1) and int(data.contact[i].geom2)==int(c.geom2)]
   return float(min(choices,key=lambda x:np.linalg.norm(x.pos-c.pos)).dist) if choices else None
  result={}
  for i in range(d.ncon):
   c=d.contact[i];gp=gap(self.plus,c);gm=gap(self.minus,c)
   result[i]=0. if gp is None or gm is None else float(np.clip((gp-2*c.dist+gm)/(eps**2),-1e6,1e6))
  return result
 def solve(self,d,frame):
  clock=time.monotonic();a_current=d.act[self.adrs].copy();lo=self.advance_activation(a_current,np.zeros(len(a_current)));hi=self.advance_activation(a_current,np.ones(len(a_current)));lo=np.maximum(lo,a_current-.6);hi=np.minimum(hi,a_current+.6);hi=np.maximum(hi,lo+1e-10)
  if self.initializing:lo=np.zeros(len(a_current));hi=np.ones(len(a_current))
  B,tau_current=self.force_map(d);wanted,tau_ref=self.reference(d,frame);self.probe.set_state(d);background=d.qfrc_applied.copy();initial_probe_acc=self.probe.d.qacc.copy();a=a_current.copy();E=leg_basis(B[self.dofs],self.groups,self.dofs,self.m.nv);projected=E.T@B;span=float(np.linalg.norm(B-E@projected)/max(np.linalg.norm(B),1e-20));assert span<1e-7,span
  if self.native_torque_feedforward:
   reference_force_change=np.zeros(self.m.nv);reference_force_change[self.dofs]=tau_ref-tau_current[self.dofs];feedforward_acceleration,_,_=self.probe.evaluate(background+reference_force_change);wanted=feedforward_acceleration+self.last_pd_correction
  def evaluate(x):return self.probe.evaluate(background+B@(x-a_current))
  def cost(acc,x):
   qres=self.accweights*(acc[self.task]-wanted[self.task]);tres=(tau_current[self.dofs]+B[self.dofs]@(x-a_current)-tau_ref)/self.torque_scale;return float(qres@qres+self.torque_weight*(tres@tres)+1e-5*(x@x))
  acc,lam,state=evaluate(a);best=cost(acc,a);initial=best;accepted=0;qpstatuses=[];consistency=[];friction_count=0;gap_count=0;max_ground_slack=0.;max_joint_slack=0.;max_body_slack=0.;ground_response=0.;prediction_errors=[];qp_wall=0.;fd_wall=0.
  for iteration in range(self.iterations):
   tic=time.monotonic();resp=self.probe.linearize(background+B@(a-a_current),E,epsilon=1e-5,central=False);fd_wall+=time.monotonic()-tic;consistency.append(resp['dynamics_response_consistency_relative_error']);ground_response=max(ground_response,float(np.linalg.norm(resp['ground_contact_generalized_force_response'])));Aacc=resp['acceleration_response']@projected;Flambda=resp['constraint_force_response']@projected;qa0=resp['qacc0'];lambda0=resp['lambda0'];J=resp['constraint_jacobian'];baseline=self.probe.d
   C=np.vstack([self.accweights[:,None]*Aacc[self.task],np.sqrt(self.torque_weight)*B[self.dofs]/self.torque_scale[:,None],np.sqrt(1e-5)*np.eye(len(a))]);target=np.r_[self.accweights*(wanted[self.task]-qa0[self.task]+Aacc[self.task]@a),np.sqrt(self.torque_weight)*(tau_ref-tau_current[self.dofs]+B[self.dofs]@a_current)/self.torque_scale,np.zeros(len(a))]
   hard=[];lower=[];upper=[];soft=[];soft_lower=[];softscale=[];softkind=[];bias=self.contact_bias(baseline)
   for ci in range(baseline.ncon):
    contact=baseline.contact[ci];addr=int(contact.efc_address)
    if addr<0:continue
    g1,g2=int(contact.geom1),int(contact.geom2);ground=(self.m.geom_bodyid[g1]==0 or self.m.geom_bodyid[g2]==0)
    # Force constraints in actual native contact coordinates. Polygon is an
    # outer approximation; native reevaluation enforces the true elliptic cone.
    normal=Flambda[addr];offset=lambda0[addr]-normal@a;hard.append(normal);lower.append(-offset-1e-9);upper.append(np.inf)
    dim=int(contact.dim)
    if dim>=3:
     mu=np.maximum(np.asarray(contact.friction[:dim-1]),1e-8);directions=[]
     if dim==3:directions=[np.array([np.cos(phi),np.sin(phi)]) for phi in np.linspace(0,2*np.pi,8,endpoint=False)]
     else:
      for k in range(dim-1):
       for sign in [-1,1]:v=np.zeros(dim-1);v[k]=sign;directions.append(v)
     for direction in directions:
      row=(direction/mu)@Flambda[addr+1:addr+dim]-normal;off=(direction/mu)@(lambda0[addr+1:addr+dim]-Flambda[addr+1:addr+dim]@a)-offset;hard.append(row);lower.append(-np.inf);upper.append(-off+1e-9);friction_count+=1
    if ground:
     normalJ=J[addr];coefficient=.5*self.h**2*(normalJ@Aacc);constant=float(contact.dist+self.h*(normalJ@d.qvel)+.5*self.h**2*(normalJ@qa0+bias[ci])-coefficient@a);floor=min(-.0001,float(contact.dist));scale=.0001;soft.append(coefficient/scale);soft_lower.append((floor-constant)/scale);softscale.append(scale);softkind.append('ground');gap_count+=1
   # Predictive joint-range constraints with diagnostic slack. MuJoCo still
   # imposes its native joint limits in the real forward simulation.
   for joint in range(self.m.njnt):
    dof=int(self.m.jnt_dofadr[joint]);qadr=int(self.m.jnt_qposadr[joint])
    if dof not in set(self.dofs) or not self.m.jnt_limited[joint]:continue
    coefficient=.5*self.h**2*Aacc[dof];constant=d.qpos[qadr]+self.h*d.qvel[dof]+.5*self.h**2*qa0[dof]-coefficient@a;scale=.005
    for sign,bound in [(1,self.m.jnt_range[joint,0]),(-1,-self.m.jnt_range[joint,1])]:soft.append(sign*coefficient/scale);soft_lower.append((bound-sign*constant)/scale);softscale.append(scale);softkind.append('joint')
   if self.body_guard:
    # Longer-horizon posture prediction is a stabilization objective; contact
    # dynamics and reachable activations are still updated every control step.
    H=.03;end=min(frame+round(H/.0002),len(self.source['qpos'])-1);future_error=np.empty(self.m.nv);mujoco.mj_differentiatePos(self.m,future_error,1.,d.qpos,self.source['qpos'][end])
    for local in [2,3,4,5]:
     dof=self.body[local];coefficient=.5*H**2*Aacc[dof];constant=H*d.qvel[dof]+.5*H**2*qa0[dof]-coefficient@a-future_error[dof];margin=.015 if local==2 else .25;scale=.01 if local==2 else .1
     signs=[1] if local==2 else [1,-1]
     for sign in signs:soft.append(sign*coefficient/scale);soft_lower.append((-margin-sign*constant)/scale);softscale.append(scale);softkind.append('body')
   ns=len(soft);n=len(a);P=C.T@C;qq=-C.T@target;Paug=sparse.block_diag([sparse.csc_matrix(P),sparse.eye(ns,format='csc')*100.],format='csc');qaug=np.r_[qq,np.zeros(ns)];parts=[sparse.eye(n+ns,format='csc')];ll=[np.r_[lo,np.zeros(ns)]];uu=[np.r_[hi,np.full(ns,np.inf)]]
   if hard:parts.append(sparse.hstack([sparse.csc_matrix(np.asarray(hard)),sparse.csc_matrix((len(hard),ns))],format='csc'));ll.append(np.asarray(lower));uu.append(np.asarray(upper))
   if soft:parts.append(sparse.hstack([sparse.csc_matrix(np.asarray(soft)),sparse.eye(ns,format='csc')],format='csc'));ll.append(np.asarray(soft_lower));uu.append(np.full(ns,np.inf))
   solver=osqp.OSQP();tic=time.monotonic();solver.setup(P=sparse.triu(Paug).tocsc(),q=qaug,A=sparse.vstack(parts,format='csc'),l=np.concatenate(ll),u=np.concatenate(uu),verbose=False,eps_abs=1e-5,eps_rel=1e-4,max_iter=2000,polishing=False,adaptive_rho=True);solver.warm_start(x=np.r_[np.clip(a,lo,hi),np.maximum(0,np.asarray(soft_lower)-np.asarray(soft)@a) if ns else []]);fit=solver.solve(raise_error=False);qp_wall+=time.monotonic()-tic;qpstatuses.append(fit.info.status)
   if fit.info.status_val not in [1,2]:break
   candidate=np.clip(fit.x[:n],lo,hi);slacks=np.maximum(fit.x[n:],0)
   for value,scale,kind in zip(slacks,softscale,softkind):
    if kind=='ground':max_ground_slack=max(max_ground_slack,float(value*scale))
    elif kind=='joint':max_joint_slack=max(max_joint_slack,float(value*scale))
    else:max_body_slack=max(max_body_slack,float(value))
   improved=False
   for alpha in [1.,.5,.25]:
    trial=a+alpha*(candidate-a);actual,forces,states=evaluate(trial);newcost=cost(actual,trial)
    if newcost<best-1e-10*max(1,best):
     predicted=qa0+Aacc@(trial-a);prediction_errors.append(float(np.linalg.norm(actual-predicted)/max(np.linalg.norm(actual-qa0),1e-8)));a=trial;acc=actual;lam=forces;state=states;best=newcost;accepted+=1;improved=True;break
   if not improved:break
  u=self.excitation_for(a_current,np.clip(a,lo,hi));self.last_u=u.copy();self.probe.evaluate(background+B@(a-a_current));return u,{'target_activation':a,'initial_cost':initial,'final_cost':best,'accepted_updates':accepted,'qp_statuses':qpstatuses,'max_dynamics_consistency_relative_error':max(consistency,default=0.),'ground_contact_force_sensitivity_norm':ground_response,'friction_linear_constraints':friction_count,'ground_gap_constraints':gap_count,'max_ground_prediction_slack_cm':max_ground_slack,'max_joint_prediction_slack_rad':max_joint_slack,'max_body_prediction_slack_normalized':max_body_slack,'nonlinear_acceleration_prediction_relative_errors':prediction_errors,'muscle_basis_span_relative_error':span,'finite_difference_wall_s':fd_wall,'qp_wall_s':qp_wall,'wall_s':time.monotonic()-clock,'reference_acceleration':wanted,'native_planned_acceleration':acc,'planned_constraint_forces':lam}
