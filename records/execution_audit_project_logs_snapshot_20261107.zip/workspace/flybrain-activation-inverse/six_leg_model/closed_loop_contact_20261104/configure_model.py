from pathlib import Path
import xml.etree.ElementTree as E,json,hashlib
ROOT=Path(__file__).resolve().parent;SRC=ROOT.parent/'activation_refine_20261104/refined_muscles.xml';records=json.load(open(ROOT.parent/'activation_refine_20261104/records.json'))['records'];names={r['actuator_name'] for r in records};tree=E.parse(SRC);count=0
for a in tree.getroot().find('actuator'):
 if a.get('name') in names:a.set('actlimited','true');a.set('actrange','0 1');count+=1
assert count==130
path=ROOT/'bounded_refined_muscles.xml';tree.write(path,encoding='unicode');report={'source_model':str(SRC),'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'configured_model':str(path),'configured_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'muscle_activation_limits_added':count,'only_changed_attributes':['actlimited','actrange'],'geometry_force_curves_and_maximum_forces_unchanged':True,'original_source_overwritten':False};(ROOT/'model_configuration.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
