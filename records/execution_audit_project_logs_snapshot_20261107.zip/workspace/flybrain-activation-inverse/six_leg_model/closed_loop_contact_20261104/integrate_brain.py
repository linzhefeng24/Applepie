from pathlib import Path
import json,copy,hashlib,os
R=Path(__file__).resolve().parent;C=Path('/workspace/flybrain-muscle-rebuild/brain.json');M=Path('/workspace/flybrain-recovered/brain.json');S=R.parents[1]/'muscle_model_selection.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads(C.read_text());assert b==json.loads(M.read_text());old=copy.deepcopy(b)
backup=R/'brain_before_contact_closed_loop.json'
if not backup.exists():backup.write_bytes(C.read_bytes())
selection=json.loads(S.read_text());n=b['neuromusculoskeletal_model']
if 'model_selection_history' not in n:n['model_selection_history']=[copy.deepcopy(n['model_selection'])]
b['muscle_model_selection']=selection;n['model_selection']=selection
for p in n['input_provenance']:
 if p['key']=='model_selection':
  p.update(sha256=sha(S),bytes=S.stat().st_size)
names=['bounded_open_loop','bounded_default','bounded_ff_default','bounded_ff_fast','bounded_fast_track','adh_off_fast','adh_phase_fast','adh_phase_qfast','adh_phase_default','final_phase_default'];reports={name:json.loads((R/name/'report.json').read_text()) for name in names}
validations={p.stem:json.loads(p.read_text()) for p in [R/'validation.json',R/'feedforward_validation.json',R/'selection_validation.json']};assert all(v['passed'] for v in validations.values())
assets=[]
for p in sorted(R.rglob('*')):
 if p.is_file() and ('__pycache__' not in p.parts) and p.name not in ['brain_before_contact_closed_loop.json','brain_integration.json'] and (p.parent==R or p.parent.name in names) and p.suffix in ['.py','.json','.npz','.gz','.png','.mp4','.xml','.md','.csv']:
  assets.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
run=dict(id='six_leg_contact_closed_loop_20261104',date='2026-11-04',role='actual native 130-muscle closed-loop torque and joint tracking with contact force variation; experimental, no normal walking achieved',previous_experiment_id='six_leg_activation_refine_20261104',default_model_replaced=True,source_q_and_torque_trajectory_changed=False,source_trajectory_sha256=reports['bounded_default']['source_sha256'],selected_model=selection,model_configuration=json.loads((R/'model_configuration.json').read_text()),results=reports,comparison=json.loads((R/'comparison.json').read_text()),validation=validations,tracking_diagnostics=json.loads((R/'tracking_diagnostics.json').read_text()),candidate_model_xml=dict(format='MuJoCo XML',text=(R/'bounded_refined_muscles.xml').read_text(),sha256=sha(R/'bounded_refined_muscles.xml')),method_document=dict(format='markdown',text=(R/'README.md').read_text()),artifacts=assets,remaining_limitations=['No tested configuration produces normal reference walking.','Ground/joint/body prediction constraints use explicit slack; native ground is compliant.','Fast kinetics are prior-bound sensitivity assumptions, not measurements.','Pre-bounds screen*/full* are exploratory and excluded from final activation-bounded comparisons.','Reference is a simulated teacher; parameter selection used the same trajectory, not independent generalization validation.','Transferred anatomy and middle/hind parameters remain uncertain; source evidence is preserved.'])
runs=b['muscle_activation_inference_experiments']['runs'];runs[:]=[r for r in runs if r['id']!=run['id']];runs.append(run)
ready=n['current_readiness'];ready.update(latest_activation_inference_experiment_id=run['id'],default_parameter_model_replaced_by_candidate=True,latest_candidate_walk_check_passed=False,whole_body_muscle_walking_validated=False,explicit_native_contact_closed_loop_implemented=True,activation_state_limits_enforced=True,latest_candidate_joint_angle_rmse_deg=reports['bounded_default']['joint_angle_rmse_deg'])
b['version']='3.4.3-six-leg-native-contact-feedback';b['date']='2026-11-04'
for key,value in old.items():
 if key not in ['version','date','muscle_model_selection','neuromusculoskeletal_model','muscle_activation_inference_experiments']:assert b[key]==value,key
blob=(json.dumps(b,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
for p in [C,M]:tmp=p.with_name(p.name+'.contact.tmp');tmp.write_bytes(blob);os.replace(tmp,p)
assert C.read_bytes()==M.read_bytes()
report=dict(passed=True,brain_version=b['version'],sha256=sha(C),bytes=len(blob),mirrors_identical=True,prior_biological_evidence_preserved=True,new_experiment_id=run['id'],walking_validated=False)
(R/'brain_integration.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
