"""Diagnostic only: project unchanged teacher torques onto the new muscle set."""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json
import numpy as np
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));from backend import SixLegMuscles
m=SixLegMuscles();z=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');idx=np.linspace(0,len(z['time_s'])-1,64,dtype=int);acts=[];preds=[];success=[]
for i in idx:
 fit=m.allocate(z['qpos'][i],z['qvel'][i],z['leg_tau_drive_Nm'][i]);acts.append(fit['activation']);preds.append(fit['predicted_torque_Nm']);success.append(fit['success'])
target=z['leg_tau_drive_Nm'][idx];pred=np.asarray(preds);a=np.asarray(acts);err=pred-target;tokens={'LF':'T1_left','RF':'T1_right','LM':'T2_left','RM':'T2_right','LH':'T3_left','RH':'T3_right'}
report={'sample_frames':len(idx),'independent_frame_problems':True,'force_or_geometry_parameters_fitted':False,'reference_torques_changed':False,'relative_torque_residual_L2':float(np.linalg.norm(err)/np.linalg.norm(target)),'all_solver_success':bool(all(success)),'fraction_activations_at_upper_bound':float(np.mean(a>.999999)),'per_leg':{}}
for leg,tok in tokens.items():
 cols=np.array([i for i,n in enumerate(m.joint_names) if n.endswith(tok)]);report['per_leg'][leg]={'relative_residual_L2':float(np.linalg.norm(err[:,cols])/np.linalg.norm(target[:,cols]))}
np.savez_compressed(ROOT/'reference_projection.npz',frame_indices=idx,time_s=z['time_s'][idx],activation=a,target_torque_Nm=target,predicted_torque_Nm=pred,muscle_ids=np.array([r['id'] for r in m.rows]));(ROOT/'reference_projection.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
