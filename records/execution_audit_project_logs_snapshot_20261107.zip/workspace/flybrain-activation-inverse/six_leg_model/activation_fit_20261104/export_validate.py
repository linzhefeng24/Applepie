import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,sys,xml.etree.ElementTree as E,csv
import numpy as np,mujoco
from scipy.optimize import lsq_linear
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));from fit import Problem,sha
P=Problem();params=np.load(ROOT/'optimized_parameters.npz');record=json.load(open(ROOT/'optimized_model_records.json'));rows=record['records'];tree=E.parse(ROOT.parent/'six_leg_muscles.xml');acts={a.get('name'):a for a in tree.getroot().find('actuator')}
for k,r in enumerate(rows):
 a=acts[r['actuator_name']];g=params['gain'][k].tolist()+[0.];a.set('gainprm',' '.join(map(str,g)));a.set('biasprm',' '.join(map(str,g)));a.set('lengthrange',' '.join(map(str,params['lengthrange'][k])))
path=ROOT/'optimized_muscles.xml';tree.write(path,encoding='unicode');m=mujoco.MjModel.from_xml_path(str(path));d=mujoco.MjData(m);mom=np.empty((m.nu,m.nv));errors=[];lowbound_nonnegative=[];lowbound_signed=[];target_norm=[]
Q=P.z['qpos'];W=P.z['qvel'];rng=np.random.default_rng(8)
for i in P.split['test']:
 d.qpos[:]=Q[i];d.qvel[:]=W[i];a=rng.random(len(P.b.ids));d.act[P.b.adrs]=a;mujoco.mj_forward(m,d);mujoco.mju_sparse2dense(mom,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);real=(mom[P.b.ids].T@d.actuator_force[P.b.ids])[P.b.dofs]*1e-7
 pred=np.zeros(66)
 for leg,g in P.groups.items():
  A,b=P.operator(i,leg,params['gain'],params['lengthrange']);pred[g['joints']]=A@a[g['muscles']]+b;y=P.target[i,g['joints']]-b;s=P.scales[leg]
  nn=lsq_linear(A/s,y/s,bounds=(0,np.inf),method='bvls',tol=1e-10,max_iter=500);signed=np.linalg.lstsq(A/s,y/s,rcond=1e-10)[0];lowbound_nonnegative.append(float(np.sum((A@nn.x-y)**2)));lowbound_signed.append(float(np.sum((A@signed-y)**2)));target_norm.append(float(P.target[i,g['joints']]@P.target[i,g['joints']]))
 errors.append(float(np.max(np.abs(real-pred))))
changes=[];source=P.b.rows
for before,after in zip(source,rows):
 for k in ['specific_stress_Pa','muscle_volume_m3','fiber_length0_m','tendon_slack_length_m','PCSA_m2','F0_N']:
  changes.append({'muscle':after['id'],'leg':after['leg'],'parameter':k,'baseline':before[k],'optimized':after[k],'ratio':after[k]/before[k] if before[k]!=0 else None})
with (ROOT/'parameter_changes.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(changes[0]));w.writeheader();w.writerows(changes)
# Verify fixed geometry/source and constrained parameter reconstruction.
opt=json.load(open(ROOT/'optimization.json'));gain,lr,recomputed,usage=P.parameters(opt['theta']);np.testing.assert_allclose(gain,params['gain'],rtol=1e-12,atol=1e-12);np.testing.assert_allclose(lr,params['lengthrange'],rtol=1e-12,atol=1e-12)
report={'model_compiles':True,'native_vs_cached_optimized_torque_max_error_Nm':max(errors),'coupled_parameter_and_compartment_constraints_passed':True,'minimum_full_reference_fiber_length_m':float(np.min(P.L*.01-np.array([r['tendon_slack_length_m'] for r in rows])[None,:])),'stress_at_60kPa_count':sum(r['specific_stress_Pa']>=59999. for r in rows),'vmax_at_100L0_per_s_count':int(np.sum(params['gain'][:,6]>=99.999)),'conditional_diagnostic_test_frames':len(P.split['test']),'unbounded_nonnegative_activation_relative_residual':float(np.sqrt(sum(lowbound_nonnegative)/sum(target_norm))),'unbounded_signed_activation_relative_residual':float(np.sqrt(sum(lowbound_signed)/sum(target_norm))),'diagnostic_warning':'Removing strength/sign bounds is diagnostic only, not an allowed activation solution; lower bounds apply only to this fixed geometry/curve version','source_unchanged':sha(P.z.files and '/workspace/fly-walking-run/output/walking_6s_5000Hz.npz')==P.meta['source_sha256'],'base_model_unchanged':sha(ROOT.parent/'six_leg_muscles.xml')==P.meta['model_xml_sha256'],'exported_candidate_model':str(path)}
report['passed']=bool(max(errors)<1e-12 and report['minimum_full_reference_fiber_length_m']>0 and report['source_unchanged'] and report['base_model_unchanged']);(ROOT/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['passed']
