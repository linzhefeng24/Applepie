import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,hashlib,copy,argparse
import numpy as np,mujoco
from scipy.optimize import lsq_linear
ROOT=Path(__file__).resolve().parent;MODEL=ROOT.parent;sys.path.insert(0,str(MODEL));from backend import SixLegMuscles
SOURCE=Path('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
def load():
 b=SixLegMuscles();z=np.load(SOURCE);return b,z

def prepare():
 b,z=load();Q=z['qpos'];W=z['qvel'];n=len(z['time_s']);M=len(b.rows);d=b.work;J=np.empty((b.model.ntendon,b.model.nv));tids=np.array([r['tendon_index'] for r in b.rows]);tokens={'LF':'T1_left','RF':'T1_right','LM':'T2_left','RM':'T2_right','LH':'T3_left','RH':'T3_right'};groups={}
 for leg,ks in b.groups.items():groups[leg]={'muscles':ks.tolist(),'joints':[j for j,name in enumerate(b.joint_names) if name.endswith(tokens[leg])]}
 L=np.lib.format.open_memmap(ROOT/'length_native.npy',mode='w+',dtype='f8',shape=(n,M));V=np.lib.format.open_memmap(ROOT/'velocity_native.npy',mode='w+',dtype='f8',shape=(n,M));mom=np.lib.format.open_memmap(ROOT/'moment_native.npy',mode='w+',dtype='f8',shape=(n,11,M));start=time.monotonic()
 for t in range(n):
  d.qpos[:]=Q[t];mujoco.mj_kinematics(b.model,d);mujoco.mj_comPos(b.model,d);mujoco.mj_tendon(b.model,d);mujoco.mju_sparse2dense(J,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));musJ=J[tids];L[t]=d.ten_length[tids];V[t]=musJ@W[t]
  for leg,g in groups.items():
   ks=np.array(g['muscles']);js=np.array(g['joints']);mom[t,:,ks]=musJ[np.ix_(ks,b.dofs[js])]
  if t%5000==0:print('cache',t,'elapsed',time.monotonic()-start,flush=True)
 L.flush();V.flush();mom.flush();params=np.stack([b.model.actuator_gainprm[i,:9] for i in b.ids]);lr=b.model.actuator_lengthrange[b.ids].copy();acc=b.model.actuator_acc0[b.ids].copy();np.savez(ROOT/'baseline_parameters.npz',gain=params,lengthrange=lr,acc0=acc)
 ts=z['time_s'];train=np.concatenate([np.flatnonzero((ts>=lo+.01)&(ts<hi-.01))[np.linspace(0,np.count_nonzero((ts>=lo+.01)&(ts<hi-.01))-1,8,dtype=int)] for lo,hi in [(0,.8),(1.2,1.8),(2.2,2.8),(3.2,3.8),(4.2,4.8),(5.2,6)]])
 valid=np.concatenate([np.flatnonzero((ts>=lo+.01)&(ts<hi-.01))[np.linspace(0,np.count_nonzero((ts>=lo+.01)&(ts<hi-.01))-1,8,dtype=int)] for lo,hi in [(.8,1.2),(2.8,3.2),(4.8,5.2)]])
 test=np.concatenate([np.flatnonzero((ts>=lo+.01)&(ts<hi-.01))[np.linspace(0,np.count_nonzero((ts>=lo+.01)&(ts<hi-.01))-1,12,dtype=int)] for lo,hi in [(1.8,2.2),(3.8,4.2)]])
 np.savez(ROOT/'split.npz',train=train,validation=valid,test=test)
 report={'source_sha256':sha(SOURCE),'model_xml_sha256':sha(MODEL/'six_leg_muscles.xml'),'manifest_sha256':sha(MODEL/'manifest.json'),'frames':n,'muscles':M,'groups':groups,'cache_elapsed_s':time.monotonic()-start,'geometry_fixed':True,'source_joint_trajectory_and_torque_unchanged':True,'muscle_force_native_to_N':1e-5,'joint_torque_native_to_Nm':1e-7}
 (ROOT/'cache.json').write_text(json.dumps(report,indent=2));print('cache complete',flush=True)

class Problem:
 def __init__(self):
  self.b,self.z=load();self.meta=json.loads((ROOT/'cache.json').read_text());self.groups=self.meta['groups'];self.L=np.load(ROOT/'length_native.npy',mmap_mode='r');self.V=np.load(ROOT/'velocity_native.npy',mmap_mode='r');self.mom=np.load(ROOT/'moment_native.npy',mmap_mode='r');self.base={k:v for k,v in np.load(ROOT/'baseline_parameters.npz').items()};self.split=np.load(ROOT/'split.npz');self.target=self.z['leg_tau_drive_Nm'];self.pr=json.load(open('/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json'));self.prior={r['id']:r for r in self.pr['muscles']};self.scales={leg:max(float(np.sqrt(np.mean(self.target[self.split['train']][:,g['joints']]**2))),1e-12) for leg,g in self.groups.items()};self.minlength=self.L.min(axis=0)*.01;self.maxlength=self.L.max(axis=0)*.01
 def parameters(self,theta):
  rows=copy.deepcopy(self.b.rows);gain=self.base['gain'].copy();lr=self.base['lengthrange'].copy();usage={};counts={}
  for r in rows:
   key=tuple(r['catalog_ids']);counts[key]=counts.get(key,0)+1
  for k,r in enumerate(rows):
   ids=r['catalog_ids'];ps=[self.prior[id] for id in ids];w=1/counts[tuple(ids)];t=theta[r['leg']]
   stress=float(np.clip(r['specific_stress_Pa']*t[0],max(p['estimated']['specific_stress_Pa']['working'][0] for p in ps),min(p['estimated']['specific_stress_Pa']['working'][1] for p in ps)))
   l0=float(np.clip(r['fiber_length0_m']*t[2],max(p['estimated']['optimal_fiber_length_m']['working'][0] for p in ps),min(p['estimated']['optimal_fiber_length_m']['working'][1] for p in ps)))
   amin=sum(p['estimated']['physiological_cross_sectional_area_m2']['working'][0] for p in ps)*w;amax=sum(p['estimated']['physiological_cross_sectional_area_m2']['working'][1] for p in ps)*w
   amin=max(amin,sum(p['estimated']['max_isometric_force_N']['working'][0] for p in ps)*w/stress);amax=min(amax,sum(p['estimated']['max_isometric_force_N']['working'][1] for p in ps)*w/stress)
   vmin=sum(p['estimated']['muscle_volume_m3']['working'][0] for p in ps)*w;vmax=sum(p['estimated']['muscle_volume_m3']['working'][1] for p in ps)*w
   amin=max(amin,vmin/l0);amax=min(amax,vmax/l0)
   if amin>amax:raise ValueError('incompatible coupled bounds')
   area=float(np.clip(r['muscle_volume_m3']*t[1]/l0,amin,amax));volume=area*l0;force=area*stress
   slack=float(np.clip(r['tendon_slack_length_m']+t[3]*r['fiber_length0_m'],0,min(self.minlength[k]*.95,min(p['estimated']['tendon_slack_length_m']['working'][1] for p in ps))))
   gain[k,2]=force*1e5;gain[k,6]=np.clip(gain[k,6]*t[4],5,100)
   if r['leg'] in ['LM','RM','LH','RH']:gain[k,7]=np.clip(gain[k,7]*t[5],.5,3.5)
   lr[k]=[(slack+gain[k,i]*l0)*100 for i in [0,1]]
   r.update(fiber_length0_m=l0,tendon_slack_length_m=slack,PCSA_m2=area,muscle_volume_m3=volume,specific_stress_Pa=stress,F0_N=force,gainprm_native=gain[k].tolist()+[0.],normalized_fiber_length_sample_min=float((self.minlength[k]-slack)/l0),normalized_fiber_length_sample_max=float((self.maxlength[k]-slack)/l0),normalized_fiber_length_domain='all 30000 fixed reference poses')
   weights=[p['estimated']['muscle_volume_m3']['initial'] for p in ps]
   for p,v in zip(ps,weights):c=p['compartment'];usage[c]=usage.get(c,0)+volume*v/sum(weights)
  for c,v in usage.items():
   if v>self.pr['compartments'][c]['muscle_volume_budget_m3'][1]*(1+1e-10):raise ValueError('shared compartment budget')
  return gain,lr,rows,usage
 def operator(self,frame,leg,gain,lr):
  g=self.groups[leg];ks=np.asarray(g['muscles']);forces=[];bias=[]
  for k in ks:
   forces.append(mujoco.mju_muscleGain(self.L[frame,k],self.V[frame,k],lr[k],self.base['acc0'][k],gain[k]));bias.append(mujoco.mju_muscleBias(self.L[frame,k],lr[k],self.base['acc0'][k],gain[k]))
  mom=self.mom[frame,:,ks].T
  return mom*np.asarray(forces)[None,:]*1e-7,mom@np.asarray(bias)*1e-7
 def solve(self,frame,leg,gain,lr):
  A,b=self.operator(frame,leg,gain,lr);g=self.groups[leg];y=self.target[frame,g['joints']];s=self.scales[leg];n=A.shape[1];C=np.vstack((A/s,np.sqrt(1e-6)*np.eye(n)));fit=lsq_linear(C,np.r_[(y-b)/s,np.zeros(n)],bounds=(0,1),method='bvls',tol=1e-9,max_iter=300);a=np.clip(fit.x,0,1);pred=A@a+b;return a,pred,fit.success
 def score(self,theta,leg,indices):
  try:gain,lr,_,_=self.parameters(theta)
  except ValueError:return 1e9,1e9
  g=self.groups[leg];sse=0.;den=0.;act=0.
  for i in indices:
   a,p,ok=self.solve(i,leg,gain,lr)
   if not ok:return 1e9,1e9
   y=self.target[i,g['joints']];sse+=float(np.sum((p-y)**2));den+=float(y@y);act+=float(a@a)
  relative=sse/max(den,1e-30);t=np.array(theta[leg]);penalty=.0005*np.sum(np.r_[np.log(t[[0,1,2,4,5]]),t[3]/.2]**2)
  return relative+1e-6*act/len(indices)+penalty,float(np.sqrt(relative))

def optimize():
 P=Problem();theta={leg:[1.,1.,1.,0.,1.,1.] for leg in P.groups};history=[];start=time.monotonic();train=P.split['train'];grids=[[.7,1.,1.5,2.],[.7,1.,1.3,1.6],[.7,.85,1.,1.15,1.3],[-.2,-.1,0.,.1,.2],[.5,1.,2.,3.,5.,10.],[.4,.7,1.,1.5,2.]]
 # Prove cached native muscle gains and transmission match the real simulator.
 cache_err=[]
 gain=P.base['gain'];lr=P.base['lengthrange']
 for i in P.split['validation'][:3]:
  AA,bb=P.b.affine(P.z['qpos'][i],P.z['qvel'][i])
  for leg,g in P.groups.items():
   A,b=P.operator(i,leg,gain,lr);cache_err.append(float(np.max(np.abs(A-AA[np.ix_(g['joints'],g['muscles'])]))));cache_err.append(float(np.max(np.abs(b-bb[g['joints']]))))
 assert max(cache_err)<1e-12,max(cache_err)
 for leg in P.groups:
  initial=P.score(theta,leg,train);best=initial
  for sweep in range(2):
   for dim,values in enumerate(grids):
    if leg in ['LF','RF'] and dim==5:continue
    for value in values:
     proposal=copy.deepcopy(theta);proposal[leg][dim]=value;score=P.score(proposal,leg,train)
     if score[0]<best[0]-1e-9:theta=proposal;best=score
   print('opt',leg,'sweep',sweep,'residual',best[1],'theta',theta[leg],flush=True)
  history.append({'leg':leg,'initial_train_relative_residual':initial[1],'final_train_relative_residual':best[1],'theta':theta[leg]})
 gain,lr,rows,usage=P.parameters(theta);np.savez(ROOT/'optimized_parameters.npz',gain=gain,lengthrange=lr)
 metrics={}
 for split in ['train','validation','test']:
  metrics[split]={leg:P.score(theta,leg,P.split[split])[1] for leg in P.groups}
 (ROOT/'optimized_model_records.json').write_text(json.dumps({'records':rows,'compartment_usage_m3':usage,'geometry_changed':False,'activation_kinetics_changed':False},indent=2))
 report={'method':'two sweeps of bounded coordinate search over six shared physiological factors per leg; exact per-frame BVLS activation allocation','theta_factor_names':['specific_stress_multiplier','volume_multiplier','optimal_fiber_length_multiplier','slack_shift_in_baseline_L0','vmax_multiplier','passive_force_multiplier_middle_hind_only'],'theta':theta,'history':history,'split_metrics_per_leg':metrics,'native_cache_operator_max_abs_error_Nm':max(cache_err),'elapsed_s':time.monotonic()-start,'trained_on_frames':len(train),'validation_frames':len(P.split['validation']),'test_frames':len(P.split['test']),'selected_by':'training objective with weak prior penalty only','constraints':'unchanged working ranges for volume, L0, PCSA, F0, stress, slack and shared compartments; vmax 5-100 L0/s; middle/hind passive multiplier within declared native range','not_optimized':['attachment geometry','neural parameters','activation time constants','whole-body reference trajectory'],'source_sha256':sha(SOURCE),'model_xml_sha256':sha(MODEL/'six_leg_muscles.xml')}
 (ROOT/'optimization.json').write_text(json.dumps(report,indent=2));print('optimization complete',flush=True)

def solve_chunk(bounds):
 P=Problem();params={k:v for k,v in np.load(ROOT/'optimized_parameters.npz').items()};start,stop=bounds;N=stop-start;M=len(P.b.ids);a=np.empty((N,M),dtype='f4');pred=np.zeros((N,66));basepred=np.zeros_like(pred);status=np.zeros((N,6),dtype='i1');clock=time.monotonic()
 for local,t in enumerate(range(start,stop)):
  for j,(leg,g) in enumerate(P.groups.items()):
   x,y,ok=P.solve(t,leg,params['gain'],params['lengthrange']);a[local,g['muscles']]=x;pred[local,g['joints']]=y;status[local,j]=ok
   _,y,_=P.solve(t,leg,P.base['gain'],P.base['lengthrange']);basepred[local,g['joints']]=y
  if local%1000==0:print('chunk',start,'frame',t,'elapsed',time.monotonic()-clock,flush=True)
 path=ROOT/f'part_{start}_{stop}.npz';np.savez_compressed(path,activation=a,prediction=pred,baseline_prediction=basepred,status=status);return start,stop,str(path)

def solve_full():
 P=Problem();p=np.load(ROOT/'optimized_parameters.npz');n=len(P.target);M=len(P.b.ids);acts=np.empty((n,M),dtype='f4');pred=np.zeros((n,66));basepred=np.zeros_like(pred);status=np.zeros((n,6),dtype='i1');start=time.monotonic()
 from concurrent.futures import ProcessPoolExecutor,as_completed
 cuts=np.linspace(0,n,5,dtype=int)
 with ProcessPoolExecutor(max_workers=4) as pool:
  futures=[pool.submit(solve_chunk,(int(cuts[i]),int(cuts[i+1]))) for i in range(4)]
  for future in as_completed(futures):
   start_i,stop_i,path=future.result();part=np.load(path);acts[start_i:stop_i]=part['activation'];pred[start_i:stop_i]=part['prediction'];basepred[start_i:stop_i]=part['baseline_prediction'];status[start_i:stop_i]=part['status'];print('assembled',start_i,stop_i,flush=True)
 np.savez_compressed(ROOT/'activation_6s_5000Hz.npz',time_s=P.z['time_s'],muscle_ids=np.array([r['id'] for r in P.b.rows]),joint_names=np.array(P.b.joint_names),activation=acts,target_torque_Nm=P.target,predicted_torque_Nm=pred,baseline_predicted_torque_Nm=basepred,residual_torque_Nm=pred-P.target,solver_success=status)
 denom=np.linalg.norm(P.target);report={'frames':n,'channels':M,'duration_s':float(P.z['time_s'][-1]+.0002),'sample_rate_Hz':5000,'baseline_relative_torque_residual_L2':float(np.linalg.norm(basepred-P.target)/denom),'optimized_relative_torque_residual_L2':float(np.linalg.norm(pred-P.target)/denom),'activation_upper_bound_fraction':float(np.mean(acts>=1-1e-6)),'activation_lower_bound_fraction':float(np.mean(acts<=1e-6)),'solver_failures':int(np.count_nonzero(status==0)),'source_unchanged':sha(SOURCE)==P.meta['source_sha256'],'model_unchanged':sha(MODEL/'six_leg_muscles.xml')==P.meta['model_xml_sha256'],'independent_frame_problems':True,'time_smoothing':False,'geometry_changed':False,'per_leg':{},'split_relative_residual_L2':{},'elapsed_s':time.monotonic()-start}
 for leg,g in P.groups.items():
  j=g['joints'];report['per_leg'][leg]={'baseline_relative_residual_L2':float(np.linalg.norm(basepred[:,j]-P.target[:,j])/np.linalg.norm(P.target[:,j])),'optimized_relative_residual_L2':float(np.linalg.norm(pred[:,j]-P.target[:,j])/np.linalg.norm(P.target[:,j]))}
 for split in P.split.files:
  i=P.split[split];report['split_relative_residual_L2'][split]=float(np.linalg.norm(pred[i]-P.target[i])/np.linalg.norm(P.target[i]))
 (ROOT/'fit_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':
 stage=sys.argv[1]
 {'prepare':prepare,'optimize':optimize,'solve':solve_full}[stage]()
