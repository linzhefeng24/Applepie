from pathlib import Path
import json,copy,hashlib,os
ROOT=Path(__file__).resolve().parent;CANON=Path('/workspace/flybrain-muscle-rebuild/brain.json');MIRROR=Path('/workspace/flybrain-recovered/brain.json')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
brain=json.loads(CANON.read_text());assert brain==json.loads(MIRROR.read_text());before=copy.deepcopy(brain)
backup=ROOT/'brain_before_activation_fit.json'
if not backup.exists():backup.write_bytes(CANON.read_bytes())
required=['fit_report.json','optimization.json','optimized_model_records.json','validation.json','activation_verification.json','forward_report.json'];content={}
for f in required:
 p=ROOT/f;content[f[:-5]]=json.loads(p.read_text())
assets=[]
for name in ['activation_6s_5000Hz.npz','activation_6s_5000Hz.csv.gz','optimized_parameters.npz','parameter_changes.csv','forward_rollout.npz','muscle_forward.mp4','activation_and_fit.png','worst_joint_torque_fits.png','split.npz']:
 p=ROOT/name;assets.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
experiment={'id':'six_leg_activation_fit_20261104','date':'2026-11-04','role':'candidate inference and constrained physiological calibration; not a validated biological activation dataset','uses_current_model':True,'default_model_parameters_replaced':False,'source_reference':'/workspace/fly-walking-run/output/walking_6s_5000Hz.npz','inputs':'fixed recorded q, qdot and synchronous leg-drive torques; adhesion kept separate','activation_array':{'path':str(ROOT/'activation_6s_5000Hz.npz'),'key':'activation','shape':[30000,130],'time_key':'time_s','muscle_id_key':'muscle_ids','range':[0,1],'measured':False,'physiological_or_neural_ground_truth':False},**content,'candidate_model_xml':{'text':(ROOT/'optimized_muscles.xml').read_text(),'format':'MuJoCo XML','sha256':sha(ROOT/'optimized_muscles.xml')},'method_document':{'text':(ROOT/'README.md').read_text(),'format':'markdown'},'artifacts':assets,'interpretation':['Each time is solved independently, with shared parameters and no temporal regularization.','Parameters and activations are conditional estimates; torque residual remains large.','Diagnostic unbounded or negative activations are not accepted solutions.','Native activation dynamics must be respected when converting state labels to excitation.','All original anatomy, uncertainty ranges and neural evidence are preserved.']}
runs=brain.setdefault('muscle_activation_inference_experiments',{'schema':'muscle_activation_inference_experiments_v1','runs':[]})['runs'];runs[:]=[r for r in runs if r['id']!=experiment['id']];runs.append(experiment)
ready=brain['neuromusculoskeletal_model']['current_readiness'];ready['middle_hind_new_parameter_optimization_performed']=True;ready['latest_activation_inference_experiment_id']=experiment['id'];ready['default_parameter_model_replaced_by_candidate']=False;ready['latest_candidate_walk_check_passed']=content['forward_report']['passes_walking_checks']
brain['version']='3.4.1-six-leg-activation-fit';brain['date']='2026-11-04'
for k,v in before.items():
 if k not in ['version','date','neuromusculoskeletal_model','muscle_activation_inference_experiments']:assert brain[k]==v,k
old=copy.deepcopy(before['neuromusculoskeletal_model']);new=copy.deepcopy(brain['neuromusculoskeletal_model']);old.pop('current_readiness');new.pop('current_readiness');assert old==new
blob=(json.dumps(brain,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
for p in [CANON,MIRROR]:temp=p.with_name(p.name+'.fit.tmp');temp.write_bytes(blob);os.replace(temp,p)
assert CANON.read_bytes()==MIRROR.read_bytes()
report={'brain_version':brain['version'],'brain_sha256':sha(CANON),'bytes':len(blob),'experiment_id':experiment['id'],'original_muscle_catalog_and_neural_evidence_unchanged':True,'default_model_not_replaced':True,'mirror_identical':True,'embedded_candidate_parameter_records':len(content['optimized_model_records']['records'])}
(ROOT/'brain_integration.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
