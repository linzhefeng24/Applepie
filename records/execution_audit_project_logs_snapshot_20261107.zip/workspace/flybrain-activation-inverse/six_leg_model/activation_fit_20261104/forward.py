import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/tmp/sixleg-fit-mesa',MPLCONFIGDIR='/tmp/sixleg-fit-mpl')
from pathlib import Path
import json,time
import numpy as np,mujoco,imageio
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parent
meta=json.load(open(ROOT.parent/'manifest.json'));rows=meta['records'];labels=np.load(ROOT/'activation_6s_5000Hz.npz');z=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');source={k:z[k] for k in ['qpos','qvel','act','ctrl','joint_qpos_indices','joint_dof_indices']}
m=mujoco.MjModel.from_xml_path(str(ROOT/'optimized_muscles.xml'));old=mujoco.MjModel.from_xml_path('/workspace/fly-walking-run/output/model/walking.xml');d=mujoco.MjData(m)
ids=np.array([mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_ACTUATOR,r['actuator_name']) for r in rows]);adrs=m.actuator_actadr[ids];dofs=source['joint_dof_indices'];qa=source['joint_qpos_indices'];a_ref=labels['activation'];dt=m.opt.timestep;duration=6.
retained=[]
for i in range(old.nu):
 name=mujoco.mj_id2name(old,mujoco.mjtObj.mjOBJ_ACTUATOR,i);j=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_ACTUATOR,name)
 if j>=0:retained.append((i,j))
d.qpos[:]=source['qpos'][0];d.qvel[:]=source['qvel'][0];d.act[adrs]=a_ref[0]
for i,j in retained:
 d.ctrl[j]=source['ctrl'][0,i]
 if m.actuator_actadr[j]>=0 and old.actuator_actadr[i]>=0:d.act[m.actuator_actadr[j]]=source['act'][0,old.actuator_actadr[i]]
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
mujoco.mj_forward(m,d);thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');ground={i for i in range(m.ngeom) if m.geom_bodyid[i]==0};moment=np.empty((m.nu,m.nv));warning0=[w.number for w in d.warning]
# Verify analytic inversion against the exact native activation derivative.
rng=np.random.default_rng(5);derror=[]
for k in range(len(ids)):
 a=float(rng.uniform(.01,.99));u=float(rng.uniform(0,1));tau=m.actuator_dynprm[ids[k],:3];factor=.5+1.5*a;value=(u-a)/(tau[0]*factor if u>a else tau[1]/factor);derror.append(abs(value-mujoco.mju_muscleDynamics(u,a,tau)))
assert max(derror)<1e-7
renderer=mujoco.Renderer(m,height=480,width=640);option=mujoco.MjvOption();option.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;option.sitegroup[:]=0
writer=imageio.get_writer(ROOT/'muscle_forward.mp4',fps=30,codec='libx264',quality=8);buffers={k:[] for k in ['time_s','thorax_mm','up_z','thorax_ground_contact','angle_rmse_rad','activation_target','activation_actual','excitation','muscle_torque_Nm']};fall_count=0;failure=None;video_frames=0;start=time.monotonic();excitation_saturation=0;excitation_elements=0
for step in range(round(duration/dt)):
 t=float(d.time);fi=min(int(round(t/.0002)),len(a_ref)-1);ft=min((t+dt)/.0002,len(a_ref)-1);lower=int(np.floor(ft));frac=ft-lower;desired=(1-frac)*a_ref[lower]+frac*a_ref[min(lower+1,len(a_ref)-1)];a=d.act[adrs].copy();factor=.5+1.5*a;delta=desired-a;tau=np.where(delta>0,m.actuator_dynprm[ids,0]*factor,m.actuator_dynprm[ids,1]/factor);raw=a+delta/dt*tau;u=np.clip(raw,0,1);d.ctrl[ids]=u;excitation_saturation+=int(np.sum((raw<0)|(raw>1)));excitation_elements+=len(raw)
 for i,j in retained:d.ctrl[j]=source['ctrl'][fi,i]
 mujoco.mj_forward(m,d)
 touch=False
 for ci in range(d.ncon):
  c=d.contact[ci];g1,g2=int(c.geom1),int(c.geom2);other=g2 if g1 in ground else g1 if g2 in ground else None
  if other is not None and c.efc_address>=0 and int(m.geom_bodyid[other])==thorax:touch=True
 up=float(d.xmat[thorax].reshape(3,3)[2,2]);fall_count=fall_count+1 if touch or up<.5 else 0
 if step%2==0:
  mujoco.mju_sparse2dense(moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);tau_actual=(moment[ids].T@d.actuator_force[ids])[dofs]*1e-7
  values=dict(time_s=t,thorax_mm=d.xpos[thorax].copy()*10,up_z=up,thorax_ground_contact=touch,angle_rmse_rad=float(np.sqrt(np.mean((d.qpos[qa]-source['qpos'][fi,qa])**2))),activation_target=a_ref[fi].copy(),activation_actual=a.copy(),excitation=u.copy(),muscle_torque_Nm=tau_actual)
  for k,v in values.items():buffers[k].append(v)
 if step%67==0:
  renderer.update_scene(d,camera=1,scene_option=option);im=Image.fromarray(renderer.render());draw=ImageDraw.Draw(im);draw.rectangle((0,0,640,34),fill='black');draw.text((8,8),f'Fitted muscle excitation replay | t={t:.3f}s | 0.2x speed',fill='white');writer.append_data(np.asarray(im));video_frames+=1
 if fall_count>=50:failure={'reason':'sustained thorax contact or up_z<0.5 for 5ms','time_s':t};break
 mujoco.mj_step(m,d)
 if any(d.warning[i].number>warning0[i] for i in [int(mujoco.mjtWarning.mjWARN_BADQPOS),int(mujoco.mjtWarning.mjWARN_BADQVEL),int(mujoco.mjtWarning.mjWARN_BADQACC)]) or not np.all(np.isfinite(d.qpos)):
  failure={'reason':'numerical warning or nonfinite state','time_s':float(d.time)};break
writer.close();renderer.close();arr={k:np.asarray(v) for k,v in buffers.items()};np.savez_compressed(ROOT/'forward_rollout.npz',**arr);xyz=arr['thorax_mm'];report={'scheduled_duration_s':6.,'simulated_duration_s':float(d.time),'failure':failure,'displacement_xy_mm':float(np.linalg.norm(xyz[-1,:2]-xyz[0,:2])),'min_thorax_up_z':float(arr['up_z'].min()),'thorax_ground_contact_samples':int(arr['thorax_ground_contact'].sum()),'angle_rmse_deg':float(np.sqrt(np.mean(arr['angle_rmse_rad']**2))*180/np.pi),'activation_target_tracking_rmse':float(np.sqrt(np.mean((arr['activation_actual']-arr['activation_target'])**2))),'excitation_clipping_fraction':excitation_saturation/excitation_elements,'native_activation_derivative_formula_max_error':max(derror),'state_overwrites_after_initialization':False,'residual_or_external_rescue_torque':False,'retained_nonmuscle_controls':len(retained),'video_frames':video_frames,'video_play_speed':.2,'wall_seconds':time.monotonic()-start}
report['passes_walking_checks']=bool(failure is None and d.time>=5.999 and report['displacement_xy_mm']>10 and report['min_thorax_up_z']>.7 and report['thorax_ground_contact_samples']==0);(ROOT/'forward_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
