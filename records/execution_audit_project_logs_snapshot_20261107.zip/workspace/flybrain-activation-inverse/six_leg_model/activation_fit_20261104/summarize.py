import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/sixleg-fit-mpl')
from pathlib import Path
import json,gzip,csv,sys,hashlib
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));from fit import Problem,sha
P=Problem();fit=json.load(open(ROOT/'fit_report.json'));valid=json.load(open(ROOT/'validation.json'));opt=json.load(open(ROOT/'optimization.json'));data={k:v for k,v in np.load(ROOT/'activation_6s_5000Hz.npz').items()}
old_verification=json.load(open(ROOT/'activation_verification.json')) if (ROOT/'activation_verification.json').exists() else {}
# Remove only machine-roundoff violations of the intended box constraints.
clip_max=float(np.max(np.abs(data['activation']-np.clip(data['activation'],0,1))))
assert clip_max<1e-7
if clip_max>0:
 data['activation']=np.clip(data['activation'],0,1)
 np.savez_compressed(ROOT/'activation_6s_5000Hz.npz',**data)
# Save the actual joint trajectory used in this inference, not only its filename.
if 'reference_joint_angle_rad' not in data:
 data['reference_joint_angle_rad']=P.z['leg_angle_rad'];data['reference_joint_velocity_rad_s']=P.z['leg_velocity_rad_s'];np.savez_compressed(ROOT/'activation_6s_5000Hz.npz',**data)
# Confirm order-independent allocation and stored-float32 force precision.
params={k:v for k,v in np.load(ROOT/'optimized_parameters.npz').items()};rng=np.random.default_rng(314);indices=rng.choice(len(P.target),24,replace=False);ae=[];te=[]
for i in indices:
 for leg,g in P.groups.items():
  a,pred,ok=P.solve(int(i),leg,params['gain'],params['lengthrange']);assert ok;ae.append(float(np.max(np.abs(a-data['activation'][i,g['muscles']]))));A,b=P.operator(i,leg,params['gain'],params['lengthrange']);te.append(float(np.max(np.abs(A@data['activation'][i,g['muscles']]+b-data['predicted_torque_Nm'][i,g['joints']]))))
verification={'shuffled_frames':len(indices),'max_saved_float32_activation_difference':max(ae),'max_saved_activation_force_reconstruction_error_Nm':max(te),'activation_finite':bool(np.all(np.isfinite(data['activation']))),'activation_min':float(data['activation'].min()),'activation_max':float(data['activation'].max()),'source_sha256':sha('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz'),'parameter_version':'bounded_physiology_fit_20261104','time_regularization':False,'maximum_numerical_box_projection':max(clip_max,old_verification.get('maximum_numerical_box_projection',0.)),'passed':bool(max(ae)<1e-6 and max(te)<1e-12 and np.all(np.isfinite(data['activation'])) and data['activation'].min()>=0 and data['activation'].max()<=1)}
(ROOT/'activation_verification.json').write_text(json.dumps(verification,indent=2));assert verification['passed']
with gzip.open(ROOT/'activation_6s_5000Hz.csv.gz','wt',newline='') as f:
 w=csv.writer(f);w.writerow(['time_s']+data['muscle_ids'].tolist())
 for t,row in zip(data['time_s'],data['activation']):w.writerow([format(float(t),'.8g')]+[format(float(x),'.8g') for x in row])
legs=list(fit['per_leg']);fig,axs=plt.subplots(2,1,figsize=(12,8),height_ratios=[1,2]);x=np.arange(6)
axs[0].bar(x-.18,[fit['per_leg'][l]['baseline_relative_residual_L2']*100 for l in legs],width=.36,label='Initial parameters');axs[0].bar(x+.18,[fit['per_leg'][l]['optimized_relative_residual_L2']*100 for l in legs],width=.36,label='Bounded calibrated parameters');axs[0].set_xticks(x,legs);axs[0].set_ylabel('Torque residual L2 (%)');axs[0].legend();axs[0].set_title('Fixed joint/torque reference; independent activation allocation')
heat=axs[1].imshow(data['activation'][::10].T,aspect='auto',origin='lower',extent=[0,6,0,130],vmin=0,vmax=1,cmap='viridis');offset=0
for leg in legs:
 count=len(P.groups[leg]['muscles']);axs[1].text(6.02,offset+count/2,leg,va='center');offset+=count;axs[1].axhline(offset,color='white',linewidth=.5)
fig.colorbar(heat,ax=axs[1],label='Activation (0 to 1)');axs[1].set_xlabel('Time (s)');axs[1].set_ylabel('Muscle channel');axs[1].set_title('130 candidate activations (display downsampled only)');fig.tight_layout();fig.savefig(ROOT/'activation_and_fit.png',dpi=160);plt.close(fig)
err=data['predicted_torque_Nm']-data['target_torque_Nm'];worst=np.argsort(np.mean(err**2,axis=0))[-4:][::-1];fig,axs=plt.subplots(4,1,figsize=(12,10),sharex=True)
for ax,j in zip(axs,worst):
 for label,key in [('Reference','target_torque_Nm'),('Initial fit','baseline_predicted_torque_Nm'),('Calibrated fit','predicted_torque_Nm')]:ax.plot(data['time_s'][::5],data[key][::5,j]*1e9,label=label,linewidth=.8)
 ax.set_ylabel('uN mm');ax.set_title(str(data['joint_names'][j]),fontsize=9)
axs[0].legend();axs[-1].set_xlabel('Time (s)');fig.tight_layout();fig.savefig(ROOT/'worst_joint_torque_fits.png',dpi=150);plt.close(fig)
forward=json.load(open(ROOT/'forward_report.json')) if (ROOT/'forward_report.json').exists() else None
report=f'''# 当前六腿肌肉模型：使用固定关节轨迹和力矩的激活反解

2026-11-04。使用现有仿真参考，关节轨迹、速度和力矩均未改变；这不是活体果蝇肌肉测量。

## 结果

- 6 秒、5,000 Hz、30,000 个时刻、130 路激活，共 390 万个候选激活值。
- 全程力矩相对 L2 残差：初始 {fit['baseline_relative_torque_residual_L2']:.2%} → 有界参数标定后 {fit['optimized_relative_torque_residual_L2']:.2%}。
- 训练窗口 {fit['split_relative_residual_L2']['train']:.2%}，验证窗口 {fit['split_relative_residual_L2']['validation']:.2%}，留出测试窗口 {fit['split_relative_residual_L2']['test']:.2%}。都是同一条行走记录，不能代表新动作或新动物泛化。
- 180,000 个腿—时刻问题均求解完成；激活上限比例 {fit['activation_upper_bound_fraction']:.2%}，下限比例 {fit['activation_lower_bound_fraction']:.2%}。零激活不能直接解释为生理静默。

[激活与拟合图](activation_and_fit.png) · [误差最大的四个关节](worst_joint_torque_fits.png)

## 文件

- [完整数值 NPZ](activation_6s_5000Hz.npz)：时间、肌肉/关节名称、参考角度与速度、130 路激活、目标与预测力矩、残差及求解状态。
- [激活 CSV.gz](activation_6s_5000Hz.csv.gz)：第一列秒，随后 130 路激活；保存 8 位有效数字。
- `optimized_model_records.json`、`optimized_parameters.npz`、`optimized_muscles.xml`：本轮候选参数与可加载模型。
- `parameter_changes.csv`：逐肌肉参数前后对照；原模型和原参数文件未覆盖。
- `fit_report.json`、`validation.json`、`activation_verification.json`：量化验证。

## 方法与限制

在参考 q(t)、qdot(t) 下计算路径长度、收缩速度和传动矩阵，使用精确 MuJoCo 原生肌肉 gain/bias 构成 `tau=A(q,qdot;theta)a+b(q;theta)`。每时刻独立求 `0<=a<=1` 的有界最小二乘，二次正则 1e-6 仅选择候选分配，没有时间平滑或前一帧热启动。

外层是两轮有界坐标搜索，每腿共享的六类因子：比张力、体积、最优长度、腱松弛长度偏移、缩短速度，以及仅中后腿的被动力系数。并非逐块优化所有自由参数，也不保证最优。使用 48 个训练时刻、24 个验证时刻和 24 个测试时刻；按训练误差和弱先验惩罚选择参数，没有用测试窗口选模型。

所有参数全程共享。体积、长度、PCSA、F0、比张力和共享区室预算受原工作范围限制；F0 始终由 PCSA×比张力推导。候选参数触及边界没有触发范围扩张。几何、肌肉路径和激活动力学时间常数没有优化。

本轮角度轨迹作为肌肉长度、速度和力臂的输入，力矩作为固定监督目标；没有让角度参考变成优化自由变量。已经有同步驱动力矩，因此不对角度二阶差分来猜力矩，也没有重复加上接触力。黏附和原关节被动项没有混入肌肉驱动力矩标签。

## 误差诊断

所有 130 路比张力达到 60 kPa 工作上限，90 路缩短速度达到 100 L0/s。以 24 个留出时刻做诊断，取消激活上限但保留只能拉的限制，残差约 {valid['unbounded_nonnegative_activation_relative_residual']:.2%}；进一步允许不生理的负力后约 {valid['unbounded_signed_activation_relative_residual']:.2%}。这些是当前几何/曲线下的诊断，不是允许的激活解，也不是所有解剖模型的误差下界。

这说明当前模型既受到可用力量容量限制，也存在传动方向/耦合限制。不能据此断言真实果蝇肌肉太弱，或把达到边界当成真实参数已经辨识。由于残差仍大，这组激活仅是带版本和残差的条件候选，不宜直接当作真实神经元训练标签。

## 前向验证

'''
if forward:
 report+=f"从参考初态开始，保留原 11 路非肌肉通道的记录控制，使用激活动力学计算受限激励；初始化后不覆盖身体/关节/激活状态，不施加外部补偿力矩。模拟 {forward['simulated_duration_s']:.4f} 秒，水平位移 {forward['displacement_xy_mm']:.2f} mm，行走检查通过：{forward['passes_walking_checks']}。终止信息：{forward['failure']}。\n\n[前向视频](muscle_forward.mp4)（0.2 倍速）· `forward_rollout.npz` · `forward_report.json`。激活状态与输入激励不同，不能直接把独立标签当作可实现控制。\n"
else:report+='前向验证尚在运行；最终报告生成后更新。\n'
if forward:report+=f"\n关节角 RMSE {forward['angle_rmse_deg']:.2f}°，激活状态跟踪 RMSE {forward['activation_target_tracking_rmse']:.3f}。激活跟踪过程中 {forward['excitation_clipping_fraction']:.2%} 的通道—时刻需要裁剪计算激励至 0–1，显示逐帧静态分配与所选激活动力学不兼容。该结果未形成行走，不能作为真实神经控制标签。\n"
(ROOT/'README.md').write_text(report)
print(json.dumps({'verification':verification,'forward_available':forward is not None,'activation_npz_bytes':(ROOT/'activation_6s_5000Hz.npz').stat().st_size},indent=2))
