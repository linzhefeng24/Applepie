import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,numpy as np,mujoco
R=Path(__file__).resolve().parent;ROOT=R.parent;m=mujoco.MjModel.from_xml_path(str(ROOT/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));z=dict(np.load(ROOT/'half_speed_angle_only_20261106/rollout_5000Hz.npz'));ref=dict(np.load(ROOT/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));records=json.loads((ROOT/'six_leg_model/activation_refine_20261104/records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];d=mujoco.MjData(m);mom=np.zeros((m.nu,m.nv));out=[]
for pose,q in [('actual',z['qpos'][-1]),('reference',ref['qpos'][-1])]:
 d.qpos[:]=q;d.qvel[:]=0;d.act[:]=0;d.ctrl[:]=z['all_control_10000Hz'][-1];mujoco.mj_forward(m,d);mujoco.mju_sparse2dense(mom,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);F=[]
 for a in [0,1]:d.act[adrs]=a;mujoco.mj_fwdActuation(m,d);F.append(d.actuator_force[ids].copy())
 for side in ['left','right']:
  jid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,f'walker/tarsus_T3_{side}');do=m.jnt_dofadr[jid]
  for i in np.flatnonzero(abs(mom[ids,do])>1e-10):out.append(dict(pose=pose,joint=f'walker/tarsus_T3_{side}',muscle=records[i]['id'],dlength_dq_cm_per_rad=float(mom[ids[i],do]),torque_gain_per_activation_Nm=float(mom[ids[i],do]*(F[1][i]-F[0][i])*1e-7)))
(R/'all_tarsus_geometry_comparison.json').write_text(json.dumps(out,indent=2));print('GEOMETRY',json.dumps(out),flush=True)
geoms=[]
for g in range(m.ngeom):
 name=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,g) or '';body=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,int(m.geom_bodyid[g])) or ''
 if body.startswith('walker/') and 'T3' in body:geoms.append(dict(name=name,body=body,contype=int(m.geom_contype[g]),conaffinity=int(m.geom_conaffinity[g])))
pairs=[dict(geom1=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,int(m.pair_geom1[i])),geom2=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,int(m.pair_geom2[i]))) for i in range(m.npair)];(R/'hindleg_collision_settings.json').write_text(json.dumps(dict(geoms=geoms,explicit_contact_pairs=pairs),indent=2));print('COLLISION',json.dumps(dict(geoms=geoms,pairs=pairs)),flush=True)
