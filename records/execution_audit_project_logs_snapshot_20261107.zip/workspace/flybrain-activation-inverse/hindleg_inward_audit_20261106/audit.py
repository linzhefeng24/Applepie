import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,numpy as np,mujoco,time
R=Path(__file__).resolve().parent;ROOT=R.parent;Z=ROOT/'half_speed_angle_only_20261106';m=mujoco.MjModel.from_xml_path(str(ROOT/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));z=dict(np.load(Z/'rollout_5000Hz.npz'));ref=dict(np.load(Z/'retimed_reference_5000Hz.npz'));records=json.loads((ROOT/'six_leg_model/activation_refine_20261104/records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];names=z['joint_names'];qadrs=ref['joint_qpos_indices'];dofs=ref['joint_dof_indices'];hind=np.array([i for i,n in enumerate(names) if '_T3_' in str(n)]);selected=np.array([i for i in hind if any(str(names[i]).startswith('walker/'+s+'_T3_') for s in ['coxa_abduct','coxa_twist','coxa','femur_twist','femur','tibia','tarsus'])]);thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');probe=mujoco.MjData(m);capacity=mujoco.MjData(m);fk=mujoco.MjData(m);d=mujoco.MjData(m);mujoco.mj_setState(m,d,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.qacc_warmstart[:]=z['initial_warmstart'];moment=np.zeros((m.nu,m.nv));out=[];snapshots=[];clock=time.monotonic();replayerr=0.;M=np.zeros((m.nv,m.nv))
def positions(data):
 rotation=data.xmat[thorax].reshape(3,3);o=data.xpos[thorax];ans={}
 for side in ['left','right']:
  ans[side]={}
  for part in ['coxa','tibia','tarsus','claw']:
   b=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,f'walker/{part}_T3_{side}');ans[side][part]=((data.xpos[b]-o)@rotation*10).tolist()
 return ans

def force_interval(q,v,act,ctrl):
 capacity.qpos[:]=q;capacity.qvel[:]=v;capacity.act[:]=act;capacity.ctrl[:]=ctrl;mujoco.mj_forward(m,capacity);mm=np.zeros_like(moment);mujoco.mju_sparse2dense(mm,capacity.actuator_moment,capacity.moment_rownnz,capacity.moment_rowadr,capacity.moment_colind);F=[]
 for a in [0,1]:capacity.act[adrs]=a;mujoco.mj_fwdActuation(m,capacity);F.append(capacity.actuator_force[ids].copy())
 return mm[ids],F

def snapshot(k):
 t=float(d.time);f=round(t/.0002);s=np.empty(z['full_state'].shape[1]);mujoco.mj_getState(m,d,s,mujoco.mjtState.mjSTATE_FULLPHYSICS);ctrl=z['all_control_10000Hz'][min(k,3999)];mujoco.mj_setState(m,probe,s,mujoco.mjtState.mjSTATE_FULLPHYSICS);probe.ctrl[:]=ctrl;probe.qacc_warmstart[:]=d.qacc_warmstart;mujoco.mj_forward(m,probe);mujoco.mju_sparse2dense(moment,probe.actuator_moment,probe.moment_rownnz,probe.moment_rowadr,probe.moment_colind);actualforces=probe.actuator_force[ids].copy();active=probe.act.copy();actualpos=positions(probe);J=np.zeros((probe.nefc,m.nv))
 if mujoco.mj_isSparse(m):mujoco.mju_sparse2dense(J,probe.efc_J,probe.efc_J_rownnz,probe.efc_J_rowadr,probe.efc_J_colind)
 else:J[:]=probe.efc_J.reshape(probe.nefc,m.nv)
 typ=probe.efc_type;maskContact=np.isin(typ,[int(mujoco.mjtConstraint.mjCNSTR_CONTACT_FRICTIONLESS),int(mujoco.mjtConstraint.mjCNSTR_CONTACT_PYRAMIDAL),int(mujoco.mjtConstraint.mjCNSTR_CONTACT_ELLIPTIC)]);maskLimit=typ==int(mujoco.mjtConstraint.mjCNSTR_LIMIT_JOINT);contact=J[maskContact].T@probe.efc_force[maskContact];limits=J[maskLimit].T@probe.efc_force[maskLimit];mujoco.mj_fullM(m,M,probe.qM);inertial=M@probe.qacc
 actual_mm,F=force_interval(probe.qpos.copy(),probe.qvel.copy(),active.copy(),ctrl);ref_mm,RF=force_interval(ref['qpos'][f],ref['qvel'][f],active.copy(),ctrl);capacity.qpos[:]=ref['qpos'][f];mujoco.mj_kinematics(m,capacity);refpos=positions(capacity)
 row=dict(time_s=t,source_phase_s=t/2,ncon=int(probe.ncon),positions_actual_body_frame_mm=actualpos,positions_reference_body_frame_mm=refpos,joints=[])
 for j in selected:
  do=int(dofs[j]);qa=int(qadrs[j]);jid=int(m.dof_jntid[do]);tau0=actual_mm[:,do]*F[0]*1e-7;tau1=actual_mm[:,do]*F[1]*1e-7;rt0=ref_mm[:,do]*RF[0]*1e-7;rt1=ref_mm[:,do]*RF[1]*1e-7;ta=(moment[ids,do]*actualforces*1e-7);ix=np.flatnonzero(abs(moment[ids,do])>1e-10);error=float(probe.qpos[qa]-ref['qpos'][f,qa]);mus=[]
  for i in ix:mus.append(dict(id=records[i]['id'],u=float(ctrl[ids[i]]),a=float(active[adrs[i]]),dlength_dq_cm_per_rad=float(moment[ids[i],do]),force_N=float(actualforces[i]*1e-5),force_if_a0_N=float(F[0][i]*1e-5),force_if_a1_N=float(F[1][i]*1e-5),torque_actual_Nm=float(ta[i]),torque_passive_bias_Nm=float(tau0[i]),torque_gain_per_activation_Nm=float(tau1[i]-tau0[i]),length_cm=float(probe.actuator_length[ids[i]]),lengthrange_cm=m.actuator_lengthrange[ids[i]].tolist()))
  row['joints'].append(dict(joint=str(names[j]),angle_deg=float(probe.qpos[qa]*180/np.pi),target_deg=float(ref['qpos'][f,qa]*180/np.pi),error_deg=error*180/np.pi,velocity_rad_s=float(probe.qvel[do]),reference_velocity_rad_s=float(ref['qvel'][f,do]),range_deg=(m.jnt_range[jid]*180/np.pi).tolist(),spring_rest_deg=float(m.qpos_spring[qa]*180/np.pi),joint_stiffness_native=float(m.jnt_stiffness[jid]),joint_damping_native=float(m.dof_damping[do]),muscle_torque_Nm=float(ta.sum()),muscle_passive_bias_torque_Nm=float(tau0.sum()),muscle_active_torque_Nm=float((ta-tau0).sum()),muscle_interval_Nm=[float(np.minimum(tau0,tau1).sum()),float(np.maximum(tau0,tau1).sum())],reference_pose_muscle_interval_Nm=[float(np.minimum(rt0,rt1).sum()),float(np.maximum(rt0,rt1).sum())],joint_and_tendon_passive_torque_Nm=float(probe.qfrc_passive[do]*1e-7),joint_damping_torque_Nm=float(-m.dof_damping[do]*probe.qvel[do]*1e-7),ground_contact_constraint_torque_Nm=float(contact[do]*1e-7),joint_limit_constraint_torque_Nm=float(limits[do]*1e-7),all_constraint_torque_Nm=float(probe.qfrc_constraint[do]*1e-7),retained_actuator_torque_Nm=float(probe.qfrc_actuator[do]*1e-7-ta.sum()),bias_including_gravity_Nm=float(probe.qfrc_bias[do]*1e-7),inertia_times_acceleration_Nm=float(inertial[do]*1e-7),force_balance_residual_Nm=float((inertial[do]-probe.qfrc_actuator[do]-probe.qfrc_passive[do]-probe.qfrc_constraint[do]+probe.qfrc_bias[do])*1e-7),muscles=mus))
 # Pure kinematic attribution: substitute one joint angle or all of one leg, without simulation.
 row['kinematic_counterfactuals']=[]
 for side in ['left','right']:
  js=[j for j in hind if str(names[j]).endswith('_'+side)];all_cases=[('all_leg_angles',js)]+[(str(names[j]),[j]) for j in js]
  for label,indices in all_cases:
   fk.qpos[:]=probe.qpos;fk.qpos[qadrs[indices]]=ref['qpos'][f,qadrs[indices]];mujoco.mj_kinematics(m,fk);pp=positions(fk)[side];row['kinematic_counterfactuals'].append(dict(side=side,substitution=label,positions_body_frame_mm=pp))
 out.append(row);snapshots.append((k,s.copy(),d.qacc_warmstart.copy()));print('sample',round(t,3),'constraints',probe.nefc,'wall_s',round(time.monotonic()-clock,2),flush=True)
for k in range(4000):
 if k%200==0:snapshot(k)
 d.ctrl[:]=z['all_control_10000Hz'][k];mujoco.mj_step(m,d)
 if k%2:
  s=np.empty(z['full_state'].shape[1]);mujoco.mj_getState(m,d,s,mujoco.mjtState.mjSTATE_FULLPHYSICS);replayerr=max(replayerr,float(np.max(abs(s-z['full_state'][k//2]))))
snapshot(4000);assert replayerr<1e-9;(R/'mechanics_timeline.json').write_text(json.dumps(out,indent=2));np.savez_compressed(R/'sample_states.npz',steps=np.array([s[0] for s in snapshots]),states=np.array([s[1] for s in snapshots]),warmstarts=np.array([s[2] for s in snapshots]));(R/'replay_validation.json').write_text(json.dumps(dict(passed=True,max_full_state_replay_error=replayerr,model_parameters_changed=False,trajectory_unchanged=True),indent=2));print('DONE',replayerr,flush=True)
