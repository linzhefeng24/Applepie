# Hindleg inward-bending audit

Right hind foot first crosses the thorax midline at 0.1422 s (saved-state resolution 0.2 ms). Foot coordinates are computed in the thorax frame, eliminating camera and body-orientation ambiguity.

The audit replays original inputs with full-state equality, decomposes native muscle/passive/contact/adhesion/limit torques, checks fixed-pose activation torque intervals and executes bounded independent counterfactual input rollouts. Original trajectory and physical parameters remain unchanged.

Main conclusions:

- The right hind foot crosses the thorax sagittal plane; both hind legs are spatially displaced toward the midline. This is not a camera effect.
- Both coxa coordinates approach their compliant lower joint limits. Large active muscle torques continue to push these coordinates away from reference, despite positive direct torque capacity at fixed pose.
- The same hip muscles influence multiple joint axes. Turning off a strongly loaded promotor for the last 20 ms slightly improves coxa but worsens other coordinates and total angle RMSE, explaining why the current aggregate endpoint objective rejects it.
- Earlier bounded hip-input correction can bring the left coxa close to reference, but worsens other joints. A 20 ms frozen-prefix solve cannot revise the earlier activation buildup.
- Tarsus muscle moment directions change with the full leg pose. At the deviated left pose, all directly coupled muscle activation gains have the same torque sign; on the right the useful opposing capacity is much weaker than at reference.
- Ground contact, adhesion and joint-limit forces are included in the torque balance. Existing hindleg collision geometries have nonzero contact masks; absence of all collision handling is not the explanation.
- Kinematic substitutions show that coxa, femur twist and tibia deviations are key contributors to medial foot displacement; straightening tarsus alone in the wrong proximal posture can move the foot further inward.

Counterfactuals include 20 ms versus 120 ms hip corrections. Earlier correction nearly restores one hip but damages other joint tracking; this is not a recovered walking solution. Instantaneous muscle intervals do not prove global unreachability.

See summary.json, mechanics_timeline.json, all_tarsus_geometry_comparison.json, counterfactual_input_trials.json and single_muscle_last_interval_trials.json for numerical evidence.
