import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent;ROOT=R.parent;m=mujoco.MjModel.from_xml_path(str(ROOT/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));z=dict(np.load(ROOT/'half_speed_angle_only_20261106/rollout_5000Hz.npz'));ref=dict(np.load(ROOT/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));sample=dict(np.load(R/'sample_states.npz'));records=json.loads((ROOT/'six_leg_model/activation_refine_20261104/records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];names=z['joint_names'];qa=ref['joint_qpos_indices'];dofs=ref['joint_dof_indices'];data=[mujoco.MjData(m) for _ in range(4)];d=mujoco.MjData(m);moment=np.zeros((m.nu,m.nv));out=[]
for pose,q in [('actual',z['qpos'][-1]),('reference',ref['qpos'][-1])]:
 d.qpos[:]=q;d.qvel[:]=0;d.ctrl[:]=z['all_control_10000Hz'][-1];d.act[:]=0;mujoco.mj_forward(m,d);mujoco.mju_sparse2dense(moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);F=[]
 for a in [0,1]:d.act[adrs]=a;mujoco.mj_fwdActuation(m,d);F.append(d.actuator_force[ids].copy())
 for side,leg in [('left','LH'),('right','RH')]:
  j=int(np.flatnonzero(names==f'walker/tarsus_T3_{side}')[0]);ii=next(i for i,r in enumerate(records) if r['id']==leg+':tarsus_levator');out.append(dict(pose=pose,velocity='all zero to isolate pose geometry',muscle=records[ii]['id'],joint=str(names[j]),dlength_dq_cm_per_rad=float(moment[ids[ii],dofs[j]]),torque_gain_per_activation_Nm=float(moment[ids[ii],dofs[j]]*(F[1][ii]-F[0][ii])*1e-7)))
(R/'geometry_action_comparison.json').write_text(json.dumps(out,indent=2));print('GEOMETRY',json.dumps(out),flush=True)
start=3800;si=int(np.flatnonzero(sample['steps']==start)[0]);base=z['all_control_10000Hz'][start:];controls=[base.copy()];labels=['baseline']
for muscle,bound in [('LH:tergopleural_promotor',0),('LH:sternal_posterior_rotator',1),('RH:tergopleural_promotor',0),('RH:sternal_posterior_rotator',1)]:
 ii=next(i for i,r in enumerate(records) if r['id']==muscle)
 for fraction in [.25,.5,1.]:
  C=base.copy();C[:,ids[ii]]=(1-fraction)*C[:,ids[ii]]+fraction*bound;controls.append(C);labels.append(f'{muscle} toward {bound}, fraction {fraction}')
S,_=rollout.rollout(m,data,sample['states'][si:si+1],np.asarray(controls),initial_warmstart=sample['warmstarts'][si:si+1],persistent_pool=True);E=(S[:,-1,1:1+m.nq][:,qa]-ref['qpos'][-1,qa])*180/np.pi;rows=[]
for i,label in enumerate(labels):rows.append(dict(trial=label,endpoint_rmse_deg=float(np.sqrt(np.mean(E[i]**2))),joint_errors_deg={str(names[j]):float(E[i,j]) for j in [44,45,46,47,55,56,57,58]}))
(R/'single_muscle_last_interval_trials.json').write_text(json.dumps(rows,indent=2));print('SINGLE_MUSCLE',json.dumps(rows),flush=True)
