import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,time,numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent;ROOT=R.parent;m=mujoco.MjModel.from_xml_path(str(ROOT/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));z=dict(np.load(ROOT/'half_speed_angle_only_20261106/rollout_5000Hz.npz'));ref=dict(np.load(ROOT/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));samples=dict(np.load(R/'sample_states.npz'));mechanics=json.loads((R/'mechanics_timeline.json').read_text());records=json.loads((ROOT/'six_leg_model/activation_refine_20261104/records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in records]);index={r['id']:i for i,r in enumerate(records)};names=z['joint_names'];qa=ref['joint_qpos_indices'];target=ref['qpos'][-1,qa];data=[mujoco.MjData(m) for _ in range(4)];fk=mujoco.MjData(m);thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');result=[];maxerr=0.;clock=time.monotonic()
for start in [.14,.2,.28,.32,.36,.38]:
 k=round(start/.0001);si=int(np.flatnonzero(samples['steps']==k)[0]);base=z['all_control_10000Hz'][k:].copy();trials=[base.copy()];labels=[dict(kind='baseline',start_time_s=start)]
 for typ in ['coxa','femur_twist','tarsus']:
  for sides in [['left'],['right'],['left','right']]:
   bounds={}
   for side in sides:
    row=next(j for j in mechanics[si]['joints'] if j['joint']==f'walker/{typ}_T3_{side}');ji=int(np.flatnonzero(names==row['joint'])[0]);q_start=row['angle_deg']*np.pi/180;direction=np.sign(target[ji]-q_start)
    for u in row['muscles']:
     gain=u['torque_gain_per_activation_Nm']
     if abs(gain)>1e-14:bounds[index[u['id']]]=float(gain*direction>0)
   for fraction in [.25,.5,.75,1.]:
    C=base.copy()
    for i,bound in bounds.items():C[:,ids[i]]=(1-fraction)*C[:,ids[i]]+fraction*bound
    trials.append(C);labels.append(dict(kind=typ,sides=sides,fraction=fraction,start_time_s=start,modified_muscles=[dict(id=records[i]['id'],toward_command=b) for i,b in bounds.items()]))
 C=np.asarray(trials);S,_=rollout.rollout(m,data,samples['states'][si:si+1],C,initial_warmstart=samples['warmstarts'][si:si+1],persistent_pool=True);assert np.isfinite(S).all() and np.allclose(S[:,-1,0],.4,atol=1e-8);maxerr=max(maxerr,float(np.max(abs(S[0,-1]-z['full_state'][-1]))));E=(S[:,-1,1:1+m.nq][:,qa]-target)*180/np.pi
 for i,label in enumerate(labels):
  fk.qpos[:]=S[i,-1,1:1+m.nq];mujoco.mj_kinematics(m,fk);rot=fk.xmat[thorax].reshape(3,3);pos={}
  for side in ['left','right']:
   bid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,f'walker/claw_T3_{side}');pos[side]=((fk.xpos[bid]-fk.xpos[thorax])@rot*10).tolist()
  row=dict(**label,endpoint_rmse_deg=float(np.sqrt(np.mean(E[i]**2))),max_error_deg=float(np.max(abs(E[i]))),joint_errors_deg={str(names[j]):float(E[i,j]) for j in range(44,66)},claw_positions_body_frame_mm=pos,thorax_up_z=float(fk.xmat[thorax].reshape(3,3)[2,2]),thorax_world_height_mm=float(fk.xpos[thorax,2]*10));result.append(row)
 (R/'counterfactual_input_trials.json').write_text(json.dumps(result,indent=2));print('completed_start',start,'trials',len(trials),'wall_s',round(time.monotonic()-clock,2),flush=True)
assert maxerr<1e-9;(R/'intervention_validation.json').write_text(json.dumps(dict(passed=True,baseline_reconstruction_max_full_state_error=maxerr,trial_count=len(result),bounded_inputs=True,all_trials_end_at_04s=True,original_trajectory_not_overwritten=True,diagnostic_only=True,limitations='Each bounded counterfactual uses muscle torque signs at the interval start, not a guarantee of optimal control. Wider windows modify earlier commands only in independent diagnostic copies.'),indent=2));print('DONE',maxerr,flush=True)
