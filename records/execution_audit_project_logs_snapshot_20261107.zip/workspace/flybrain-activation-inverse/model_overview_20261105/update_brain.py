from pathlib import Path
import json,copy,hashlib,os,collections,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent
C=Path('/workspace/flybrain-muscle-rebuild/brain.json');M=Path('/workspace/flybrain-recovered/brain.json')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=json.loads(C.read_text());assert b==json.loads(M.read_text());before=copy.deepcopy(b)
backup=R/'brain_before_model_overview.json'
if not backup.exists():backup.write_bytes(C.read_bytes())
selection=json.load(open('/workspace/flybrain-activation-inverse/muscle_model_selection.json'))
records_path=Path(selection['model_records']);rows=json.loads(records_path.read_text())['records'];counts=dict(collections.Counter(x['leg'] for x in rows))
model=ET.parse(selection['native_model']).getroot();muscles=[x for x in model.find('actuator') if x.get('dyntype')=='muscle'];assert len(rows)==len(muscles)==130
assert all(x.get('gaintype')=='muscle' and x.get('biastype')=='muscle' and x.get('actlimited')=='true' and x.get('actrange')=='0 1' for x in muscles)
report_path=Path('/workspace/flybrain-activation-inverse/six_leg_model/closed_loop_contact_20261104/bounded_default/report.json');report=json.loads(report_path.read_text())
assert sha(selection['native_model'])==selection['native_model_sha256']==report['model_sha256']
overview={
 'schema':'current_six_leg_muscle_model_overview_v1','updated_date':'2026-11-05','language':'zh-CN',
 'summary':'采用 FlyMimic MuJoCo 肌肉方程体系，在 flybody 自由身体骨架上扩展的六腿逐肌肉工作模型；不是论文原模型的原样复现，也不是 OpenSim Millard 实现。',
 'scope':{'legs':['LF','RF','LM','RM','LH','RH'],'MTU_channels':130,'MTUs_per_leg':counts,'catalog_slots_covered':126,'scope_excludes':'未建立全身翅、胸腹、口器等全部肌肉。','count_interpretation':'130 是模拟肌肉—腱单元数，126 是目录槽位数；划分粒度不同，不代表独立真实肌肉数已获解剖确认。'},
 'relationship_to_FlyMimic':{
  'upstream_paper':'https://arxiv.org/abs/2509.06426','upstream_repository':'https://github.com/gizemozd/FlyMimic',
  'inherited':'MuJoCo 原生肌肉主动增益、被动力及激活动力学；部分前腿解剖模板、曲线与参数。',
  'upstream_front_leg_MTU_count':15,'upstream_front_leg_modeled_DoFs':7,
  'current_source_template_channels':30,'current_other_evidence_and_geometry_hypothesis_channels':100,
  'extensions':'前腿补充其他类别，中后腿采用同类肌肉方法并结合各腿资料和几何假设；当前候选做过有界几何和生理参数优化。',
  'not_inherited_unchanged':['全六腿解剖与参数','原作者 PPO 控制策略','OpenSim Millard 2013 求解器及静态优化—前向动力学流程'],
  'paper_limits':'所查论文版本的主要行为验证集中在前腿；中后腿为解剖重建，未完成同等级行为优化。作者明确未纳入身体—身体及身体—环境接触力，不能据此宣称完整六腿承重行走已实现。',
  'tendon_distinction':'当前没有独立求解可伸长肌腱—肌纤维的弹性平衡。论文 OpenSim 设置也假设刚性肌腱、忽略肌腱顺应性并采用零羽状角；不能将其笼统描述为可伸长肌腱模型。'},
 'per_MTU_representation':{
  'fields':['目录关联与来源','所属腿与肌群','附着点、路径点及腱传动','长度及长度变化速度','随姿态变化的力臂','最大力与力长、力速和被动力参数','激活及去激活时间常数','激励 u 和激活 a'],
  'signal_chain':'u(t) → 原生激活动力学 → a(t) → 长度/速度相关肌肉拉力 → 当前路径力臂 → 关节广义力矩',
  'force_and_transmission':'肌肉产生拉力；关节屈伸力矩由路径与力臂方向决定，跨关节路径可以同时影响多个关节。',
  'activation_bounds':[0,1],'excitation_bounds':[0,1],
  'native_actuator_types':{'dyntype':'muscle','gaintype':'muscle','biastype':'muscle'},
  'default_kinetics':[
   {'channels':30,'source':'FlyMimic 前腿模板通道','activation_tau_s':0.0001,'deactivation_tau_s':0.0004},
   {'channels':100,'source':'其他资料与几何假设通道','activation_tau_s':0.02,'deactivation_tau_s':0.05,'status':'当前默认估计，非实测鉴定'}],
  'fast_kinetics_experiment':'曾把 100 个非 FlyMimic 来源通道的时间常数改为 1 ms/2 ms，作为先验下界敏感性实验；不是当前默认值，也未证明真实生理取值。'},
 'mathematical_structure':{
  'fixed_state_relation':'tau_muscle = B(q,qdot) @ a + b(q,qdot)',
  'fixed_state_interpretation':'在固定关节位置和速度下，原生主动肌肉力对激活为仿射关系；被动力在 b 中。因此单帧有界力矩反解可用凸二次优化。',
  'full_problem':'肌肉激活状态积分、姿态相关长度/速度/力臂、自由身体运动及接触切换组成非线性动态问题；不能称整个模型或整段轨迹优化为线性。',
  'independence_limit':'固定参考状态逐帧分配激活可以独立求解；加入实际激活动力学和前向运动后，相邻时刻由状态连接，不再独立。'},
 'body_and_current_solver':{
  'body':'flybody 原自由身体骨架，腿部关节坐标保留。','removed_original_leg_actuators':48,
  'retained_actuators':{'foot_adhesion':6,'head_abdomen_and_other':5},
  'main_simulation':'由肌肉与保留执行器驱动，原生计算重力、惯性、碰撞、摩擦和接触力；闭环主仿真不加外部救援力矩、不逐步重写身体姿态或激活。',
  'controller_period_s':0.002,'physics_timestep_s':0.0001,
  'method':'当前状态局部线性化 + 接触反力变化灵敏度 + 二次规划，随后完整原生非线性仿真执行。不是 FlyMimic 的 PPO 方法。',
  'objective':'力矩拟合 + 参考关节位置/速度跟踪及身体姿态任务。',
  'constraints':'激励/激活及动态可达范围；接触法向力与摩擦近似；预测地面间隙、关节限位和身体状态带显式惩罚松弛量。原生地面是软接触，不保证零穿透。'},
 'uncertainty_and_validation':{
  'geometry_fully_measured':False,'normal_six_leg_walking_validated':False,
  'known_uncertainties':['中后腿许多附着位置、力量、长度与时间常数为估计值','前腿模板配准有偏差，16 个沿用附着假设位于目标网格凸包外','部分长腱路径和远端传动采用代理结构','肌肉拆分和目录覆盖不等于逐块真实组织已精确还原'],
  'parameter_policy':'未知实测值保持 null；估计值及可修订先验范围单独记录。已做优化不等于实测参数已知。',
  'reference_state_refined_torque_relative_residual_L2':0.5711829831080207,
  'current_closed_loop_case':'bounded_default','duration_s':report['simulated_duration_s'],'joint_angle_RMSE_deg':report['joint_angle_rmse_deg'],
  'actual_result':'6 秒保持稳定但主要站立，未正常行走；中后腿缺少有效离地循环。',
  'comparison_caveat':'不同版本、动力学和限幅条件的旧实验不可按单一误差或位移直接排名。快速动力学早期视频未补显式激活状态限幅，不作为最终受限验证。'},
 'related_experiment_ids':['six_leg_activation_fit_20261104','six_leg_activation_refine_20261104','six_leg_contact_closed_loop_20261104'],
 'source_files':[{'path':str(p),'sha256':sha(p)} for p in [Path(selection['native_model']),records_path,report_path,Path('/workspace/flybrain-muscle-rebuild/sources/flymimic-paper.txt')]],
 'active_model_path':selection['native_model'],'active_model_sha256':sha(selection['native_model'])}
b['neuromusculoskeletal_model']['current_muscle_model_overview']=overview
b['version']='3.4.4-six-leg-muscle-model-overview';b['date']='2026-11-05'
for k,v in before.items():
 if k not in ['version','date','neuromusculoskeletal_model']:assert b[k]==v,k
for k,v in before['neuromusculoskeletal_model'].items():
 if k!='current_muscle_model_overview':assert b['neuromusculoskeletal_model'][k]==v,k
blob=(json.dumps(b,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
for p in [C,M]:
 tmp=p.with_name(p.name+'.overview.tmp');tmp.write_bytes(blob);os.replace(tmp,p)
assert C.read_bytes()==M.read_bytes()
validation={'passed':True,'version':b['version'],'overview_key':'neuromusculoskeletal_model.current_muscle_model_overview','prior_sections_preserved':True,'mirrors_identical':True,'MTU_channels_checked':len(muscles),'brain_sha256':sha(C)}
(R/'validation.json').write_text(json.dumps(validation,indent=2));print(json.dumps(validation,ensure_ascii=False,indent=2))
