from pathlib import Path
import json,hashlib,copy,os
R=Path(__file__).resolve().parent;C=Path('/workspace/flybrain-muscle-rebuild/brain.json');M=Path('/workspace/flybrain-recovered/brain.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads(C.read_text());assert b==json.loads(M.read_text());old=copy.deepcopy(b)
backup=R/'brain_before_position_search.json'
if not backup.exists():backup.write_bytes(C.read_bytes())
validation=json.loads((R/'validation.json').read_text());assert all(v['passed'] for v in validation.values());comparison=json.loads((R/'comparison.json').read_text())
run=dict(id='six_leg_position_direction_search_20261105',date='2026-11-05',role='receding actual-state joint-angle tracking with evolutionary mutation-selection and stochastic-gradient candidate comparison; short trials, not normal walking',previous_experiment_id='six_leg_nonlinear_gradient_20261105',comparison=comparison,validation=validation,method_document={'format':'markdown','text':(R/'README.md').read_text()},artifacts=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in ['brain_before_position_search.json','brain_integration.json'] and p.suffix in ['.json','.py','.npz','.md','.mp4','.png']],muscle_model_and_default_parameters_replaced=False,walking_validated=False)
runs=b['muscle_activation_inference_experiments']['runs'];runs[:]=[r for r in runs if r['id']!=run['id']];runs.append(run)
n=b['neuromusculoskeletal_model'];n['current_readiness']['latest_position_direction_search_experiment_id']=run['id'];n['current_muscle_model_overview']['position_direction_search_trial']={'experiment_id':run['id'],'horizon_s':.6,'gradient_and_evolution_candidates_tested':True,'walking_validated':False,'selected_model_and_default_parameters_unchanged':True}
b['version']='3.4.6-position-direction-evolution-search';b['date']='2026-11-05'
for k,v in old.items():
 if k not in ['version','date','neuromusculoskeletal_model','muscle_activation_inference_experiments']:assert b[k]==v,k
blob=(json.dumps(b,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
for p in [C,M]:tmp=p.with_name(p.name+'.position.tmp');tmp.write_bytes(blob);os.replace(tmp,p)
assert C.read_bytes()==M.read_bytes();out=dict(passed=True,version=b['version'],mirrors_identical=True,prior_biological_evidence_preserved=True,walking_validated=False,brain_sha256=sha(C));(R/'brain_integration.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
