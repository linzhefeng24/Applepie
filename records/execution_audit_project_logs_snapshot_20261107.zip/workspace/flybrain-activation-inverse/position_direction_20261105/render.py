import os
os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/tmp/direction-mesa',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,numpy as np,mujoco,imageio
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'nonlinear_gradient_20261105'));from problem import BASE
m=mujoco.MjModel.from_xml_path(str(BASE/'bounded_refined_muscles.xml'));d=mujoco.MjData(m);renderer=mujoco.Renderer(m,height=240,width=320);opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
zs=[np.load(BASE/'bounded_default/rollout.npz'),np.load(R/'hybrid/rollout_5000Hz.npz')]
with imageio.get_writer(R/'position_direction_comparison.mp4',fps=15,codec='libx264',quality=8) as w:
 for t in np.arange(.001,.6,.02):
  ims=[]
  for z,label in zip(zs,['Previous local-QP feedback','Gradient + mutations']):
   j=int(np.argmin(abs(z['time_s']-t)));d.qpos[:]=z['qpos'][j];d.qvel[:]=z['qvel'][j];d.time=z['time_s'][j];mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=opt);im=Image.fromarray(renderer.render());dr=ImageDraw.Draw(im);dr.rectangle((0,0,320,36),fill='black');dr.text((4,3),label,fill='white');dr.text((4,18),f't={d.time:.3f}s | 0.3x | short trial',fill='white');ims.append(np.asarray(im))
  w.append_data(np.concatenate(ims,axis=1))
renderer.close();print('Saved states rendered, no resimulation.')
