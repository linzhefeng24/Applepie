import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/mpl-position-direction')
from pathlib import Path
import json,sys,numpy as np,mujoco
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.ndimage import median_filter
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'nonlinear_gradient_20261105'));from problem import Problem,BASE
p=Problem(seconds=.6);m=p.m;d=mujoco.MjData(m);bid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');cf=np.zeros(6);geo={};tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right']
for i in range(m.ngeom):
 n=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or ''
 if n.startswith('walker/') and any(k in n for k in ['tarsus','claw']):
  for j,t in enumerate(tokens):
   if t in n:geo[i]=j
sourceq=p.src['qpos'];fig,axs=plt.subplots(2,1,figsize=(9,6),constrained_layout=True);results={}
b=np.load(BASE/'bounded_default/rollout.npz');t=b['time_s'];mask=t<=.600001;fr=np.minimum(np.rint(t[mask]/.0002).astype(int),len(sourceq)-1);err=b['qpos'][mask][:,p.qadrs]-sourceq[fr][:,p.qadrs];rmse=np.sqrt(np.mean(err**2,axis=1))*180/np.pi
results['previous_closed_loop']=dict(duration_s=float(t[mask][-1]),joint_rmse_deg=float(np.sqrt(np.mean(err**2))*180/np.pi),first_02s_joint_rmse_deg=float(np.sqrt(np.mean(err[t[mask]<=.200001]**2))*180/np.pi));axs[0].plot(t[mask],rmse,label='Previous local-QP feedback');axs[1].plot(t[mask],b['thorax_mm'][mask,0]-b['thorax_mm'][0,0],label='Previous local-QP feedback')
for case in ['evolution','hybrid']:
 z={k:v for k,v in np.load(R/case/'rollout_5000Hz.npz').items()};T=z['time_s'];up=[];xyz=[];support=[];chest=[];pen=[]
 for i in range(0,len(T),5):
  mujoco.mj_setState(m,d,z['full_state'][i],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.ctrl[:]=z['all_control'][i];mujoco.mj_forward(m,d);up.append(float(d.xmat[bid].reshape(3,3)[2,2]));xyz.append(d.xpos[bid].copy()*10);f=np.zeros(6);touch=False;penetr=0.
  for k in range(d.ncon):
   c=d.contact[k];g1,g2=int(c.geom1),int(c.geom2);other=g2 if m.geom_bodyid[g1]==0 else g1 if m.geom_bodyid[g2]==0 else None
   if other is None:continue
   penetr=max(penetr,-float(c.dist));touch=touch or m.geom_bodyid[other]==bid
   if other in geo and c.efc_address>=0:mujoco.mj_contactForce(m,d,k,cf);f[geo[other]]+=max(0.,cf[0])
  support.append(f);chest.append(bool(touch));pen.append(penetr)
 xyz=np.asarray(xyz);support=np.asarray(support);stance=median_filter(support>m.body_subtreemass[bid]*np.linalg.norm(m.opt.gravity)*.01,size=(5,1),mode='nearest');rep=json.loads((R/case/'report.json').read_text());rep.update(min_thorax_up_z=min(up),thorax_ground_contact_samples=sum(chest),displacement_xyz_mm=(xyz[-1]-xyz[0]).tolist(),per_leg_contact_transitions=np.sum(stance[1:]!=stance[:-1],axis=0).tolist(),support_fraction=float(np.mean(np.any(stance,axis=1))),max_ground_penetration_um=max(pen)*1e4)
 results[case]=rep;(R/case/'analysis.json').write_text(json.dumps(rep,indent=2));np.savez_compressed(R/case/'contact_audit.npz',time_s=T[::5],thorax_mm=xyz,up_z=up,support_dyne=support,thorax_ground=chest)
 axs[0].plot(T,np.sqrt(np.mean(z['qerror_rad']**2,axis=1))*180/np.pi,label=case);axs[1].plot(T[::5],xyz[:,0]-xyz[0,0],label=case)
axs[0].set(ylabel='Joint RMSE (deg)');axs[1].set(xlabel='Time (s)',ylabel='Forward displacement (mm)')
for ax in axs:ax.legend();ax.grid(alpha=.3)
fig.savefig(R/'comparison.png',dpi=150);plt.close(fig);(R/'comparison.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
