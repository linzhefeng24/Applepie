import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,hashlib,numpy as np,mujoco
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'nonlinear_gradient_20261105'));from problem import Problem,BASE
p=Problem(seconds=.6);source=p.src['ctrl'];results={}
for case in ['evolution','hybrid']:
 z={k:v for k,v in np.load(R/case/'rollout_5000Hz.npz').items()};d=mujoco.MjData(p.m);mujoco.mj_setState(p.m,d,p.initial,mujoco.mjtState.mjSTATE_FULLPHYSICS);mujoco.mj_forward(p.m,d);err=0.;amin=1.;amax=0.
 for step in range(2*len(z['time_s'])):
  frame=min(round(d.time/.0002),len(source)-1)
  for i,j in p.retained:d.ctrl[j]=source[frame,i]
  d.ctrl[p.ids]=z['excitation'][step//2];mujoco.mj_step(p.m,d);amin=min(amin,float(d.act[p.adrs].min()));amax=max(amax,float(d.act[p.adrs].max()))
  if step%2==1:
   state=np.empty(len(p.initial));mujoco.mj_getState(p.m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);err=max(err,float(np.max(np.abs(state-z['full_state'][step//2]))))
 assert err<1e-9,err;assert 0<=amin<=amax<=1;assert not np.any(d.qfrc_applied) and not np.any(d.xfrc_applied)
 hist=json.loads((R/case/'history.json').read_text());assert all(h['chosen_loss']<=h['initial_loss']+1e-12 for h in hist)
 results[case]=dict(passed=True,replay_full_state_max_abs_error=err,activation_min_every_physics_step=amin,activation_max_every_physics_step=amax,all_chosen_predictions_nonworsening=True,applied_extra_force=False,model_sha256=hashlib.sha256((BASE/'bounded_refined_muscles.xml').read_bytes()).hexdigest())
(R/'validation.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
