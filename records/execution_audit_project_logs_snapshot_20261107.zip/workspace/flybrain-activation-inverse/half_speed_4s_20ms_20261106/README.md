# Half-speed 4-second reference, 200 x 20 ms muscle reconstruction

The original source is /workspace/fly-walking-run/output/walking_6s_5000Hz.npz. Select original times 0..2 s and run them at speed 0.5, yielding four physical simulation seconds. The exact mapping is t_source = 0.5 * t_simulation. Reference positions use quaternion-safe interpolation, velocities are multiplied by 0.5, and reference acceleration used only for inverse-dynamics warm starting is multiplied by 0.25. This is not a 0.4 s clip stretched to 4 s.

The 200 sequential intervals each last 0.02 s and integrate 200 native 0.0001 s substeps. Each interval has 130 independent bounded muscle excitation offsets; all 11 retained nonmuscle controls follow the original policy at half speed. The current muscle model and all strength/activation parameters are unchanged. Activation and excitation remain in [0,1]. Physical, muscle and solver warm-start state continuously propagate across interval boundaries.

The overall angle objective A is used. Path poses are sampled every 4 ms, and endpoint residual multiplier is 4. Hind-foot, coxa, twist, tarsus and body-up safeguards remain soft penalties. Height and velocity penalties are zero. Bounded finite-difference Gauss-Newton, Broyden/cached Jacobians, actual line search and random candidates use up to eight iterations per interval. No candidate is accepted based solely on its linear prediction. No B trial is reported.

Complete actual replay: 40,000 control steps and 20,000 saved physical states. Complete independent replay maximum state error: 0.0. Check analysis.json for reference mapping, bounds, source-control checks, body motion, contact diagnostics and all 200 endpoint errors. The four-second trajectory is verified continuous, without pose resets or added forces.

| Metric | Result |
|---|---:|
| Full-path angle RMS | 29.4418 deg |
| Terminal angle RMS | 30.0003 deg |
| Maximum terminal absolute angle error | 112.5429 deg |
| Maximum absolute angle error over path | 116.9016 deg |
| First left/right hind-foot midline crossing | [1.3091999999998722, 0.5831999999999521] s |
| Actual world root displacement | [1.9299773313327533, -0.09086043406454684, -0.13402574296100644] mm |
| Reference world root displacement | [40.260662562427, -0.01910055193297974, 0.05877429279770613] mm |

The fit has large errors and does not establish normal walking. Previous controllers and the globally selected model are preserved.

Video: https://github.com/linzhefeng24/Applepie/blob/main/videos/muscle_fit_reference_half_speed_4s_20ms_20261106.mp4

Download: https://raw.githubusercontent.com/linzhefeng24/Applepie/main/videos/muscle_fit_reference_half_speed_4s_20ms_20261106.mp4

Left: half-speed reference. Right: actual muscle-driven replay. The video lasts four seconds at 50 fps; frames sample 0,0.02,...,3.98 s and each is held 0.02 s. The simulated episode endpoint is 4 s. Original source phase runs from 0 to 2 s. Cameras follow each body separately; world root X displacement is overlaid to make locomotion progress visible. Source is simulated walking, not animal footage.
