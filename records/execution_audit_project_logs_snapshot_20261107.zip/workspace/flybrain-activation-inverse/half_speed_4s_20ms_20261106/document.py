from pathlib import Path
import copy,json,hashlib
R=Path(__file__).resolve().parent;source=Path('/workspace/flybrain-muscle-rebuild/brain.json');mirror=Path('/workspace/flybrain-recovered/brain.json');assert source.read_bytes()==mirror.read_bytes();b=json.loads(source.read_text());before=copy.deepcopy(b);analysis=json.loads((R/'analysis.json').read_text());manifest=json.loads((R/'reference_manifest.json').read_text());solver=json.loads((R/'A/report.json').read_text());video=json.loads((R/'video/github_verified.json').read_text());entry=dict(id='six_leg_half_speed_4s_20ms_20261106',date='2026-11-06',role='200-segment continuous muscle-driven reconstruction of an original 2 s walking reference played at half speed over 4 physical seconds',reference=manifest,solver=solver,analysis=analysis,video=video,excitation_and_activation_data=str(R/'A/optimized_rollout.npz'),excitation_field='all_control_10000Hz, muscle columns ordered by records actuator_index',activation_field='activation, 130 muscle channels at 5000 Hz',segment_history=str(R/'A/segments.json'),artifact_directory=str(R),selected_model_or_controller_replaced=False,walking_validated=False,notes=['Reference is the original first 2 s of the 6 s Flybody policy simulation, not the old 0.4 s motion stretched tenfold.','Only the overall joint-angle tracking objective A was used; no B trial is claimed.','No height or velocity penalty, no applied rescue forces, and no intermediate posture resets.','Inverse-dynamics muscle projection is a bounded warm start only. Actual candidates use full native forward contact and activation dynamics.','Broyden updates and cached finite-difference response matrices accelerate the longer trajectory; accepted steps always reduce the actually simulated local objective.','Muscle geometry, native force curves, strength and activation time constants are unchanged.','Large joint errors remain, so this is not a successful reconstruction of normal walking.'])
backup=R/'brain_before_4s.json'
if not backup.exists():backup.write_bytes(source.read_bytes())
b['muscle_activation_inference_experiments']['runs']=[r for r in b['muscle_activation_inference_experiments']['runs'] if r.get('id')!=entry['id']]+[entry];b['version']='3.4.21-half-speed-4s-20ms';b['date']='2026-11-06';b['neuromusculoskeletal_model']['current_readiness'].update(latest_half_speed_4s_experiment_id=entry['id'],latest_half_speed_4s_segment_count=200,latest_half_speed_4s_all_segments_completed=True,latest_half_speed_4s_tracking_passed=False,whole_body_muscle_walking_validated=False)
for k in before:
 if k not in ['version','date','muscle_activation_inference_experiments','neuromusculoskeletal_model']:assert before[k]==b[k]
s=json.dumps(b,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
for p in [source,mirror]:tmp=p.with_suffix('.4s.tmp');tmp.write_text(s);tmp.replace(p)
assert source.read_bytes()==mirror.read_bytes();(R/'brain_update_validation.json').write_text(json.dumps(dict(version=b['version'],mirrors_identical=True,biological_top_level_data_preserved=True,selected_model_unchanged=True),indent=2));text=f'''# Half-speed 4-second reference, 200 x 20 ms muscle reconstruction

The original source is /workspace/fly-walking-run/output/walking_6s_5000Hz.npz. Select original times 0..2 s and run them at speed 0.5, yielding four physical simulation seconds. The exact mapping is t_source = 0.5 * t_simulation. Reference positions use quaternion-safe interpolation, velocities are multiplied by 0.5, and reference acceleration used only for inverse-dynamics warm starting is multiplied by 0.25. This is not a 0.4 s clip stretched to 4 s.

The 200 sequential intervals each last 0.02 s and integrate 200 native 0.0001 s substeps. Each interval has 130 independent bounded muscle excitation offsets; all 11 retained nonmuscle controls follow the original policy at half speed. The current muscle model and all strength/activation parameters are unchanged. Activation and excitation remain in [0,1]. Physical, muscle and solver warm-start state continuously propagate across interval boundaries.

The overall angle objective A is used. Path poses are sampled every 4 ms, and endpoint residual multiplier is 4. Hind-foot, coxa, twist, tarsus and body-up safeguards remain soft penalties. Height and velocity penalties are zero. Bounded finite-difference Gauss-Newton, Broyden/cached Jacobians, actual line search and random candidates use up to eight iterations per interval. No candidate is accepted based solely on its linear prediction. No B trial is reported.

Complete actual replay: 40,000 control steps and 20,000 saved physical states. Complete independent replay maximum state error: {analysis['validation']['full_state_replay_max_abs_error']}. Check analysis.json for reference mapping, bounds, source-control checks, body motion, contact diagnostics and all 200 endpoint errors. The four-second trajectory is verified continuous, without pose resets or added forces.

| Metric | Result |
|---|---:|
| Full-path angle RMS | {analysis['path_joint_rmse_deg']:.4f} deg |
| Terminal angle RMS | {analysis['terminal_joint_rmse_deg']:.4f} deg |
| Maximum terminal absolute angle error | {analysis['max_terminal_error_deg']:.4f} deg |
| Maximum absolute angle error over path | {analysis['max_path_error_deg']:.4f} deg |
| First left/right hind-foot midline crossing | {analysis['hind_foot_first_midline_crossing_s']} s |
| Actual world root displacement | {analysis['actual_root_displacement_mm']} mm |
| Reference world root displacement | {analysis['reference_root_displacement_mm']} mm |

The fit has large errors and does not establish normal walking. Previous controllers and the globally selected model are preserved.

Video: {video['html_url']}

Download: {video['download_url']}

Left: half-speed reference. Right: actual muscle-driven replay. The video lasts four seconds at 50 fps; frames sample 0,0.02,...,3.98 s and each is held 0.02 s. The simulated episode endpoint is 4 s. Original source phase runs from 0 to 2 s. Cameras follow each body separately; world root X displacement is overlaid to make locomotion progress visible. Source is simulated walking, not animal footage.
''';(R/'README.md').write_text(text);print('Updated',b['version'])
