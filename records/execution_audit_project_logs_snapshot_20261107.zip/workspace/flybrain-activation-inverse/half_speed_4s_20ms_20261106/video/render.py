import os
os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/tmp/hind-correction-mesa',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',LP_NUM_THREADS='2')
from pathlib import Path
import sys,json,numpy as np,mujoco,imageio
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;ROOT=R.parent.parent;P=ROOT/'hindleg_correction_20261106';m=mujoco.MjModel.from_xml_path(str(P/'candidate_muscles.xml'));d=mujoco.MjData(m);ref=dict(np.load(R.parent/'reference_5000Hz.npz'));only='--reference-only' in sys.argv;z=None if only else dict(np.load(R.parent/'A/optimized_rollout.npz'));renderer=mujoco.Renderer(m,height=480,width=640);opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0;thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');qa=ref['joint_qpos_indices'];(R/'reference_frames').mkdir(exist_ok=True)
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
measure=[];file=R/('reference_half_speed_4s.mp4' if only else 'reference_vs_muscle_half_speed_4s_20ms.mp4')
def draw(q,v,t,label,rms):
 d.qpos[:]=q;d.qvel[:]=v;d.time=t;mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=opt);renderer.scene.flags[mujoco.mjtRndFlag.mjRND_REFLECTION]=False;renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW]=False;im=Image.fromarray(renderer.render());dr=ImageDraw.Draw(im);dr.rectangle((0,0,640,67),fill='black');dr.text((10,7),label,fill='white');dr.text((10,27),f'simulation time={t:.2f} s | original reference time={.5*t:.2f} s',fill='white');dr.text((10,47),f'angle RMS={rms:.2f} deg | world root X change={(q[0]-ref["qpos"][0,0])*10:.2f} mm',fill='white');return im
with imageio.get_writer(file,fps=50,codec='libx264',quality=8,macro_block_size=2) as writer:
 for f in range(200):
  t=f*.02;k=f*100;path=R/'reference_frames'/f'{f:03d}.png'
  if path.exists():a=Image.open(path).convert('RGB')
  else:a=draw(ref['qpos'][k],ref['qvel'][k],t,'Reference: original 0..2 s at 0.5 speed',0);a.save(path)
  if only:combined=np.asarray(a)
  else:
   if f==0:q=z['initial_state'][1:1+m.nq];v=z['initial_state'][1+m.nq:1+m.nq+m.nv]
   else:q=z['qpos'][k-1];v=z['qvel'][k-1]
   err=float(np.sqrt(np.mean((q[qa]-ref['qpos'][k,qa])**2))*180/np.pi);b=draw(q,v,t,'Muscle-driven replay: 200 consecutive 20 ms segments',err);combined=np.concatenate([np.asarray(a),np.asarray(b)],axis=1);measure.append(dict(frame=f,time_s=t,source_time_s=.5*t,angle_rmse_deg=err))
  writer.append_data(combined)
  if f in [0,100,199]:Image.fromarray(combined).save(R/f'{"ref" if only else "comparison"}_{f:03d}.png')
  if f%50==0:print('rendered',f,flush=True)
renderer.close();(R/('reference_video_manifest.json' if only else 'render_measurements.json')).write_text(json.dumps(dict(frames=200,fps=50,duration_s=4,physical_reference_duration_s=4,original_reference_duration_s=2,speed_factor=.5,frame_sampling_interval_s=.02,frame_times='0,0.02,...,3.98 s, each held 0.02 s; simulated episode endpoint is 4 s',cameras_follow_bodies_independently=True,measurements=measure),indent=2));print('FINISHED',str(file),flush=True)
