import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,argparse
import numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent/'track';R.mkdir(exist_ok=True);SOURCE=Path(__file__).resolve().parent;sys.path.insert(0,str(SOURCE.parent/'nonlinear_gradient_20261105'));from problem import Problem,BASE
ap=argparse.ArgumentParser();ap.add_argument('--seconds',type=float,default=.6);ap.add_argument('--interval',type=float,default=.01);ap.add_argument('--horizon',type=float,default=.03);ap.add_argument('--mutations',type=int,default=16);ap.add_argument('--case',choices=['track','recovery'],default='track');args=ap.parse_args();R=SOURCE/args.case;R.mkdir(exist_ok=True)
rng=np.random.default_rng(20261105);p=Problem(seconds=args.seconds);m=p.m;main=mujoco.MjData(m);mujoco.mj_setState(m,main,p.initial,mujoco.mjtState.mjSTATE_FULLPHYSICS);mujoco.mj_forward(m,main);
if args.case=='recovery':
 previous=np.load(SOURCE.parent/'position_direction_20261105/hybrid/rollout_5000Hz.npz');j=int(np.argmin(abs(previous['time_s']-.2)));mujoco.mj_setState(m,main,previous['full_state'][j],mujoco.mjtState.mjSTATE_FULLPHYSICS);mujoco.mj_forward(m,main)
initial_run=np.empty(len(p.initial));mujoco.mj_getState(m,main,initial_run,mujoco.mjtState.mjSTATE_FULLPHYSICS)
src={k:p.src[k] for k in ['time_s','qpos','qvel','ctrl','joint_names']};seed=np.load(BASE/'bounded_default/rollout.npz');root=p.rootq;thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');zfloor=main.qpos[root+2]-.03;nh=round(args.horizon/m.opt.timestep);nc=round(args.interval/m.opt.timestep);last=seed['excitation'][min(round(main.time/.002),len(seed['time_s'])-1)].copy();clock=time.monotonic();logs=[];physics=[];controls=[];history=[];data=[mujoco.MjData(m) for _ in range(4)];warm=main.qacc_warmstart.copy();nstate=len(p.initial)
def simulate(U,initial,ctrl0,refq,refv):
 U=np.atleast_2d(U);ctrl=np.broadcast_to(ctrl0,(len(U),*ctrl0.shape)).copy();ctrl[:,:,p.ids]=U[:,None,:]
 state,_=rollout.rollout(m,data,initial[None],ctrl,initial_warmstart=warm[None],persistent_pool=True)
 ss=state[:,9::10];q=ss[:,:,1:1+m.nq];v=ss[:,:,1+m.nq:1+m.nq+m.nv];e=q[:,:,p.qadrs]-refq[None,:,p.qadrs];qcost=np.mean(e*e,axis=(1,2));vel=np.mean(((v[:,:,p.dofs]-refv[None,:,p.dofs])/50)**2,axis=(1,2))
 quat=q[:,:,root+3:root+7];refquat=refq[:,root+3:root+7];dot=np.clip(abs(np.sum(quat*refquat[None],axis=2)),0.,1.);angle=2*np.arccos(dot);orientation=np.mean((angle/.26)**2,axis=1);height=np.mean(((q[:,:,root+2]-refq[None,:,root+2])/.01)**2,axis=1)
 terminal=np.mean(e[:,-1]**2,axis=1);cost=.5*qcost+.5*terminal+.02*vel+.05*orientation+.05*height
 valid=np.isfinite(state).all(axis=(1,2))&np.all(np.isclose(state[:,:,0],initial[0]+np.arange(1,nh+1)*m.opt.timestep,atol=1e-7),axis=1);cost=np.where(valid,cost,1e6)
 return cost,dict(qcost=qcost,orientation=orientation,height=height)
for step in range(round(args.seconds/args.interval)):
 t=main.time;initial=np.empty(nstate);mujoco.mj_getState(m,main,initial,mujoco.mjtState.mjSTATE_FULLPHYSICS);warm=main.qacc_warmstart.copy();prediction_times=np.empty(nh);future_time=float(t)
 for j in range(nh):prediction_times[j]=future_time;future_time+=m.opt.timestep
 frames=np.minimum(np.rint(prediction_times/.0002).astype(int),len(src['time_s'])-1);ctrl0=np.zeros((nh,m.nu))
 for i,j in p.retained:ctrl0[:,j]=src['ctrl'][frames,i]
 rf=np.minimum(np.rint((t+np.arange(10,nh+1,10)*m.opt.timestep)/.0002).astype(int),len(src['time_s'])-1);refq=src['qpos'][rf];refv=src['qvel'][rf]
 old=seed['excitation'][min(round(t/.002),len(seed['time_s'])-1)];bases=np.array([last,old]);bc,bd=simulate(bases,initial,ctrl0,refq,refv);bi=int(np.argmin(bc));u=bases[bi].copy();basecost=float(bc[bi]);before=basecost
 # One feasible coordinate perturbation per muscle: numerical partial derivative of actual predicted angle loss.
 eps=.02;dh=np.where(u<=.5,eps,-eps);probes=np.broadcast_to(u,(130,130)).copy();probes[np.arange(130),np.arange(130)]+=dh;pc,_=simulate(probes,initial,ctrl0,refq,refv);gradient=(pc-basecost)/dh
 direction=gradient/max(np.sqrt(np.mean(gradient**2)),1e-12);rates=np.array([.05,.15,.4]);cand=np.clip(u[None]-rates[:,None]*direction[None],0,1);noise=rng.normal(size=(args.mutations,130));mask=rng.random((args.mutations,130))<.3;scales=rng.choice([.05,.15,.35],size=(args.mutations,1));mutants=np.clip(u+scales*noise*mask,0,1);cand=np.concatenate([cand,mutants]);cc,cd=simulate(cand,initial,ctrl0,refq,refv);ci=int(np.argmin(cc));accepted=bool(cc[ci]<basecost)
 if accepted:u=cand[ci];basecost=float(cc[ci])
 history.append(dict(chosen_direction=('gradient' if ci<3 else 'mutation') if accepted else 'unchanged',mutation_candidates=args.mutations,time_s=float(t),initial_loss=before,chosen_loss=basecost,accepted=accepted,gradient_norm=float(np.linalg.norm(gradient)),step_size=float(rates[ci]) if accepted and ci<len(rates) else None,initial_qcost=float(bd['qcost'][bi]),chosen_qcost=float(cd['qcost'][ci]) if accepted else float(bd['qcost'][bi])))
 for j in range(nc):
  fi=min(round(main.time/.0002),len(src['time_s'])-1)
  for i,k in p.retained:main.ctrl[k]=src['ctrl'][fi,i]
  main.ctrl[p.ids]=u;mujoco.mj_step(m,main)
  if j%2==1:
   st=np.empty(nstate);mujoco.mj_getState(m,main,st,mujoco.mjtState.mjSTATE_FULLPHYSICS);physics.append(st);controls.append(main.ctrl.copy())
 last=u.copy();idx=min(round(main.time/.0002),len(src['time_s'])-1);qe=float(np.sqrt(np.mean((main.qpos[p.qadrs]-src['qpos'][idx,p.qadrs])**2))*180/np.pi);print(json.dumps(dict(step=step+1,time_s=float(main.time),instant_joint_rmse_deg=qe,accepted=accepted,predicted_loss_before=before,predicted_loss_after=basecost,wall_s=time.monotonic()-clock)),flush=True)
 (R/'history.json').write_text(json.dumps(history,indent=2))
assert np.max(np.abs(main.qfrc_applied))==0 and np.max(np.abs(main.xfrc_applied))==0
s=np.asarray(physics);ctrl=np.asarray(controls);q=s[:,1:1+m.nq];v=s[:,1+m.nq:1+m.nq+m.nv];a=s[:,1+m.nq+m.nv:][:,p.adrs];frames=np.minimum(np.rint(s[:,0]/.0002).astype(int),len(src['time_s'])-1);error=q[:,p.qadrs]-src['qpos'][frames][:,p.qadrs]
np.savez_compressed(R/'rollout_5000Hz.npz',time_s=s[:,0],initial_state=initial_run,full_state=s,qpos=q,qvel=v,activation=a,excitation=ctrl[:,p.ids],all_control=ctrl,qerror_rad=error,muscle_ids=np.array([r['id'] for r in p.rows]),joint_names=src['joint_names'])
report=dict(case=args.case,initial_time_s=float(initial_run[0]),method='all 130 coordinate finite-difference gradient with continuous reference body height/orientation, terminal-angle and velocity tracking; mutation candidate comparison',seconds=args.seconds,interval_s=args.interval,prediction_horizon_s=args.horizon,coordinate_gradient_directions_per_update=130,activation_bounds=[float(a.min()),float(a.max())],joint_rmse_deg=float(np.sqrt(np.mean(error*error))*180/np.pi),first_02s_joint_rmse_deg=float(np.sqrt(np.mean(error[(s[:,0]-initial_run[0])<=.2000001]**2))*180/np.pi),accepted_updates=sum(h['accepted'] for h in history),updates=len(history),mutation_selected_updates=sum(h['chosen_direction']=='mutation' for h in history),gradient_selected_updates=sum(h['chosen_direction']=='gradient' for h in history),wall_seconds=time.monotonic()-clock,muscle_model_and_parameters_unchanged=True,extra_rescue_force_or_torque=False,main_state_resets_after_initialization=False,walking_validated=False)
(R/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
