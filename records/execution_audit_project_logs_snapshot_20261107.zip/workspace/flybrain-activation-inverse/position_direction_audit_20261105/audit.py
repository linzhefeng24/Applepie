import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'nonlinear_gradient_20261105'));from problem import Problem,BASE
p=Problem(seconds=.6);m=p.m;d=mujoco.MjData(m);mujoco.mj_setState(m,d,p.initial,mujoco.mjtState.mjSTATE_FULLPHYSICS);mujoco.mj_forward(m,d);old=R.parent/'position_direction_20261105';z={k:v for k,v in np.load(old/'hybrid/rollout_5000Hz.npz').items()};source={k:p.src[k] for k in ['ctrl','qpos']};r=p.rootq;q=z['qpos'];quat=q[:,r+3:r+7];up=1-2*(quat[:,1]**2+quat[:,2]**2);zf=p.initial[1+r+2]-.03;history=json.loads((old/'hybrid/history.json').read_text());off=1+m.nq+m.nv;checks=[];dtest=[mujoco.MjData(m) for _ in range(4)]
for k in range(6000):
 if k in [0,200,1000,2000,4000,5800]:
  init=np.empty(len(p.initial));mujoco.mj_getState(m,d,init,mujoco.mjtState.mjSTATE_FULLPHYSICS);warm=d.qacc_warmstart.copy();n=200;t=float(d.time);times=[];tt=t
  for j in range(n):times.append(tt);tt+=m.opt.timestep
  f0=np.rint((t+np.arange(n)*m.opt.timestep)/.0002).astype(int);f1=np.rint(np.asarray(times)/.0002).astype(int);controls=np.zeros((2,n,m.nu));u=z['excitation'][k//2]
  for i,j in p.retained:controls[0,:,j]=source['ctrl'][f0,i];controls[1,:,j]=source['ctrl'][f1,i]
  controls[:,:,p.ids]=u;states,_=rollout.rollout(m,dtest,init[None],controls,initial_warmstart=warm[None],persistent_pool=True);actual=z['full_state'][(k+n)//2-1]
  checks.append(dict(time_s=t,old_prediction_q_max_error=float(np.max(abs(states[0,-1,1:1+m.nq]-actual[1:1+m.nq]))),consistent_index_prediction_q_max_error=float(np.max(abs(states[1,-1,1:1+m.nq]-actual[1:1+m.nq]))),retained_control_difference_max=float(np.max(abs(controls[0]-controls[1])))))
 fi=min(round(d.time/.0002),len(source['ctrl'])-1)
 for i,j in p.retained:d.ctrl[j]=source['ctrl'][fi,i]
 d.ctrl[p.ids]=z['excitation'][k//2];mujoco.mj_step(m,d)
fr=np.minimum(np.rint(z['time_s']/.0002).astype(int),len(source['qpos'])-1);qe=q[:,p.qadrs]-source['qpos'][fr][:,p.qadrs];rmse=np.sqrt(np.mean(qe*qe,axis=0))*180/np.pi
rep=dict(old_height_penalty_threshold_mm=float(zf*10),old_min_root_height_mm=float(q[:,r+2].min()*10),height_penalty_nonzero_fraction=float(np.mean(q[:,r+2]<zf)),old_min_up_z=float(up.min()),tilt_penalty_nonzero_fraction=float(np.mean(up<.8660254)),gradient_directions_used=6,optimization_variables=130,mean_relative_predicted_improvement=float(np.mean([1-h['chosen_loss']/h['initial_loss'] for h in history])),accepted_qcost_increase_count=sum(h['chosen_qcost']>h['initial_qcost'] for h in history),old_velocity_raw_squared_error_coefficient=.001/100**2,checks=checks,worst_joints=[dict(name=str(p.src['joint_names'][i]),RMSE_deg=float(rmse[i])) for i in np.argsort(-rmse)[:10]],interpretation=['Loss nonincrease relative to a candidate parent at one forecast state does not enforce time-to-time tracking-error contraction.','Averaging errors over all leg coordinates permits tradeoffs and includes passive/coupled coordinates.','Sparse random-direction descent does not establish a descent direction for every muscle.','Root pose guard had a dead zone and did not request recovery toward reference height/orientation.'])
(R/'audit.json').write_text(json.dumps(rep,indent=2));print(json.dumps(rep,indent=2))
