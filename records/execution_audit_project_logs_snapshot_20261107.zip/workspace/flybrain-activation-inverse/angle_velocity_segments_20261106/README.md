# Angle and angular velocity endpoint tracking, all ten intervals

All ten sequential intervals last 20 ms. Only current-interval muscle commands change. The full actual state, including muscle activation, passes continuously to the next interval. No height penalty, state resets, extra forces, initial-state changes or muscle-parameter changes.

Objective: mean((q-q_ref)^2) + (0.02 s)^2 * mean((qvel-qvel_ref)^2). The two residuals are separately squared; the scale converts velocity error to an angular scale over one interval. This is a weighted compromise, not a guarantee both metrics independently decrease.

The same bounded nonlinear search structure is retained: cyclic per-joint paired corrections accept collateral error, bounded joint polishing and nonlocal trials explore further, and the lowest combined-cost physically simulated candidate is executed. Each muscle has one uniform offset within the current selected seed interval. Finite local search does not establish global optimality.

| End time (s) | Previous angle RMSE (deg) | Current angle RMSE (deg) | Previous velocity RMSE (rad/s) | Current velocity RMSE (rad/s) |
|---|---:|---:|---:|---:|
| 0.02 | 5.350 | 5.876 | 8.144 | 6.908 |
| 0.04 | 5.706 | 7.216 | 8.715 | 6.578 |
| 0.06 | 10.057 | 9.677 | 12.523 | 11.240 |
| 0.08 | 12.668 | 14.368 | 12.417 | 8.035 |
| 0.10 | 11.052 | 12.081 | 13.572 | 9.273 |
| 0.12 | 11.416 | 11.295 | 10.297 | 9.159 |
| 0.14 | 11.312 | 16.323 | 9.741 | 7.936 |
| 0.16 | 10.184 | 18.277 | 13.730 | 12.179 |
| 0.18 | 9.960 | 14.186 | 11.132 | 9.309 |
| 0.20 | 10.830 | 16.242 | 14.499 | 12.446 |

The complete physical trial is 0.2 seconds. Three-panel video: reference simulation, previous angle-only result, current angle + velocity result. Saved actual states are rendered at 0.05x playback speed. Cameras follow each body independently. This short trial does not establish sustained normal walking.
