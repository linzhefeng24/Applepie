import os
os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/tmp/qv-review-mesa',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,numpy as np,mujoco,imageio
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;root=R.parent.parent;m=mujoco.MjModel.from_xml_path(str(root/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));d=mujoco.MjData(m)
new=dict(np.load(R.parent/'rollout_5000Hz.npz'));old=dict(np.load(root/'all_segments_refined_20261106/rollout_5000Hz.npz'));src=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');refq=src['qpos'];refv=src['qvel'];reft=src['time_s'];qadrs=src['joint_qpos_indices'];dofs=src['joint_dof_indices'];renderer=mujoco.Renderer(m,height=360,width=480);opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');measurements=[];fps=15;frames=60
with imageio.get_writer(R/'angle_velocity_vs_angle_only_vs_reference_005x.mp4',fps=fps,codec='libx264',quality=8,macro_block_size=2) as writer:
 for frame in range(frames):
  t=frame/(frames-1)*.2;ri=int(np.argmin(abs(reft-t)));panels=[]
  for label,z in [('Reference simulation',None),('Previous: angle-only endpoints',old),('Current: angle + velocity endpoints',new)]:
   if z is None:d.qpos[:]=refq[ri];d.qvel[:]=refv[ri]
   elif frame==0:d.qpos[:]=z['initial_state'][1:1+m.nq];d.qvel[:]=z['initial_state'][1+m.nq:1+m.nq+m.nv]
   else:
    k=int(np.argmin(abs(z['time_s']-t)));d.qpos[:]=z['qpos'][k];d.qvel[:]=z['qvel'][k]
   d.time=t;mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=opt);im=Image.fromarray(renderer.render());dr=ImageDraw.Draw(im);dr.rectangle((0,0,480,48),fill='black');dr.text((7,5),label,fill='white');dr.text((7,23),f't={t:.3f} s | 0.05x | complete 0.2 s trial',fill='white');panels.append(np.asarray(im));measurements.append(dict(time_s=t,panel=label,thorax_xyz_mm=(d.xpos[thorax]*10).tolist(),up_z=float(d.xmat[thorax].reshape(3,3)[2,2]),angle_rmse_deg=float(np.sqrt(np.mean((d.qpos[qadrs]-refq[ri,qadrs])**2))*180/np.pi),velocity_rmse_rad_s=float(np.sqrt(np.mean((d.qvel[dofs]-refv[ri,dofs])**2)))))
  combined=np.concatenate(panels,axis=1);writer.append_data(combined)
  if frame in [0,30,59]:Image.fromarray(combined).save(R/f'frame_{frame:03d}.png')
  if frame%15==0:print('rendered',frame,'/',frames,flush=True)
renderer.close();(R/'render_measurements.json').write_text(json.dumps(measurements,indent=2));(R/'README.txt').write_text('Left: simulated reference. Middle: previous angle-only sequential result. Right: new angle + angular velocity sequential result.\nThe complete physical trial is 0.2 seconds; playback is four seconds at 0.05x speed.\nSaved actual simulation states are rendered, with no pose correction. All three panels start at their exact initial state. Camera follows each body independently, so this view compares posture and leg motion rather than world displacement.\nThe video does not establish sustained walking.\n');print('Finished',flush=True)
