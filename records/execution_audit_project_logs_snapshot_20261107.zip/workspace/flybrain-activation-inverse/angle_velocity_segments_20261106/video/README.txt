Left: simulated reference. Middle: previous angle-only sequential result. Right: new angle + angular velocity sequential result.
The complete physical trial is 0.2 seconds; playback is four seconds at 0.05x speed.
Saved actual simulation states are rendered, with no pose correction. All three panels start at their exact initial state. Camera follows each body independently, so this view compares posture and leg motion rather than world displacement.
The video does not establish sustained walking.
