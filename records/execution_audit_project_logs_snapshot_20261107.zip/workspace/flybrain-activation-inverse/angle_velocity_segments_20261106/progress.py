from pathlib import Path
import json
r=Path(__file__).resolve().parent;p=r/'segment_history.json'
if p.exists():
 try:print('COMPLETED',[(x['segment'],round(x['endpoint_rmse_deg'],3),round(x['endpoint_velocity_rmse_rad_s'],3),round(x['max_endpoint_error_deg'],3),x['rollouts']) for x in json.loads(p.read_text())])
 except json.JSONDecodeError:pass
for line in (r/'run.log').read_text().splitlines()[-2:]:
 try:
  x=json.loads(line);print({k:v for k,v in x.items() if k not in ['changed_muscles','worst_joints']})
 except json.JSONDecodeError:print(line[:400])
