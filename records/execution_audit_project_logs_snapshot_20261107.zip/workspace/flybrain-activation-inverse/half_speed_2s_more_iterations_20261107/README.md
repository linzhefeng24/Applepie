# More optimization, first 100 segments / 2 seconds

User stopped the longer job and requested the completed first 100 segments only. Reference is original time 0..1 s played at speed 0.5 over 2 physical seconds. Each segment lasts 20 ms. Saved controls contain exactly 20,000 native 0.1 ms steps; physical states and muscle activation contain 10,000 samples at 5 kHz.

The original composite tracking/pose objective is retained (evaluation function AST identical). More search uses 12..32 rounds, periodic native full input Jacobians, targeted worst-joint trials and multiscale random candidates. Actual mean rounds: 20.46; histogram: {'16': 17, '14': 21, '22': 8, '23': 10, '32': 9, '15': 17, '30': 13, '31': 3, '24': 2}. Same model, strength, activation dynamics and initial full state. No height/velocity penalty, rescue forces or pose correction. The rejected angle-priority partial trial is not used here.

| Metric | Previous matching 2 s | More rounds 2 s |
|---|---:|---:|
| Path angle RMS (deg) | 27.6480 | 20.8432 |
| Terminal angle RMS (deg) | 34.0314 | 25.6296 |
| Maximum terminal absolute error (deg) | 115.4845 | 115.0201 |
| World root X displacement (mm) | 0.8583 | 3.2065 |

Independent replay maximum full-state error: 0.0. Muscle activation and excitation stay in [0,1]. Original source time mapping and retained controls are checked. Large joint errors remain; normal walking is not established. No old controller or model selection is replaced.

Video: https://github.com/linzhefeng24/Applepie/blob/main/videos/muscle_more_rounds_100segments_2s_20261107.mp4

Download: https://raw.githubusercontent.com/linzhefeng24/Applepie/main/videos/muscle_more_rounds_100segments_2s_20261107.mp4

Three panels: reference / previous <=8-round result / new 12..32-round result. Exact 2 s, 100 frames at 50 fps, frames sample physical t=0,0.02,...,1.98 s. Cameras follow each body separately; world root X progress is overlaid.
