from pathlib import Path
import json,hashlib,copy,os
R=Path(__file__).resolve().parent;C=Path('/workspace/flybrain-muscle-rebuild/brain.json');M=Path('/workspace/flybrain-recovered/brain.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads(C.read_text());assert b==json.loads(M.read_text());before=copy.deepcopy(b)
backup=R/'brain_before_angle_audit.json'
if not backup.exists():backup.write_bytes(C.read_bytes())
validation=json.loads((R/'validation.json').read_text());assert all(v['passed'] for v in validation.values());summary=json.loads((R/'summary.json').read_text());audit_path=R.parent/'position_direction_audit_20261105'
run=dict(id='six_leg_angle_only_tracking_audit_20261105',date='2026-11-05',role='audit of earlier joint-angle search; angle-only full-coordinate endpoint optimization and prediction/execution consistency tests',previous_experiment_id='six_leg_position_direction_search_20261105',prior_controller_audit=json.loads((audit_path/'audit.json').read_text()),timing_audit_details=json.loads((audit_path/'timing_audit_details.json').read_text()),results=summary,validation=validation,large_error_joint_mechanics=json.loads((R/'large_error_joint_mechanics.json').read_text()),early_error_timeline=json.loads((R/'early_error_timeline.json').read_text()),user_objective_policy={'height_penalty':0,'orientation_penalty':0,'velocity_penalty':0,'primary_objective':'joint-angle error only'},method_document={'format':'markdown','text':(R/'README.md').read_text()},muscle_model_and_parameters_changed=False,walking_validated=False,artifacts=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in ['brain_before_angle_audit.json','brain_integration.json'] and p.suffix in ['.json','.py','.npz','.png','.md']])
runs=b['muscle_activation_inference_experiments']['runs'];runs[:]=[x for x in runs if x['id']!=run['id']]
for old in runs:
 if old['id']=='six_leg_position_direction_search_20261105':old['subsequent_audit']={'experiment_id':run['id'],'saved_physical_rollout_remains_valid':True,'forecast_execution_time_index_mismatch_found':True,'first_20ms_max_leg_prediction_error_deg':run['timing_audit_details']['first_20ms_max_leg_joint_error_deg'],'do_not_infer_global_muscle_infeasibility_from_this_trial':True,'prior_replay_validation_did_not_test_forecast_execution_consistency':True,'parent_candidate_improvement_does_not_guarantee_timewise_error_contraction':True}
runs.append(run)
n=b['neuromusculoskeletal_model'];n['current_readiness']['latest_angle_only_tracking_audit_experiment_id']=run['id'];n['current_muscle_model_overview']['current_tracking_objective_policy']={'source':'explicit user instruction 2026-11-05','height_penalty':0,'orientation_penalty':0,'primary_objective':'joint-angle tracking','latest_experiment_id':run['id'],'implementation':str(R/'run.py'),'note':'Earlier body-height/attitude objectives remain historical experimental records, not the current requested objective.'}
n['current_readiness']['local_tarsus_bidirectional_control_loss_observed']=True
n['current_muscle_model_overview']['local_mechanical_control_limit_audit']={'experiment_id':run['id'],'joints':['walker/tarsus_T2_right','walker/tarsus_T2_left'],'finding':'Active torque is bidirectional near reference pose but one-sided at some deviated poses; isolated-angle sweeps were performed with other joints fixed.','geometry_modified':False,'not_global_unreachability_proof':True}
b['version']='3.4.7-angle-only-tracking-audit';b['date']='2026-11-05'
for k,v in before.items():
 if k not in ['version','date','neuromusculoskeletal_model','muscle_activation_inference_experiments']:assert b[k]==v,k
blob=(json.dumps(b,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
for p in [C,M]:tmp=p.with_name(p.name+'.angle.tmp');tmp.write_bytes(blob);os.replace(tmp,p)
assert C.read_bytes()==M.read_bytes();report=dict(passed=True,version=b['version'],mirrors_identical=True,biological_evidence_preserved=True,prior_rollouts_preserved=True,height_penalty=0,brain_sha256=sha(C));(R/'brain_integration.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
