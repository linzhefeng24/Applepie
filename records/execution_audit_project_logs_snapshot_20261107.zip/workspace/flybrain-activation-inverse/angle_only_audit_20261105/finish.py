import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/mpl-angle-audit')
from pathlib import Path
import sys,json,numpy as np,mujoco
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'nonlinear_gradient_20261105'));from problem import Problem
p=Problem(seconds=.6);m=p.m;sourceq=p.src['qpos'];names=p.src['joint_names'];sourcectrl=p.src['ctrl'];old={k:v for k,v in np.load(R.parent/'position_direction_20261105/hybrid/rollout_5000Hz.npz').items()};summary={};valid={};fig,axs=plt.subplots(2,1,figsize=(9,7),constrained_layout=True)
# Directly verify that reference joint arrays address the same named model joints.
for name,qa,va in zip(names,p.qadrs,p.dofs):
 j=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,str(name));assert j>=0 and m.jnt_qposadr[j]==qa and m.jnt_dofadr[j]==va
for mode in ['fixed','moving','moving_start']:
 z={k:v for k,v in np.load(R/mode/'rollout_5000Hz.npz').items()};rep=json.loads((R/mode/'report.json').read_text());hist=json.loads((R/mode/'history.json').read_text());d=mujoco.MjData(m);mujoco.mj_setState(m,d,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS);oi=int(np.argmin(abs(old['time_s']-z['initial_state'][0])));d.ctrl[:]=old['all_control'][oi];mujoco.mj_forward(m,d);maxerr=0.
 for step in range(2*len(z['time_s'])):
  fi=min(round(d.time/.0002),len(sourcectrl)-1)
  for a,b in p.retained:d.ctrl[b]=sourcectrl[fi,a]
  d.ctrl[p.ids]=z['excitation'][step//2];mujoco.mj_step(m,d)
  if step%2==1:
   state=np.empty(len(p.initial));mujoco.mj_getState(m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);maxerr=max(maxerr,float(np.max(abs(state-z['full_state'][step//2]))))
 assert maxerr<1e-9;assert rep['height_penalty']==rep['orientation_penalty']==rep['velocity_penalty']==0
 assert rep['activation_all_physics_steps_min']>=0 and rep['activation_all_physics_steps_max']<=1
 valid[mode]=dict(passed=True,full_state_replay_max_abs_error=maxerr,max_online_prediction_joint_error_rad=rep['max_prediction_execution_joint_error_rad'],height_penalty=0,orientation_penalty=0,reference_joint_indices_match=True)
 end=z['qerror_rad'][-1];init=z['initial_state'][1:1+m.nq][p.qadrs]-z['target_joint_angle'][0];u=z['excitation'][-1];a=z['activation'][-1]
 rep.update(mean_excitation_at_bounds_fraction=float(np.mean([h['excitation_at_bounds_fraction'] for h in hist])),final_excitation_at_zero_fraction=float(np.mean(u<.001)),final_excitation_at_one_fraction=float(np.mean(u>.999)),final_activation_at_one_fraction=float(np.mean(a>.999)),worst_final_joints=[dict(joint=str(names[i]),final_error_deg=float(end[i]*180/np.pi)) for i in np.argsort(-abs(end))[:10]],interpretation='Bounded local endpoint optimization and one update per control interval do not prove global reachability or an optimal full trajectory.')
 summary[mode]=rep;axs[0].plot(z['time_s']-z['initial_state'][0],np.sqrt(np.mean(z['qerror_rad']**2,axis=1))*180/np.pi,label=mode)
 axs[1].plot([h['time_s']-z['initial_state'][0] for h in hist],[h['next_rmse_deg'] for h in hist],marker='o',label=mode)
mask=(old['time_s']>.2-1e-8)&(old['time_s']<=.4+1e-8);e=old['qerror_rad'][mask];summary['previous_moving_same_window']=dict(initial_time_s=.2,end_time_s=.4,initial_rmse_deg=float(np.sqrt(np.mean(e[0]**2))*180/np.pi),final_rmse_deg=float(np.sqrt(np.mean(e[-1]**2))*180/np.pi),trajectory_rmse_deg=float(np.sqrt(np.mean(e**2))*180/np.pi));axs[0].plot(old['time_s'][mask]-.2,np.sqrt(np.mean(e**2,axis=1))*180/np.pi,label='Previous moving controller',ls='--')
for ax in axs:ax.set(xlabel='Elapsed time from same initial state (s)',ylabel='Joint RMSE (deg)');ax.grid(alpha=.3);ax.legend()
fig.savefig(R/'comparison.png',dpi=150);plt.close(fig);mask0=old['time_s']<=.20000001;e0=old['qerror_rad'][mask0];summary['previous_moving_from_start']=dict(duration_s=.2,final_rmse_deg=float(np.sqrt(np.mean(e0[-1]**2))*180/np.pi),trajectory_rmse_deg=float(np.sqrt(np.mean(e0**2))*180/np.pi));(R/'summary.json').write_text(json.dumps(summary,indent=2));(R/'validation.json').write_text(json.dumps(valid,indent=2));print(json.dumps({'summary':summary,'validation':valid},indent=2))
