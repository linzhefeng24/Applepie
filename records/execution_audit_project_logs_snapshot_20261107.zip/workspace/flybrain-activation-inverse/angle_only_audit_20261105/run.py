import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,argparse
import numpy as np,mujoco
from mujoco import rollout
from scipy.optimize import lsq_linear
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT.parent/'nonlinear_gradient_20261105'));from problem import Problem
ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['fixed','moving'],required=True);ap.add_argument('--seconds',type=float,default=.2);ap.add_argument('--start',type=float,default=.2);args=ap.parse_args();R=ROOT/(args.mode+'_start' if args.start==0 else args.mode);R.mkdir(exist_ok=True)
p=Problem(seconds=.6);m=p.m;src={k:p.src[k] for k in ['qpos','qvel','ctrl','joint_names','time_s']};old={k:v for k,v in np.load(ROOT.parent/'position_direction_20261105/hybrid/rollout_5000Hz.npz').items()};oi=int(np.argmin(abs(old['time_s']-args.start)));d=mujoco.MjData(m);mujoco.mj_setState(m,d,p.initial if args.start==0 else old['full_state'][oi],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.ctrl[:]=old['all_control'][oi];mujoco.mj_forward(m,d);init=np.empty(len(p.initial));mujoco.mj_getState(m,d,init,mujoco.mjtState.mjSTATE_FULLPHYSICS);start_time=d.time;fixed=src['qpos'][round(start_time/.0002),p.qadrs].copy();last=old['excitation'][oi].copy();data=[mujoco.MjData(m) for _ in range(4)];nc=200;dt=m.opt.timestep;states_out=[];ctrl_out=[];hist=[];warm=d.qacc_warmstart.copy();clock=time.monotonic();amin=1.;amax=0.
def target(t):return fixed if args.mode=='fixed' else src['qpos'][min(round(t/.0002),len(src['time_s'])-1),p.qadrs]
def forecast(U,initial,other):
 U=np.atleast_2d(U);ctrl=np.broadcast_to(other,(len(U),*other.shape)).copy();ctrl[:,:,p.ids]=U[:,None,:];state,_=rollout.rollout(m,data,initial[None],ctrl,initial_warmstart=warm[None],persistent_pool=True);q=state[:,-1,1:1+m.nq][:,p.qadrs];valid=np.isfinite(state).all(axis=(1,2))&np.isclose(state[:,-1,0],initial[0]+nc*dt,atol=1e-8);return q,np.where(valid,0.,1e6)
for it in range(round(args.seconds/(nc*dt))):
 initial=np.empty(len(p.initial));mujoco.mj_getState(m,d,initial,mujoco.mjtState.mjSTATE_FULLPHYSICS);warm=d.qacc_warmstart.copy();future=d.time;other=np.zeros((nc,m.nu))
 for j in range(nc):
  fi=min(round(future/.0002),len(src['time_s'])-1)
  for a,b in p.retained:other[j,b]=src['ctrl'][fi,a]
  future+=dt
 tgt=target(future);current=np.mean((d.qpos[p.qadrs]-target(d.time))**2);u=last.copy();q0,bad=forecast(u,initial,other);q0=q0[0];parent=float(np.mean((q0-tgt)**2));eps=.02;dh=np.where(u<=.5,eps,-eps);probes=np.broadcast_to(u,(130,130)).copy();probes[np.arange(130),np.arange(130)]+=dh;qp,_=forecast(probes,initial,other);J=((qp-q0)/dh[:,None]).T
 ridge=max(np.linalg.norm(J,'fro')/np.sqrt(130)*.01,1e-7);A=np.vstack([J,ridge*np.eye(130)]);b=np.r_[tgt-q0,np.zeros(130)];fit=lsq_linear(A,b,bounds=(-u,1-u),method='bvls',tol=1e-8,max_iter=300);du=fit.x
 candidates=np.clip(u[None]+np.array([1.,.5,.25,.125])[:,None]*du,0,1);qe,invalid=forecast(candidates,initial,other);cost=np.mean((qe-tgt)**2,axis=1)+invalid;best=int(np.argmin(cost));chosen=u if cost[best]>=parent else candidates[best];prediction=q0 if cost[best]>=parent else qe[best];chosen_loss=min(parent,float(cost[best]));linear_error=float(np.mean((q0+J@du-tgt)**2));sing=np.linalg.svd(J,compute_uv=False)
 for j in range(nc):
  d.ctrl[:]=other[j];d.ctrl[p.ids]=chosen;mujoco.mj_step(m,d);amin=min(amin,float(d.act[p.adrs].min()));amax=max(amax,float(d.act[p.adrs].max()))
  if j%2==1:
   state=np.empty(len(p.initial));mujoco.mj_getState(m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);states_out.append(state);ctrl_out.append(d.ctrl.copy())
 actual=float(np.mean((d.qpos[p.qadrs]-target(d.time))**2));match=float(np.max(abs(d.qpos[p.qadrs]-prediction)));assert match<1e-9,match
 row=dict(time_s=float(d.time),current_rmse_deg=float(np.sqrt(current)*180/np.pi),next_rmse_deg=float(np.sqrt(actual)*180/np.pi),parent_predicted_rmse_deg=float(np.sqrt(parent)*180/np.pi),chosen_predicted_rmse_deg=float(np.sqrt(chosen_loss)*180/np.pi),actual_error_contracted=bool(actual<current),prediction_execution_joint_max_error_rad=match,linearized_best_rmse_deg=float(np.sqrt(linear_error)*180/np.pi),Jacobian_rank=int(np.sum(sing>max(sing[0]*1e-6,1e-10))),least_squares_success=bool(fit.success),excitation_at_bounds_fraction=float(np.mean((chosen<.001)|(chosen>.999))),wall_s=time.monotonic()-clock)
 hist.append(row);last=chosen.copy();print(json.dumps(row),flush=True);(R/'history.json').write_text(json.dumps(hist,indent=2))
 # Checkpoint preserves completed steps while expensive finite differences continue.
 np.savez_compressed(R/'checkpoint.npz',full_state=np.asarray(states_out),all_control=np.asarray(ctrl_out),initial_state=init,fixed_target=fixed)
s=np.asarray(states_out);ctrl=np.asarray(ctrl_out);q=s[:,1:1+m.nq];a=s[:,1+m.nq+m.nv:][:,p.adrs];targets=np.array([target(t) for t in s[:,0]]);errors=q[:,p.qadrs]-targets
np.savez_compressed(R/'rollout_5000Hz.npz',time_s=s[:,0],qpos=q,qvel=s[:,1+m.nq:1+m.nq+m.nv],activation=a,excitation=ctrl[:,p.ids],full_state=s,all_control=ctrl,initial_state=init,target_joint_angle=targets,qerror_rad=errors,muscle_ids=np.array([r['id'] for r in p.rows]),joint_names=src['joint_names'])
assert not np.any(d.qfrc_applied) and not np.any(d.xfrc_applied) and 0<=amin<=amax<=1
report=dict(mode=args.mode,method='angle-only native endpoint residual Jacobian, bounded Gauss-Newton least squares and nonlinear line search',height_penalty=0,orientation_penalty=0,velocity_penalty=0,initial_time_s=float(init[0]),duration_s=args.seconds,initial_rmse_deg=hist[0]['current_rmse_deg'],final_rmse_deg=hist[-1]['next_rmse_deg'],trajectory_rmse_deg=float(np.sqrt(np.mean(errors**2))*180/np.pi),error_contracting_updates=sum(h['actual_error_contracted'] for h in hist),updates=len(hist),activation_all_physics_steps_min=amin,activation_all_physics_steps_max=amax,max_prediction_execution_joint_error_rad=max(h['prediction_execution_joint_max_error_rad'] for h in hist),muscle_model_parameters_changed=False,extra_forces=False,intermediate_state_resets=False,wall_s=time.monotonic()-clock,walking_validated=False)
(R/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
