import os
os.environ.update(MUJOCO_GL='egl',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',LP_NUM_THREADS='2',MESA_SHADER_CACHE_DIR='/tmp/closed-cycle-mesa')
from pathlib import Path
import numpy as np,mujoco,imageio,json
from scipy.interpolate import CubicHermiteSpline
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;z=np.load(R/'closed_joint_reference_cycle.npz');raw=np.load(R/'representative_reference_cycle.npz');src=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');qa=src['joint_qpos_indices'];t=z['time_s'];T=float(t[-1]);q=z['joint_angles_rad'];v=z['joint_velocities_rad_s'];spline=CubicHermiteSpline(t,q,v)
m=mujoco.MjModel.from_xml_path('/workspace/flybrain-activation-inverse/hindleg_correction_20261106/candidate_muscles.xml');d=mujoco.MjData(m);d.qpos[:]=raw['qpos'][0];base=d.qpos.copy();d.qvel[:]=0
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0
renderer=mujoco.Renderer(m,height=640,width=960)
def frame(phase):
 d.qpos[:]=base;d.qpos[qa]=spline(phase);d.qvel[:]=0;mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=opt);renderer.scene.flags[mujoco.mjtRndFlag.mjRND_REFLECTION]=False;renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW]=False
 im=Image.fromarray(renderer.render());draw=ImageDraw.Draw(im);draw.rectangle((0,0,960,52),fill='black');draw.text((15,10),'Closed reference gait | 10x slow motion | kinematic playback',fill='white');draw.text((15,30),'One cycle: 0.126 s physical / 1.26 s display | body stabilized',fill='white');return np.asarray(im)
a=frame(0);b=frame(T);assert np.max(abs(a.astype(int)-b.astype(int)))==0
frames=[frame(k*T/63) for k in range(63)];renderer.close()
with imageio.get_writer(R/'closed_reference_cycle_loop.mp4',fps=50,codec='libx264',quality=9,macro_block_size=2) as writer:
 for _ in range(4):
  for im in frames:writer.append_data(im)
# Shared palette avoids independent-frame palette changes at the GIF seam.
palette=Image.fromarray(frames[0]).resize((720,480)).quantize(colors=128)
gifs=[Image.fromarray(f).resize((720,480)).quantize(palette=palette,dither=Image.Dither.NONE) for f in frames]
gifs[0].save(R/'closed_reference_cycle_loop.gif',save_all=True,append_images=gifs[1:],duration=20,loop=0,optimize=False,disposal=2)
Image.fromarray(frames[0]).save(R/'closed_reference_cycle_preview.png')
report=dict(physical_period_s=T,display_period_s=1.26,slowdown_from_half_speed_reference=10,frames_per_cycle=63,fps=50,mp4_cycles=4,mp4_duration_s=5.04,gif_loops_forever=True,rendered_start_end_pixel_max_difference=int(np.max(abs(a.astype(int)-b.astype(int)))),joint_angle_seam_max_rad=float(abs(spline(0)-spline(T)).max()),joint_velocity_seam_max_rad_s=float(abs(spline(0,1)-spline(T,1)).max()),end_frame_not_duplicated=True,body_and_nonleg_coordinates='Fixed at initial pose to stabilize framing and guarantee full visual closure; six-leg motion uses corrected reference',physical_validation='Kinematic playback only. No muscle-driven dynamics or contact feasibility claim.')
(R/'loop_video_manifest.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
