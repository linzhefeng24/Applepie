import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLBACKEND='Agg',MPLCONFIGDIR='/tmp/reference-gait-period-mpl')
from pathlib import Path
import json,numpy as np,matplotlib.pyplot as plt
from scipy.signal import find_peaks,periodogram
from scipy.ndimage import median_filter
R=Path(__file__).resolve().parent;src=dict(np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz'));sup=dict(np.load('/workspace/fly-walking-run/output/walking_angles_torques.npz'));t=src['time_s'];q=src['leg_angle_rad'];v=src['leg_velocity_rad_s'];names=src['joint_names'];labels=['LF','RF','LM','RM','LH','RH'];suffixes=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];indices=[int(np.flatnonzero(names=='walker/femur_'+s)[0]) for s in suffixes];contact=sup['foot_support_filtered'].astype(bool);clean=contact.copy()
# Join brief OFF gaps and remove brief ON islands, retaining original onset times of sustained bouts.
def bouts(x):
 edge=np.diff(np.r_[False,x,False].astype(int));return list(zip(np.flatnonzero(edge==1),np.flatnonzero(edge==-1)))
for leg in range(6):
 b=bouts(clean[:,leg]);joined=[]
 for start,end in b:
  if joined and (start-joined[-1][1])*.0002<.008:joined[-1]=(joined[-1][0],end)
  else:joined.append((start,end))
 clean[:,leg]=False
 for start,end in joined:
  if (end-start)*.0002>=.008:clean[start:end,leg]=True
allpeaks={}
for label,ix in zip(labels,indices):
 y=median_filter(q[:,ix],size=5);peaks,_=find_peaks(y,distance=180,prominence=.15*np.ptp(y[(t>=.2)&(t<2)]));allpeaks[label]=peaks
windows=[('video_first_2s_original_0to1_steady',.2,1),('reference_first_4s_original_0to2_steady',.2,2),('source_steady_1to2',1,2),('source_steady_2to4',2,4),('source_steady_4to6',4,6)];summary={}
for label,lo,hi in windows:
 mask=(t>=lo)&(t<hi);perleg={}
 for leg,ix in zip(labels,indices):
  peak=allpeaks[leg];peak=peak[(t[peak]>=lo)&(t[peak]<hi)];interval=np.diff(t[peak]);f,p=periodogram(q[mask,ix],fs=5000);valid=(f>=5)&(f<=30);dom=float(f[np.flatnonzero(valid)[np.argmax(p[valid])]])
  perleg[leg]=dict(source_peak_times_s=t[peak].tolist(),source_intervals_s=interval.tolist(),source_median_period_s=float(np.median(interval)),half_speed_median_period_s=float(2*np.median(interval)),half_speed_period_p10_p90_s=(2*np.quantile(interval,[.1,.9])).tolist(),source_spectral_frequency_Hz=dom)
 # Multijoint autocorrelation, exclude tiny-amplitude coordinates and find first full-stride peak.
 X=q[mask];std=X.std(axis=0);use=std>3*np.pi/180;X=(X[:,use]-X[:,use].mean(axis=0))/std[use];lags=np.arange(200,451);ac=[]
 for lag in lags:
  A=X[:-lag];B=X[lag:];ac.append(float(np.sum(A*B)/np.sqrt(np.sum(A*A)*np.sum(B*B))))
 ac=np.array(ac);best=int(np.argmax(ac));events={}
 for j,leg in enumerate(labels):
  onset=np.flatnonzero(np.diff(clean[:,j].astype(int),prepend=0)==1);onset=onset[(t[onset]>=lo)&(t[onset]<hi)];interval=np.diff(t[onset]);valid_intervals=interval[(interval>.04)&(interval<.10)];events[leg]=dict(source_onset_times_s=t[onset].tolist(),source_median_stride_s=(float(np.median(valid_intervals)) if len(valid_intervals) else None),half_speed_median_stride_s=(float(2*np.median(valid_intervals)) if len(valid_intervals) else None),interval_count=len(interval),interval_count_in_40to100ms=len(valid_intervals))
 summary[label]=dict(source_window_s=[lo,hi],per_leg=perleg,multijoint_autocorrelation_source_period_s=float(lags[best]*.0002),multijoint_autocorrelation_half_speed_period_s=float(lags[best]*.0004),multijoint_autocorrelation_at_period=float(ac[best]),autocorrelation_source_lags_s=(lags*.0002).tolist(),autocorrelation=ac.tolist(),joints_used=int(use.sum()),contact_crosscheck=events)
# Candidate cycles inside the actual selected video (source 0..1 s), using LF peaks with a common phase offset.
peaks=allpeaks['LF'];peaks=peaks[(t[peaks]>=.2)&(t[peaks]<1)];candidates=[];omega=2*np.pi/.065
for a,b in zip(peaks,peaks[1:]):
 for shift in range(0,51):
  i=a+shift;j=b+shift
  if t[j]>1:continue
  dq=q[j]-q[i];dv=v[j]-v[i];mismatch=int(np.count_nonzero(clean[j]!=clean[i]));score=float(np.mean(dq*dq+(dv/omega)**2));candidates.append(dict(source_start_s=float(t[i]),source_end_s=float(t[j]),half_speed_start_s=float(2*t[i]),half_speed_end_s=float(2*t[j]),half_speed_duration_s=float(2*(t[j]-t[i])),joint_endpoint_rmse_deg=float(np.sqrt(np.mean(dq*dq))*180/np.pi),joint_velocity_endpoint_rmse_rad_s=float(np.sqrt(np.mean(dv*dv))),contact_mismatch_count=mismatch,score=score,start_index=int(i),end_index=int(j),source_root_displacement_mm=((src['qpos'][j,:3]-src['qpos'][i,:3])*10).tolist()))
feasible=[c for c in candidates if c['contact_mismatch_count']==0];best=min(feasible or candidates,key=lambda c:c['score']);i=best['start_index'];j=best['end_index'];np.savez_compressed(R/'representative_reference_cycle.npz',time_s=2*(t[i:j+1]-t[i]),original_time_s=t[i:j+1],reference_video_time_s=2*t[i:j+1],qpos=src['qpos'][i:j+1],qvel=.5*src['qvel'][i:j+1],joint_angles_rad=q[i:j+1],joint_velocities_rad_s=.5*v[i:j+1],joint_names=names,reference_support_phase=clean[i:j+1],speed_factor=.5)
# Circular touchdown phase relative to LF onset; do not infer tripod phase from joint extrema across different legs.
events=summary['reference_first_4s_original_0to2_steady']['contact_crosscheck'];lf=np.array(events['LF']['source_onset_times_s']);phase={}
for leg in labels:
 tt=np.array(events[leg]['source_onset_times_s']);ph=[]
 for aa,bb in zip(lf,lf[1:]):
  if not .045<bb-aa<.09:continue
  within=tt[(tt>=aa)&(tt<bb)]
  if len(within)==1:ph.append(float((within[0]-aa)/(bb-aa)))
 angles=2*np.pi*np.array(ph);mean=float((np.angle(np.mean(np.exp(1j*angles)))/(2*np.pi))%1) if ph else None;phase[leg]=dict(circular_mean_stride_phase=mean,resultant_concentration=float(abs(np.mean(np.exp(1j*angles)))) if ph else None,cycles_used=len(ph))
report=dict(reference_source='/workspace/fly-walking-run/output/walking_6s_5000Hz.npz',source_sampling_s=.0002,half_speed_time_equation='video_time = 2 * source_time',current_video_interval_source_s=[0,1],current_video_duration_s=2,windows=summary,representative_cycle=best,touchdown_phase_vs_LF=phase,contact_debounce_s=.008,limitations=['Near-periodic simulated reference, not a strictly closed periodic motion or real animal recording.','Startup and cycle-to-cycle timing vary; one constant period does not make all recorded positions and velocities match at boundaries.','Contact phase is derived from original recorded support and time-scaled; it is not a measurement of new half-speed muscle simulation forces.','The reference has original motor/filter states, not the new muscle activation states; those must be solved separately for a periodic muscle replay.']);(R/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False))
fig,ax=plt.subplots(3,1,figsize=(12,10));mask=t<1
for lab,ix in zip(labels,indices):ax[0].plot(2*t[mask],q[mask,ix]*180/np.pi,label=lab)
ax[0].axvspan(best['half_speed_start_s'],best['half_speed_end_s'],color='black',alpha=.08);ax[0].set_ylabel('Femur angle (deg)');ax[0].set_title('Actual 2 s half-speed reference: six leg cycles');ax[0].legend(ncol=6)
for k in range(6):ax[1].fill_between(2*t[mask],k, k+.8,where=clean[mask,k],step='post')
ax[1].set_yticks(np.arange(6)+.4,labels);ax[1].set_xlabel('half-speed reference time (s)');ax[1].set_title('Debounced reference support bouts (not new muscle contact forces)')
w=summary['reference_first_4s_original_0to2_steady'];ax[2].plot(2*np.array(w['autocorrelation_source_lags_s']),w['autocorrelation']);ax[2].axvline(w['multijoint_autocorrelation_half_speed_period_s'],color='red',ls='--');ax[2].set_xlabel('half-speed lag (s)');ax[2].set_ylabel('Multijoint correlation');ax[2].set_title('First full-stride recurrence')
for a in ax:a.grid(alpha=.25)
fig.tight_layout();fig.savefig(R/'reference_stride_period.png',dpi=170);print(json.dumps(dict(current_video_summary={leg:{k:val for k,val in d.items() if k not in ['source_peak_times_s','source_intervals_s']} for leg,d in summary['video_first_2s_original_0to1_steady']['per_leg'].items()},autocorrelation_half_speed_period_s=w['multijoint_autocorrelation_half_speed_period_s'],autocorrelation=w['multijoint_autocorrelation_at_period'],representative_cycle=best,touchdown_phase=phase),indent=2),flush=True)
