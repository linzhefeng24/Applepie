import os
os.environ.update(OPENBLAS_NUM_THREADS='1',MPLBACKEND='Agg',MPLCONFIGDIR='/tmp/gait-close-mpl')
import numpy as np,json,csv
from pathlib import Path
from scipy.interpolate import BPoly
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
s=np.load(R/'representative_reference_cycle.npz');t=s['time_s'];q=s['joint_angles_rad'];v=s['joint_velocities_rad_s'];names=s['joint_names'];T=t[-1];acc=np.gradient(v,t,axis=0,edge_order=2)
dq=q[-1]-q[0];dv=v[-1]-v[0];da=acc[-1]-acc[0]
# Split adjustment equally between both ends; cubic correction closes q and v.
p=BPoly.from_derivatives([0,T],[[dq/2,dv/2],[-dq/2,-dv/2]])
c=p(t);vc=p.derivative()(t);ac=p.derivative(2)(t);qc=q+c;vv=v+vc;aa=acc+ac
deg=180/np.pi
rows=[]
for j,n in enumerate(names):rows.append(dict(joint=str(n),start_deg=float(q[0,j]*deg),end_deg=float(q[-1,j]*deg),signed_end_minus_start_deg=float(dq[j]*deg),half_speed_velocity_gap_deg_s=float(dv[j]*deg),max_adjustment_deg=float(np.max(abs(c[:,j]))*deg)))
with open(R/'cycle_joint_boundary_errors.csv','w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
perleg={}
for k,label in enumerate(['LF','RF','LM','RM','LH','RH']):
 d=dq[k*11:(k+1)*11]*deg;idx=k*11+int(np.argmax(abs(d)));perleg[label]=dict(rms_deg=float(np.sqrt(np.mean(d*d))),max_abs_deg=float(max(abs(d))),worst_joint=str(names[idx]))
report=dict(duration_s=float(T),raw_boundary_rms_deg=float(np.sqrt(np.mean(dq*dq))*deg),raw_boundary_max_deg=float(max(abs(dq))*deg),per_leg=perleg,largest_errors=sorted(rows,key=lambda x:abs(x['signed_end_minus_start_deg']),reverse=True)[:10],raw_velocity_boundary_rms_deg_s=float(np.sqrt(np.mean(dv*dv))*deg),correction_rms_deg=float(np.sqrt(np.mean(c*c))*deg),correction_max_deg=float(abs(c).max()*deg),corrected_boundary_max_deg=float(abs(qc[-1]-qc[0]).max()*deg),corrected_velocity_boundary_max_deg_s=float(abs(vv[-1]-vv[0]).max()*deg),corrected_acceleration_boundary_max_rad_s2=float(abs(aa[-1]-aa[0]).max()),method='Symmetric cubic additive correction matching mean start/end joint position and velocity. Acceleration is not forced closed, avoiding noise amplification from numerical differentiation.',limitations=['Kinematic reference only; no muscle excitations, new inverse dynamics, or physical replay computed.','Ground clearance, contact consistency and joint limits after adjustment remain to be validated in the physical model.','Body translation is preserved separately: this artifact closes the 66 leg coordinates only, not the floating base or muscle activation states.','Original torques cannot be reused as dynamically exact torques for the corrected trajectory.'])
(R/'closed_cycle_report.json').write_text(json.dumps(report,indent=2,allow_nan=False))
np.savez_compressed(R/'closed_joint_reference_cycle.npz',time_s=t,joint_names=names,joint_angles_rad=qc,joint_velocities_rad_s=vv,joint_accelerations_rad_s2=aa,raw_joint_angles_rad=q,raw_joint_velocities_rad_s=v,angle_correction_rad=c,original_reference_support_phase=s['reference_support_phase'],reference_support_is_unvalidated_after_correction=True)
fig,ax=plt.subplots(2,1,figsize=(12,7));ix=np.argsort(abs(dq))[-6:][::-1]
for j in ix:
 label=str(names[j]).replace('walker/','');line=ax[0].plot(t,q[:,j]*deg,ls='--',alpha=.5)[0];ax[0].plot(t,qc[:,j]*deg,color=line.get_color(),label=label);ax[1].plot(t,c[:,j]*deg,label=label)
ax[0].set_ylabel('Angle (deg)');ax[0].set_title('Largest boundary errors: original dashed / closed solid');ax[0].legend(ncol=2);ax[1].set_ylabel('Correction (deg)');ax[1].set_xlabel('Half-speed cycle time (s)')
for a in ax:a.grid(alpha=.3)
fig.tight_layout();fig.savefig(R/'closed_cycle_comparison.png',dpi=150)
print(json.dumps(report,indent=2))
