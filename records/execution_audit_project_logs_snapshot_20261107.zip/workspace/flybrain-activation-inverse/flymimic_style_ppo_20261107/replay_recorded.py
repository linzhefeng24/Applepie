import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,numpy as np,mujoco
from mujoco import rollout
from environment import MuscleEnv
R=Path(__file__).resolve().parent;z=np.load(R/'best_feedback_10cycles.npz');env=MuscleEnv(noise=0,random_phase=False);N=env.N;C=z['full_controls'][-N:];I=z['full_state'][-(env.period_controls+1)].copy();I[0]=0;S,_=rollout.rollout(env.m,[mujoco.MjData(env.m)],I[None],np.tile(C,(10,1))[None]);S=S[0];expected=z['full_state'][-env.period_controls:].copy();expected[:,0]-=z['full_state'][-(env.period_controls+1),0];independent_error=float(abs(S[np.arange(19,N,20)]-expected).max());rows=[];previous=I
for k in range(10):
 end=S[(k+1)*N-1];cost,row=env.closure(previous,end);row['cycle']=k+1;rows.append(row);previous=end
report=dict(source='last actual feedback cycle, replayed with no policy feedback',initial_state_is_the_actual_recorded_state=True,no_intermediate_resets=True,independent_first_cycle_max_state_error=independent_error,period_s=env.T,cycles=rows,walking_validated=False,periodic_walking_validated=False,source_feedback_walking_validated=json.load(open(R/'best_feedback_10cycles.json'))['walking_validated']);(R/'recorded_open_loop_10cycles.json').write_text(json.dumps(report,indent=2));np.savez_compressed(R/'recorded_open_loop_10cycles.npz',initial_state=I,full_state=S[19::20],time_s=S[19::20,0],control_one_cycle=C);print(json.dumps(report,indent=2),flush=True)
