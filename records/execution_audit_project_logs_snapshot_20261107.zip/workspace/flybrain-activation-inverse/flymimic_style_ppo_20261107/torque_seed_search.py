import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,ctypes,numpy as np,mujoco
from scipy.optimize import lsq_linear
from scipy.ndimage import gaussian_filter1d
from environment import MuscleEnv,MODEL
R=Path(__file__).resolve().parent;env=MuscleEnv(noise=0,random_phase=False);m=env.m;d=env.d;original=dict(env.task);src=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');old=mujoco.MjModel.from_xml_path('/workspace/fly-walking-run/output/model/walking.xml');od=mujoco.MjData(old);oi=np.array([i for i in range(old.nu) if 'adhere' not in (mujoco.mj_id2name(old,mujoco.mjtObj.mjOBJ_ACTUATOR,i) or '') and '_T' in (mujoco.mj_id2name(old,mujoco.mjtObj.mjOBJ_ACTUATOR,i) or '')]);assert len(oi)==48;mom=np.empty((m.nu,m.nv));omom=np.empty((old.nu,old.nv));A=[];bias=[];targets=[];nodes=20;steps=63
for i in range(nodes):
 k=i*steps;phase_source=.587+.5*k*m.opt.timestep;si=round(phase_source/.0002);od.qpos[:]=original['qpos'][k];od.qvel[:]=original['qvel'][k];od.act[:]=src['act'][si];od.ctrl[:]=src['ctrl'][si];mujoco.mj_forward(old,od);mujoco.mju_sparse2dense(omom,od.actuator_moment,od.moment_rownnz,od.moment_rowadr,od.moment_colind);targets.append((omom[oi].T@od.actuator_force[oi])[env.vd]);d.qpos[:]=original['qpos'][k];d.qvel[:]=original['qvel'][k];d.act[:]=original['activation'][k];d.act[env.adrs]=0;mujoco.mj_forward(m,d);f0=d.actuator_force[env.ids].copy();mujoco.mju_sparse2dense(mom,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);bias.append((mom[env.ids].T@f0)[env.vd]);d.act[env.adrs]=1;mujoco.mj_forward(m,d);gain=d.actuator_force[env.ids]-f0;A.append((mom[env.ids].T*gain)[env.vd])
A=np.array(A);bias=np.array(bias);targets=np.array(targets);lib=ctypes.CDLL(str(R.parent/'steady_periodic_shooting_20261107/periodic_activation.so'));fn=lib.periodic_nodes;ptr=np.ctypeslib.ndpointer;fn.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_double,ptr(np.float64,flags='C_CONTIGUOUS'),ptr(np.int32,flags='C_CONTIGUOUS'),ptr(np.float64,flags='C_CONTIGUOUS'),ptr(np.float64,flags='C_CONTIGUOUS')];types=np.ascontiguousarray(m.actuator_dyntype,dtype=np.int32);prm=np.ascontiguousarray(m.actuator_dynprm);rows=[];best=None
for scale in [.25,.5,1.]:
 for prior in [.05,.25]:
  alpha=[];fit=[]
  for i in range(nodes):
   target=targets[i]*scale-bias[i];norm=max(np.linalg.norm(A[i]),1e-12);fit0=lsq_linear(np.vstack([A[i]/norm,1e-3*np.eye(len(env.ids))]),np.r_[target/norm,np.full(len(env.ids),prior*1e-3)],bounds=(0,1),method='bvls',max_iter=200);alpha.append(fit0.x);fit.append(float(np.linalg.norm(A[i]@fit0.x-target)/max(np.linalg.norm(target),1e-12)))
  alpha=gaussian_filter1d(np.array(alpha),.75,axis=0,mode='wrap');derivative=(np.roll(alpha,-1,axis=0)-np.roll(alpha,1,axis=0))/(2*env.T/nodes);p=m.actuator_dynprm[env.ids];s=.5+1.5*alpha;tau=np.where(derivative>=0,p[None,:,0]*s,p[None,:,1]/s)
  for compensate in [False,True]:
   U=np.clip(alpha+(tau*derivative if compensate else 0),0,1);C=original['controls'].copy()
   for i in range(nodes):C[i*steps:(i+1)*steps,env.ids]=U[i]
   for k in range(0,env.N,20):C[k:k+20,env.ids]=C[k,env.ids]
   commands=np.ascontiguousarray(np.tile(C,(4,1)));act=np.empty_like(commands);fn(len(commands),1,m.na,m.opt.timestep,commands,types,prm,act);act=act[:env.N];env.task['controls']=C;env.task['activation']=act;obs,_=env.reset();errors=[];ups=[];ret=0.;torso=[]
   for k in range(3*env.period_controls):
    obs,reward,term,trunc,info=env.step(np.zeros(130));errors.append(info['angle_rmse_deg']);ups.append(info['body_up']);ret+=reward;torso.append(any((m.geom_bodyid[d.contact[j].geom1]==0 and m.geom_bodyid[d.contact[j].geom2]==env.body) or (m.geom_bodyid[d.contact[j].geom2]==0 and m.geom_bodyid[d.contact[j].geom1]==env.body) for j in range(d.ncon)))
    if term:break
   row=dict(torque_scale=scale,coactivation_prior=prior,activation_dynamics_compensation=compensate,mean_angle_rmse_deg=float(np.mean(errors)),minimum_body_up=float(min(ups)),torso_ground_fraction=float(np.mean(torso)),return_raw=float(ret),terminal_angle_rmse_deg=float(errors[-1]),allocation_mean_relative_error=float(np.mean(fit)));rows.append(row);print(json.dumps(row),flush=True)
   if best is None or ret>best[0]:best=(ret,row,C.copy(),act.copy())
(R/'torque_seed_search.json').write_text(json.dumps(dict(cases=rows,selected=best[1],model_parameters_unchanged=True,teacher='Original recorded motor filter states evaluated at closed reference poses; torque scales are initialization hypotheses, not muscle force capacity changes.'),indent=2));task=original.copy();task['controls']=best[2];task['activation']=best[3];np.savez_compressed(R/'torque_seed_task_data.npz',**task);print('SELECTED',json.dumps(best[1]),flush=True)
