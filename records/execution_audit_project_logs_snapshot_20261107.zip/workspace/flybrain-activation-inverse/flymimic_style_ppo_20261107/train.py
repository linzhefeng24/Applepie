import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/flymimic-style-ppo-mpl',MKL_NUM_THREADS='1')
from pathlib import Path
import json,time,hashlib,numpy as np,torch,mujoco
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.vec_env import SubprocVecEnv,VecNormalize
from stable_baselines3.common.logger import configure
from stable_baselines3.common.env_checker import check_env
from environment import MuscleEnv,prepare,MODEL
R=Path(__file__).resolve().parent;torch.set_num_threads(1)

def evaluate(model,name,cycles=3,save=True):
 env=MuscleEnv(seed=123,cycles=cycles,noise=0,random_phase=False);obs,_=env.reset();states=[env.state()];control=[];actions=[];phases=[];errors=[];rewards=[];boundaries=[];previous=states[0];up=[];torso=[];closure_to_initial=[];start=time.monotonic()
 for k in range(cycles*env.period_controls):
  phase=env.phase;action=np.zeros(130) if model is None else model.predict(obs,deterministic=True)[0];obs,r,term,trunc,info=env.step(action);states.append(env.state());actions.append(action);control.append(env.d.ctrl.copy());phases.append(phase);errors.append(info['angle_rmse_deg']);rewards.append(r);up.append(info['body_up']);hit=any((env.m.geom_bodyid[env.d.contact[c].geom1]==0 and env.m.geom_bodyid[env.d.contact[c].geom2]==env.body) or (env.m.geom_bodyid[env.d.contact[c].geom2]==0 and env.m.geom_bodyid[env.d.contact[c].geom1]==env.body) for c in range(env.d.ncon));torso.append(hit)
  if (k+1)%env.period_controls==0:
   cost,row=env.closure(previous,states[-1]);row['cycle']=(k+1)//env.period_controls;boundaries.append(row);previous=states[-1].copy();closure_to_initial.append(info['closure_cost'])
  if term:break
 S=np.array(states);C=[]
 for phase,c in zip(phases,control):
  block=env.task['controls'][(phase+np.arange(env.substeps))%env.N].copy();block[:,env.ids]=c[env.ids];C.append(block)
 C=np.concatenate(C) if C else np.empty((0,env.m.nu));report=dict(name=name,cycles_completed=len(boundaries),period_s=env.T,feedback=model is not None,return_raw=float(sum(rewards)),mean_angle_rmse_deg=float(np.mean(errors)),terminal_angle_rmse_deg=float(errors[-1]),minimum_body_up=float(min(up)),thorax_ground_fraction=float(np.mean(torso)),forward_total_mm=float((S[-1,1]-S[0,1])*10),boundary_metrics=boundaries,closure_to_initial=closure_to_initial,all_u_in_bounds=bool(np.all((C[:,env.ids]>=0)&(C[:,env.ids]<=1))),all_activation_in_bounds=bool(np.all((S[:,1+env.m.nq+env.m.nv:][:,env.adrs]>=-1e-10)&(S[:,1+env.m.nq+env.m.nv:][:,env.adrs]<=1+1e-10))),no_intermediate_resets=True,wall_s=time.monotonic()-start)
 report['walking_validated']=bool(report['minimum_body_up']>.8 and report['thorax_ground_fraction']==0 and report['forward_total_mm']>.1 and report['cycles_completed']==cycles and report['mean_angle_rmse_deg']<15)
 report['periodic_validated']=bool(len(boundaries)>=3 and max(x['angle_max_deg'] for x in boundaries[-2:])<.5 and max(x['velocity_rms_rad_s'] for x in boundaries[-2:])<.1 and max(x['activation_max'] for x in boundaries[-2:])<1e-5 and max(x['root_rotation_deg'] for x in boundaries[-2:])<.5 and report['walking_validated'])
 if save:
  (R/f'{name}.json').write_text(json.dumps(report,indent=2));np.savez_compressed(R/f'{name}.npz',full_state=S,initial_state=S[0],full_controls=C,actions=np.array(actions),phases=np.array(phases),joint_qpos_indices=env.qa,joint_dof_indices=env.vd,muscle_ids=env.ids,activation_adrs=env.adrs,angle_rmse_deg=np.array(errors),time_s=S[:,0],control_timestep_s=.002)
 return report

class Progress(BaseCallback):
 def __init__(self):super().__init__();self.start=time.monotonic();self.last_eval=0;self.history=[];self.best=-np.inf
 def _on_step(self):
  if self.num_timesteps-self.last_eval>=8192:
   self.last_eval=self.num_timesteps;self.model.save(R/f'policy_{self.num_timesteps:06d}');self.model.get_vec_normalize_env().save(R/'vecnormalize.pkl');name=f'eval_{self.num_timesteps:06d}';report=evaluate(self.model,name,cycles=3);row=dict(report,timesteps=self.num_timesteps,training_wall_s=time.monotonic()-self.start);self.history.append(row);(R/'evaluation_history.json').write_text(json.dumps(self.history,indent=2));self.model.save(R/f'policy_{self.num_timesteps:06d}');self.model.get_vec_normalize_env().save(R/'vecnormalize.pkl');print('EVALUATION',json.dumps({k:v for k,v in row.items() if k not in ['boundary_metrics','closure_to_initial']}),flush=True)
   if report['return_raw']>self.best:self.best=report['return_raw'];self.model.save(R/'best_return_policy')
  return True

if __name__=='__main__':
 if not (R/'task_data.npz').exists():prepare()
 check_env(MuscleEnv(noise=0,random_phase=False),warn=True)
 baseline=evaluate(None,'baseline_feedforward',cycles=3);print('BASELINE',json.dumps(baseline),flush=True)
 vec=SubprocVecEnv([lambda rank=i:MuscleEnv(seed=20261107+rank,cycles=2,noise=.005,random_phase=True) for i in range(4)],start_method='fork');vec=VecNormalize(vec,norm_obs=False,norm_reward=True,clip_reward=100.,gamma=.995)
 model=PPO('MlpPolicy',vec,learning_rate=1e-4,n_steps=256,batch_size=256,n_epochs=5,gamma=.995,gae_lambda=.95,clip_range=.2,ent_coef=.001,vf_coef=.5,max_grad_norm=.5,policy_kwargs=dict(net_arch=dict(pi=[512,512,256],vf=[512,512,256]),activation_fn=torch.nn.ReLU,log_std_init=-1.6),device='cpu',seed=20261107,verbose=1);model.set_logger(configure(str(R/'logs'),['stdout','csv']));model.save(R/'untrained_policy');initial=evaluate(model,'untrained_feedback',cycles=3);print('UNTRAINED',json.dumps(initial),flush=True)
 config=dict(method='FlyMimic-style PPO residual feedback policy; six-leg full-body task adaptation, not reproduction of the original isolated-foreleg experiment',model_xml=str(MODEL),model_sha256=hashlib.sha256(MODEL.read_bytes()).hexdigest(),reference_period_s=.126,control_frequency_Hz=500,physics_frequency_Hz=10000,muscle_actions=130,observations=vec.observation_space.shape[0],training_envs=4,training_steps=32768,policy_layers=[512,512,256],seed=20261107,learning_rate=1e-4,reward='exp(-5*joint-angle RMS) each step; periodic mechanical-state return penalty and consecutive-cycle activation return penalty at cycle boundaries',closure_weight=5,activation_warmup_cycles=1,absolute_height_tracking_penalty=False,forward_distance_target=False,model_parameter_changes=False,extra_forces=False,training_episode_reference_resets=True,training_cycles_per_episode=2,validation_intermediate_resets=False,closure_is_training_objective_not_a_hard_feasibility_guarantee=True)
 (R/'configuration.json').write_text(json.dumps(config,indent=2));start=time.monotonic();model.learn(total_timesteps=32768,callback=Progress());model.save(R/'final_policy');vec.save(R/'vecnormalize.pkl');vec.close();best=PPO.load(R/'best_return_policy',device='cpu');final=evaluate(best,'best_feedback_10cycles',cycles=10);last=evaluate(model,'final_feedback_10cycles',cycles=10);(R/'training_summary.json').write_text(json.dumps(dict(training_steps=32768,wall_s=time.monotonic()-start,best=final,final=last,baseline=baseline),indent=2));print('DONE',json.dumps(final),flush=True)
