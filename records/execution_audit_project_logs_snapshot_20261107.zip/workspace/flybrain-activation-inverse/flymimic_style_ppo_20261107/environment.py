import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/flymimic-style-ppo-mpl')
from pathlib import Path
import ctypes,json,numpy as np,mujoco,gymnasium as gym
from gymnasium import spaces
R=Path(__file__).resolve().parent;S=R.parent/'steady_periodic_shooting_20261107';MODEL=R.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'

def prepare():
 ref=np.load(S/'reference_10000Hz.npz');seed=np.load(S/'optimization_seed_only.npz');C=seed['all_control_10000Hz'].copy();m=mujoco.MjModel.from_xml_path(str(MODEL));ids=np.flatnonzero(m.actuator_dyntype==int(mujoco.mjtDyn.mjDYN_MUSCLE));
 for phase in range(0,len(C),20):C[phase:phase+20,ids]=C[phase,ids]
 na=C.shape[1];N=len(C);dt=1e-4;repeat=max(1,int(np.ceil(4/(8*N*dt))));commands=np.ascontiguousarray(np.tile(C,(repeat,1)));values=np.empty_like(commands);m=mujoco.MjModel.from_xml_path(str(MODEL));lib=ctypes.CDLL(str(S/'periodic_activation.so'));fn=lib.periodic_nodes;ptr=np.ctypeslib.ndpointer;fn.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_double,ptr(np.float64,flags='C_CONTIGUOUS'),ptr(np.int32,flags='C_CONTIGUOUS'),ptr(np.float64,flags='C_CONTIGUOUS'),ptr(np.float64,flags='C_CONTIGUOUS')];fn(len(commands),1,na,dt,commands,np.ascontiguousarray(m.actuator_dyntype,dtype=np.int32),np.ascontiguousarray(m.actuator_dynprm),values)
 np.savez_compressed(R/'task_data.npz',qpos=ref['qpos'],qvel=ref['qvel'],controls=C,activation=values[:N],joint_qpos_indices=ref['joint_qpos_indices'],joint_dof_indices=ref['joint_dof_indices'],joint_names=ref['joint_names'])

class MuscleEnv(gym.Env):
 metadata={'render_modes':[]}
 def __init__(self,seed=0,cycles=2,noise=.005,random_phase=True):
  self.m=mujoco.MjModel.from_xml_path(str(MODEL));self.m.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_WARMSTART);self.d=mujoco.MjData(self.m);self.task=dict(np.load(R/'task_data.npz'));self.qa=self.task['joint_qpos_indices'];self.vd=self.task['joint_dof_indices'];self.ids=np.flatnonzero(self.m.actuator_dyntype==int(mujoco.mjtDyn.mjDYN_MUSCLE));self.adrs=self.m.actuator_actadr[self.ids];self.retained=np.setdiff1d(np.arange(self.m.nu),self.ids);self.N=len(self.task['controls']);self.substeps=20;assert self.N%self.substeps==0;self.period_controls=self.N//self.substeps;self.T=self.N*self.m.opt.timestep;self.cycles=cycles;self.noise=noise;self.random_phase=random_phase;self.seed_value=seed;self.action_space=spaces.Box(-1.,1.,shape=(len(self.ids),),dtype=np.float32);self.body=mujoco.mj_name2id(self.m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');self.vscale=np.r_[[1.]*3,[20.]*3,[50.]*(108-6)];self.reset(seed=seed);obs=self._obs();self.observation_space=spaces.Box(-10.,10.,shape=obs.shape,dtype=np.float32)
 def reset(self,*,seed=None,options=None):
  super().reset(seed=seed);mujoco.mj_resetData(self.m,self.d);self.phase=int(self.np_random.integers(self.period_controls))*self.substeps if self.random_phase else 0
  if options and 'phase' in options:self.phase=int(options['phase'])%self.N
  self.start_phase=self.phase;self.d.qpos[:]=self.task['qpos'][self.phase];self.d.qvel[:]=self.task['qvel'][self.phase];self.d.act[:]=self.task['activation'][self.phase];self.d.ctrl[:]=self.task['controls'][self.phase]
  if self.noise:self.d.qpos[self.qa]+=self.np_random.normal(0,self.noise,len(self.qa))
  mujoco.mj_forward(self.m,self.d);self.initial_q=self.d.qpos.copy();self.previous_boundary=None;self.initial_physical_state=self.state();self.previous_boundary_warm=None;self.count=0;self.completed_cycles=0;self.episode_return=0.;self.closure_costs=[];self.last_action=np.zeros(len(self.ids));return self._obs(),{}
 def _obs(self):
  q=self.d.qpos;v=self.d.qvel;target=self.task['qpos'][self.phase];rv=self.task['qvel'][self.phase];phi=2*np.pi*self.phase/self.N;span=np.maximum(np.ptp(self.m.actuator_lengthrange[self.ids],axis=1),1e-6);length=(self.d.actuator_length[self.ids]-self.m.actuator_lengthrange[self.ids].mean(axis=1))/span;velocity=self.d.actuator_velocity[self.ids]*.02/span;force=self.d.actuator_force[self.ids]/np.maximum(abs(self.m.actuator_gainprm[self.ids,2]),1e-6)
  obs=np.r_[length,velocity,force,q[7:109]/.5,v[:108]/self.vscale,self.d.act,(q[self.qa]-target[self.qa])/.3,target[self.qa]/.5,rv[self.vd]/50,q[3:7],(q[1]-self.initial_q[1])/.02,(q[2]-target[2])/.01,np.sin(phi),np.cos(phi)]
  return np.clip(np.nan_to_num(obs,nan=0,posinf=10,neginf=-10),-10,10).astype(np.float32)
 def state(self):
  out=np.empty(mujoco.mj_stateSize(self.m,mujoco.mjtState.mjSTATE_FULLPHYSICS));mujoco.mj_getState(self.m,self.d,out,mujoco.mjtState.mjSTATE_FULLPHYSICS);return out
 def closure(self,previous,current,activation_previous=None):
  off=1+self.m.nq+self.m.nv;dq=np.empty(self.m.nv);mujoco.mj_differentiatePos(self.m,dq,1.,previous[1:1+self.m.nq],current[1:1+self.m.nq]);dv=current[1+self.m.nq:off]-previous[1+self.m.nq:off];da=current[off:]-(activation_previous if activation_previous is not None else previous)[off:];qcost=np.mean((dq[6:108]/.15)**2);vcost=np.mean((dv[6:108]/20)**2);acost=np.mean((da/.15)**2);body=np.r_[dq[1:3]/.01,dq[3:6]/.2,dv[:3]/.3,dv[3:6]/10];bcost=np.mean(body**2);cost=float(qcost+vcost+acost+bcost)
  return cost,dict(angle_rms_deg=float(np.sqrt(np.mean(dq[self.vd]**2))*180/np.pi),angle_max_deg=float(abs(dq[self.vd]).max()*180/np.pi),velocity_rms_rad_s=float(np.sqrt(np.mean(dv[self.vd]**2))),activation_max=float(abs(da).max()),root_rotation_deg=float(np.linalg.norm(dq[3:6])*180/np.pi),forward_mm=float((current[1]-previous[1])*10),closure_cost=cost,activation_cost=float(acost))
 def step(self,action):
  action=np.clip(np.asarray(action,dtype=float),-1,1);base=self.task['controls'][self.phase,self.ids];u=np.clip(base+action,0,1);start_time=self.d.time
  for j in range(self.substeps):
   k=(self.phase+j)%self.N;self.d.ctrl[:]=self.task['controls'][k];self.d.ctrl[self.ids]=u;mujoco.mj_step(self.m,self.d)
  self.phase=(self.phase+self.substeps)%self.N;self.count+=1;mujoco.mj_forward(self.m,self.d);err=self.d.qpos[self.qa]-self.task['qpos'][self.phase,self.qa];rms=float(np.sqrt(np.mean(err**2)));tracking=float(np.exp(-5*rms));reward=tracking;info=dict(angle_rmse_deg=rms*180/np.pi,tracking_reward=tracking,closure_cost=0.,body_up=float(self.d.xmat[self.body].reshape(3,3)[2,2]));numerical_failure=not np.isfinite(self.d.qpos).all() or not np.isfinite(self.d.qvel).all() or abs(self.d.time-start_time-self.substeps*self.m.opt.timestep)>1e-8
  if self.count%self.period_controls==0:
   self.completed_cycles+=1;boundary=self.state()
   cost,metrics=self.closure(self.initial_physical_state,boundary,activation_previous=self.previous_boundary)
   if self.previous_boundary is None:cost-=metrics['activation_cost']
   self.closure_costs.append(cost);reward-=5*cost;info.update(metrics);info['closure_cost']=float(cost)
   self.previous_boundary=boundary.copy()
  if numerical_failure:reward=-100.;info['numerical_failure']=True
  assert not self.d.qfrc_applied.any() and not self.d.xfrc_applied.any();self.episode_return+=reward;terminated=bool(numerical_failure);truncated=self.count>=self.cycles*self.period_controls
  if terminated or truncated:info['episode']={'r':self.episode_return,'l':self.count,'t':self.d.time};info['episode_closure_mean']=float(np.mean(self.closure_costs)) if self.closure_costs else None
  return self._obs(),float(reward),terminated,bool(truncated),info

if __name__=='__main__':
 prepare();env=MuscleEnv(noise=0,random_phase=False);obs,_=env.reset();rewards=[]
 for _ in range(126):obs,r,a,b,info=env.step(np.zeros(130));rewards.append(r)
 print(json.dumps(dict(observation_shape=obs.shape,action_shape=env.action_space.shape,period_s=env.T,steps=env.count,mean_reward=float(np.mean(rewards)),last_info=info,no_extra_forces=True),indent=2),flush=True)
