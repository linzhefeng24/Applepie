import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import ctypes,json,numpy as np,mujoco
from pathlib import Path
from environment import MuscleEnv
R=Path(__file__).resolve().parent;e=MuscleEnv(noise=0,random_phase=False);base=e.m.actuator_dynprm.copy();unknown=e.ids[base[e.ids,0]>.001];assert len(unknown)==100;C=np.ascontiguousarray(np.tile(e.task['controls'],(4,1)));lib=ctypes.CDLL(str(R.parent/'steady_periodic_shooting_20261107/periodic_activation.so'));fn=lib.periodic_nodes;ptr=np.ctypeslib.ndpointer;fn.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_double,ptr(np.float64,flags='C_CONTIGUOUS'),ptr(np.int32,flags='C_CONTIGUOUS'),ptr(np.float64,flags='C_CONTIGUOUS'),ptr(np.float64,flags='C_CONTIGUOUS')];kind=np.ascontiguousarray(e.m.actuator_dyntype,dtype=np.int32);rows=[]
for scale in [1.,.5,.25,.1,.05]:
 e.m.actuator_dynprm[:]=base;e.m.actuator_dynprm[unknown,:2]=base[unknown,:2]*scale;assert e.m.actuator_dynprm[unknown,0].min()>=.001-1e-12 and e.m.actuator_dynprm[unknown,1].min()>=.002-1e-12;A=np.empty_like(C);fn(len(C),1,e.m.na,e.m.opt.timestep,C,kind,np.ascontiguousarray(e.m.actuator_dynprm),A);e.task['activation']=A[:e.N];obs,_=e.reset();rs=[];errors=[];up=[];initial=e.d.qpos.copy()
 for i in range(3*e.period_controls):obs,r,t,tr,info=e.step(np.zeros(130));rs.append(r);errors.append(info['angle_rmse_deg']);up.append(info['body_up'])
 row=dict(time_constant_scale=scale,estimated_channels_changed=len(unknown),activation_tau_s=float(.02*scale),deactivation_tau_s=float(.05*scale),return_raw=float(sum(rs)),mean_angle_rmse_deg=float(np.mean(errors)),minimum_body_up=float(min(up)),forward_total_mm=float((e.d.qpos[0]-initial[0])*10),force_capacities_and_geometry_changed=False);rows.append(row);print(json.dumps(row),flush=True)
(R/'time_constant_ablation.json').write_text(json.dumps(dict(cases=rows,prior_bounds_s={'activation':[.001,.15],'deactivation':[.002,.3]},prior_source='brain.json neuromusculoskeletal_model.six_leg_parameter_priors; engineering priors, not per-muscle measurements',training_model_unchanged=True,diagnostic_only=True),indent=2))
