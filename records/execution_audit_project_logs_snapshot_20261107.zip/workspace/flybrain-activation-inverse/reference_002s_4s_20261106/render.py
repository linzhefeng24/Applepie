import os
os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/tmp/hind-correction-mesa',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',LP_NUM_THREADS='4')
from pathlib import Path
import json,numpy as np,mujoco,imageio
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;root=R.parent;m=mujoco.MjModel.from_xml_path(str(root/'hindleg_correction_20261106/candidate_muscles.xml'));d=mujoco.MjData(m);ref=dict(np.load(root/'half_speed_angle_only_20261106/retimed_reference_5000Hz.npz'));renderer=mujoco.Renderer(m,height=600,width=800);opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
T=np.arange(21)*.02;rows=[]
with imageio.get_writer(R/'reference_every_002s_playback_4s.mp4',fps=21/4,codec='libx264',quality=8,macro_block_size=2) as writer:
 for i,t in enumerate(T):
  k=round(t/.0002);assert abs(ref['time_s'][k]-t)<1e-10;d.qpos[:]=ref['qpos'][k];d.qvel[:]=ref['qvel'][k];d.time=t;mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=opt);renderer.scene.flags[mujoco.mjtRndFlag.mjRND_REFLECTION]=False;renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW]=False;im=Image.fromarray(renderer.render());dr=ImageDraw.Draw(im);dr.rectangle((0,0,800,50),fill='black');dr.text((10,7),'Reference only | trajectory sample interval 0.02 s | video duration 4.00 s',fill='white');dr.text((10,27),f'target time={t:.2f} s | original source phase={t/2:.2f} s | frame {i+1}/21',fill='white');writer.append_data(np.asarray(im));rows.append(dict(frame=i,target_time_s=float(t),reference_index=k,video_frame_time_s=i/(21/4)))
  if i in [0,10,20]:im.save(R/f'frame_{i:02d}.png')
renderer.close();(R/'sampling.json').write_text(json.dumps(dict(reference_duration_s=.4,trajectory_interval_s=.02,video_duration_s=4,frame_count=21,fps=21/4,frames=rows,notes='Reference poses rendered directly at 0,0.02,...,0.4 s. Each of 21 frames is held for 4/21 s; no pose interpolation. Reference is simulated, not an animal recording.'),indent=2));print('FINISHED',flush=True)
