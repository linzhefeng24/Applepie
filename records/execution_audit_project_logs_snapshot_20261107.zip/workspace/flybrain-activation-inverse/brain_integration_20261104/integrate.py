"""Embed the adopted six-leg model knowledge in brain.json, preserving prior sections."""
from pathlib import Path
import json,hashlib,copy,os,tempfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent;SIX=PROJECT/'six_leg_model';FM=PROJECT/'flymimic_adoption'
CANON=Path('/workspace/flybrain-muscle-rebuild/brain.json');MIRROR=Path('/workspace/flybrain-recovered/brain.json')
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
brain=read(CANON);assert brain==read(MIRROR)
backup=ROOT/'brain_before_full_model_embedding.json'
if not backup.exists():backup.write_bytes(CANON.read_bytes())
before=copy.deepcopy(brain)
inputs={};provenance=[]
def document(key,p):
 p=Path(p);v=read(p);inputs[key]=v;provenance.append({'key':key,'source_path':str(p),'sha256':digest(p),'bytes':p.stat().st_size,'storage':'full JSON contents embedded; path is provenance, not required to read the data'});return v
selection=document('model_selection',PROJECT/'muscle_model_selection.json')
model=document('six_leg_working_model',SIX/'manifest.json')
unc=document('middle_hind_parameter_uncertainty',SIX/'middle_hind_uncertainty.json')
document('six_leg_parameter_priors','/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json')
native=document('native_flymimic_reference',FM/'manifest.json')
document('native_flymimic_existing_evidence_links',FM/'evidence_links.json')
for key,p in [('six_leg_mechanics_validation',SIX/'validation.json'),('fixed_reference_torque_projection',SIX/'reference_projection.json'),('reference_pose_direction_audit',SIX/'direction_audit.json'),('uncertainty_interface_validation',SIX/'uncertainty_validation.json'),('six_leg_adoption_preservation',SIX/'preservation_report.json'),('native_flymimic_validation',FM/'validation.json'),('native_flymimic_adoption_preservation',FM/'preservation_report.json')]:document(key,p)
texts={}
for key,p in [('six_leg_model_method',SIX/'README.md'),('middle_hind_parameter_method',SIX/'MIDDLE_HIND_PARAMETERS.md'),('native_reference_method_and_history',FM/'README.md')]:
 texts[key]={'format':'markdown','text':p.read_text(),'source_path':str(p),'sha256':digest(p)}
xmls={}
for key,p in [('six_leg_model',SIX/'six_leg_muscles.xml'),('native_LF_reference',FM/'models'/native['selected_xml'])]:
 xmls[key]={'format':'MuJoCo XML','text':p.read_text(),'source_path':str(p),'sha256':digest(p),'external_mesh_assets_required':True}
# Existing catalogs stay untouched. This index links those records to the new model.
catalog=brain['muscle_table']['catalog'];crosswalk=[]
for i,c in enumerate(catalog):
 channels=[r['id'] for r in model['records'] if c['id'] in r['catalog_ids']]
 assert channels,c['id']
 crosswalk.append({'catalog_id':c['id'],'catalog_array_index':i,'model_MTU_ids':channels,'middle_hind_uncertainty_ids':[r['id'] for r in unc['records'] if c['id'] in r['catalog_ids']],'semantic_status':'category-to-representative-MTU relation; may be split or merged; not verified fiber or motor-unit identity'})
# Large binary research artifacts are indexed, not encoded as unreadable JSON strings.
artifact_paths=[SIX/'six_leg_muscles.mjb',SIX/'reference_projection.npz',FM/'adopted_demo_replay.npz']
artifact_paths+=sorted((FM/'models').rglob('*.stl'))
for definition in xmls.values():
 tree=ET.fromstring(definition['text']);base=Path(definition['source_path']).parent;compiler=tree.find('compiler')
 for asset in tree.findall('asset/*'):
  if 'file' not in asset.attrib:continue
  key='meshdir' if asset.tag=='mesh' else 'texturedir' if asset.tag=='texture' else None
  directory=compiler.get(key,'') if compiler is not None and key else ''
  path=Path(asset.get('file'))
  if not path.is_absolute():path=base/directory/path
  path=path.resolve();assert path.is_file(),str(path);artifact_paths.append(path)
artifact_paths=sorted(set(p.resolve() for p in artifact_paths))

artifacts=[{'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p),'storage':'external binary asset; referenced by embedded model XML or assessment'} for p in artifact_paths if p.exists()]
model_knowledge={'schema':'integrated_six_leg_neuromuscular_model_v1','date':'2026-11-04','scope':'Full structured model knowledge embedded; large binary meshes and recorded arrays remain indexed external artifacts','current_readiness':{'six_legs_modeled':True,'runtime_MTU_channels':130,'catalog_slots_covered':126,'middle_hind_uncertain_muscles':80,'middle_hind_parameter_entries':sum(len(r['parameters']) for r in unc['records']),'native_LF_unchanged_reference_available':True,'whole_body_muscle_walking_validated':False,'middle_hind_new_parameter_optimization_performed':False,'geometry_is_fully_measured':False,'known_remaining_limitations':['Estimated target attachments and transferred foreleg geometry, not fully measured anatomy.','No independent claw DoF; long tendons have routing proxies.','Active matrices sampled at rank 9 per 11 existing leg coordinates.','Initial fixed-torque projection has about 89.98% relative L2 residual.','One weak opposing direction proxy in the LF trochanter extensor requires checking.']},'interpretation_rules':['Measured unknown values remain null; simulation initial values are estimates.','Working ranges are revisable priors, not measured confidence intervals or absolute biological limits.','F0=PCSA*specific_stress; shared volume and geometry constraints apply.','One parameter set is shared across timestamps; activation allocations remain per-frame conditional estimates.','Original muscle catalog, neural evidence and historical model results are retained without automatic neuron-to-MTU reassignment.','Earlier 126-channel labels do not become 130-channel labels by renaming.','A successful solver or a short finite simulation does not establish normal walking.'],**inputs,'catalog_to_model_crosswalk':crosswalk,'method_documents':texts,'model_definitions_xml':xmls,'input_provenance':provenance,'binary_artifact_index':artifacts}
if before.get('muscle_activation_inference_experiments',{}).get('runs'):
 previous_ready=before.get('neuromusculoskeletal_model',{}).get('current_readiness',{})
 for k,v in previous_ready.items():
  if k.startswith('latest_') or k in ['middle_hind_new_parameter_optimization_performed','default_parameter_model_replaced_by_candidate']:model_knowledge['current_readiness'][k]=v
brain['neuromusculoskeletal_model']=model_knowledge
brain['version']=before['version'] if before.get('muscle_activation_inference_experiments',{}).get('runs') else '3.4.0-integrated-six-leg-muscle-model';brain['date']='2026-11-04'
# All historical content except top-level version/date must remain exactly equal.
for key,value in before.items():
 if key not in ['version','date','neuromusculoskeletal_model']:assert brain[key]==value,key
assert len(crosswalk)==126 and len(model['records'])==130 and len(unc['records'])==80
assert set(r['id'] for r in model['records'])==set(id for r in crosswalk for id in r['model_MTU_ids'])
assert all(s.get('measured_value') is None for r in unc['records'] for s in r['parameters'].values())
blob=(json.dumps(brain,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
# Validate serialization before replacing either canonical copy.
assert json.loads(blob)==brain
for p in [CANON,MIRROR]:
 tmp=p.with_name(p.name+'.sixleg.tmp');tmp.write_bytes(blob);os.replace(tmp,p)
assert CANON.read_bytes()==MIRROR.read_bytes()
report={'version':brain['version'],'canonical':str(CANON),'mirror':str(MIRROR),'bytes':len(blob),'sha256':digest(CANON),'prior_sections_unchanged_except_version_date':True,'mirrors_identical':True,'embedded_json_documents':len(inputs),'embedded_method_documents':len(texts),'embedded_model_xmls':len(xmls),'embedded_model_MTU_records':len(model['records']),'embedded_catalog_crosswalk_records':len(crosswalk),'embedded_middle_hind_uncertainty_records':len(unc['records']),'embedded_middle_hind_parameter_entries':model_knowledge['current_readiness']['middle_hind_parameter_entries'],'all_unknown_measurements_remain_null':True,'external_binary_artifacts_indexed':len(artifacts),'strict_json_valid':True}
(ROOT/'integration_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
