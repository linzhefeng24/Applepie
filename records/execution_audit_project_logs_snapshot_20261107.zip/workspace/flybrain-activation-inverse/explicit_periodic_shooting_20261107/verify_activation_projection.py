from pathlib import Path
R=Path(__file__).resolve().parent
exec(compile((R/'solver.py').read_text().split('x=np.zeros(nvar)')[0],str(R/'solver.py'),'exec'))
x=np.load(R/'checkpoint.npz')['variables'];a=project_activation(x);I=node_state(x,0);I[0]=0;C=np.concatenate([controls(x,i) for i in range(ns)]);S,_=rollout.rollout(m,data,I[None],C[None],persistent_pool=True);observed=S[0,np.arange(steps-1,ns*steps,steps),off:];expected=np.roll(a,-1,axis=0);error=float(abs(observed-expected).max());assert error<1e-10
report=dict(native_mujoco_activation_node_max_error=error,native_periodic_activation_seam_max=float(abs(S[0,-1,off:]-I[off:]).max()),all_141_internal_states_included=True,control_limits_respected=bool(np.all((C[:,ids]>=0)&(C[:,ids]<=1))),no_intermediate_state_reset=True,geometry_or_force_capacity_changed=False)
(R/'activation_projection_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
