from pathlib import Path
R=Path(__file__).resolve().parent
exec(compile((R/'solver.py').read_text().split('x=np.zeros(nvar)')[0],str(R/'solver.py'),'exec'))
x=np.load(R/'checkpoint.npz')['variables'];rng=np.random.default_rng(7);D=rng.normal(size=nvar);D[0]=0;reports=[]
for tol in [1e-8,1e-12,0.]:
 m.opt.tolerance=tol;m.opt.iterations=100 if tol else 20
 E,mm,ends=evaluate(x.copy());repeats=[]
 for k in range(3):
  EE,_,_=evaluate(x.copy());repeats.append(float(np.linalg.norm(EE-E)))
 pert=[]
 for eps in [1e-4,1e-5,1e-6,1e-7]:
  xx=np.clip(x+eps*D,lo,hi);EE,_,_=evaluate(xx);delta=EE-E;pert.append(dict(epsilon=eps,change_l2=float(np.linalg.norm(delta)),worst_segment=int(np.argmax(np.linalg.norm(delta.reshape(ns,nx),axis=1)))+1))
 report=dict(tolerance=tol,iterations=int(m.opt.iterations),exact_repeat_l2=repeats,perturbations=pert,baseline_l2=float(np.linalg.norm(E)));reports.append(report);print(json.dumps(report),flush=True)
(R/'repeatability_audit.json').write_text(json.dumps(reports,indent=2))
