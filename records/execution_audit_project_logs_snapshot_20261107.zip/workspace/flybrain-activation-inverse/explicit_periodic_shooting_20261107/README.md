# Explicit periodic multiple shooting

This experiment resumes the user's 0.4 s half-speed reference / 20 × 20 ms task.
It uses the same `bounded_refined_muscles.xml` model as the original angle-only
trial. Model geometry, force capacity and activation time constants are preserved.
Numerical warm-starting is disabled so segment maps depend only on the modeled
physical state; this numerical choice is retained during validation.

There are 9,741 variables: 20 nodes containing all 108 actual body generalized
position coordinates (quaternion tangent coordinates), 108 velocities, 141
actuator internal states, 130 muscle commands, plus one free forward translation.
The decorative ghost's six generalized coordinates are excluded from closure.
All 2,600 muscle commands participate independently with bounds [0,1].

There are 7,140 nonlinear dynamic equality constraints. Each native MuJoCo segment
must end in the next node's physical state; the last node connects back to the
first with free root translation. The arbitrary global x origin is anchored.
Both contact and passive joint dynamics are included in every segment simulation.
No extra forces are applied. No forward-distance target or absolute-height
objective is used. Reference leg-angle tracking is the trajectory objective.

The optimizer first restores equality feasibility with a bounded local QP, using
elastic residual variables as a numerical restoration technique. Nonzero defects
are NEVER called a feasible orbit. Once maximum scaled defect is below 1e-5,
tracking uses an equality-constrained QP. Line search accepts feasibility
improvement first; thus a reduced node tracking error alone is not success.

Each full Jacobian differentiates all 357 start-state variables and all 130
segment muscle commands for every segment. Between full refreshes, the worst four
segments are recomputed and sparse secant updates are used. State and command
finite differences run through native MuJoCo including contacts. Derivatives of
next-node coordinates use the quaternion manifold. The finite-difference step is
0.001 in scaled coordinates. This is still a local nonlinear optimizer.

`shooting_candidate.npz` contains OPTIMIZATION NODES that may still violate
segment continuity. It must not be rendered or reported as a free physical
rollout. `audit_one_cycle.py` and `validate.py` replay inputs without node resets.
Only `validation.json` can establish the outcome of that continuous replay.

The first run completed iteration 1, then hit a JSON numpy-integer logging bug.
`resume.log` records recovery from the preserved checkpoint; it did not restart
from scratch. QP accuracy is adjusted to the current nonlinear defect to avoid
oversolving initial, physically inaccurate linearizations.

## Exact activation manifold projection

`periodic_activation.c` integrates the same native Euler muscle/filter activation
recurrence over repeated prescribed segment inputs to compute periodic internal
activation at each node. Every trial is projected onto this activation manifold
before physical segment evaluation. This is a state-dependent-on-input reduction;
it does not change the muscle model, force capacity, or time constants. The local
QP still includes activation tangent constraints and the physical derivatives
with respect to start activation. Native MuJoCo verification of an uninterrupted
cycle is stored in `activation_projection_validation.json`. Physical body state
closure remains unsolved until the remaining mechanical defects vanish. The
larger activation update trust range only changes the numerical optimizer.

The fixed-input retained actuator filters are computed analytically. Their nodes
are fixed to their unique periodic responses. These are head/abdomen/foot adhesion
actuators already present in the original model, not added rescue actuators.

The auxiliary `steady_periodic_shooting_20261107` branch uses the previously
closed, half-speed 0.126 s steady reference cycle and 20 intervals of 6.3 ms. It
keeps the same muscle model and the same periodic-state / reference-tracking
formulation, with a new initial command estimate from contact-aware inverse
dynamics. The inverse estimate is an initialization, not a walking validation.
