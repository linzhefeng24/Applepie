from pathlib import Path
R=Path(__file__).resolve().parent
exec(compile((R/'solver.py').read_text().split('x=np.zeros(nvar)')[0],str(R/'solver.py'),'exec'))
x=np.load(R/'checkpoint.npz')['variables'];J=sparse.load_npz(R/'constraint_jacobian.npz');E,meta,ends=evaluate(x);rng=np.random.default_rng(7);D=rng.normal(size=nvar);D[0]=0;rows=[]
for epsilon in [1e-3,1e-4,1e-5,1e-6]:
 xx=np.clip(x+epsilon*D,lo,hi);EE,mm,ep=evaluate(xx);dx=xx-x;pred=J@dx;actual=EE-E;err=(actual-pred).reshape(ns,nx);physical=slice(0,2*nv);r=dict(epsilon=epsilon,actual_residual_change_l2=float(np.linalg.norm(actual)),prediction_change_l2=float(np.linalg.norm(pred)),relative_derivative_error=float(np.linalg.norm(actual-pred)/max(np.linalg.norm(actual),1e-20)),physical_derivative_error=float(np.linalg.norm(err[:,physical])/max(np.linalg.norm(actual.reshape(ns,nx)[:,physical]),1e-20)),activation_prediction_change_max=float(abs(pred.reshape(ns,nx)[:,2*nv:]).max()),activation_actual_change_max=float(abs(actual.reshape(ns,nx)[:,2*nv:]).max()),max_end_time_error_s=float(abs(ep[:,0]-(np.arange(ns)+1)*steps*dt).max()),worst_segment=int(np.argmax(np.linalg.norm(err[:,:2*nv],axis=1)))+1);rows.append(r);print(json.dumps(r),flush=True)
(R/'directional_derivative_audit.json').write_text(json.dumps(dict(baseline=meta,checks=rows),indent=2))
