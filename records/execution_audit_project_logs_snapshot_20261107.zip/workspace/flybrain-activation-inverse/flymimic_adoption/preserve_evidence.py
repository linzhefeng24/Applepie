from pathlib import Path
import json,hashlib,copy
ROOT=Path(__file__).resolve().parent
canonical=Path('/workspace/flybrain-muscle-rebuild/brain.json');mirror=Path('/workspace/flybrain-recovered/brain.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
brain=json.loads(canonical.read_text());assert brain==json.loads(mirror.read_text())
backup=ROOT/'brain_before_adoption.json'
if not backup.exists():backup.write_bytes(canonical.read_bytes())
base=json.loads(backup.read_text())
# Link existing biological records; never substitute category labels for motor units.
map_categories={
'LFC_tergopleural_promotor_a':['tergopleural_promotor'],
'LFC_tergopleural_promotor_b':['tergopleural_promotor'],
'LFC_pleural_remotor_and_abductor':['pleural_remotor_and_abductor'],
'LFC_pleural_promotor':['pleural_promotor'],
'LFC_sternal_anterior_rotator':['sternal_anterior_rotator'],
'LFC_sternal_posterior_rotator':['sternal_posterior_rotator'],
'LFC_sternal_adductor':['sternal_adductor'],
'LFF_trochanter_flexor_a':['trochanter_flexor'],
'LFF_trochanter_flexor_b':['trochanter_flexor'],
'LFF_sterno-tergo-trochanter_extensor_a':['tergotrochanter_extensor','sternotrochanter_extensor'],
'LFF_sterno-tergo-trochanter_extensor_b':['tergotrochanter_extensor','sternotrochanter_extensor'],
'LFF_accesory_trochanter_flexor':['accessory_trochanter_flexor'],
'LFF_trochanter_extensor':['trochanter_extensor'],
'LFTibia_flex_93434':['tibia_flexor'],
'LFTibia_extensor_93932':['tibia_extensor']}
catalog=base['muscle_table']['catalog'];by_id={r['id']:r for r in catalog};manifest=json.loads((ROOT/'manifest.json').read_text());links=[]
for r in manifest['records']:
 ids=['LF:'+x for x in map_categories[r['upstream_name']]]
 assert all(i in by_id for i in ids),ids
 evidence=[by_id[i] for i in ids]
 sources=sorted({s for x in evidence for s in x.get('anatomy_sources',[])})
 links.append({'MTU_id':r['id'],'candidate_catalog_ids':ids,'relationship':'candidate functional/anatomical group correspondence; NOT a verified fiber or motor-unit mapping','ambiguity':'combined upstream extensor label; candidates are not to be summed or duplicated' if len(ids)>1 else 'representative MTU versus atlas category; subdivision remains unresolved','existing_anatomy_sources':sources,'neural_evidence_preserved_at':ids,'auto_assign_motor_neurons':False,'auto_merge_parameter_values':False})
(ROOT/'evidence_links.json').write_text(json.dumps({'schema':'flymimic_existing_evidence_links_v1','links':links,'policy':{'compatible':'retain literature, functional actions, naming, neural evidence and uncertainty as independently sourced annotations','conflicting':'retain both values and their source; use upstream mechanics for selected backend, without relabeling old estimates as measurements','not_comparable':'block numerical merging across units, coordinates, MTU versus category, or different leg identities','unprovided':'retain six-leg evidence catalog; do not create missing muscles by copying foreleg parameters'}},ensure_ascii=False,indent=2))
selection=json.loads(Path('/workspace/flybrain-activation-inverse/muscle_model_selection.json').read_text());selection.update({'evidence_links':str(ROOT/'evidence_links.json'),'existing_evidence_catalog':'preserved unchanged','activation_labels':'old labels are version-specific historical outputs; recompute for adopted mechanics','adoption_scope':'native LF backend operational; whole-body transplant not completed'})
brain['muscle_model_selection']=selection
# Every pre-existing section must be identical. New data stays in a separate field.
for k,v in base.items():assert brain[k]==v,k
blob=json.dumps(brain,ensure_ascii=False,indent=2)+'\n';canonical.write_text(blob);mirror.write_text(blob)
protected=[]
for root in [Path('/workspace/flybrain-muscle-rebuild/priors'),Path('/workspace/flybrain-muscle-rebuild/data')]:
 for p in sorted(root.rglob('*')):
  if p.is_file():protected.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for p in [Path('/workspace/flybrain-activation-inverse/model/geometry.json'),Path('/workspace/flybrain-activation-inverse/optimization/optimized_geometry.json'),Path('/workspace/flybrain-activation-inverse/activation_definition.json')]:protected.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
report={'all_preexisting_brain_sections_unchanged':True,'preexisting_section_hashes':{k:objsha(v) for k,v in base.items()},'muscle_catalog_slots_before':len(base['muscle_table']['catalog']),'muscle_catalog_slots_after':len(brain['muscle_table']['catalog']),'new_annotation_field':'muscle_model_selection','mirrors_equal':canonical.read_bytes()==mirror.read_bytes(),'historical_files_retained':protected,'backup':str(backup),'no_existing_muscle_parameters_overwritten':True,'MTU_evidence_links':len(links)}
(ROOT/'preservation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('All',len(base),'existing brain sections preserved;',len(catalog),'catalog slots retained; links',len(links))
