# 采用 FlyMimic 肌肉模型，同时保留已有证据

> 后续更新：六腿工作模型已经建立，并成为新实验默认入口，见 [六腿模型](../six_leg_model/README.md)。本目录保留作者原样 LF 模型作为独立参考，以下“尚未完成的全身适配”为此原样参考接口的历史范围说明。


采用日期：2026-11-04。当前模型选择见上级 `muscle_model_selection.json`。新的肌肉力学基线为 FlyMimic，已建立可运行的左前腿原生力学接口。这个选择不代表已完成六腿全身模型移植。

## 已完成

- 导入官方固定提交 `9ea1131626cd76f7203b74076ef8f0e9cab30bef` 的模型与网格，保留许可、作者 README 及来源哈希。
- 选择已复现过的 `best_combined_arm_cvt3.xml`；15 个 MTU 的附着点、完整路径、肌肉力学参数及激活动力学均原样保留，XML 与源文件 SHA-256 完全一致。
- 模型保留作者的 armature 数值设置。这个附加惯量不能当作实测的关节属性；被动关节属性也没有用我们的旧先验覆盖。
- `backend.py` 提供原生 7 关节坐标下的肌力/力矩计算、精确仿射矩阵、逐帧有界激活反解，以及使用原生激活动力学的前向积分。
- 上级 `code/selected_muscle_backend.py` 是新模型选择入口。新计算调用这个入口；旧脚本仍属于各自历史实验，未批量改写，也不声称已自动切换。
- `brain.json` 两份镜像仅新增 `muscle_model_selection` 字段。所有原有 22 个部分、126 个肌肉目录槽位、神经证据和参数范围均保持原值。
- `evidence_links.json` 将 15 个 MTU 关联到已有解剖类别及文献来源。它是功能类别的候选对应，不是已验证的纤维/运动单位对应，不能自动复制运动神经元权重。

## 验证

见 `validation.json`。在 32 个参考状态上：

- 直接原生力矩与 `tau=A@activation+b` 的最大差异为 2.66e-15 原生力矩单位。
- 传动力矩与肌肉执行器功率的虚功一致性误差为 2.84e-14 原生功率单位。
- 可行力矩的有界反解最大相对残差为 3.00e-15；冗余肌肉的激活不要求唯一恢复。
- 224 步官方示例控制重放：关节轨迹最大差异 1.75e-15 rad、激活差异为 0。没有逐帧覆盖状态。

使用锁定的 MuJoCo 3.3.2 环境，不改原有肌肉求解环境。

## 接口示例

```python
import sys
sys.path.insert(0, '/workspace/flybrain-activation-inverse/code')
from selected_muscle_backend import load_selected_backend

muscles = load_selected_backend(leg='LF', coordinate_system='flymimic_native')
state = muscles.reset()  # 仿真通常应从参考动作首帧初始化，而不是随意使用零姿态
A, b = muscles.affine(state['q_rad'], state['qdot_rad_s'])
# 给定同一原生坐标、同一单位下的目标肌肉力矩：
fit = muscles.allocate(state['q_rad'], state['qdot_rad_s'], A @ state['activation'] + b)
state = muscles.step(excitation=fit['activation'])  # 仅为接口示例；激活状态不等于所需激励
```

示例最后一行不能用来声称逐帧激活的时序可实现。实际控制应输出 excitation，由原生动力学产生 activation。`step` 保留原模型的控制下限 1e-4。

执行验证：

```bash
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/flymimic_adoption/validate.py
```

## 证据保留与冲突处理

1. 不冲突的解剖功能、文献和神经元证据保留，通过带来源的链接使用。
2. 有冲突的参数保留双方原值。当前力学计算采用所选 FlyMimic 模型值，旧估计作为历史先验，不混合平均，也不重新标记为测量值。
3. 肌肉目录类别和 MTU 粒度不同，不能按名字自动视为一一对应。上游合并命名的伸肌对应两个候选类别时，不重复计算或重复分配力量。
4. 旧优化几何、旧 126 路激活及运动实验原样保留，不再视为新模型下的结果；后续需要重新计算。
5. `preservation_report.json` 记录原有部分的内容哈希；`brain_before_adoption.json` 保存加入模型选择前的完整备份。

## 尚未完成的全身适配

- 现有 flybody 与 FlyMimic 的关节链、旋转轴和零位不同，不能照名字复制角度。对 flybody 坐标请求会显式拒绝，不静默使用旧力线。
- 上游仅有可直接使用的 LF 肌肉路径；RF 需要经过验证的镜像与坐标注册，中后腿也没有可直接引用的上游肌肉。现有六腿解剖证据继续保留，不能用前腿复制值冒充实测六腿模型。
- 保留原生单位。XML 几何和重力数值显示毫米尺度，但随库 OpenSim 元数据标注 m/N；在完成质量、几何和力的量纲核对前，不启用到 flybody SI 力矩的隐式换算。
- 因此这里尚未生成采用这些肌肉的六腿承重行走结果，也不替换此前行走视频的含义。

此前的解剖不确定性没有被消除，只是把有公开解剖依据的局部肌肉模型作为新的基线。
