"""Import upstream foreleg mechanics without refitting or changing anatomical paths."""
from pathlib import Path
import json,hashlib,shutil,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
SOURCE=next(Path('/workspace/fly-platforms/FlyMimic/code').iterdir())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
model='best_combined_arm_cvt3.xml'
assets=SOURCE/'flymimic/assets/models'
shutil.copytree(assets,ROOT/'models',dirs_exist_ok=True)
for name in ['LICENSE','README.md']:
 if (SOURCE/name).exists():shutil.copy2(SOURCE/name,ROOT/('UPSTREAM_'+name))
p=ROOT/'models'/model;r=ET.parse(p).getroot()
site_bodies={};bodies={}
def visit(body):
 name=body.get('name','world');bodies[name]={k:v for k,v in body.attrib.items()}
 for s in body.findall('site'):site_bodies[s.get('name')]={'body':name,'local_position_native':[float(v) for v in s.get('pos','0 0 0').split()]}
 for b in body.findall('body'):visit(b)
visit(r.find('worldbody'))
tendons={t.get('name'):t for t in r.findall('tendon/spatial')}
records=[]
for a in r.findall('actuator/general'):
 name=a.get('name');t=tendons[a.get('tendon')];points=[]
 for x in t:
  if x.tag=='site':points.append({'site':x.get('site'),**site_bodies[x.get('site')]})
 records.append({'id':'LF:'+name,'upstream_name':name,'anatomical_side':'LF','granularity':'upstream representative muscle-tendon unit, not a motor unit','tendon':a.get('tendon'),'path':points,'actuator_attributes':a.attrib,'geometry_source':'upstream anatomical model; imported unchanged','force_law':'MuJoCo native muscle gain/bias, no Gaussian/Hill reimplementation','activation_dynamics':'MuJoCo native muscle dynamics, upstream per-actuator dynprm unchanged'})
manifest={'schema':'flymimic_adoption_v1','adoption_date':'2026-11-04','upstream_repository':'https://github.com/gizemozd/FlyMimic','upstream_commit':'9ea1131626cd76f7203b74076ef8f0e9cab30bef','upstream_xml_sha256':sha(assets/model),'adopted_xml_sha256':sha(p),'selected_xml':model,'selected_variant':'armature only; passive joint settings preserved as numerical modeling choices, not measured physiology','backend':'backend.py','runtime_python':'/workspace/fly-platforms/reproduction/venv-flymimic/bin/python','runtime_mujoco':'3.3.2','imported_MTU_count':len(records),'supported_native_coordinates':'LF 7 named hinge coordinates in upstream order','records':records,'body_frames':bodies,'unit_policy':{'default':'upstream native quantities, explicitly suffixed _native; no implicit SI conversion','reason':'XML geometry/gravity suggest mm-scale coordinates, but OpenSim labels say m/N; physical scaling must be separately audited before coupling to flybody','cross_model_torque_conversion':'not enabled'},'scope_limits':['Upstream left foreleg is operational; RF requires validated mirror/coordinate registration.','No upstream middle/hind-leg muscles are supplied.','No automatic fallback to old anatomical hypotheses.','Native model remains a fixed-body local limb system; this is not whole-body muscle walking.','Old 126-channel activations, torque fits, optimization and walking claims do not transfer to this backend.'],'old_hypothesis_model':'/workspace/flybrain-activation-inverse/optimization/optimized_geometry.json','selection_role':'new reference muscle backend; old model retained only as explicit legacy experiment'}
assert len(records)==15 and sha(assets/model)==sha(p)
(ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
selection={'schema':'muscle_model_selection_v1','selected_family':'FlyMimic','selected_backend':'/workspace/flybrain-activation-inverse/flymimic_adoption/backend.py','manifest':str(ROOT/'manifest.json'),'native_model':str(p),'operational_scope':['LF native 7-DoF foreleg'],'RF_status':'not registered; not silently mirrored','middle_hind_status':'not provided by upstream; historical models preserved, not claimed adopted','full_body_integration':'not ready: joint-frame and dimensional registration required','legacy_default_for_new_experiments':False}
Path('/workspace/flybrain-activation-inverse/muscle_model_selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2))
print('Imported',len(records),'MTUs with identical XML hash.')
