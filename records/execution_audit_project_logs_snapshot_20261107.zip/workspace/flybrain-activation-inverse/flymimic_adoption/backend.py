"""Exact upstream LF muscle mechanics in upstream coordinates and native units.

No implicit mapping from flybody coordinates or SI torques is allowed.
"""
from pathlib import Path
import json
import numpy as np
import mujoco
from scipy.optimize import lsq_linear

ROOT=Path(__file__).resolve().parent
JOINTS=('joint_LFCoxa_yaw','joint_LFCoxa_pitch','joint_LFCoxa_roll',
        'joint_LFTrochanter_yaw','joint_LFTrochanter_pitch',
        'joint_LFTrochanter_roll','joint_LFTibia_pitch')

class FlyMimicMuscles:
    def __init__(self, leg='LF'):
        if leg!='LF':
            raise NotImplementedError(f'{leg}: upstream anatomy/coordinate registration is unavailable; no implicit copy or legacy fallback.')
        if mujoco.__version__!='3.3.2':
            raise RuntimeError('Use pinned MuJoCo 3.3.2 runtime recorded in manifest.json.')
        meta=json.loads((ROOT/'manifest.json').read_text())
        self.model_path=ROOT/'models'/meta['selected_xml']
        self.model=mujoco.MjModel.from_xml_path(str(self.model_path))
        self.data=mujoco.MjData(self.model)
        ids=[mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_JOINT,n) for n in JOINTS]
        if min(ids)<0:raise ValueError('Missing upstream joint')
        self.qadr=self.model.jnt_qposadr[ids].copy()
        self.vadr=self.model.jnt_dofadr[ids].copy()
        self.muscle_names=tuple(mujoco.mj_id2name(self.model,mujoco.mjtObj.mjOBJ_ACTUATOR,i) for i in range(self.model.nu))
        if self.model.nu!=15 or self.model.na!=15:raise ValueError('Unexpected upstream actuator model')
        self.q_reference=self.model.qpos0.copy()
        self._work=mujoco.MjData(self.model)
        self._moment=np.empty((self.model.nu,self.model.nv))
        self.reset()

    @staticmethod
    def _array(x,n,name,bounds=None):
        x=np.asarray(x,dtype=np.float64)
        if x.shape!=(n,) or not np.all(np.isfinite(x)):raise ValueError(f'{name} must be a finite vector of shape ({n},)')
        if bounds and (np.any(x<bounds[0]) or np.any(x>bounds[1])):raise ValueError(f'{name} outside {bounds}')
        return x

    def _set_state(self,d,q,qdot,activation):
        q=self._array(q,7,'native joint angles');qdot=self._array(qdot,7,'native joint velocities')
        activation=self._array(activation,15,'activation',(0,1))
        mujoco.mj_resetData(self.model,d)
        d.qpos[:]=self.q_reference;d.qpos[self.qadr]=q;d.qvel[self.vadr]=qdot
        d.act[:]=activation
        mujoco.mj_forward(self.model,d)

    def reset(self,q=None,qdot=None,activation=None):
        if q is None:q=self.q_reference[self.qadr]
        if qdot is None:qdot=np.zeros(7)
        if activation is None:activation=np.zeros(15)
        self._set_state(self.data,q,qdot,activation)
        return self.observe()

    def observe(self):
        d=self.data
        return {'time_s':float(d.time),'joint_names':JOINTS,'muscle_names':self.muscle_names,
                'q_rad':d.qpos[self.qadr].copy(),'qdot_rad_s':d.qvel[self.vadr].copy(),
                'activation':d.act.copy(),'excitation':d.ctrl.copy(),
                'actuator_force_native':d.actuator_force.copy(),
                'muscle_torque_native':d.qfrc_actuator[self.vadr].copy(),
                'other_passive_torque_native':d.qfrc_passive[self.vadr].copy(),
                'path_length_native':d.actuator_length.copy(),
                'path_velocity_native_per_s':d.actuator_velocity.copy()}

    def evaluate(self,q,qdot,activation):
        """Stateless force evaluation; does not overwrite an ongoing rollout."""
        self._set_state(self._work,q,qdot,activation)
        d=self._work
        return {'muscle_torque_native':d.qfrc_actuator[self.vadr].copy(),
                'actuator_force_native':d.actuator_force.copy(),
                'path_length_native':d.actuator_length.copy(),
                'path_velocity_native_per_s':d.actuator_velocity.copy()}

    def affine(self,q,qdot):
        """Return exact same-state muscle torque tau = A @ activation + b.

        b contains the upstream muscle passive component, but excludes other
        joint passive forces, gravity, inertia and contact reactions.
        """
        self._set_state(self._work,q,qdot,np.zeros(15))
        d=self._work
        f0=d.actuator_force.copy();b=d.qfrc_actuator[self.vadr].copy()
        d.act[:]=1
        mujoco.mj_fwdActuation(self.model,d)
        gain=d.actuator_force-f0
        mujoco.mju_sparse2dense(self._moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind)
        A=self._moment[:,self.vadr].T*gain[None,:]
        return A,b

    def allocate(self,q,qdot,target_torque_native,scale_native=1.,ridge=1e-6):
        """Independent bounded activation inference in native coordinates.

        This estimates activation state, not excitation or firing rate. No
        temporal feasibility or physiological uniqueness is asserted.
        """
        target=self._array(target_torque_native,7,'target_torque_native')
        scale=float(scale_native);ridge=float(ridge)
        if not np.isfinite(scale) or scale<=0 or not np.isfinite(ridge) or ridge<0:raise ValueError('Invalid scale or ridge')
        A,b=self.affine(q,qdot)
        C=np.vstack((A/scale,np.sqrt(ridge)*np.eye(15)))
        y=np.r_[(target-b)/scale,np.zeros(15)]
        fit=lsq_linear(C,y,bounds=(0,1),method='bvls',tol=1e-10,max_iter=500)
        a=fit.x;prediction=A@a+b
        return {'activation':a,'predicted_torque_native':prediction,
                'residual_torque_native':prediction-target,'success':bool(fit.success),
                'status':int(fit.status),'A_native':A,'passive_muscle_torque_native':b}

    def step(self,excitation,substeps=20):
        """Advance upstream dynamics (normally 20 x 0.1ms = 2ms).

        Native actuator limits, including the 1e-4 control floor, are retained.
        No externally imposed target poses or residual torque is added.
        """
        u=self._array(excitation,15,'excitation',(0,1))
        if isinstance(substeps,bool) or not isinstance(substeps,(int,np.integer)) or substeps<1:raise ValueError('substeps must be a positive integer')
        self.data.ctrl[:]=u
        for _ in range(substeps):mujoco.mj_step(self.model,self.data)
        mujoco.mj_forward(self.model,self.data)
        if not np.all(np.isfinite(self.data.qpos)) or not np.all(np.isfinite(self.data.act)):raise FloatingPointError('Nonfinite muscle simulation')
        return self.observe()
