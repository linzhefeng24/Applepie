from pathlib import Path
import sys,json,hashlib
import numpy as np,mujoco
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from backend import FlyMimicMuscles
m=FlyMimicMuscles();source=next(Path('/workspace/fly-platforms/FlyMimic/code').iterdir());q=np.load(source/'flymimic/assets/mocap/qpos/0002.npy');v=np.load(source/'flymimic/assets/mocap/qvel/0002.npy')
rng=np.random.default_rng(42);errors=[];fd=[];power=[]
for i in np.linspace(0,len(q)-1,32,dtype=int):
 a=rng.uniform(0,1,15);A,b=m.affine(q[i],v[i]);native=m.evaluate(q[i],v[i],a)
 errors.append(float(np.max(np.abs(A@a+b-native['muscle_torque_native']))))
 # Check virtual work with actual transmission moment matrix (includes sign).
 d=m._work;moment=m._moment.copy();joint_power=float(d.qfrc_actuator@d.qvel);muscle_power=float(d.actuator_force@d.actuator_velocity);power.append(abs(joint_power-muscle_power))
 # Check that inference can explain a known feasible torque; no uniqueness claim.
 target=A@a+b;fit=m.allocate(q[i],v[i],target,scale_native=max(np.linalg.norm(target),1e-5),ridge=0)
 fd.append(float(np.linalg.norm(fit['residual_torque_native'])/max(np.linalg.norm(target),1e-8)))
 assert fit['success']
# Replay the previously evaluated official policy controls through adopted model.
orig=np.load('/workspace/fly-platforms/reproduction/flymimic/demo_model/rollout.npz');m.reset(q[0],v[0]);qs=[];acts=[]
for u in orig['control']:
 o=m.step(u);qs.append(o['q_rad']);acts.append(o['activation'])
qs=np.asarray(qs);acts=np.asarray(acts)
np.savez_compressed(ROOT/'adopted_demo_replay.npz',time_s=orig['time_s'],q_rad=qs,activation=acts,control=orig['control'],target_q_rad=orig['target_qpos_rad'])
unsupported=[]
for leg in ['RF','LM','RM','LH','RH']:
 try:FlyMimicMuscles(leg)
 except NotImplementedError:unsupported.append(leg)
meta=json.loads((ROOT/'manifest.json').read_text());h=hashlib.sha256((ROOT/'models'/meta['selected_xml']).read_bytes()).hexdigest()
report={'mujoco':mujoco.__version__,'muscle_count':15,'native_joint_count':7,'source_xml_identical':h==meta['upstream_xml_sha256'],'sampled_states':32,'affine_operator_max_abs_error_native':max(errors),'virtual_work_max_abs_error_native_per_s':max(power),'feasible_inverse_max_relative_residual':max(fd),'replayed_control_steps':len(qs),'replay_max_abs_q_error_rad':float(np.max(np.abs(qs-orig['qpos_rad']))),'replay_max_abs_activation_error':float(np.max(np.abs(acts-orig['activation']))),'tracking_rmse_deg':float(np.sqrt(np.mean((qs-orig['target_qpos_rad'])**2))*180/np.pi),'unsupported_legs_rejected':unsupported,'native_units_only':True}
report['passed']=bool(report['source_xml_identical'] and max(errors)<1e-8 and max(power)<1e-6 and max(fd)<1e-6 and report['replay_max_abs_q_error_rad']<1e-6 and len(unsupported)==5)
(ROOT/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['passed']
