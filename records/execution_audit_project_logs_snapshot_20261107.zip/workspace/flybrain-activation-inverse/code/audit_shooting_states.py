"""Offline contact/force audit of archived states. Never used to move the actual walker."""
import sys,pathlib,json,numpy as np,mujoco
from scipy.ndimage import median_filter
import shooting_mpc as s
out=pathlib.Path(sys.argv[1]);config=json.load(open(out/'config.json'));s.prepare_source(config.get('speed',1.));s.FAST=config.get('fast_force',False);z0=np.load(out/'rollout.npz');z={k:z0[k] for k in z0.files};m=s.m;d=mujoco.MjData(m);d.act[:]=s.src['act'][0]
# Filter activation states evolve only from ctrl in this model (filter/filterexact/none).
assert set(m.actuator_dyntype.tolist()) <= {0,2,3}
core={i for i in range(m.nbody) if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,i) or '').startswith(('walker/head','walker/abdomen','walker/thorax'))};ground={i for i in range(m.ngeom) if m.geom_bodyid[i]==0};tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];feet={}
for i in range(m.ngeom):
 name=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or ''
 if name.startswith('walker/') and any(k in name for k in ['tarsus','claw']):
  for j,tok in enumerate(tokens):
   if tok in name:feet[i]=j
supports=[];touches=[];torques=[];cf=np.zeros(6);native=0.;outside=0.
for t,a in enumerate(z['activation']):
 d.qpos[:]=z['qpos'][t];d.qvel[:]=z['qvel'][t];d.ctrl[:]=s.src['ctrl'][t];d.qacc_warmstart[:]=0
 f,x=s.forces(d,a);assert f is not None;d.qfrc_applied[:]=s.src['qfrc_applied'][t]+f;mujoco.mj_forward(m,d);native=max(native,float(np.max(np.abs(d.actuator_force[s.mask]))));ff=f.copy();ff[s.fw.dofs]=0;outside=max(outside,float(np.max(np.abs(ff))));support=np.zeros(6);touch=False
 for j in range(d.ncon):
  con=d.contact[j];g1,g2=int(con.geom1),int(con.geom2);other=g2 if g1 in ground else g1 if g2 in ground else None
  if other is None or con.efc_address<0:continue
  if int(m.geom_bodyid[other]) in core and con.dist<=0:touch=True
  if other in feet:mujoco.mj_contactForce(m,d,j,cf);support[feet[other]]+=max(0.,cf[0])
 supports.append(support);touches.append(touch);torques.append(f[s.fw.dofs]*1e-7)
 # Advance filter states one physical step; next archived pose overrides ONLY in this offline audit.
 mujoco.mj_step(m,d)
stance=median_filter(np.array(supports)>m.body_subtreemass[s.thorax]*np.linalg.norm(m.opt.gravity)*.01,size=(25,1),mode='nearest');late=stance[len(stance)//4:];cycle=np.sum(late[1:]!=late[:-1],axis=0);duty=late.mean(axis=0);r={'audit_only_archived_states':True,'warmstart_for_contact_audit':'zero','body_ground_samples':sum(touches),'foot_contact_transitions_late':cycle.tolist(),'foot_support_fraction_late':duty.tolist(),'native_leg_force_max':native,'muscle_force_outside_legs_max_native':outside,'activation_bounds_pass':bool(np.all((z['activation']>=0)&(z['activation']<=1))),'fiber_range':[float(z['fiber_min_norm'].min()),float(z['fiber_max_norm'].max())]}
r['normal_walk_checks']=bool(len(z['time_s'])>=30000 and z['up_z'].min()>.7 and not any(touches) and z['thorax_mm'][-1,0]-z['thorax_mm'][0,0]>10 and np.all((cycle>=2)&(duty>.01)&(duty<.99)))
np.savez_compressed(out/'state_audit.npz',support_native=supports,body_ground=touches,leg_torque_Nm=torques);json.dump(r,open(out/'state_audit.json','w'),indent=2);print(json.dumps(r,indent=2))
