import os;os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/workspace/fly-walking-run/mesa',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
import pathlib,json,subprocess,numpy as np,mujoco
from PIL import Image,ImageDraw,ImageFont
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'multitrajectory_ab_20261104';refs=json.load(open(O/'references.json'));panels=[]
for ident,profile,it in [('speed0.5_seed2','torque_first',1),('speed0.75_seed5','balanced',2)]:
 ref=next(r for r in refs if r['id']==ident);s=np.load(ref['source']);panels.append(dict(q=s['qpos'],t=s['time_s'],title=f"参考：{ref['speed']:g} cm/s",note='原生执行器参考，已验证行走',reference=True))
 for method in ['A','B']:
  folder=O/'full'/f'{ident}_{method}_{profile}_it{it}';z=np.load(folder/'rollout.npz');r=json.load(open(folder/'report.json'));panels.append(dict(q=z['qpos'],t=z['time_s'],title=method+'：力矩＋关节'+('＋足端' if method=='B' else '＋身体'),note=f"停止 {r['duration_s']:.2f}s；位移 {r['forward_along_reference_mm']:.2f}mm",reference=False,report=r))
m=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m);m.vis.quality.shadowsize=256;m.vis.quality.offsamples=0
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
renderer=mujoco.Renderer(m,width=400,height=300);option=mujoco.MjvOption();option.sitegroup[:]=0;option.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;font={s:ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',s) for s in [13,15,18]};out=O/'multitrajectory_AB_not_walking_20261104.mp4';writer=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1200x600','-r','25','-i','-','-an','-c:v','libx264','-preset','fast','-bf','0','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
for frame in range(150):
 t=frame/25;images=[]
 for p in panels:
  idx=min(round(t/.0002),len(p['q'])-1);d.qpos[:]=p['q'][idx];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_camlight(m,d);renderer.update_scene(d,camera=1,scene_option=option);renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW]=False;renderer.scene.flags[mujoco.mjtRndFlag.mjRND_REFLECTION]=False;images.append(renderer.render().copy())
 im=Image.fromarray(np.concatenate([np.concatenate(images[:3],axis=1),np.concatenate(images[3:],axis=1)],axis=0));draw=ImageDraw.Draw(im)
 for k,p in enumerate(panels):
  x=(k%3)*400;y=(k//3)*300;draw.rectangle((x,y,x+400,y+57),fill='black');draw.rectangle((x,y+240,x+400,y+300),fill='black');stopped=t>=float(p['t'][-1])+.0002;status='已停止，显示末帧' if stopped else '实际仿真时间，1×播放';texts=[(p['title'],3,18,'white'),(p['note'],31,13,'yellow'),(f"t={min(t,float(p['t'][-1])):.3f} s；"+('参考' if p['reference'] else '未通过正常步行验收'),244,15,'white'),(status,275,13,'orange' if stopped else 'white')]
  for text,dy,sz,color in texts:
   bb=draw.textbbox((0,0),text,font=font[sz]);draw.text((x+(400-bb[2]+bb[0])/2,y+dy),text,font=font[sz],fill=color)
 writer.stdin.write(np.asarray(im).tobytes())
 if frame==25:im.save(O/'comparison_preview.png')
writer.stdin.close();assert writer.wait()==0;renderer.close();(O/'video_provenance.json').write_text(json.dumps({'fps':25,'frames':150,'playback_speed':1,'duration_s':6,'all_states_archived_free_simulations':True,'stopped_panels_held_and_marked':True,'body_and_muscle_physics_not_modified_for_rendering':True},indent=2));print('VIDEO READY',out)
