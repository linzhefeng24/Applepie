import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import json,numpy as np,mujoco,time
import forward_walk_test as fw
from test_feedback_walk import groups
from contact_controller import ContactMuscleController
m=mujoco.MjModel.from_binary_path(str(fw.R/'optimization/optimized_geometry.mjb'));m.actuator_gainprm[fw.src['joint_actuator_mask']]=0;m.actuator_biasprm[fw.src['joint_actuator_mask']]=0;d=mujoco.MjData(m);source=dict(fw.src,qacc=fw.raw['qacc']);control=ContactMuscleController(m,source,fw.rows,fw.dofs,groups,fw.activation,body_weight=5,iterations=2);records=[]
old=np.load(fw.R/'feedback_test/muscle_pd_w1000_z0.5_plain_rollout.npz')
for t,off in [(0,False),(100,False),(5000,False),(5000,True),(15000,True)]:
 d.qpos[:]=old['qpos'][t] if off else source['qpos'][t];d.qvel[:]=old['qvel'][t] if off else source['qvel'][t];d.ctrl[:]=source['ctrl'][t];d.act[:]=source['act'][t];d.qfrc_applied[:]=0;mujoco.mj_forward(m,d);before=[d.qpos.copy(),d.qvel.copy(),d.qfrc_applied.copy(),d.time];a,r=control.solve(d,t);assert np.array_equal(before[0],d.qpos) and np.array_equal(before[1],d.qvel) and np.array_equal(before[2],d.qfrc_applied) and before[3]==d.time;assert np.all((a>=0)&(a<=1));assert r['final_native_acceleration_cost']<=r['initial_native_acceleration_cost']+1e-8;rec={k:v for k,v in r.items() if not isinstance(v,np.ndarray)};rec.update(frame=t,off_reference=off);records.append(rec);print(json.dumps(rec),flush=True)
json.dump(records,open(fw.R/'contact_feedback/controller_frame_validation.json','w'),indent=2)
