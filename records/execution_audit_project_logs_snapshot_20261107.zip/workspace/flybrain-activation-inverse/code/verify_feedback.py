import pathlib,json,subprocess,numpy as np,mujoco
import forward_walk_test as fw
O=fw.R/'feedback_test';names=['muscle_pd_w1000_z0.5_plain','torque_pd_w1000_z1_plain'];results={}
for name in names:
 z=np.load(O/(name+'_rollout.npz'));r=json.load(open(O/(name+'_report.json')));assert len(z['time_s'])==30000;assert np.all(np.isfinite(z['qpos']));assert np.all(np.isfinite(z['qvel']));assert r['disabled_native_leg_force_max']==0;assert r['failure'] is None
 if name.startswith('muscle'):assert np.all((z['activation']>=0)&(z['activation']<=1))
 m=mujoco.MjModel.from_binary_path(str(fw.R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m);thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');weight=m.body_subtreemass[thorax]*np.linalg.norm(m.opt.gravity)
 from scipy.ndimage import median_filter
 foot=median_filter(z['support_dyne']>weight*.01,size=(25,1),mode='nearest');late=foot[z['time_s']>=1]
 results[name]={'six_seconds_finite':True,'native_leg_drives_zero':True,'late_foot_contact_fraction':late.mean(axis=0).tolist(),'late_contact_transitions':np.sum(late[1:]!=late[:-1],axis=0).tolist(),'source_control_timestep_s':.001,'walking_check':r['passes_walking_checks']}
 if name.startswith('muscle'):
  q=z['qpos'];v=z['qvel'];a=z['activation'];actual=z['actual_torque_Nm'];dense=np.empty((m.ntendon,m.nv));error=0.;outside=0.
  for t in np.random.default_rng(2).choice(len(q),16,replace=False):
   d.qpos[:]=q[t];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));J=dense[fw.tid];fiber=d.ten_length[fw.tid]*.01-fw.slack;assert np.all(fiber>0);x=fiber/fw.l0;vn=(J@v[t]*.01)/(fw.l0*fw.vmax);neg=np.minimum(vn,0);pos=np.maximum(vn,0);fv=np.where(vn<0,np.maximum(0,(1+neg)/(1-neg/fw.hill)),1+(fw.ecc-1)*pos/(fw.hill+pos));cap=fw.F0*np.exp(-((x-1)/fw.width)**2)*fv;fp=fw.F0*np.expm1(np.clip(fw.shape*np.maximum(x-fw.ps,0)/fw.strain,0,30))/np.expm1(fw.shape);general=-(J.T@((fp+a[t]*cap)*1e5));error=max(error,float(np.max(np.abs(general[fw.dofs]*1e-7-actual[t]))));outside=max(outside,float(np.max(np.abs(np.delete(general,fw.dofs)))))
  assert error<1e-14;assert outside<1e-10;results[name]['live_force_recheck_max_error_Nm']=error;results[name]['muscle_generalized_force_outside_leg_dofs_max_native']=outside;results[name]['all_activations_in_0_1']=True
p=O/'fly_feedback_comparison_20261102.mp4';media=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate,nb_frames,duration','-of','json',str(p)]))['streams'][0];assert int(media['nb_frames'])==300;assert abs(float(media['duration'])-6)<1e-6;results['video']=media;json.dump(results,open(O/'verification.json','w'),indent=2);print(json.dumps(results,indent=2))
