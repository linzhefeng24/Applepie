import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import pathlib,sys,json,argparse
import test_feedback_walk as fb
P=fb.fw.R/'gain_search';p=argparse.ArgumentParser();p.add_argument('id',type=int);p.add_argument('--render',action='store_true');a=p.parse_args();c=next(c for c in json.load(open(P/'plan.json'))['configs'] if c['id']==a.id);fb.O=P/('final_video' if a.render else 'full_validation');fb.O.mkdir(exist_ok=True)
r=fb.run('muscle_pd',c['omega'],c['zeta'],duration=6,render=a.render,early_stop=False,control_steps=c['control_steps'],save_rollout=True);r['config']=c;r['contact_statistics_revision']=2;(fb.O/f'candidate_{a.id}.json').write_text(json.dumps(r,indent=2))
