import pathlib,json,csv
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=pathlib.Path('/workspace/flybrain-activation-inverse');z=np.load(R/'output/activation_6s_5000Hz.npz');b=np.load(R/'output/forward_blocks.npz');meta=json.load(open(R/'model/geometry.json'));report=json.load(open(R/'output/report.json'));a=z['activation'];ids=z['muscle_ids'];t=z['time_s'];legs=['LF','RF','LM','RM','LH','RH'];gain=np.zeros(126);unsupported=[];rank={}
for leg in legs:
 B=b[leg];j=b[leg+'_joint_indices'];k=b[leg+'_muscle_indices'];gain[k]=np.sqrt(np.mean(B.astype(float)**2,axis=(0,1)));rms=np.sqrt(np.mean(B.astype(float)**2,axis=(0,2)));unsupported.extend(z['joint_names'][j[rms<1e-10]].tolist());rank[leg]=[int(np.linalg.matrix_rank(B[i],tol=1e-7)) for i in [0,len(t)//2,len(t)-1]]
target=z['target_torque_Nm']*1e9;pred=z['predicted_torque_Nm']*1e9;lower=np.zeros_like(target);upper=np.zeros_like(target)
for leg in legs:
 B=b[leg];j=b[leg+'_joint_indices'];k=b[leg+'_muscle_indices'];p=pred[:,j]-np.einsum('tjk,tk->tj',B,a[:,k]);lower[:,j]=p+np.minimum(B,0).sum(axis=2);upper[:,j]=p+np.maximum(B,0).sum(axis=2)
frame_relative=np.linalg.norm(pred-target,axis=1)/np.maximum(np.linalg.norm(target,axis=1),1e-12)
np.savez_compressed(R/'output/frame_quality.npz',time_s=t,relative_torque_residual=frame_relative,within_10pct_torque_error=frame_relative<=.1,component_feasible_lower_uN_mm=lower,component_feasible_upper_uN_mm=upper)
report['fraction_frames_within_10pct_torque_error']=float(np.mean(frame_relative<=.1));report['fraction_joint_samples_outside_component_feasible_bounds']=float(np.mean((target<lower-1e-6)|(target>upper+1e-6)));report['unsupported_joint_dofs']=unsupported;report['sample_matrix_rank_per_leg']=rank;report['zero_capacity_muscle_columns']=ids[gain<1e-10].tolist();json.dump(report,open(R/'output/report.json','w'),indent=2)
with open(R/'output/muscle_summary.csv','w') as f:
 w=csv.writer(f);w.writerow(['id','mean_activation','max_activation','fraction_at_1','torque_column_rms_uN_mm','zero_column_unidentifiable','function_hypothesis','missing_claw_dof'])
 for i,r in enumerate(meta['records']):w.writerow([r['id'],float(a[:,i].mean()),float(a[:,i].max()),float(np.mean(a[:,i]>.999999)),gain[i],gain[i]<1e-10,r['function_hypothesis'],r['long_tendon_claw_dof_missing']])
fig,ax=plt.subplots(3,1,figsize=(13,9),constrained_layout=True)
im=ax[0].imshow(a[::10].T,aspect='auto',origin='lower',extent=[t[0],t[-1],0,126],vmin=0,vmax=1,cmap='viridis');ax[0].set_ylabel('Muscle catalogue index');ax[0].set_title('Conditional muscle activation: fixed geometry hypothesis');fig.colorbar(im,ax=ax[0],label='a')
target=z['target_torque_Nm']*1e9;res=z['residual_torque_Nm']*1e9
ax[1].plot(t[::10],np.sqrt(np.mean(target**2,axis=1))[::10],label='Target RMS');ax[1].plot(t[::10],np.sqrt(np.mean(res**2,axis=1))[::10],label='Residual RMS');ax[1].legend();ax[1].set_ylabel('Torque (uN mm)')
idx=[list(ids).index('LF:'+x) for x in ['tibia_extensor','tibia_flexor','trochanter_extensor','trochanter_flexor']]
for i in idx:ax[2].plot(t[::10],a[::10,i],label=ids[i])
ax[2].legend(ncol=2);ax[2].set_ylabel('Activation');ax[2].set_xlabel('Recorded time (s)');fig.savefig(R/'output/activation_overview.png',dpi=150)
print(json.dumps(report,indent=2))
