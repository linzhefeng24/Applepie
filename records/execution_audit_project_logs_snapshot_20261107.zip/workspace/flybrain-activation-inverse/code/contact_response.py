"""Native MuJoCo soft-contact local response, including elliptic friction cones.
At fixed q,v: M a + h = u + J.T lambda(a), d lambda = -H J d a.
Thus d a = inv(M + J.T H J) d u, d lambda = -H J d a.
No predicted contact force is applied externally.
"""
import numpy as np,mujoco
from scipy.linalg import cho_factor,cho_solve

def constraint_jacobian(m,d):
 J=np.empty((d.nefc,m.nv))
 if mujoco.mj_isSparse(m):mujoco.mju_sparse2dense(J,d.efc_J.reshape(-1),d.efc_J_rownnz,d.efc_J_rowadr,d.efc_J_colind.reshape(-1))
 else:J[:]=d.efc_J.reshape(d.nefc,m.nv)
 return J

def response(m,d):
 """Requires mj_forward with the actual baseline applied force already present."""
 J=constraint_jacobian(m,d);jar=J@d.qacc-d.efc_aref
 mujoco.mj_constraintUpdate(m,d,jar,None,1)
 state=d.efc_state.copy();H=np.diag(np.where(state==int(mujoco.mjtConstraintState.mjCNSTRSTATE_QUADRATIC),d.efc_D,0.))
 for i in range(d.ncon):
  c=d.contact[i];a=int(c.efc_address);dim=int(c.dim)
  if a>=0 and int(state[a])==int(mujoco.mjtConstraintState.mjCNSTRSTATE_CONE):H[a:a+dim,a:a+dim]=np.asarray(c.H).reshape(-1)[:dim*dim].reshape(dim,dim)
 M=np.empty((m.nv,m.nv));mujoco.mj_fullM(m,M,d.qM);K=M+J.T@H@J;K=(K+K.T)/2;chol=cho_factor(K,lower=True,check_finite=False);P=cho_solve(chol,np.eye(m.nv),check_finite=False)
 return {'J':J,'H':H,'M':M,'P':P,'contact_force_sensitivity':-H@J@P,'lambda0':d.efc_force.copy(),'qacc0':d.qacc.copy(),'state':state,'type':d.efc_type.copy(),'jar':jar,'chol':chol}
