"""Independent native-MuJoCo checks of calibrated geometry and complete labels."""
import pathlib,json,hashlib
import numpy as np,mujoco
from invert import allocate
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'optimization';out=O/'full_trajectory';g=json.load(open(O/'optimized_geometry.json'));rows=g['records'];details=np.load(O/'geometry_constraint_details.npz');src=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');z={k:v for k,v in np.load(out/'activation_6s_5000Hz.npz').items()};report=json.load(open(out/'report.json'));a=z['activation'];assert np.all((a>=0)&(a<=1));assert np.all(z['solver_status']>0);np.testing.assert_array_equal(z['target_torque_Nm'],src['leg_tau_drive_Nm']);np.testing.assert_array_equal(z['time_s'],src['time_s']);assert report['fiber_length_nonpositive_count']==0;assert report['finite_difference_tendon_derivative_max_abs_cm_per_rad']<1e-6;assert report['source_sha256_before']==report['source_sha256_after']
# Convex local mesh-region membership, not merely a free-space distance check.
v=np.load(O/'best_variables.npz');logits=v['attachment_logits'];weights=np.exp(logits-logits.max(axis=1,keepdims=True));weights/=weights.sum(axis=1,keepdims=True);points=np.sum(weights[:,:,None]*details['candidate_points_m'],axis=1);np.testing.assert_allclose(points,details['points_m'],atol=1e-15);displacement=np.linalg.norm(points-details['point0_m'],axis=1);assert np.all(displacement<=details['point_radius_m']+1e-14)
m=mujoco.MjModel.from_binary_path(str(O/'optimized_geometry.mjb'));d=mujoco.MjData(m);d.qpos[:]=src['qpos'][0];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);dense=np.empty((m.ntendon,m.nv));mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));names=src['joint_names'].tolist();dofs=src['joint_dof_indices'];tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];legs=['LF','RF','LM','RM','LH','RH'];cols=[np.array([i for i,n in enumerate(names) if n.endswith(tok)]) for tok in tokens];mi=[np.array([i for i,r in enumerate(rows) if r['leg']==leg]) for leg in legs];angles=[];p=0
for i,r in enumerate(rows):
 orig=[];new=[]
 for s in r['points']:
  bid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,s['body']);rot=d.xmat[bid].reshape(3,3);orig.append(rot@details['point0_m'][p]+d.xpos[bid]*.01);new.append(rot@points[p]+d.xpos[bid]*.01);p+=1
 for u,w in zip(np.diff(orig,axis=0),np.diff(new,axis=0)):
  angles.append(float(np.degrees(np.arccos(np.clip(u@w/np.linalg.norm(u)/np.linalg.norm(w),-1,1)))))
 assert np.isclose(r['F0_N'],r['muscle_volume_m3']/r['fiber_length0_m']*r['specific_stress_Pa'],rtol=1e-12)
 if details['known_action'][i]:
  leg=legs.index(r['leg']);k=details['primary_joint'][i];assert -dense[r['tendon_index'],dofs[cols[leg][k]]]*details['primary_sign'][i]>=-1e-11
assert max(angles)<=30+1e-8
# Recompute constitutive forces and allocations at shuffled complete-trajectory states.
tid=np.array([r['tendon_index'] for r in rows]);get=lambda key:np.array([r[key] for r in rows]);l0=get('fiber_length0_m');slack=get('tendon_slack_length_m');F0=get('F0_N');vmax=get('vmax_L0_per_s');width=get('force_length_width');hill=get('force_velocity_hill_shape');ecc=get('eccentric_cap');ps=get('passive_slack_normalized');strain=get('passive_strain_at_F0');shape=get('passive_exponent');Q=src['qpos'];V=src['qvel'];srctorque=src['leg_tau_drive_Nm'];maxa=0.;maxforward=0.
for t in np.random.default_rng(3).choice(len(a),24,replace=False):
 d.qpos[:]=Q[t];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));J=dense[tid];moment=-J[:,dofs].T*.01;x=(d.ten_length[tid]*.01-slack)/l0;vn=(J@V[t]*.01)/(l0*vmax);neg=np.minimum(vn,0);pos=np.maximum(vn,0);fv=np.where(vn<0,np.maximum(0,(1+neg)/(1-neg/hill)),1+(ecc-1)*pos/(hill+pos));cap=F0*np.exp(-((x-1)/width)**2)*fv;fp=F0*np.expm1(np.clip(shape*np.maximum(x-ps,0)/strain,0,30))/np.expm1(shape);A=moment*cap[None,:]*1e9;passive=moment@fp*1e9;pred=passive+A@a[t];maxforward=max(maxforward,float(np.max(np.abs(pred-z['predicted_torque_Nm'][t]*1e9))))
 for k,(j,indices) in enumerate(zip(cols,mi)):
  new,_,_=allocate(A[np.ix_(j,indices)],srctorque[t,j]*1e9-passive[j],report['torque_scale_uN_mm_per_leg'][k]);maxa=max(maxa,float(np.max(np.abs(new-a[t,indices]))))
assert maxa<1e-5,maxa;assert maxforward<1e-4,maxforward
res=z['residual_torque_Nm'];target=z['target_torque_Nm'];spl=np.load(O/'frame_split.npz');spliterrors={}
for split in ['train','validation','test']:
 idx=spl[split+'_frames'];spliterrors[split]=float(np.linalg.norm(res[idx])/np.linalg.norm(target[idx]));assert abs(spliterrors[split]-g[split+'_relative_residual'])<1e-6
fullframe=np.linalg.norm(res,axis=1)/np.maximum(np.linalg.norm(target,axis=1),1e-30)
result={'source_targets_match_bitwise':True,'solver_bounds_and_success_pass':True,'all_30000_frames_have_positive_fiber_lengths':True,'derived_F0_identity_pass':True,'mesh_region_convex_membership_pass':True,'max_reference_segment_angle_change_deg':max(angles),'known_reference_action_signs_pass':True,'max_point_displacement_m':float(displacement.max()),'native_forward_recheck_max_error_uN_mm':maxforward,'independent_shuffled_resolve_max_activation_error':maxa,'train_validation_test_native_residual':spliterrors,'full_relative_residual':report['relative_residual_L2'],'fraction_full_frames_within_10pct_error':float(np.mean(fullframe<=.1))}
json.dump(result,open(O/'verification.json','w'),indent=2);print(json.dumps(result,indent=2))
