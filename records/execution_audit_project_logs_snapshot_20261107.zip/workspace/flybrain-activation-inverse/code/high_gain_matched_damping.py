import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import json,numpy as np
from scipy.optimize import lsq_linear
import high_gain_search as hs
fb=hs.fb;O=hs.O;fb.O=O/'matched_damping';fb.O.mkdir(exist_ok=True)
def precise(A,b,scale,ridge=1e-6):
 n=A.shape[1];C=np.vstack([A/scale,np.sqrt(ridge)*np.eye(n)]);y=np.r_[b/scale,np.zeros(n)];fit=lsq_linear(C,y,bounds=(0,1),method='bvls',tol=1e-12,max_iter=500);return np.clip(fit.x,0,1),fit.optimality,fit.status
fb.allocate=precise
configs=[]
for w in [8000,12000,20000,40000,80000]:
 for step in [5,1]:configs.append(dict(omega=w,zeta=w/2000,control_steps=step,id=30+len(configs),gain_family='constant_Kd_over_Kp_0.001s'))
(O/'matched_damping_plan.json').write_text(json.dumps(configs,indent=2));records=[]
for c in configs:
 r=fb.run('muscle_pd',c['omega'],c['zeta'],duration=.8,control_steps=c['control_steps']);r['config']=c;r['allocation_tolerance']=1e-12;records.append(r);(O/'matched_damping_results.json').write_text(json.dumps(records,indent=2));print('MATCHED',json.dumps(r),flush=True)
