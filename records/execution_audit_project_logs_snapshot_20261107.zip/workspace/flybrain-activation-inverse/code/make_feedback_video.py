import pathlib,json,subprocess
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'feedback_test';font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
inputs=[R/'forward_test/muscle_raw.mp4',O/'muscle_pd_w1000_z0.5_plain_raw.mp4',O/'torque_pd_w1000_z1_plain_raw.mp4'];headers=['肌肉开环重放','肌肉约束＋轨迹反馈','直接力矩＋轨迹反馈（对照）'];verdict=['约 0.16 s 后倒地','保持直立，但未持续行走','持续行走 6 s'];details=['净位移 1.56 mm','净位移 5.06 mm','净位移 105.77 mm'];filters=[]
for i in range(3):
 def text(s,y,size=23,color='white'):return f"drawtext=fontfile={font}:text='{s}':x=(w-tw)/2:y={y}:fontsize={size}:fontcolor={color}:shadowcolor=black:shadowx=1:shadowy=1"
 f=f'[{i}:v]fps=50,tpad=stop_mode=clone:stop_duration=0.04,settb=expr=1/50,setpts=N,drawbox=x=0:y=0:w=iw:h=52:color=black@0.75:t=fill,'+text(headers[i],14)+','+text(verdict[i],410,22,'lime' if i==2 else 'yellow')+','+text(details[i],447,21)+f'[v{i}]';filters.append(f)
filters.append('[v0][v1][v2]hstack=inputs=3[v]');args=['ffmpeg','-hide_banner','-loglevel','error','-y']
for p in inputs:args+=['-i',str(p)]
args+=['-filter_complex',';'.join(filters),'-map','[v]','-r','50','-frames:v','300','-an','-c:v','libx264','-preset','fast','-bf','0','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'fly_feedback_comparison_20261102.mp4')];subprocess.run(args,check=True)
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss','1','-i',str(O/'fly_feedback_comparison_20261102.mp4'),'-frames:v','1',str(O/'feedback_preview.png')],check=True)
print('Feedback comparison video generated')
