"""Free forward dynamics: original torque replay versus live-state muscle forces.
No walker state restoration, trajectory tracking controller, or residual torque rescue.
"""
import os
os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/workspace/fly-walking-run/mesa',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
import pathlib,json,time,subprocess,hashlib
import numpy as np,mujoco
from scipy.ndimage import median_filter
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'forward_test';O.mkdir(exist_ok=True);S=pathlib.Path('/workspace/fly-walking-run/output');raw=np.load(S/'walking_6s_5000Hz.npz');keys=['time_s','qpos','qvel','ctrl','act','qacc_warmstart','qfrc_applied','leg_tau_drive_Nm','joint_dof_indices','joint_actuator_mask'];src={k:raw[k] for k in keys};N=len(src['time_s']);dofs=src['joint_dof_indices'];mus=np.load(R/'optimization/full_trajectory/activation_6s_5000Hz.npz');activation=mus['activation'];rows=json.load(open(R/'optimization/optimized_geometry.json'))['records'];WIDTH=640;HEIGHT=480;FPS=50
get=lambda k:np.array([r[k] for r in rows]);l0=get('fiber_length0_m');slack=get('tendon_slack_length_m');F0=get('F0_N');vmax=get('vmax_L0_per_s');width=get('force_length_width');hill=get('force_velocity_hill_shape');ecc=get('eccentric_cap');ps=get('passive_slack_normalized');strain=get('passive_strain_at_F0');shape=get('passive_exponent');tid=np.array([r['tendon_index'] for r in rows]);dt=float(src['time_s'][1]-src['time_s'][0]);assert dt==.0002

def video_writer(path):return subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{WIDTH}x{HEIGHT}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p',str(path)],stdin=subprocess.PIPE)

def run(mode):
 m=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb' if mode=='muscle' else S/'model/walking.mjb'));d=mujoco.MjData(m)
 for i in range(m.ngeom):
  if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
 # Remove only native LEG actuator forces; keep head/abdomen servos and contact-dependent adhesion.
 mask=src['joint_actuator_mask'];m.actuator_gainprm[mask]=0;m.actuator_biasprm[mask]=0
 d.qpos[:]=src['qpos'][0];d.qvel[:]=src['qvel'][0];d.act[:]=src['act'][0];d.ctrl[:]=src['ctrl'][0];d.qacc_warmstart[:]=src['qacc_warmstart'][0];d.time=src['time_s'][0]
 thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');ghost=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'ghost/');ga=int(m.jnt_qposadr[ghost]);gv=int(m.jnt_dofadr[ghost]);ground={i for i in range(m.ngeom) if m.geom_bodyid[i]==0};geom_leg={};tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right']
 for i in range(m.ngeom):
  name=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or ''
  if name.startswith('walker/') and any(s in name for s in ['tarsus','claw']):
   for k,tok in enumerate(tokens):
    if tok in name:geom_leg[i]=k
 renderer=mujoco.Renderer(m,height=HEIGHT,width=WIDTH);option=mujoco.MjvOption();option.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;option.sitegroup[:]=0
 writer=video_writer(O/(mode+'_raw.mp4'));dense=np.empty((m.ntendon,m.nv));cf=np.zeros(6);logs={k:[] for k in ['time_s','qpos','qvel','thorax_mm','up_z','thorax_ground','support_dyne','leg_torque_Nm','angle_error_rms_rad']};failure=None;lastframe=None;start=time.time();initial_force_error=None;maxlegnative=0.;warning_initial=np.array([w.number for w in d.warning]);frame_count=0
 mujoco.mj_forward(m,d)
 for t in range(N):
  if failure is None:
   # Only the non-colliding reference ghost receives prescribed poses, as in source task.
   if t%10==0:d.qpos[ga:ga+7]=src['qpos'][t,ga:ga+7];d.qvel[gv:gv+6]=src['qvel'][t,gv:gv+6]
   d.ctrl[:]=src['ctrl'][t];d.qfrc_applied[:]=src['qfrc_applied'][t];mujoco.mj_forward(m,d)
   maxlegnative=max(maxlegnative,float(np.max(np.abs(d.actuator_force[mask]))))
   if mode=='torque':
    applied=src['leg_tau_drive_Nm'][t];d.qfrc_applied[dofs]+=applied/1e-7
   else:
    mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));J=dense[tid];fiber=d.ten_length[tid]*.01-slack;x=fiber/l0
    if np.any(fiber<=0):failure={'time_s':float(d.time),'reason':'nonpositive fiber length: rigid-tendon muscle model outside valid domain','muscles':[rows[i]['id'] for i in np.flatnonzero(fiber<=0)]}
    else:
     vn=(J@d.qvel*.01)/(l0*vmax);neg=np.minimum(vn,0);pos=np.maximum(vn,0);fv=np.where(vn<0,np.maximum(0,(1+neg)/(1-neg/hill)),1+(ecc-1)*pos/(hill+pos));cap=F0*np.exp(-((x-1)/width)**2)*fv;fp=F0*np.expm1(np.clip(shape*np.maximum(x-ps,0)/strain,0,30))/np.expm1(shape);force=fp+activation[t]*cap;generalized=-(J.T@(force*1e5));d.qfrc_applied[:]+=generalized;applied=generalized[dofs]*1e-7
     if t==0:initial_force_error=float(np.max(np.abs(applied-mus['predicted_torque_Nm'][0])))
   if failure is None:
    # State is sampled BEFORE integration, exactly as the source torque recording.
    support=np.zeros(6);touch=False
    for c in range(d.ncon):
     con=d.contact[c];g1,g2=int(con.geom1),int(con.geom2);other=g2 if g1 in ground else g1 if g2 in ground else None
     if other is None or con.efc_address<0:continue
     if int(m.geom_bodyid[other])==thorax:touch=True
     if other in geom_leg:mujoco.mj_contactForce(m,d,c,cf);support[geom_leg[other]]+=max(0.,cf[0])
    vals=dict(time_s=float(d.time),qpos=d.qpos.copy(),qvel=d.qvel.copy(),thorax_mm=d.xpos[thorax]*10,up_z=float(d.xmat[thorax].reshape(3,3)[2,2]),thorax_ground=touch,support_dyne=support,leg_torque_Nm=applied.copy(),angle_error_rms_rad=float(np.sqrt(np.mean((d.qpos[raw['joint_qpos_indices']]-src['qpos'][t,raw['joint_qpos_indices']])**2))))
    for k,v in vals.items():logs[k].append(v)
    mujoco.mj_step(m,d)
    badwarn=any(d.warning[i].number>warning_initial[i] for i in [int(mujoco.mjtWarning.mjWARN_BADQPOS),int(mujoco.mjtWarning.mjWARN_BADQVEL),int(mujoco.mjtWarning.mjWARN_BADQACC)])
    if badwarn or not np.all(np.isfinite(d.qpos)) or not np.all(np.isfinite(d.qvel)):failure={'time_s':float(d.time),'reason':'numerical instability / MuJoCo bad-state warning'}
  if t%100==9:
   if failure is None or lastframe is None:
    mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=option);lastframe=renderer.render().copy()
   writer.stdin.write(lastframe.tobytes());frame_count+=1
  if t%5000==0:print(mode,t,'xyz_mm',d.xpos[thorax]*10,'failure',failure,flush=True)
 writer.stdin.close();assert writer.wait()==0;renderer.close();arr={k:np.asarray(v) for k,v in logs.items()};np.savez_compressed(O/(mode+'_rollout.npz'),**arr)
 xyz=arr['thorax_mm'];up=arr['up_z'];weight=float(m.body_subtreemass[thorax]*np.linalg.norm(m.opt.gravity));support=median_filter(arr['support_dyne']>weight*.01,size=(25,1),mode='nearest');transitions=np.sum(support[1:]!=support[:-1],axis=0);ground_arr=arr['thorax_ground'];fallen=(up<.5)|ground_arr;fallidx=np.flatnonzero(np.convolve(fallen.astype(int),np.ones(25,dtype=int),mode='valid')>=25) if len(fallen)>=25 else []
 displacement=float(np.linalg.norm(xyz[-1,:2]-xyz[0,:2]));duration=float(len(xyz)*dt);stats={'mode':mode,'simulated_duration_s':duration,'scheduled_duration_s':6.,'failure':failure,'first_sustained_fall_s':float(arr['time_s'][fallidx[0]]) if len(fallidx) else None,'displacement_xy_mm':displacement,'path_xy_mm':float(np.linalg.norm(np.diff(xyz[:,:2],axis=0),axis=1).sum()),'min_thorax_up_z':float(up.min()),'upright_fraction':float(np.mean(up>.7)),'min_thorax_height_mm':float(xyz[:,2].min()),'thorax_ground_contact_samples':int(ground_arr.sum()),'foot_contact_transitions':transitions.tolist(),'foot_support_fraction':float(np.mean(np.any(support,axis=1))),'mean_angle_error_rms_rad':float(np.mean(arr['angle_error_rms_rad'])),'max_disabled_leg_actuator_force_native':maxlegnative,'initial_muscle_vs_inverse_torque_error_Nm':initial_force_error,'video_frames':frame_count,'wall_time_s':time.time()-start}
 stats['passes_walking_checks']=bool(failure is None and duration>5.999 and displacement>10 and np.min(up)>.7 and not np.any(ground_arr) and np.mean(np.any(support,axis=1))>.8 and np.all(transitions>2));json.dump(stats,open(O/(mode+'_report.json'),'w'),indent=2);print(json.dumps(stats,indent=2),flush=True);return stats
if __name__=='__main__':
 allstats={mode:run(mode) for mode in ['torque','muscle']};json.dump(allstats,open(O/'comparison.json','w'),indent=2)
