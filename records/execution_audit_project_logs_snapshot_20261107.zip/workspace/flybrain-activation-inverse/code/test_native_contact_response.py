import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import pathlib,json,time,numpy as np,mujoco
import forward_walk_test as fw
from contact_response_fd import NativeContactResponse,leg_basis
from test_feedback_walk import groups
O=fw.R/'contact_feedback';Q=fw.src['qpos'];V=fw.src['qvel'];m=mujoco.MjModel.from_binary_path(str(fw.R/'optimization/optimized_geometry.mjb'));m.actuator_gainprm[fw.src['joint_actuator_mask']]=0;m.actuator_biasprm[fw.src['joint_actuator_mask']]=0;d=mujoco.MjData(m);probe=NativeContactResponse(m);dense=np.empty((m.ntendon,m.nv));rng=np.random.default_rng(5);results=[]
for t in [0,100,500,2000,5000,10000,15000,20000,25000]:
 for key in ['qpos','qvel','ctrl','act']:getattr(d,key)[:]=fw.src[key][t]
 d.qfrc_applied[:]=0;d.qfrc_applied[fw.dofs]=fw.src['leg_tau_drive_Nm'][t]/1e-7;d.qacc_warmstart[:]=0;mujoco.mj_forward(m,d);probe.set_state(d);mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));R=-dense[fw.tid][:,fw.dofs].T;E=leg_basis(R,groups,fw.dofs,m.nv);force=d.qfrc_applied.copy();start=time.time();r=probe.linearize(force,E,epsilon=1e-4,central=True);elapsed=time.time()-start
 direction=rng.normal(size=E.shape[1]);direction/=np.linalg.norm(direction);delta=E@direction*1e-5;ap,fp,_=probe.evaluate(force+delta);am,fm,_=probe.evaluate(force-delta);da=(ap-am)/2;df=(fp-fm)/2;pa=r['acceleration_response']@(direction*1e-5);pf=r['constraint_force_response']@(direction*1e-5);accerr=float(np.linalg.norm(da-pa)/max(np.linalg.norm(da),np.linalg.norm(pa),1e-12));ferr=float(np.linalg.norm(df-pf)/max(np.linalg.norm(df),np.linalg.norm(pf),1e-12));askip,fskip,_=probe.evaluate(force+delta);afull,ffull,_=probe.evaluate(force+delta,full=True)
 rec={'frame':t,'ncon':int(d.ncon),'nefc':int(d.nefc),'basis_rank':E.shape[1],'acceleration_prediction_relative_error':accerr,'contact_force_prediction_relative_error':ferr,'skip_vs_full_acc_abs_error':float(np.max(np.abs(askip-afull))),'skip_vs_full_contact_abs_error':float(np.max(np.abs(fskip-ffull))),'linearization_wall_s':elapsed,'noslip_iterations':int(m.opt.noslip_iterations),'dynamics_identity_relative_error':r['dynamics_response_consistency_relative_error']};results.append(rec);print(json.dumps(rec),flush=True)
assert max(r['acceleration_prediction_relative_error'] for r in results)<1e-5
assert max(r['contact_force_prediction_relative_error'] for r in results)<1e-5
assert max(r['dynamics_identity_relative_error'] for r in results)<1e-6
json.dump(results,open(O/'native_response_validation.json','w'),indent=2)
