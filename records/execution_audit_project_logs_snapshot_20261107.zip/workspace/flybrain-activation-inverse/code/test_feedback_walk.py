"""Live trajectory-error feedback; bounded muscle allocation, no rescue torque.
Torque PD is a separately labeled diagnostic, not a muscle success.
"""
import os
os.environ.update(MUJOCO_GL='egl',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import pathlib,json,time,argparse
import numpy as np,mujoco
from scipy.ndimage import median_filter
import forward_walk_test as fw
from invert import allocate
O=fw.R/'feedback_test';O.mkdir(exist_ok=True)
Q=fw.src['qpos'];V=fw.src['qvel'];CTRL=fw.src['ctrl'];ACT=fw.src['act'];TAU=fw.src['leg_tau_drive_Nm']/1e-7;dofs=fw.dofs;qa=fw.raw['joint_qpos_indices'];mask=fw.src['joint_actuator_mask'];tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];legs=['LF','RF','LM','RM','LH','RH'];names=fw.raw['joint_names'].tolist();groups=[(np.array([i for i,n in enumerate(names) if n.endswith(tok)]),np.array([i for i,r in enumerate(fw.rows) if r['leg']==leg])) for tok,leg in zip(tokens,legs)];scale=np.array([max(np.sqrt(np.mean((TAU[:,j]*100)**2)),1e-6) for j,k in groups]);Mfull=np.empty((114,114))

def run(mode,omega,zeta,duration=.5,render=False,early_stop=True,weight='plain',control_steps=5,feedback_method='acceleration_pd',save_rollout=False):
 m=mujoco.MjModel.from_binary_path(str(fw.R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m);nativekp=-m.actuator_biasprm[mask,1].copy();actmoment=np.empty((m.nu,m.nv));m.actuator_gainprm[mask]=0;m.actuator_biasprm[mask]=0
 for i in range(m.ngeom):
  if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
 for key in ['qpos','qvel','act','ctrl','qacc_warmstart']:getattr(d,key)[:]=fw.src[key][0]
 thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');ghost=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'ghost/');ga=m.jnt_qposadr[ghost];gv=m.jnt_dofadr[ghost];ground={i for i in range(m.ngeom) if m.geom_bodyid[i]==0};footgeoms={};coreids={i for i in range(m.nbody) if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,i) or '').startswith(('walker/head','walker/abdomen','walker/thorax'))}
 for i in range(m.ngeom):
  n=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or ''
  if n.startswith('walker/') and any(x in n for x in ['tarsus','claw']):
   for k,tok in enumerate(tokens):
    if tok in n:footgeoms[i]=k
 dense=np.empty((m.ntendon,m.nv));a=np.zeros(126);force=np.zeros(126);cf=np.zeros(6);logs={k:[] for k in ['time_s','thorax_mm','up_z','thorax_ground','body_ground','support_dyne','angle_error_rms_rad','activation','actual_torque_Nm','target_torque_Nm','qpos','qvel']};fail=None;firstfall=None;fallrun=0;maxnative=0.;started=time.time();tag=f'{mode}_w{omega:g}_z{zeta:g}_{weight}'+('_servo' if feedback_method=='native_stiffness' else '')+(f'_dt{control_steps}' if control_steps!=5 else '');writer=None;renderer=None;lastframe=None;warnings=np.array([w.number for w in d.warning]);disabledforce=0.;kktmax=0.;Mfull=np.empty((m.nv,m.nv));target=np.zeros(66)
 if render:
  renderer=mujoco.Renderer(m,height=480,width=640);option=mujoco.MjvOption();option.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;option.sitegroup[:]=0;writer=fw.video_writer(O/(tag+'_raw.mp4'))
 N=min(round(duration/.0002),len(Q))
 for t in range(N):
  if fail is None:
   if t%10==0:d.qpos[ga:ga+7]=Q[t,ga:ga+7];d.qvel[gv:gv+6]=V[t,gv:gv+6]
   d.ctrl[:]=CTRL[t];d.qfrc_applied[:]=fw.src['qfrc_applied'][t];mujoco.mj_forward(m,d);disabledforce=max(disabledforce,float(np.max(np.abs(d.actuator_force[mask]))))
   if t%control_steps==0:
    mujoco.mj_fullM(m,Mfull,d.qM);LL=Mfull[np.ix_(dofs,dofs)];error=Q[t,qa]-d.qpos[qa];velerror=V[t,dofs]-d.qvel[dofs];feedback=LL@(omega**2*error+2*zeta*omega*velerror)
    if feedback_method=='native_stiffness':
     mujoco.mju_sparse2dense(actmoment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);jj=actmoment[mask][:,dofs];feedback=omega*(jj.T@(nativekp*(jj@error)))
    target=TAU[t]+feedback
   if mode=='muscle_pd':
    mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));J=dense[fw.tid];fiber=d.ten_length[fw.tid]*.01-fw.slack;x=fiber/fw.l0
    if np.any(fiber<=0):fail={'time_s':float(d.time),'reason':'nonpositive fiber length'}
    else:
     vn=(J@d.qvel*.01)/(fw.l0*fw.vmax);neg=np.minimum(vn,0);pos=np.maximum(vn,0);fv=np.where(vn<0,np.maximum(0,(1+neg)/(1-neg/fw.hill)),1+(fw.ecc-1)*pos/(fw.hill+pos));cap=fw.F0*np.exp(-((x-1)/fw.width)**2)*fv;fp=fw.F0*np.expm1(np.clip(fw.shape*np.maximum(x-fw.ps,0)/fw.strain,0,30))/np.expm1(fw.shape);moment=-J[:,dofs].T*.01;A=moment*cap[None,:]*1e9;p=moment@fp*1e9
     if t%control_steps==0:
      for g,(j,k) in enumerate(groups):
       w=np.ones(len(j))
       if weight=='inertia':
        diag=np.diag(LL)[j];w=np.clip(np.sqrt(np.median(diag)/np.maximum(diag,1e-18)),.2,5)
       if weight=='acceleration':
        diag=np.diag(LL)[j];w=np.clip(np.median(diag)/np.maximum(diag,1e-18),.02,50)
       if weight=='lift':w[[4,5]]=8.
       a[k],_,status=allocate(A[np.ix_(j,k)]*w[:,None],(target[j]*100-p[j])*w,scale[g])
       if t%100==0:
        C=A[np.ix_(j,k)]*w[:,None]/scale[g];yy=(target[j]*100-p[j])*w/scale[g];gg=C.T@(C@a[k]-yy)+1e-6*a[k];vv=np.where(a[k]<1e-7,np.minimum(gg,0),np.where(a[k]>1-1e-7,np.maximum(gg,0),gg));kktmax=max(kktmax,float(np.max(np.abs(vv))/max(1.,np.max(np.abs(C.T@yy)))))
       if status<=0:fail={'time_s':float(d.time),'reason':'allocation solver failed'}
     force=fp+a*cap;general=-(J.T@(force*1e5));d.qfrc_applied[:]+=general;actual=general[dofs]*1e-7
   else:
    # Diagnostic only: direct generalized torque feedback, no muscle constraints.
    d.qfrc_applied[dofs]+=target;actual=target*1e-7
   if fail is None:
    # Re-solve after applying the new muscle/feedback force: contact loads must
    # describe actual applied forces, not the preceding force-free evaluation.
    mujoco.mj_forward(m,d)
    touch=False;coretouch=False;support=np.zeros(6)
    for c in range(d.ncon):
     con=d.contact[c];g1,g2=int(con.geom1),int(con.geom2);other=g2 if g1 in ground else g1 if g2 in ground else None
     if other is None or con.efc_address<0:continue
     if int(m.geom_bodyid[other])==thorax:touch=True
     if int(m.geom_bodyid[other]) in coreids and con.dist<=0:coretouch=True
     if other in footgeoms:mujoco.mj_contactForce(m,d,c,cf);support[footgeoms[other]]+=max(0.,cf[0])
    up=float(d.xmat[thorax].reshape(3,3)[2,2]);fallen=up<.5 or touch;fallrun=fallrun+1 if fallen else 0
    if fallrun>=25 and firstfall is None:firstfall=float(d.time-24*.0002)
    vals={'time_s':float(d.time),'thorax_mm':d.xpos[thorax]*10,'up_z':up,'thorax_ground':touch,'body_ground':coretouch,'support_dyne':support,'angle_error_rms_rad':float(np.sqrt(np.mean((Q[t,qa]-d.qpos[qa])**2))),'activation':a.copy(),'actual_torque_Nm':actual.copy(),'target_torque_Nm':target.copy()*1e-7,'qpos':d.qpos.copy(),'qvel':d.qvel.copy()}
    for key,value in vals.items():logs[key].append(value)
    mujoco.mj_step(m,d)
    bad=any(d.warning[i].number>warnings[i] for i in [int(mujoco.mjtWarning.mjWARN_BADQPOS),int(mujoco.mjtWarning.mjWARN_BADQVEL),int(mujoco.mjtWarning.mjWARN_BADQACC)])
    if bad or not np.all(np.isfinite(d.qpos)) or not np.all(np.isfinite(d.qvel)):fail={'time_s':float((t+1)*.0002),'reason':'numerical instability'}
  if not render and t%100==9 and fail is None:mujoco.mj_forward(m,d)
  if render and t%100==9:
   if fail is None or lastframe is None:mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=option);lastframe=renderer.render().copy()
   writer.stdin.write(lastframe.tobytes())
  if early_stop and (fail is not None or firstfall is not None):break
  if render and t%5000==0:print(tag,'time',d.time,'fall',firstfall,'failure',fail,flush=True)
 if writer:writer.stdin.close();assert writer.wait()==0;renderer.close()
 arr={k:np.asarray(v) for k,v in logs.items()};xyz=arr['thorax_mm'];duration_done=len(xyz)*.0002;up=arr['up_z'];weightforce=m.body_subtreemass[thorax]*np.linalg.norm(m.opt.gravity);support=median_filter(arr['support_dyne']>weightforce*.01,size=(25,1),mode='nearest');transitions=np.sum(support[1:]!=support[:-1],axis=0);displacement=float(np.linalg.norm(xyz[-1,:2]-xyz[0,:2]));result={'mode':mode,'feedback_method':feedback_method,'omega_per_s':omega if feedback_method=='acceleration_pd' else None,'stiffness_gain_multiplier':omega if feedback_method=='native_stiffness' else None,'zeta':zeta,'row_weight':weight,'control_timestep_s':control_steps*.0002,'duration_s':duration_done,'first_sustained_fall_s':firstfall,'failure':fail,'displacement_xy_mm':displacement,'displacement_x_mm':float(xyz[-1,0]-xyz[0,0]),'displacement_y_mm':float(xyz[-1,1]-xyz[0,1]),'path_xy_mm':float(np.linalg.norm(np.diff(xyz[:,:2],axis=0),axis=1).sum()),'min_up_z':float(up.min()),'upright_fraction':float(np.mean(up>.7)),'thorax_ground_samples':int(np.sum(arr['thorax_ground'])),'body_ground_samples':int(np.sum(arr['body_ground'])),'mean_angle_error_rad':float(arr['angle_error_rms_rad'].mean()),'foot_contact_transitions':transitions.tolist(),'support_fraction':float(np.mean(np.any(support,axis=1))),'disabled_native_leg_force_max':disabledforce,'bounded_activation':bool(np.all((arr['activation']>=0)&(arr['activation']<=1))),'torque_target_residual_L2':float(np.linalg.norm(arr['actual_torque_Nm']-arr['target_torque_Nm'])/max(np.linalg.norm(arr['target_torque_Nm']),1e-20)),'elapsed_s':time.time()-started,'tag':tag}
 late=support[arr['time_s']>=min(.5,duration_done*.5)];result['late_support_fraction_per_leg']=late.mean(axis=0).tolist();result['late_contact_transitions']=np.sum(late[1:]!=late[:-1],axis=0).tolist();result['late_moving_legs']=int(np.sum((np.sum(late[1:]!=late[:-1],axis=0)>=2)&(late.mean(axis=0)>.01)&(late.mean(axis=0)<.99)))
 result['passes_walking_checks']=bool(fail is None and duration_done>=5.999 and displacement>10 and np.min(up)>.7 and result['thorax_ground_samples']==0 and result['support_fraction']>.8 and np.all(transitions>2))
 result['activation_at_zero_fraction']=float(np.mean(arr['activation']<1e-6));result['activation_at_one_fraction']=float(np.mean(arr['activation']>1-1e-6));result['sampled_allocation_kkt_relative_max']=kktmax;result['target_torque_abs_max_Nm']=float(np.max(np.abs(arr['target_torque_Nm'])));result['actual_torque_abs_max_Nm']=float(np.max(np.abs(arr['actual_torque_Nm'])))
 result['passes_six_leg_walk_check']=bool(result['passes_walking_checks'] and result['body_ground_samples']==0 and result['late_moving_legs']==6)
 if render or save_rollout:np.savez_compressed(O/(tag+'_rollout.npz'),**arr);json.dump(result,open(O/(tag+'_report.json'),'w'),indent=2)
 print(json.dumps(result),flush=True);return result
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--stage',default='sweep');parser.add_argument('--mode',default='muscle_pd');parser.add_argument('--omega',type=float,default=1000);parser.add_argument('--zeta',type=float,default=1);parser.add_argument('--weight',default='plain');parser.add_argument('--control-steps',type=int,default=5);parser.add_argument('--feedback-method',default='acceleration_pd');args=parser.parse_args()
 if args.stage=='sweep':
  results=[]
  for mode in ['torque_pd','muscle_pd']:
   for omega in [100,300,1000,3000]:
    for zeta in ([1.] if mode=='torque_pd' else [.5,1.]):
     results.append(run(mode,omega,zeta,duration=.6));json.dump(results,open(O/'sweep.json','w'),indent=2)
 elif args.stage=='full':run(args.mode,args.omega,args.zeta,duration=6,render=True,early_stop=False,weight=args.weight,control_steps=args.control_steps,feedback_method=args.feedback_method)
