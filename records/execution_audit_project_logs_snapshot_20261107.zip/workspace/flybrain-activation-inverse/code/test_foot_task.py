import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import numpy as np,mujoco,json
import run_contact_feedback as rc
from foot_trajectory_task import FootTrajectoryTask
m=mujoco.MjModel.from_binary_path(str(rc.fw.R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m);body=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');ft=FootTrajectoryTask(m,rc.source,body,0,rc.fw.R/'guarded_contact/reference_foot_task.npz');records=[]
for t in [0,500,5000]:
 d.qpos[:]=rc.source['qpos'][t];d.qvel[:]=rc.source['qvel'][t];mujoco.mj_forward(m,d);J,b,_=ft.task(d,t);p=d.xpos[ft.feet]-d.xpos[body];v=(J@d.qvel).reshape(6,3);desired=ft.acceleration[t]+ft.omega**2*(ft.position[t]-p)+2*ft.omega*(ft.velocity[t]-v);curv=desired.reshape(18)-b;a=rc.source['qacc'][t];vals=[];eps=1e-6
 for sign in [1,-1]:
  q=d.qpos.copy();mujoco.mj_integratePos(m,q,d.qvel+sign*.5*eps*a,sign*eps);ft.geom.qpos[:]=q;mujoco.mj_kinematics(m,ft.geom);vals.append((ft.geom.xpos[ft.feet]-ft.geom.xpos[body]).reshape(18).copy())
 vf=(vals[0]-vals[1])/(2*eps);af=(vals[0]+vals[1]-2*p.reshape(18))/eps**2;vp=J@d.qvel;ap=J@a+curv;ve=float(np.linalg.norm(vf-vp)/max(1.,np.linalg.norm(vp)));ae=float(np.linalg.norm(af-ap)/max(1.,np.linalg.norm(ap)));assert ve<1e-3 and ae<1e-3;records.append(dict(frame=t,velocity_chain_rule_relative_error=ve,acceleration_chain_rule_relative_error=ae))
(rc.fw.R/'guarded_contact/foot_kinematics_validation.json').write_text(json.dumps(records,indent=2));print(records)
