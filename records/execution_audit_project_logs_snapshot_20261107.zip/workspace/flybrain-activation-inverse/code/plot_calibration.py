import os;os.environ['MPLCONFIGDIR']='/tmp/fly-calibration-mpl'
import json,pathlib,numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'optimization';hist=json.load(open(O/'history.json'));report=json.load(open(O/'full_trajectory/report.json'));diag=json.load(open(O/'parameter_diagnostics.json'));z=np.load(O/'full_trajectory/activation_6s_5000Hz.npz');base=json.load(open(R/'output/report.json'));upper=json.load(open(R/'output/capacity_sensitivity.json'));t=z['time_s'];tau=z['target_torque_Nm']*1e9;pred=z['predicted_torque_Nm']*1e9
fig,ax=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
for key,label in [('train_relative_residual','Train'),('validation_relative_residual','Validation')]:ax[0,0].plot([h['iteration'] for h in hist],[100*h[key] for h in hist],label=label)
ax[0,0].set_xlabel('Refinement iteration');ax[0,0].set_ylabel('Residual / target L2 (%)');ax[0,0].legend();ax[0,0].set_title('Global bounded calibration')
vals=[base['relative_residual_L2'],upper['relative_residual_L2'],report['relative_residual_L2']];bars=ax[0,1].bar(['Default','Higher capacity','Optimized'],np.array(vals)*100,color=['gray','orange','teal']);ax[0,1].bar_label(bars,fmt='%.1f%%');ax[0,1].set_ylim(0,105);ax[0,1].set_title('All 30,000 fixed frames')
k=int(np.argmax(np.mean(tau[:,:11]**2,axis=0)));sel=(t>=1)&(t<=1.05);ax[1,0].plot(t[sel],tau[sel,k],label='Fixed target',color='black',lw=1);ax[1,0].plot(t[sel],pred[sel,k],label='Optimized model',lw=1);ax[1,0].set_xlabel('Recorded time (s)');ax[1,0].set_ylabel('Torque (uN mm)');ax[1,0].set_title(str(z['joint_names'][k]));ax[1,0].legend()
keys=['specific_stress_Pa','vmax_L0_per_s','PCSA_m2'];counts=[len(diag[key]['near_upper']) for key in keys];bars=ax[1,1].bar(['Stress','Vmax','PCSA'],counts,color='darkorange');ax[1,1].bar_label(bars);ax[1,1].set_ylim(0,135);ax[1,1].set_ylabel('Muscle slots (out of 126)');ax[1,1].set_title('Within 1% of upper prior bound: uncertainty remains')
fig.suptitle('Improved torque fit within prior bounds; not biological ground truth');fig.savefig(O/'calibration_summary.png',dpi=150)
