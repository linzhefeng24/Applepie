"""Reference-derived operational-space foot task; does not move/anchor real feet."""
import pathlib,hashlib,numpy as np,mujoco
from scipy.ndimage import gaussian_filter1d
class FootTrajectoryTask:
 def __init__(self,m,source,rootbody,rootdof,cache_path,omega=150.,smoothing_s=.002):
  self.m=m;self.body=rootbody;self.rootdof=rootdof;self.omega=omega;tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];self.feet=np.array([mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/claw_'+t) for t in tokens]);assert np.all(self.feet>=0);self.geom=mujoco.MjData(m);self.jp=np.empty((3,m.nv));self.jr=np.empty_like(self.jp);dt=.0002;path=pathlib.Path(cache_path);signature=hashlib.sha256(source['qpos'].tobytes()).hexdigest()
  if path.exists():
   z=np.load(path)
   if str(z['source_qpos_sha256'])==signature and float(z['smoothing_s'])==smoothing_s:self.position=z['relative_position_cm'];self.velocity=z['relative_velocity_cm_s'];self.acceleration=z['relative_acceleration_cm_s2'];return
  rel=np.empty((len(source['qpos']),6,3))
  for t,q in enumerate(source['qpos']):
   self.geom.qpos[:]=q;mujoco.mj_kinematics(m,self.geom);rel[t]=self.geom.xpos[self.feet]-self.geom.xpos[self.body]
  self.position=gaussian_filter1d(rel,smoothing_s/dt,axis=0,mode='nearest');self.velocity=np.gradient(self.position,dt,axis=0,edge_order=2);self.acceleration=np.gradient(self.velocity,dt,axis=0,edge_order=2);np.savez_compressed(path,relative_position_cm=self.position,relative_velocity_cm_s=self.velocity,relative_acceleration_cm_s2=self.acceleration,source_qpos_sha256=np.array(signature),smoothing_s=smoothing_s)
 def task(self,d,t):
  mujoco.mj_jacBody(self.m,d,self.jp,self.jr,self.body);Jbody=self.jp.copy();J=np.empty((6,3,self.m.nv));pos=d.xpos[self.feet]-d.xpos[self.body]
  for i,b in enumerate(self.feet):mujoco.mj_jacBody(self.m,d,self.jp,self.jr,int(b));J[i]=self.jp-Jbody
  speed=np.einsum('fij,j->fi',J,d.qvel);eps=min(1e-4,.005/max(1.,np.linalg.norm(d.qvel)));rel=[]
  for sign in [1,-1]:
   self.geom.qpos[:]=d.qpos;mujoco.mj_integratePos(self.m,self.geom.qpos,d.qvel,sign*eps);mujoco.mj_kinematics(self.m,self.geom);rel.append(self.geom.xpos[self.feet]-self.geom.xpos[self.body])
  curvature=(rel[0]+rel[1]-2*pos)/(eps*eps);desired=self.acceleration[t]+self.omega**2*(self.position[t]-pos)+2*self.omega*(self.velocity[t]-speed);return J.reshape(18,self.m.nv),(desired-curvature).reshape(18),{'relative_foot_position_error_mm':float(np.sqrt(np.mean((self.position[t]-pos)**2))*10),'relative_foot_velocity_error_cm_s':float(np.sqrt(np.mean((self.velocity[t]-speed)**2)))}
