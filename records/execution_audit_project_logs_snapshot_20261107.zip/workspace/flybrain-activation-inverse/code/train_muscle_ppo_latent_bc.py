"""Small CPU PPO feasibility baseline. Training resets are confined to episode boundaries.
Evaluation starts at reference frame zero and freely integrates with muscle forces only.
"""
import os
os.environ.update(TF_CPP_MIN_LOG_LEVEL='3',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',TF_NUM_INTEROP_THREADS='1',TF_NUM_INTRAOP_THREADS='1',MUJOCO_GL='egl')
import numpy as np,mujoco,time,pathlib,json,multiprocessing as mp,argparse
import shooting_mpc as s
s.FAST=True
class Env:
 def __init__(self,seed):self.rng=np.random.default_rng(seed);self.d=mujoco.MjData(s.m);self.e=np.empty(s.m.nv);self.t=0;self.elapsed=0;self.maxsteps=150
 def reset(self,training=True,maxsteps=150):
  self.maxsteps=maxsteps;self.elapsed=0;self.t=int(self.rng.integers(0,28000)) if training and self.rng.random()<.8 else 0;mujoco.mj_resetData(s.m,self.d)
  for k in ['qpos','qvel','act','ctrl','qacc_warmstart']:getattr(self.d,k)[:]=s.src[k][self.t]
  mujoco.mj_forward(s.m,self.d);return self.obs()
 def obs(self):
  t=min(self.t,29999);mujoco.mj_differentiatePos(s.m,self.e,1.,s.src['qpos'][t],self.d.qpos);dv=self.d.qvel-s.src['qvel'][t];body=self.e[s.rv:s.rv+6].copy();body[:3]*=10
  phase=2*np.pi*t*s.dt*np.array([5,10,20,40]);o=np.r_[self.e[s.fw.dofs]*2,dv[s.fw.dofs]/500,body,self.d.qvel[s.rv:s.rv+6]/np.array([10,10,10,100,100,100]),np.sin(phase),np.cos(phase),s.fw.activation[t]*2-1]
  return np.clip(o,-5,5).astype('f4')
 def advance(self,y,record=False):
  trace=[];failed=False;offset=np.tanh(y)
  for _ in range(10):
   t=min(self.t,29999);a=np.clip(s.fw.activation[t]+offset,0,1)
   mujoco.mj_forward(s.m,self.d);f,x=s.forces(self.d,a)
   up=float(self.d.xmat[s.thorax].reshape(3,3)[2,2])
   if f is None or up<.5:failed=True;break
   if record:trace.append(dict(time_s=self.elapsed*10*s.dt+len(trace)*s.dt,qpos=self.d.qpos.copy(),qvel=self.d.qvel.copy(),activation=a.copy(),up_z=up,thorax_mm=self.d.xpos[s.thorax]*10,fiber_min_norm=float(x.min()),fiber_max_norm=float(x.max())))
   ok,_=s.step(self.d,a,t);self.t+=1
   if not ok:failed=True;break
  self.elapsed+=1;obs=self.obs();e=self.e;qe=float(np.mean(e[s.fw.dofs]**2));be=e[s.rv:s.rv+6];ve=float(np.mean(((self.d.qvel-s.src['qvel'][min(self.t,29999)])[s.fw.dofs]/500)**2))
  reward=.4*np.exp(-5*qe)+.15*np.exp(-ve)+.3*np.exp(-10*np.sum(be[3:]**2))+.15*np.exp(-np.sum((be[:3]/.1)**2))
  done=failed or self.elapsed>=self.maxsteps or self.t>=29990
  if failed:reward-=2
  return obs,float(reward),done,trace

def worker(pipe,seed):
 env=Env(seed)
 while True:
  command,payload=pipe.recv()
  if command=='close':break
  if command=='reset':pipe.send(env.reset(True,payload));continue
  y,maxsteps=payload;o,r,done,_=env.advance(y)
  if done:o=env.reset(True,maxsteps)
  pipe.send((o,r,done))
 pipe.close()

def main(args):
 out=s.R/'ppo_muscle'/args.tag;out.mkdir(parents=True,exist_ok=True);json.dump(vars(args),open(out/'config.json','w'),indent=2)
 np.random.seed(args.seed);pipes=[];processes=[]
 for i in range(4):
  pa,ch=mp.get_context('fork').Pipe();p=mp.get_context('fork').Process(target=worker,args=(ch,args.seed+100+i));p.start();pipes.append(pa);processes.append(p)
 import tensorflow as tf
 tf.random.set_seed(args.seed);tf.config.threading.set_intra_op_parallelism_threads(1);tf.config.threading.set_inter_op_parallelism_threads(1)
 for pipe in pipes:pipe.send(('reset',100))
 obs=np.stack([p.recv() for p in pipes]);dim=obs.shape[1]
 inp=tf.keras.Input(shape=(dim,));h=tf.keras.layers.Dense(128,activation='tanh')(inp);h=tf.keras.layers.Dense(128,activation='tanh')(h);mu=tf.keras.layers.Dense(126,kernel_initializer='zeros',bias_initializer='zeros')(h);vh=tf.keras.layers.Dense(128,activation='tanh')(inp);vh=tf.keras.layers.Dense(128,activation='tanh')(vh);value=tf.keras.layers.Dense(1)(vh);net=tf.keras.Model(inp,[mu,value]);logstd=tf.Variable(np.full(126,-1.2,dtype='f4'));opt=tf.keras.optimizers.Adam(3e-5)
 @tf.function
 def predict(x):return net(x,training=False)
 @tf.function
 def update(x,y,oldlog,adv,returns,oldvalue):
  with tf.GradientTape() as tape:
   mean,v=net(x,training=True);v=tf.squeeze(v,1);ls=tf.clip_by_value(logstd,-3.,0.);lp=-.5*tf.reduce_sum(((y-mean)/tf.exp(ls))**2+2*ls+np.log(2*np.pi),axis=1);ratio=tf.exp(tf.clip_by_value(lp-oldlog,-20,20));policy=-tf.reduce_mean(tf.minimum(ratio*adv,tf.clip_by_value(ratio,.8,1.2)*adv));vf=.5*tf.reduce_mean((v-returns)**2);loss=policy+.5*vf-.0001*tf.reduce_sum(ls)
  variables=net.trainable_variables+[logstd];grads=tape.gradient(loss,variables);grads,_=tf.clip_by_global_norm(grads,.5);opt.apply_gradients(zip(grads,variables));return loss,tf.reduce_mean(oldlog-lp)
 if args.teacher_bc:
  teacher=np.load(s.R/'guarded_contact/v2_full/contact_bw1_lw1000_bw50_it2_dt5_rollout.npz');Q=teacher['qpos'];V=teacher['qvel'];A=teacher['activation'];env=Env(5);X=[];Y=[]
  for i in range(0,len(Q),5):
   env.t=i;env.d.qpos[:]=Q[i];env.d.qvel[:]=V[i];X.append(env.obs());Y.append(np.arctanh(np.clip(A[i]-s.fw.activation[i],-.999,.999)))
  X=np.array(X,dtype='f4');Y=np.array(Y,dtype='f4');actor=tf.keras.Model(inp,mu);bcopt=tf.keras.optimizers.Adam(3e-4)
  @tf.function
  def bcupdate(x,y):
   with tf.GradientTape() as tape:prediction=actor(x,training=True);loss=tf.reduce_mean((prediction-y)**2)
   bcopt.apply_gradients(zip(tape.gradient(loss,actor.trainable_variables),actor.trainable_variables));return loss
  for k in range(args.teacher_bc):
   ix=np.random.randint(0,len(X),256);loss=bcupdate(X[ix],Y[ix])
   if k%500==0:print('BC',k,float(loss),flush=True)
  pred=actor(X).numpy();activation_pred=np.clip(s.fw.activation[np.arange(0,len(Q),5)]+np.tanh(pred),0,1);bc_report={'samples':len(X),'latent_mse':float(np.mean((pred-Y)**2)),'activation_rmse':float(np.sqrt(np.mean((activation_pred-A[::5])**2))),'teacher_duration_s':len(Q)*s.dt};json.dump(bc_report,open(out/'bc_report.json','w'),indent=2);print('BC_RESULT',bc_report,flush=True)
 def evaluate(number):
  env=Env(123);o=env.reset(False,3000);logs=[]
  for j in range(3000):
   mean,_=predict(o[None,:]);o,r,done,trace=env.advance(mean.numpy()[0],True);logs.extend(trace)
   if done:break
  arr={k:np.array([r[k] for r in logs]) for k in logs[0]} if logs else {};duration=len(logs)*s.dt
  path=out/f'eval_{number:06d}';path.mkdir(exist_ok=True)
  if arr:np.savez_compressed(path/'rollout.npz',**arr,muscle_ids=np.array([r['id'] for r in s.fw.rows]))
  report={'training_transitions':number,'duration_s':duration,'forward_mm':float(arr['thorax_mm'][-1,0]-arr['thorax_mm'][0,0]) if arr else 0,'min_up':float(arr['up_z'].min()) if arr else None,'not_yet_walking_certified':True};json.dump(report,open(path/'report.json','w'),indent=2);net.save_weights(str(path/'policy'));np.save(path/'logstd.npy',logstd.numpy());print('EVAL',json.dumps(report),flush=True);return report
 reports=[evaluate(0)];history=[];wall=time.time();total=0
 try:
  for iteration in range(args.iterations):
   batch=[];maxsteps=min(500,100+iteration*15)
   for k in range(128):
    mean,val=predict(obs);mean=mean.numpy();val=val.numpy().ravel();ls=np.clip(logstd.numpy(),-3,0);y=(mean+np.random.normal(size=mean.shape)*np.exp(ls)).astype('f4');lp=(-.5*np.sum(((y-mean)/np.exp(ls))**2+2*ls+np.log(2*np.pi),axis=1)).astype('f4')
    for p,action in zip(pipes,y):p.send(('step',(action,maxsteps)))
    results=[p.recv() for p in pipes];newobs=np.stack([r[0] for r in results]);reward=np.array([r[1] for r in results],dtype='f4');done=np.array([r[2] for r in results],dtype='f4');batch.append((obs.copy(),y,lp,val,reward,done));obs=newobs
   _,nv=predict(obs);nv=nv.numpy().ravel();gae=np.zeros(4,dtype='f4');adv=[];returns=[]
   for b in batch[::-1]:
    delta=b[4]+.99*nv*(1-b[5])-b[3];gae=delta+.99*.95*(1-b[5])*gae;adv.append(gae.copy());returns.append(gae+b[3]);nv=b[3]
   x=np.concatenate([b[0] for b in batch]);y=np.concatenate([b[1] for b in batch]);lp=np.concatenate([b[2] for b in batch]);v=np.concatenate([b[3] for b in batch]);ad=np.array(adv[::-1]).reshape(-1);ret=np.array(returns[::-1]).reshape(-1);ad=(ad-ad.mean())/(ad.std()+1e-8)
   early_kl=False
   for epoch in range(4):
    ix=np.random.permutation(len(x))
    for start in range(0,len(x),256):
     j=ix[start:start+256];loss,kl=update(x[j],y[j],lp[j],ad[j],ret[j],v[j])
     if float(kl)>.03:early_kl=True;break
    if early_kl:break
   total+=len(x);row={'iteration':iteration,'transitions':total,'mean_reward':float(np.mean([b[4] for b in batch])),'loss':float(loss),'kl':float(kl),'wall_s':time.time()-wall};history.append(row);print('TRAIN',json.dumps(row),flush=True)
   if (iteration+1)%args.eval_every==0:reports.append(evaluate(total))
  if total and reports[-1]['training_transitions']!=total:reports.append(evaluate(total))
 finally:
  for p in pipes:p.send(('close',None))
  for p in processes:p.join(timeout=10)
  json.dump(history,open(out/'history.json','w'),indent=2);json.dump(reports,open(out/'evaluation_summary.json','w'),indent=2)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--tag',default='baseline');p.add_argument('--iterations',type=int,default=40);p.add_argument('--eval-every',type=int,default=10);p.add_argument('--seed',type=int,default=42);p.add_argument('--teacher-bc',type=int,default=0);main(p.parse_args())
