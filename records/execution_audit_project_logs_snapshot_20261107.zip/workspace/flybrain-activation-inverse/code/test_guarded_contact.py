import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import json,numpy as np,mujoco
import run_contact_feedback as rc
from guarded_contact_controller import GuardedContactController
from test_feedback_walk import groups
m=mujoco.MjModel.from_binary_path(str(rc.fw.R/'optimization/optimized_geometry.mjb'));mask=rc.source['joint_actuator_mask'];m.actuator_gainprm[mask]=0;m.actuator_biasprm[mask]=0;d=mujoco.MjData(m);c=GuardedContactController(m,rc.source,rc.fw.rows,rc.fw.dofs,groups,rc.fw.activation);c.set_control_steps(5);spec=int(mujoco.mjtState.mjSTATE_INTEGRATION);records=[]
for t in [0,100,5000]:
 for k in ['qpos','qvel','ctrl','act']:getattr(d,k)[:]=rc.source[k][t]
 d.time=t*.0002;mujoco.mj_forward(m,d);B,p,_=c.force_map(d);a=rc.fw.activation[t].copy();d.qfrc_applied[:]=rc.source['qfrc_applied'][t]+p+B@a;mujoco.mj_forward(m,d);state=np.empty(mujoco.mj_stateSize(m,spec));mujoco.mj_getState(m,d,state,spec);c.guard_cache={};guard=c.check_rollout(d,a,t);after=np.empty_like(state);mujoco.mj_getState(m,d,after,spec);np.testing.assert_array_equal(state,after)
 rec={'frame':t,'guard':guard,'main_integration_state_unchanged':True}
 if guard['safe']:
  predictedq=c.guard.d.qpos.copy();predictedv=c.guard.d.qvel.copy();real=mujoco.MjData(m);mujoco.mj_setState(m,real,state,spec);ghost=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'ghost/');ga=m.jnt_qposadr[ghost];gv=m.jnt_dofadr[ghost]
  for k in range(5):
   i=t+k
   if i%10==0:real.qpos[ga:ga+7]=rc.source['qpos'][i,ga:ga+7];real.qvel[gv:gv+6]=rc.source['qvel'][i,gv:gv+6]
   real.ctrl[:]=rc.source['ctrl'][i];mujoco.mj_kinematics(m,real);mujoco.mj_comPos(m,real);mujoco.mj_tendon(m,real);BB,pp,_=c.force_map(real);real.qfrc_applied[:]=rc.source['qfrc_applied'][i]+pp+BB@a
   if k==0:real.qacc_warmstart[:]=0
   mujoco.mj_forward(m,real);mujoco.mj_step(m,real)
  qe=float(np.max(np.abs(predictedq-real.qpos)));ve=float(np.max(np.abs(predictedv-real.qvel)));assert qe<1e-12 and ve<1e-10;rec.update(predicted_vs_independent_qpos_error=qe,predicted_vs_independent_qvel_error=ve)
 records.append(rec)
# Reject a geometrically invalid state in a test copy, without altering that state.
bad=mujoco.MjData(m);bad.qpos[:]=rc.source['qpos'][0];bad.qvel[:]=rc.source['qvel'][0];found=False
for qadr in rc.qa:
 for shift in [-2.,-1.,-.5,.5,1.,2.]:
  bad.qpos[:]=rc.source['qpos'][0];bad.qpos[qadr]+=shift;mujoco.mj_kinematics(m,bad);mujoco.mj_comPos(m,bad);mujoco.mj_tendon(m,bad)
  if np.min((bad.ten_length[c.tid]*.01-c.slack)/c.l0)<=0:found=True;break
 if found:break
assert found;c.guard_cache={};before=bad.qpos.copy();rejected=c.check_rollout(bad,np.zeros(126),0);assert not rejected['safe'];np.testing.assert_array_equal(before,bad.qpos);assert any('predicted_vs_independent_qpos_error' in r for r in records)
out={'valid_state_tests':records,'invalid_test_copy_rejected':rejected,'no_main_state_clamping':True,'native_joint_ranges_unchanged':True};path=rc.fw.R/'guarded_contact/guard_validation.json';path.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
