"""Paired, direct muscle-constrained tracking of torque AND joint trajectories.
A = joint/body tasks plus recorded torque. B = A plus relative foot trajectory.
No teacher forces, residual torques, policy training, or walker state restoration.
"""
import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MUJOCO_GL='egl')
import pathlib,json,time,argparse,concurrent.futures,numpy as np,mujoco
from scipy.optimize import lsq_linear
from scipy.ndimage import median_filter
from guarded_contact_controller import GuardedContactController
from native_muscle_force import NativeForce
from foot_trajectory_task import FootTrajectoryTask
R=pathlib.Path('/workspace/flybrain-activation-inverse');ROOT=R/'multitrajectory_ab_20261104';ROOT.mkdir(exist_ok=True);MODEL=R/'optimization/optimized_geometry.mjb';ROWS=json.load(open(R/'optimization/optimized_geometry.json'))['records'];TOKENS=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];LEGS=['LF','RF','LM','RM','LH','RH'];CACHE={}
def load_ref(ref):
 if CACHE.get('id')!=ref['id']:
  z=np.load(ref['source']);needed=['time_s','qpos','qvel','qacc','act','ctrl','qacc_warmstart','qfrc_applied','leg_tau_drive_Nm','joint_qpos_indices','joint_dof_indices','joint_actuator_mask','joint_names'];src={k:z[k] for k in needed};names=src['joint_names'].tolist();groups=[(np.array([i for i,n in enumerate(names) if n.endswith(t)]),np.array([i for i,row in enumerate(ROWS) if row['leg']==leg])) for t,leg in zip(TOKENS,LEGS)];a=np.load(ref['seed'])['activation'];CACHE.clear();CACHE.update(id=ref['id'],src=src,groups=groups,a=a)
 return CACHE['src'],CACHE['groups'],CACHE['a']
def prepare(ref):
 srcpath=pathlib.Path(ref['source']);z=np.load(srcpath);src={k:z[k] for k in ['time_s','qpos','qvel','qacc','leg_tau_drive_Nm','joint_dof_indices','joint_names','qfrc_applied','ctrl']};m=mujoco.MjModel.from_binary_path(str(MODEL));d=mujoco.MjData(m);names=src['joint_names'].tolist();groups=[(np.array([i for i,n in enumerate(names) if n.endswith(t)]),np.array([i for i,row in enumerate(ROWS) if row['leg']==leg])) for t,leg in zip(TOKENS,LEGS)];seedpath=pathlib.Path(ref['seed']);seedpath.parent.mkdir(parents=True,exist_ok=True)
 if not seedpath.exists():
  from contact_controller import ContactMuscleController
  aa=np.zeros((len(src['time_s']),126),dtype='f4');c=ContactMuscleController(m,src,ROWS,src['joint_dof_indices'],groups,aa);tau=src['leg_tau_drive_Nm']/1e-7;scale=[max(float(np.sqrt(np.mean(tau[:,j]**2))),1e-5) for j,k in groups]
  for t in range(0,len(aa),5):
   d.qpos[:]=src['qpos'][t];d.qvel[:]=src['qvel'][t];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);B,p,_=c.force_map(d);a=np.zeros(126)
   for (j,k),sc in zip(groups,scale):
    C=B[np.ix_(src['joint_dof_indices'][j],k)]/sc;b=(tau[t,j]-p[src['joint_dof_indices'][j]])/sc;fit=lsq_linear(np.vstack([C,.001*np.eye(len(k))]),np.r_[b,np.zeros(len(k))],bounds=(0,1),method='bvls',tol=1e-9,max_iter=200);a[k]=np.clip(fit.x,0,1)
   aa[t:t+5]=a
  np.savez_compressed(seedpath,activation=aa,muscle_ids=[r['id'] for r in ROWS],time_s=src['time_s'],seed_sampling_Hz=1000,reference_source=str(srcpath))
 root=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'walker/');body=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');FootTrajectoryTask(m,src,body,int(m.jnt_dofadr[root]),ref['foot_cache']);return ref['id']
def run_task(job):
 ref=job['ref'];cfg=job['cfg'];duration=job['duration'];stage=job['stage'];tag=job['tag'];out=ROOT/stage/tag;out.mkdir(parents=True,exist_ok=True)
 if (out/'report.json').exists():return json.load(open(out/'report.json'))
 wall=time.time();src,groups,refa=load_ref(ref);m=mujoco.MjModel.from_binary_path(str(MODEL));m.actuator_gainprm[src['joint_actuator_mask']]=0;m.actuator_biasprm[src['joint_actuator_mask']]=0;d=mujoco.MjData(m)
 for k in ['qpos','qvel','act','ctrl','qacc_warmstart']:getattr(d,k)[:]=src[k][0]
 dofs=src['joint_dof_indices'];qa=src['joint_qpos_indices'];native=NativeForce(m,ROWS);body=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');ghost=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'ghost/');ga=m.jnt_qposadr[ghost];gv=m.jnt_dofadr[ghost];ground={i for i in range(m.ngeom) if m.geom_bodyid[i]==0};core={i for i in range(m.nbody) if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,i) or '').startswith(('walker/head','walker/abdomen','walker/thorax'))};feet={}
 for g in range(m.ngeom):
  name=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,g) or ''
  if name.startswith('walker/') and any(s in name for s in ['tarsus','claw']):
   for i,tok in enumerate(TOKENS):
    if tok in name:feet[g]=i
 c=GuardedContactController(m,src,ROWS,dofs,groups,refa,leg_omega=cfg['omega'],body_omega=cfg.get('body_omega',50.),body_weight=cfg['body_weight'],iterations=cfg.get('iterations',1),body_accel_mode=cfg['body_accel'],rotation_weight_multiplier=cfg['rotation_weight'],foot_weight=cfg.get('foot_weight',.5) if cfg['method']=='B' else 0.,foot_omega=150,joint_task_multiplier=1.,torque_weight=cfg['torque_weight'],foot_cache_path=ref['foot_cache']);c.set_control_steps(5)
 a=refa[0].astype(float).copy();cf=np.zeros(6);logs={k:[] for k in ['time_s','qpos','qvel','activation','thorax_mm','up_z','body_ground','support_dyne','angle_error_rad','actual_torque_Nm','target_torque_Nm','fiber_min_norm','fiber_max_norm']};controls=[];failure=None;fall=None;fallrun=0;native_max=0.;maxroot=0.;warn0=np.array([w.number for w in d.warning]);N=min(round(duration/.0002),len(src['time_s']))
 for t in range(N):
  if t%10==0:d.qpos[ga:ga+7]=src['qpos'][t,ga:ga+7];d.qvel[gv:gv+6]=src['qvel'][t,gv:gv+6]
  d.ctrl[:]=src['ctrl'][t];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);f,x,ok=native(d,a)
  if not ok:failure='actual muscle length domain';break
  d.qfrc_applied[:]=src['qfrc_applied'][t]+f;mujoco.mj_forward(m,d)
  if t%5==0:
   try:c.current_activation=refa[t].copy();a,info=c.solve(d,t)
   except Exception as e:failure='control: '+str(e);break
   f,x,ok=native(d,a)
   if not ok:failure='selected activation muscle domain';break
   d.qfrc_applied[:]=src['qfrc_applied'][t]+f;d.qacc_warmstart[:]=0;mujoco.mj_forward(m,d);controls.append({'time_s':t*.0002,'torque_rmse_Nm':float(np.sqrt(np.mean((f[dofs]*1e-7-src['leg_tau_drive_Nm'][t])**2))),'torque_weight':info['torque_weight'],'guard_checks':info['guard_checks'],'qp_status':info['qp_status'],'final_cost':info['final_native_acceleration_cost'],'initial_cost':info['initial_native_acceleration_cost']})
  native_max=max(native_max,float(np.max(np.abs(d.actuator_force[src['joint_actuator_mask']]))));outside=f.copy();outside[dofs]=0;maxroot=max(maxroot,float(np.max(np.abs(outside))));support=np.zeros(6);touch=False
  for ci in range(d.ncon):
   con=d.contact[ci];g1,g2=int(con.geom1),int(con.geom2);other=g2 if g1 in ground else g1 if g2 in ground else None
   if other is None or con.efc_address<0:continue
   if con.dist<=0 and m.geom_bodyid[other] in core:touch=True
   if other in feet:mujoco.mj_contactForce(m,d,ci,cf);support[feet[other]]+=max(0.,cf[0])
  up=float(d.xmat[body].reshape(3,3)[2,2]);fallrun=fallrun+1 if up<.5 or touch else 0
  if fallrun>=25:fall=(t-24)*.0002
  vals=dict(time_s=t*.0002,qpos=d.qpos.copy(),qvel=d.qvel.copy(),activation=a.copy(),thorax_mm=d.xpos[body]*10,up_z=up,body_ground=touch,support_dyne=support,angle_error_rad=float(np.sqrt(np.mean((d.qpos[qa]-src['qpos'][t,qa])**2))),actual_torque_Nm=f[dofs]*1e-7,target_torque_Nm=src['leg_tau_drive_Nm'][t],fiber_min_norm=float(x.min()),fiber_max_norm=float(x.max()))
  for k,v in vals.items():logs[k].append(v)
  mujoco.mj_step(m,d)
  if any(d.warning[i].number>warn0[i] for i in [int(mujoco.mjtWarning.mjWARN_BADQPOS),int(mujoco.mjtWarning.mjWARN_BADQVEL),int(mujoco.mjtWarning.mjWARN_BADQACC)]):failure='native warning';break
  if fall is not None:break
 arr={k:np.asarray(v) for k,v in logs.items()}
 if not len(arr['time_s']):return {'tag':tag,'ref':ref['id'],'method':cfg['method'],'duration_s':0.,'failure':failure,'passes_walking_checks':False,'score':-100}
 xyz=arr['thorax_mm'];delta=xyz[-1,:2]-xyz[0,:2];root=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'walker/');rq=m.jnt_qposadr[root];refdelta=(src['qpos'][len(xyz)-1,rq:rq+2]-src['qpos'][0,rq:rq+2])*10;direction=refdelta/max(np.linalg.norm(refdelta),1e-9);progress=float(delta@direction);side=float(delta@np.array([-direction[1],direction[0]]));weight=m.body_subtreemass[body]*np.linalg.norm(m.opt.gravity);stance=median_filter(arr['support_dyne']>weight*.01,size=(25,1),mode='nearest');late=stance[len(stance)//4:];cycles=np.sum(late[1:]!=late[:-1],axis=0);duty=late.mean(0);moving=int(np.sum((cycles>=2)&(duty>.01)&(duty<.99)));dur=len(xyz)*.0002;torque_rel=float(np.linalg.norm(arr['actual_torque_Nm']-arr['target_torque_Nm'])/max(np.linalg.norm(arr['target_torque_Nm']),1e-20));passwalk=bool(dur>=5.999 and not failure and fall is None and progress>10 and abs(side)<max(10.,.5*progress) and arr['up_z'].min()>.7 and not arr['body_ground'].any() and moving==6 and native_max==0)
 score=10*float(dur>=duration-1e-9)+5*dur+2*float(arr['up_z'].min())+min(2.,progress/max(np.linalg.norm(refdelta),1e-5))+.1*moving-2*float(arr['body_ground'].mean())-.2*float(arr['angle_error_rad'].mean());r={'tag':tag,'ref':ref['id'],'method':cfg['method'],'config':cfg,'scheduled_s':duration,'duration_s':dur,'failure':failure,'fall_s':fall,'forward_along_reference_mm':progress,'sideways_mm':side,'min_up':float(arr['up_z'].min()),'body_ground_samples':int(arr['body_ground'].sum()),'moving_legs':moving,'foot_transitions':cycles.tolist(),'foot_duty':duty.tolist(),'angle_rmse_deg':float(np.rad2deg(np.sqrt(np.mean(arr['angle_error_rad']**2)))),'relative_torque_error':torque_rel,'activation_bounds':bool(np.all((arr['activation']>=0)&(arr['activation']<=1))),'fiber_min':float(arr['fiber_min_norm'].min()),'fiber_max':float(arr['fiber_max_norm'].max()),'native_leg_force_max':native_max,'muscle_force_outside_legs_max':maxroot,'teacher_or_rescue_torque':False,'passes_walking_checks':passwalk,'score':score,'wall_s':time.time()-wall};np.savez_compressed(out/'rollout.npz',**arr,muscle_ids=[r['id'] for r in ROWS]);(out/'report.json').write_text(json.dumps(r,indent=2));(out/'config.json').write_text(json.dumps(job,indent=2));(out/'controls.json').write_text(json.dumps(controls));return r
PROFILES=[dict(name='balanced',omega=300.,torque_weight=1.,body_weight=2.,rotation_weight=2.,body_accel='smooth'),dict(name='tight',omega=1000.,torque_weight=.3,body_weight=1.,rotation_weight=1.,body_accel='raw'),dict(name='torque_first',omega=300.,torque_weight=3.,body_weight=2.,rotation_weight=2.,body_accel='smooth')]
def batch(jobs,workers):
 results=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
  futures={pool.submit(run_task,j):j for j in jobs}
  for fut in concurrent.futures.as_completed(futures):
   job=futures[fut]
   try:r=fut.result()
   except Exception as e:r={'tag':job['tag'],'ref':job['ref']['id'],'method':job['cfg']['method'],'duration_s':0.,'failure':'runner '+repr(e),'score':-100,'passes_walking_checks':False}
   results.append(r);print('RESULT',json.dumps(r),flush=True)
 return results
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--stage',choices=['prepare','screen','medium','medium1','extra','full'],required=True);p.add_argument('--workers',type=int,default=4);a=p.parse_args();refs=json.load(open(ROOT/'references.json'))
 if a.stage=='prepare':
  with concurrent.futures.ProcessPoolExecutor(max_workers=min(3,a.workers)) as pool:
   for result in pool.map(prepare,refs):print('PREPARED',result,flush=True)
 else:
  jobs=[]
  if a.stage=='screen':
   for ref in refs:
    for profile in PROFILES:
     for method in ['A','B']:
      cfg=dict(profile,method=method,iterations=1);tag=f"{ref['id']}_{method}_{profile['name']}_it1";jobs.append(dict(ref=ref,cfg=cfg,stage='screen',duration=.45,tag=tag))
  elif a.stage in ['medium','medium1']:
   rr=json.load(open(ROOT/'screen_results.json'));paired=[]
   for ref in refs:
    pairs=[]
    for profile in PROFILES:
     ss=[r for r in rr if r['ref']==ref['id'] and r.get('config',{}).get('name')==profile['name']]
     if len(ss)==2:pairs.append((max(r['score'] for r in ss),ss))
    if pairs:paired.append(max(pairs,key=lambda p:p[0]))
   for score,pair in sorted(paired,key=lambda p:p[0],reverse=True)[:4]:
    for row in pair:
     ref=next(x for x in refs if x['id']==row['ref']);iterations=2 if a.stage=='medium' else 1;cfg=dict(row['config'],iterations=iterations);tag=row['tag'].replace('_it1',f'_it{iterations}');jobs.append(dict(ref=ref,cfg=cfg,stage=a.stage,duration=1.5,tag=tag))
  elif a.stage=='extra':
   rr=json.load(open(ROOT/'medium_results.json'))
   for ref in [r for r in refs if r['id'] in ['speed0.5_seed2','speed2_seed0']]:
    cfg0=next(r['config'] for r in rr if r['ref']==ref['id'])
    for foot in [1.5,5.]:
     cfg=dict(cfg0,method='B',iterations=1,foot_weight=foot);tag=f"{ref['id']}_B_{cfg['name']}_it1_fw{foot:g}";jobs.append(dict(ref=ref,cfg=cfg,stage='extra',duration=1.5,tag=tag))
  else:
   rr=[]
   for filename in ['medium_results.json','medium1_results.json','extra_results.json']:
    if (ROOT/filename).exists():rr+=json.load(open(ROOT/filename))
   chosen=[]
   for ref in refs:
    pairs=[]
    for row in [r for r in rr if r['ref']==ref['id'] and r['method']=='B' and 'config' in r]:
     aa=[r for r in rr if r['ref']==ref['id'] and r['method']=='A' and r.get('config',{}).get('name')==row['config']['name'] and r['config']['iterations']==row['config']['iterations']]
     if aa:
      ar=max(aa,key=lambda r:r['score']);score=max(ar['score'],row['score'])+.01*min(ar['score'],row['score']);pairs.append((score,[ar,row]))
    if pairs:chosen.append(max(pairs,key=lambda p:p[0]))
   for score,pair in sorted(chosen,key=lambda p:p[0],reverse=True)[:2]:
    for row in pair:
     ref=next(x for x in refs if x['id']==row['ref']);jobs.append(dict(ref=ref,cfg=row['config'],stage='full',duration=6.,tag=row['tag']))
  results=batch(jobs,a.workers);(ROOT/(a.stage+'_results.json')).write_text(json.dumps(results,indent=2))
