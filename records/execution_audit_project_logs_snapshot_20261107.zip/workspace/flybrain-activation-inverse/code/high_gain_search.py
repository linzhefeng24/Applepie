import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import pathlib,json,argparse,hashlib,numpy as np
import test_feedback_walk as fb
O=fb.fw.R/'high_gain_search';O.mkdir(exist_ok=True)
def make_plan():
 configs=[]
 for omega in [8000,12000,20000,40000,80000]:
  for z in [0,.5,1,2]:configs.append(dict(omega=omega,zeta=z,control_steps=5))
  for z in [.5,2]:configs.append(dict(omega=omega,zeta=z,control_steps=1))
 np.random.default_rng(20261104).shuffle(configs)
 for i,c in enumerate(configs):c['id']=i
 (O/'plan.json').write_text(json.dumps({'duration_s':.8,'configs':configs},indent=2));(O/'fixed_hashes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [fb.fw.R/'optimization/optimized_geometry.json',fb.fw.R/'optimization/optimized_geometry.mjb']},indent=2));print('planned',len(configs))
def worker(shard,full=False,render=False,cid=None):
 if full:
  from scipy.optimize import lsq_linear
  def precise_allocate(A,b,scale,ridge=1e-6):
   n=A.shape[1];C=np.vstack([A/scale,np.sqrt(ridge)*np.eye(n)]);y=np.r_[b/scale,np.zeros(n)];fit=lsq_linear(C,y,bounds=(0,1),method='bvls',tol=1e-12,max_iter=500);return np.clip(fit.x,0,1),fit.optimality,fit.status
  fb.allocate=precise_allocate
 fb.O=O/('video_run' if render else 'full' if full else 'screen');fb.O.mkdir(exist_ok=True);configs=json.load(open(O/'plan.json'))['configs']
 if full:configs=[c for c in configs if c['id']==cid]
 else:configs=[c for i,c in enumerate(configs) if i%3==shard]
 dest=O/(f'full_{cid}'+('_render' if render else '')+'.json' if full else f'worker_{shard}.json');records=json.load(open(dest)) if dest.exists() and not full else [];done={r['config']['id'] for r in records}
 for c in configs:
  if c['id'] in done:continue
  try:r=fb.run('muscle_pd',c['omega'],c['zeta'],duration=6 if full else .8,render=render,early_stop=not full,control_steps=c['control_steps'],save_rollout=full);r['config']=c;r['allocation_tolerance']=1e-12 if full else 1e-9
  except Exception as e:r={'exception':str(e),'config':c}
  records.append(r);dest.write_text(json.dumps(records,indent=2));print('RESULT',json.dumps(r),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--plan',action='store_true');p.add_argument('--shard',type=int,default=0);p.add_argument('--full',type=int);p.add_argument('--render',action='store_true');a=p.parse_args()
 if a.plan:make_plan()
 else:worker(a.shard,a.full is not None,a.render,a.full)
