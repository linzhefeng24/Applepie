import os;os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/workspace/fly-walking-run/mesa',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
import pathlib,json,subprocess,math,numpy as np,mujoco
from PIL import Image,ImageDraw,ImageFont
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'guarded_contact';paths=[O/'v2_full/contact_bw1_lw1000_bw50_it2_dt5_rollout.npz',O/'warm_foot1_full/contact_bw2_lw1000_bw50_it2_dt5_rollout.npz'];reps=[json.load(open(p.with_name(p.name.replace('_rollout.npz','_full_report.json')))) for p in paths];qs=[np.load(p)['qpos'] for p in paths];duration=max(r['duration_s'] for r in reps);frames=int(math.ceil(duration/.02))+1;m=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m)
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
renderer=mujoco.Renderer(m,height=480,width=640);opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0;fonts={s:ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',s) for s in [20,22,24]};out=O/'fly_guarded_contact_attempts_20261102.mp4';writer=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x480','-r','10','-i','-','-an','-c:v','libx264','-preset','fast','-bf','0','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
for i in range(frames):
 t=i*.02;ims=[]
 for q in qs:
  d.qpos[:]=q[min(int(round(t/.0002)),len(q)-1)];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_camlight(m,d);renderer.update_scene(d,camera=1,scene_option=opt);ims.append(renderer.render().copy())
 im=Image.fromarray(np.concatenate(ims,axis=1));draw=ImageDraw.Draw(im);draw.rectangle([0,0,1280,83],fill='black');draw.rectangle([0,392,1280,480],fill='black')
 for k,r in enumerate(reps):
  title=['候选 A：接触反馈＋长度约束','候选 B：增加足端轨迹目标'][k];texts=[(title,10,24,'white'),('0.2×慢放；正式仿真未达到持续步行',48,20,'yellow'),(f"真实模拟时间 {min(t,r['duration_s']):.3f} s",398,22,'white'),(f"约 {r['fall_s']:.2f} s 失稳；前进 {r['forward_mm']:.2f} mm",432,20,'yellow')]
  if t>=r['duration_s']:texts.append(('本组已停止，当前为末帧',260,22,'yellow'))
  for text,y,size,color in texts:
   box=draw.textbbox((0,0),text,font=fonts[size]);draw.text((k*640+(640-(box[2]-box[0]))/2,y),text,font=fonts[size],fill=color)
 writer.stdin.write(np.asarray(im).tobytes())
writer.stdin.close();assert writer.wait()==0;renderer.close();subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss','2','-i',str(out),'-frames:v','1',str(O/'attempts_preview.png')],check=True);(O/'video_provenance.json').write_text(json.dumps({'path':str(out),'playback_speed':.2,'frames':frames,'fps':10,'physical_trial_duration_s':[r['duration_s'] for r in reps],'physical_trial_fall_s':[r['fall_s'] for r in reps],'stopped_panel_holds_final_frame_with_label':True,'rendered_from_actual_free_simulation_states':True},indent=2));print('attempt video ready')
