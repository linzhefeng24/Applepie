"""Native simulation shooting MPC. Fixed model, bounded activations, free state integration."""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MUJOCO_GL='egl')
import numpy as np,mujoco,pathlib,json,time,argparse,multiprocessing as mp
from scipy.optimize import lsq_linear
import forward_walk_test as fw
R=fw.R; src={k:fw.raw[k] for k in fw.raw.files}; dt=.0002
m=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb'));mask=src['joint_actuator_mask'];m.actuator_gainprm[mask]=0;m.actuator_biasprm[mask]=0
root=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'walker/');rq=int(m.jnt_qposadr[root]);rv=int(m.jnt_dofadr[root]);ghost=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'ghost/');ga=int(m.jnt_qposadr[ghost]);gv=int(m.jnt_dofadr[ghost]);thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax')
dense=np.empty((m.ntendon,m.nv));wd=mujoco.MjData(m);err=np.empty(m.nv);spec=mujoco.mjtState.mjSTATE_INTEGRATION

def forces(d,a):
 mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d)
 mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));J=dense[fw.tid];x=(d.ten_length[fw.tid]*.01-fw.slack)/fw.l0
 if not np.all(np.isfinite(x)) or x.min()<=.02 or x.max()>=1.98: return None,x
 vn=(J@d.qvel*.01)/(fw.l0*fw.vmax);neg=np.minimum(vn,0);pos=np.maximum(vn,0);fv=np.where(vn<0,np.maximum(0,(1+neg)/(1-neg/fw.hill)),1+(fw.ecc-1)*pos/(fw.hill+pos));cap=fw.F0*np.exp(-((x-1)/fw.width)**2)*fv;fp=fw.F0*np.expm1(np.clip(fw.shape*np.maximum(x-fw.ps,0)/fw.strain,0,30))/np.expm1(fw.shape)
 return -(J.T@((fp+cap*a)*1e5)),x

def step(d,a,t):
 t=min(t,len(src['qpos'])-1)
 if t%10==0:d.qpos[ga:ga+7]=src['qpos'][t,ga:ga+7];d.qvel[gv:gv+6]=src['qvel'][t,gv:gv+6]
 d.ctrl[:]=src['ctrl'][t];f,x=forces(d,a)
 if f is None:return False,x
 d.qfrc_applied[:]=src['qfrc_applied'][t]+f
 bad_indices=[int(mujoco.mjtWarning.mjWARN_BADQPOS),int(mujoco.mjtWarning.mjWARN_BADQVEL),int(mujoco.mjtWarning.mjWARN_BADQACC)];before=[d.warning[i].number for i in bad_indices];mujoco.mj_step(m,d)
 if any(d.warning[i].number>b for i,b in zip(bad_indices,before)):return False,x
 return bool(np.all(np.isfinite(d.qvel)) and np.max(np.abs(d.qvel))<1e6),x

def residual(state,t,a,horizon,bodyweight,veltime):
 mujoco.mj_setState(m,wd,state,spec);parts=[]
 for k in range(horizon):
  ok,x=step(wd,a,t+k)
  if not ok:return None
  if (k+1)%max(1,horizon//3)==0:
   ti=min(t+k+1,len(src['qpos'])-1);mujoco.mj_differentiatePos(m,err,1.,src['qpos'][ti],wd.qpos)
   # q errors in radians, root translation cm, angular velocities in local frame.
   rvref=src['qvel'][ti].copy();Ra=np.empty(9);Rr=np.empty(9);mujoco.mju_quat2Mat(Ra,wd.qpos[rq+3:rq+7]);mujoco.mju_quat2Mat(Rr,src['qpos'][ti,rq+3:rq+7]);rvref[rv+3:rv+6]=Ra.reshape(3,3).T@Rr.reshape(3,3)@rvref[rv+3:rv+6]
   dv=wd.qvel-rvref
   parts.extend([err[fw.dofs],veltime*dv[fw.dofs],bodyweight*err[rv:rv+3],bodyweight*.3*err[rv+3:rv+6],bodyweight*.01*dv[rv:rv+3],bodyweight*.003*dv[rv+3:rv+6],10*np.maximum(.08-x,0),10*np.maximum(x-1.9,0)])
 return np.concatenate(parts)

def cols(task):
 state,t,a,horizon,bw,vt,r0,indices=task;out=[]
 for j in indices:
  aa=a.copy();eps=.02 if aa[j]<.98 else -.02;aa[j]+=eps;r=residual(state,t,aa,horizon,bw,vt)
  if r is None:
   aa=a.copy();eps=-eps;aa[j]+=eps
   if aa[j]<0 or aa[j]>1:out.append(np.zeros_like(r0));continue
   r=residual(state,t,aa,horizon,bw,vt)
  out.append(np.zeros_like(r0) if r is None else (r-r0)/eps)
 return np.asarray(out).T

def run(args):
 if args.speed!=1.:
  phase=np.arange(len(src['qpos']))*args.speed;ii=np.arange(len(phase))
  for key in ['qpos','qvel','ctrl','act','qacc_warmstart','qfrc_applied']:
   arr=src[key];src[key]=np.column_stack([np.interp(phase,ii,arr[:,j]) for j in range(arr.shape[1])])
  for qi in [rq,ga]:src['qpos'][:,qi+3:qi+7]/=np.linalg.norm(src['qpos'][:,qi+3:qi+7],axis=1)[:,None]
  src['qvel']*=args.speed;src['qacc_warmstart']*=args.speed**2
  fw.activation=np.column_stack([np.interp(phase,ii,fw.activation[:,j]) for j in range(126)])
 out=R/'shooting_mpc'/args.tag;out.mkdir(parents=True,exist_ok=True);json.dump(vars(args),open(out/'config.json','w'),indent=2)
 d=mujoco.MjData(m)
 for key in ['qpos','qvel','act','ctrl','qacc_warmstart']:getattr(d,key)[:]=src[key][0]
 a=fw.activation[0].astype(float).copy();state=np.empty(mujoco.mj_stateSize(m,spec));pool=mp.get_context('fork').Pool(args.workers) if args.workers>1 else None
 logs={k:[] for k in ['time_s','qpos','qvel','activation','up_z','thorax_mm','fiber_min_norm','fiber_max_norm']};trace=[];failure=None;start=time.time();fall=None
 for t in range(round(args.duration/dt)):
  if t%args.steps==0:
   mujoco.mj_getState(m,d,state,spec);r=None;seed='held';horizon=args.horizon
   ar=fw.activation[min(t,len(fw.activation)-1)].astype(float)
   seeds=[a,ar,np.zeros(126),np.ones(126)*.5,np.ones(126)]
   for horizon in sorted(set([args.horizon,max(args.steps,args.horizon//2),args.steps]),reverse=True):
    candidates=[]
    for si,aa in enumerate(seeds):
     rr=residual(state,t,aa,horizon,args.body,args.velocity)
     if rr is not None:candidates.append((float(rr@rr),aa.copy(),rr,si))
    if candidates:
     _,a,r,si=min(candidates,key=lambda v:v[0]);seed=str(si);break
   if r is None:failure='no valid initial horizon';break
   initial=float(r@r);accepted=0
   for it in range(args.iterations):
    tasks=[(state.copy(),t,a.copy(),horizon,args.body,args.velocity,r.copy(),ix) for ix in np.array_split(np.arange(126),args.workers)]
    J=np.concatenate(pool.map(cols,tasks) if pool else [cols(q) for q in tasks],axis=1)
    ridge=1e-5;lo=np.maximum(-a,-.5);hi=np.minimum(1-a,.5)
    fit=lsq_linear(np.vstack([J,np.sqrt(ridge)*np.eye(126)]),np.r_[-r,np.zeros(126)],bounds=(lo,hi),method='bvls',tol=1e-7,max_iter=80)
    delta=fit.x;found=False
    for alpha in [1.,.5,.25,.125]:
     aa=np.clip(a+alpha*delta,0,1);rr=residual(state,t,aa,horizon,args.body,args.velocity)
     if rr is not None and rr@rr<r@r:a=aa;r=rr;found=True;accepted+=1;break
    if not found:break
   trace.append(dict(time=t*dt,cost0=initial,cost=float(r@r),accepted=accepted,seed=seed,horizon_steps=horizon))
  mujoco.mj_forward(m,d);f,x=forces(d,a)
  if f is None:failure='actual fiber domain';break
  up=float(d.xmat[thorax].reshape(3,3)[2,2]);v=dict(time_s=t*dt,qpos=d.qpos.copy(),qvel=d.qvel.copy(),activation=a.copy(),up_z=up,thorax_mm=d.xpos[thorax]*10,fiber_min_norm=x.min(),fiber_max_norm=x.max())
  for k,val in v.items():logs[k].append(val)
  if up<.5:fall=t*dt;break
  ok,x=step(d,a,t)
  if not ok:failure='integration invalid';break
  if t%250==0:print(args.tag,'t',round(t*dt,3),'up',round(up,3),'wall',round(time.time()-start,1),flush=True)
 if pool:pool.close();pool.join()
 mujoco.mj_getState(m,d,state,spec);np.savez_compressed(out/'checkpoint.npz',state=state,next_frame=len(logs['time_s']),activation=a);arr={k:np.asarray(v) for k,v in logs.items()};np.savez_compressed(out/'rollout.npz',**arr,muscle_ids=np.array([r['id'] for r in fw.rows]));json.dump(trace,open(out/'optimization.json','w'))
 r=dict(duration_s=len(arr['time_s'])*dt,fall_s=fall,failure=failure,forward_mm=float(arr['thorax_mm'][-1,0]-arr['thorax_mm'][0,0]),min_up=float(arr['up_z'].min()),fiber_min=float(arr['fiber_min_norm'].min()),fiber_max=float(arr['fiber_max_norm'].max()),angle_rms=float(np.sqrt(np.mean((arr['qpos'][:,src['joint_qpos_indices']]-src['qpos'][:len(arr['time_s']),src['joint_qpos_indices']])**2))),bounded_activation=bool(np.all((arr['activation']>=0)&(arr['activation']<=1))),wall_s=time.time()-start)
 json.dump(r,open(out/'report.json','w'),indent=2);print('RESULT',r,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--tag',default='first');p.add_argument('--duration',type=float,default=.3);p.add_argument('--steps',type=int,default=10);p.add_argument('--horizon',type=int,default=30);p.add_argument('--body',type=float,default=3.);p.add_argument('--velocity',type=float,default=.001);p.add_argument('--iterations',type=int,default=2);p.add_argument('--workers',type=int,default=4);p.add_argument('--speed',type=float,default=1.);run(p.parse_args())
