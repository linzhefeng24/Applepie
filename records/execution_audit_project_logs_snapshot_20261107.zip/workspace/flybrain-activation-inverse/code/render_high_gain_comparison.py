import os;os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/workspace/fly-walking-run/mesa',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
import pathlib,json,subprocess,numpy as np,mujoco
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'high_gain_search';V=O/'video';V.mkdir(exist_ok=True);ids=[7,1,14];reps=[json.load(open(O/f'full_{i}.json'))[0] for i in ids];qs=[np.load(O/'full'/(r['tag']+'_rollout.npz'))['qpos'] for r in reps];assert all(len(q)==30000 for q in qs)
m=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m)
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
renderer=mujoco.Renderer(m,height=480,width=640);option=mujoco.MjvOption();option.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;option.sitegroup[:]=0
writer=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1920x480','-r','50','-i','-','-an','-c:v','libx264','-preset','fast','-bf','0','-crf','20','-pix_fmt','yuv420p',str(V/'three_high_gains_raw.mp4')],stdin=subprocess.PIPE)
for f,t in enumerate(range(10,30000,100)):
 ims=[]
 for q in qs:
  d.qpos[:]=q[t];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_camlight(m,d);renderer.update_scene(d,camera=1,scene_option=option);ims.append(renderer.render().copy())
 writer.stdin.write(np.concatenate(ims,axis=1).tobytes())
 if f%50==0:print('frame',f,flush=True)
writer.stdin.close();assert writer.wait()==0;renderer.close()
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';vf='drawbox=x=0:y=0:w=iw:h=85:color=black@0.75:t=fill'
for i,r in enumerate(reps):
 texts=[(f"ω={r['omega_per_s']:g} /s；ζ=0.5",12,24,'white'),('均为肌肉约束；每 0.2 ms 更新',48,20,'white'),('未形成正常六足步态',380,22,'yellow'),(f"前进 {r['displacement_x_mm']:.2f} mm",414,22,'white'),(f"激活为 0 或 1：{100*(r['activation_at_zero_fraction']+r['activation_at_one_fraction']):.1f}%",447,20,'white')]
 for text,y,size,color in texts:vf+=f",drawtext=fontfile={font}:text='{text}':x={i*640}+320-tw/2:y={y}:fontsize={size}:fontcolor={color}:shadowcolor=black:shadowx=1:shadowy=1"
out=O/'fly_high_omega_comparison_20261102.mp4';subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(V/'three_high_gains_raw.mp4'),'-vf',vf,'-an','-c:v','libx264','-preset','fast','-bf','0','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],check=True);subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss','2','-i',str(out),'-frames:v','1',str(O/'high_gain_preview.png')],check=True);print('video ready')
