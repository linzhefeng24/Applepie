"""One coherent upper-capacity scenario, fixed across all frames; no geometry fit."""
import json,pathlib,time
import numpy as np
from invert import allocate
R=pathlib.Path('/workspace/flybrain-activation-inverse');z={k:v for k,v in np.load(R/'output/activation_6s_5000Hz.npz').items()};blocks={k:v for k,v in np.load(R/'output/forward_blocks.npz').items()};rows=json.load(open(R/'model/geometry.json'))['records'];pr=json.load(open('/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json'));pm={r['id']:r for r in pr['muscles']};comp=pr['compartments'];legs=['LF','RF','LM','RM','LH','RH'];report=json.load(open(R/'output/report.json'));a0=np.clip(z['activation'].astype(float),0,1);factors={}
for name,c in comp.items():
 group=[r for r in rows if pm[r['id']]['compartment']==name];V=sum(r['muscle_volume_m3'] for r in group);occ=.2 if name.startswith('thorax') else .8;fixedbudget=c['volume_initial_m3']*occ
 factors[name]=min(fixedbudget/V,min(pm[r['id']]['estimated']['muscle_volume_m3']['working'][1]/r['muscle_volume_m3'] for r in group))
mult=np.array([2*factors[pm[r['id']]['compartment']] for r in rows]);target=z['target_torque_Nm']*1e9;oldpred=z['predicted_torque_Nm']*1e9;pred=np.zeros_like(target);a=np.zeros_like(a0);status=np.zeros((len(a),6),dtype='i1');passive=np.zeros_like(target)
# Recompute passive generalized torque from the original frozen model, not from rounded A.
import mujoco
m=mujoco.MjModel.from_binary_path(str(R/'model/muscle_geometry.mjb'));d=mujoco.MjData(m);src=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');Q=src['qpos'];dofs=src['joint_dof_indices'];tid=np.array([r['tendon_index'] for r in rows]);P=z['passive_force_N'];dense=np.empty((m.ntendon,m.nv));start=time.time()
for t in range(len(a)):
 d.qpos[:]=Q[t];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));passive[t]=-dense[tid][:,dofs].T*.01@(P[t]*mult)*1e9
 pred[t]=passive[t]
 for g,leg in enumerate(legs):
  j=blocks[leg+'_joint_indices'];k=blocks[leg+'_muscle_indices'];A=blocks[leg][t].astype(float)*mult[k];sol,_,st=allocate(A,target[t,j]-passive[t,j],report['torque_scale_uN_mm_per_leg'][g]);a[t,k]=sol;pred[t,j]+=A@sol;status[t,g]=st
 if t%6000==0:print(t,round(time.time()-start,1),flush=True)
res=pred-target
np.savez_compressed(R/'output/activation_upper_capacity.npz',time_s=z['time_s'],muscle_ids=z['muscle_ids'],joint_names=z['joint_names'],activation=a.astype('f4'),target_torque_Nm=z['target_torque_Nm'],predicted_torque_Nm=pred*1e-9,residual_torque_Nm=pred*1e-9-z['target_torque_Nm'],capacity_multiplier=mult,solver_status=status)
out={'scenario':'fixed geometry, same fiber length, same relative volume allocation, 60kPa stress, volume increase bounded jointly by fixed compartment geometry and 80% leg /20% thorax occupancy','compartment_volume_multiplier':factors,'muscle_force_multiplier_min_max':[float(mult.min()),float(mult.max())],'relative_residual_L2':float(np.linalg.norm(res)/np.linalg.norm(target)),'residual_rms_uN_mm':float(np.sqrt(np.mean(res**2))),'fraction_activation_at_upper_bound':float(np.mean(a>1-1e-6)),'fraction_frames_within_10pct_torque_error':float(np.mean(np.linalg.norm(res,axis=1)<=.1*np.linalg.norm(target,axis=1))),'solver_failure_count':int(np.count_nonzero(status<=0))}
json.dump(out,open(R/'output/capacity_sensitivity.json','w'),indent=2);print(json.dumps(out,indent=2),flush=True)
