"""Jointwise reachability diagnostics. Counterfactual relaxations are NEVER deployed."""
import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import pathlib,json,csv,numpy as np,mujoco
from scipy.optimize import lsq_linear
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'joint_limit_audit';O.mkdir(exist_ok=True);z0=np.load(R/'optimization/full_trajectory/activation_6s_5000Hz.npz');z={k:z0[k] for k in z0.files};b0=np.load(R/'optimization/full_trajectory/forward_blocks.npz');blocks={k:b0[k] for k in b0.files};rows=json.load(open(R/'optimization/optimized_geometry.json'))['records'];names=z['joint_names'].tolist();target=z['target_torque_Nm']*1e9;pred=z['predicted_torque_Nm']*1e9;error=target-pred;act=z['activation'].astype(float);N=len(act);musids=z['muscle_ids'].tolist();legs=['LF','RF','LM','RM','LH','RH'];stats=[];maps={};envelope={};total_out=0.
for leg in legs:
 A=blocks[leg].astype(float);j=blocks[leg+'_joint_indices'];k=blocks[leg+'_muscle_indices'];p=pred[:,j]-np.einsum('njk,nk->nj',A,act[:,k]);lo=p+np.minimum(A,0).sum(2);hi=p+np.maximum(A,0).sum(2);out=np.maximum(lo-target[:,j],0)+np.maximum(target[:,j]-hi,0);total_out+=np.sum(out**2);envelope[leg]=(p,lo,hi);maps[leg]=(j,k)
 for local,col in enumerate(j):
  e=error[:,col];high=(abs(e)>=np.quantile(abs(e),.9))&(abs(e)>1e-5);direction=np.sign(e);u=A[:,local,:]*direction[:,None];ag=np.maximum(u,0);ant=np.maximum(-u,0);agcap=ag.sum(1);ants=ant.sum(1);sat=np.divide(np.sum(ag*(act[:,k]>=.999),axis=1),agcap,out=np.zeros(N),where=agcap>1e-12);off=np.divide(np.sum(ant*(act[:,k]<=.001),axis=1),ants,out=np.zeros(N),where=ants>1e-12)
  idx=int(np.argmax(abs(e)));s={'joint_index':int(col),'joint':names[col],'leg':leg,'rmse_uNmm':float(np.sqrt(np.mean(e**2))),'target_rms_uNmm':float(np.sqrt(np.mean(target[:,col]**2))),'relative_l2':float(np.linalg.norm(e)/max(np.linalg.norm(target[:,col]),1e-10)),'residual_energy_share':float(np.sum(e**2)/np.sum(error**2)),'peak_time_s':float(z['time_s'][idx]),'peak_target_uNmm':float(target[idx,col]),'peak_predicted_uNmm':float(pred[idx,col]),'peak_error_uNmm':float(e[idx]),'peak_lower_uNmm':float(lo[idx,local]),'peak_upper_uNmm':float(hi[idx,local]),'high_error_outside_scalar_envelope_fraction':float(np.mean(out[high,local]>1e-5)) if high.any() else None,'high_error_agonist_capacity_at_activation_upper_bound':float(np.mean(sat[high])) if high.any() else None,'high_error_antagonist_capacity_at_activation_lower_bound':float(np.mean(off[high])) if high.any() else None,'scalar_envelope_lower_bound_energy_fraction':float(np.sum(out[:,local]**2)/max(np.sum(e**2),1e-20))};stats.append(s)
stats.sort(key=lambda r:r['rmse_uNmm'],reverse=True)
with open(O/'joint_force_errors.csv','w') as f:w=csv.DictWriter(f,fieldnames=list(stats[0]));w.writeheader();w.writerows(stats)
# Same-state counterfactuals, stratified over the worst 10% of each leg's residual and its maximum.
source=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');Q=source['qpos'];V=source['qvel'];dofs=source['joint_dof_indices'];m=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m);dense=np.zeros((m.ntendon,m.nv));tid=np.array([r['tendon_index'] for r in rows]);F0=np.array([r['F0_N'] for r in rows]);l0=np.array([r['fiber_length0_m'] for r in rows]);width=np.array([r['force_length_width'] for r in rows]);samples=[];peaks=[]
def fit(A,y,upper=1.):return lsq_linear(A,y,bounds=(0,upper),method='bvls',tol=1e-10,max_iter=300).x
for leg in legs:
 j,k=maps[leg];Aall=blocks[leg].astype(float);pall,_,_=envelope[leg];energy=np.sum(error[:,j]**2,axis=1);high=np.flatnonzero(energy>=np.quantile(energy,.9));ix=np.unique(np.concatenate([high[np.linspace(0,len(high)-1,80).astype(int)],np.array([np.argmax(energy)]+[np.argmax(abs(error[:,c])) for c in j])]))
 for frame in ix:
  A=Aall[frame];p=pall[frame];y=target[frame,j];scale=max(np.sqrt(np.mean(target[:,j]**2)),1e-5);C=A/scale;rhs=(y-p)/scale;a=fit(C,rhs);best=A@a+p;row={'leg':leg,'frame':int(frame),'time_s':float(z['time_s'][frame]),'nominal_squared_error':float(np.sum((y-best)**2)),'archived_squared_error':float(np.sum(error[frame,j]**2))}
  variants={'double_upper':(C,rhs,2.),'nonnegative_no_upper':(C,rhs,np.inf),'no_passive':(C,y/scale,1.)}
  x=z['fiber_length_m'][frame,k]/l0[k];fl=np.exp(-((x-1)/width[k])**2);variants['no_force_length_penalty']=(C/np.maximum(fl,1e-20)[None,:],rhs,1.)
  d.qpos[:]=Q[frame];d.qvel[:]=V[frame];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));moment=-dense[tid[k]][:,dofs[j]].T*.01
  Cvel=moment*(F0[k]*fl)[None,:]*1e9/scale;variants['no_force_velocity_penalty']=(Cvel,rhs,1.)
  for name,(M,b,upper) in variants.items():
   aa=fit(M,b,upper);row[name+'_squared_error']=float(np.sum((M@aa-b)**2)*scale**2)
  aa=np.linalg.lstsq(C,rhs,rcond=1e-10)[0];row['signed_unbounded_squared_error']=float(np.sum((C@aa-rhs)**2)*scale**2);row['rank']=int(np.linalg.matrix_rank(C,tol=1e-8));samples.append(row)
 print('counterfactual leg',leg,'states',len(ix),flush=True)
# Exact geometry and force contributors at the maximum-error state of the largest-error joints.
for stat in stats[:10]:
 col=stat['joint_index'];leg=stat['leg'];j,k=maps[leg];local=int(np.flatnonzero(j==col)[0]);frame=int(round(stat['peak_time_s']/.0002));d.qpos[:]=Q[frame];d.qvel[:]=V[frame];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));r=-dense[tid[k],dofs[col]]*.01;x=z['fiber_length_m'][frame,k]/l0[k];fl=np.exp(-((x-1)/width[k])**2);cap=z['active_capacity_N'][frame,k];fv=cap/np.maximum(F0[k]*fl,1e-30);A=r*cap*1e9;fp=r*z['passive_force_N'][frame,k]*1e9;e=error[frame,col];contributors=[]
 for ii,mi in enumerate(k):
  if abs(r[ii])<1e-12:continue
  contributors.append({'id':musids[mi],'activation':float(act[frame,mi]),'moment_arm_mm':float(r[ii]*1000),'F0_uN':float(F0[mi]*1e6),'active_capacity_uN':float(cap[ii]*1e6),'force_length_factor':float(fl[ii]),'force_velocity_factor':float(fv[ii]),'passive_force_uN':float(z['passive_force_N'][frame,mi]*1e6),'active_torque_uNmm':float(A[ii]*act[frame,mi]),'passive_torque_uNmm':float(fp[ii]),'capacity_torque_uNmm':float(A[ii]),'helps_needed_direction_if_increased':bool(A[ii]*e>0)})
 contributors.sort(key=lambda r:abs(r['capacity_torque_uNmm']),reverse=True);peaks.append({'joint':stat['joint'],'frame':frame,'time_s':stat['peak_time_s'],'error_uNmm':float(e),'passive_total_uNmm':float(fp.sum()),'contributors':contributors})
# Actual angle errors from A; this is a different problem from inverse force fitting.
p=R/'guarded_contact/v2_full/contact_bw1_lw1000_bw50_it2_dt5_rollout.npz';zz=np.load(p);qa=source['joint_qpos_indices'];errq=zz['qpos'][:,qa]-Q[:len(zz['time_s']),qa];angle=[]
for col,name in enumerate(names):
 peak=int(np.argmax(abs(errq[:,col])));angle.append({'joint':name,'rmse_deg':float(np.rad2deg(np.sqrt(np.mean(errq[:,col]**2)))),'max_abs_deg':float(np.rad2deg(abs(errq[peak,col]))),'peak_time_s':float(zz['time_s'][peak]),'pre_up09_rmse_deg':float(np.rad2deg(np.sqrt(np.mean(errq[zz['up_z']>=.9,col]**2))))})
angle.sort(key=lambda r:r['rmse_deg'],reverse=True)
ratios={}
for leg in legs+['ALL']:
 ss=[r for r in samples if leg=='ALL' or r['leg']==leg];base=sum(r['nominal_squared_error'] for r in ss);ratios[leg]={'states':len(ss),'nominal_rms_uNmm':float(np.sqrt(base/(11*len(ss)))),'max_nominal_vs_archived_squared_error_difference':max(abs(r['nominal_squared_error']-r['archived_squared_error']) for r in ss),'residual_energy_ratio_vs_nominal':{v:sum(r[v+'_squared_error'] for r in ss)/base for v in ['double_upper','nonnegative_no_upper','signed_unbounded','no_passive','no_force_length_penalty','no_force_velocity_penalty']}}
report={'scope':'Fixed reference states, optimized working muscle model; no modified model or counterfactual forces deployed','frames':N,'joints':66,'relative_force_residual_l2':float(np.linalg.norm(error)/np.linalg.norm(target)),'scalar_envelope_minimum_explained_residual_energy_fraction':float(total_out/np.sum(error**2)),'joint_stats':stats,'counterfactuals':ratios,'peak_contributors':peaks,'A_angle_errors':angle,'warning':'Counterfactual changes interact; percentages are not additive causal attributions. Scalar intervals ignore cross-joint coupling. Force fitting on reference states is distinct from free-walking controller performance.'}
json.dump(report,open(O/'report.json','w'),indent=2);json.dump(samples,open(O/'counterfactual_states.json','w'),indent=2)
print(json.dumps({'top_joints':stats[:8],'counterfactuals':ratios,'A_angles':angle[:8]},indent=2),flush=True)
