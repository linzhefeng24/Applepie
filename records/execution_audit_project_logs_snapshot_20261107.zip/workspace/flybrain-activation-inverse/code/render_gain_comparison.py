"""Render archived FREE simulation states, never reference-state tracking."""
import os;os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/workspace/fly-walking-run/mesa',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
import pathlib,json,subprocess,numpy as np,mujoco
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'gain_search';V=O/'video';V.mkdir(exist_ok=True);m=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m)
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
paths=[R/'feedback_test/muscle_pd_w1000_z0.5_plain_rollout.npz',O/'full_validation/muscle_pd_w2200_z1_plain_dt2_rollout.npz',O/'full_validation/muscle_pd_w6000_z2_plain_rollout.npz'];qs=[np.load(p)['qpos'] for p in paths];assert all(len(q)==30000 for q in qs);renderer=mujoco.Renderer(m,height=480,width=640);option=mujoco.MjvOption();option.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;option.sitegroup[:]=0
writer=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1920x480','-r','50','-i','-','-an','-c:v','libx264','-preset','fast','-bf','0','-crf','20','-pix_fmt','yuv420p',str(V/'three_gains_raw.mp4')],stdin=subprocess.PIPE)
for f,idx in enumerate(range(10,30000,100)):
 ims=[]
 for q in qs:
  d.qpos[:]=q[idx];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_camlight(m,d);renderer.update_scene(d,camera=1,scene_option=option);ims.append(renderer.render().copy())
 writer.stdin.write(np.concatenate(ims,axis=1).tobytes())
 if f%50==0:print('frame',f,flush=True)
writer.stdin.close();assert writer.wait()==0;renderer.close()
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';texts=[(0,'原方案 ω=1000 ζ=0.5','更新 1 ms','前进 4.76 mm；侧移 -1.72 mm'),(640,'新方案 ω=2200 ζ=1','更新 0.4 ms','前进 2.28 mm；侧移 -0.50 mm'),(1280,'新方案 ω=6000 ζ=2','更新 1 ms','前进 5.06 mm；侧移 -14.43 mm')];vf='drawbox=x=0:y=0:w=iw:h=85:color=black@0.75:t=fill'
for x,title,sub,stat in texts:
 for text,y,size,color in [(title,12,24,'white'),(sub,48,21,'white'),('均未形成持续正常步行',410,22,'yellow'),(stat,447,21,'white')]:
  vf+=f",drawtext=fontfile={font}:text='{text}':x={x}+320-tw/2:y={y}:fontsize={size}:fontcolor={color}:shadowcolor=black:shadowx=1:shadowy=1"
out=O/'fly_gain_search_comparison_20261102.mp4';subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(V/'three_gains_raw.mp4'),'-vf',vf,'-an','-c:v','libx264','-preset','fast','-bf','0','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],check=True);subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss','2','-i',str(out),'-frames:v','1',str(O/'gain_comparison_preview.png')],check=True);print('gain comparison ready',flush=True)
