"""Small CPU PPO feasibility baseline. Training resets are confined to episode boundaries.
Evaluation starts at reference frame zero and freely integrates with muscle forces only.
"""
import os
os.environ.update(TF_CPP_MIN_LOG_LEVEL='3',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',TF_NUM_INTEROP_THREADS='1',TF_NUM_INTRAOP_THREADS='1',MUJOCO_GL='egl')
import numpy as np,mujoco,time,pathlib,json,multiprocessing as mp,argparse
import shooting_mpc as s
s.FAST=True
TAU_SCALE=np.maximum(np.sqrt(np.mean(s.src['leg_tau_drive_Nm']**2,axis=0))*1e7,1e-5)
LOCOMOTION=False;FULL_STATE=False;ASSIST_OBS=False
foot_reference=np.load(s.R/'guarded_contact/reference_foot_task.npz')['relative_position_cm'];foot_bodies=np.array([mujoco.mj_name2id(s.m,mujoco.mjtObj.mjOBJ_BODY,'walker/claw_'+t) for t in ['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right']]);core_bodies={i for i in range(s.m.nbody) if (mujoco.mj_id2name(s.m,mujoco.mjtObj.mjOBJ_BODY,i) or '').startswith(('walker/head','walker/abdomen','walker/thorax'))}
class Env:
 def __init__(self,seed):self.rng=np.random.default_rng(seed);self.d=mujoco.MjData(s.m);self.e=np.empty(s.m.nv);self.t=0;self.elapsed=0;self.maxsteps=150;self.training=False;self.assistance=0.
 def reset(self,training=True,maxsteps=150):
  self.training=training
  if not training:self.assistance=0.
  self.maxsteps=maxsteps;self.elapsed=0;self.t=int(self.rng.integers(0,28000)) if training and self.rng.random()<.2 else 0;mujoco.mj_resetData(s.m,self.d)
  for k in ['qpos','qvel','act','ctrl','qacc_warmstart']:getattr(self.d,k)[:]=s.src[k][self.t]
  mujoco.mj_forward(s.m,self.d);return self.obs()
 def obs(self):
  t=min(self.t,29999);mujoco.mj_differentiatePos(s.m,self.e,1.,s.src['qpos'][t],self.d.qpos);dv=self.d.qvel-s.src['qvel'][t];body=self.e[s.rv:s.rv+6].copy();body[:3]*=10
  phase=2*np.pi*t*s.dt*np.array([5,10,20,40]);o=np.r_[self.e[s.fw.dofs]*2,dv[s.fw.dofs]/500,body,self.d.qvel[s.rv:s.rv+6]/np.array([10,10,10,100,100,100]),np.sin(phase),np.cos(phase),s.fw.activation[t]*2-1]
  if FULL_STATE:
   contact=np.zeros(6)
   for con in self.d.contact:
    if con.dist<=0:
     for gg in [int(con.geom1),int(con.geom2)]:
      body=int(s.m.geom_bodyid[gg]);match=np.flatnonzero(foot_bodies==body)
      if len(match):contact[match[0]]=1
   extra=np.r_[self.d.qpos[s.src['joint_qpos_indices']],self.d.qvel[s.fw.dofs]/500,self.d.qpos[s.rq+3:s.rq+7],self.t/30000.,contact]
   if ASSIST_OBS:extra=np.r_[extra,self.assistance]
   o=np.r_[o[:-126],extra,o[-126:]]
  return np.clip(o,-5,5).astype('f4')
 def advance(self,y,record=False,assist=0.):
  self.assistance=float(assist) if self.training else 0.;s.ASSIST=self.assistance;deficit=[]
  trace=[];failed=False;ref=np.clip(s.fw.activation[min(self.t,29999)],.01,.99);activation=1/(1+np.exp(-np.clip(np.log(ref/(1-ref))+y,-30,30)))
  for _ in range(5):
   t=min(self.t,29999);a=activation
   mujoco.mj_forward(s.m,self.d);f,x=s.forces(self.d,a)
   up=float(self.d.xmat[s.thorax].reshape(3,3)[2,2])
   if f is None or up<.5:failed=True;break
   if self.assistance:
    teacher=s.teacher_force(self.d,ready=True);deficit.append(float(np.mean(((f[s.fw.dofs]-teacher[s.fw.dofs])/TAU_SCALE)**2)))
   if record:trace.append(dict(time_s=self.elapsed*5*s.dt+len(trace)*s.dt,qpos=self.d.qpos.copy(),qvel=self.d.qvel.copy(),activation=a.copy(),up_z=up,thorax_mm=self.d.xpos[s.thorax]*10,fiber_min_norm=float(x.min()),fiber_max_norm=float(x.max())))
   ok,_=s.step(self.d,a,t);self.t+=1
   if not ok:failed=True;break
  self.elapsed+=1;obs=self.obs();e=self.e;qe=float(np.mean(e[s.fw.dofs]**2));be=e[s.rv:s.rv+6];ve=float(np.mean(((self.d.qvel-s.src['qvel'][min(self.t,29999)])[s.fw.dofs]/500)**2))
  body_v=(self.d.qvel[s.rv:s.rv+3]-s.src['qvel'][min(self.t,29999),s.rv:s.rv+3])/2.;reward=.35*np.exp(-5*qe)+.15*np.exp(-ve)+.25*np.exp(-10*np.sum(be[3:]**2))+.15*np.exp(-np.sum((be[:3]/.05)**2))+.1*np.exp(-np.sum(body_v**2))
  if LOCOMOTION:
   ti=min(self.t,29999);fp=self.d.xpos[foot_bodies]-self.d.xpos[s.thorax];foot_error=float(np.mean((fp-foot_reference[ti])**2));desired=max(.5,float(np.linalg.norm(s.src['qvel'][ti,s.rv:s.rv+2])));progress=float(np.clip(self.d.qvel[s.rv]/desired,-1,2));body_touch=False
   for con in self.d.contact:
    g1,g2=int(con.geom1),int(con.geom2);b1,b2=int(s.m.geom_bodyid[g1]),int(s.m.geom_bodyid[g2])
    if con.efc_address>=0 and con.dist<=0 and ((b1==0 and b2 in core_bodies) or (b2==0 and b1 in core_bodies)):body_touch=True;break
   reward=.2*np.exp(-5*qe)+.2*np.exp(-10*np.sum(be[3:]**2))+.15*np.exp(-foot_error/.0004)+.15*np.exp(-(be[2]/.01)**2)+.3*progress-.05*abs(self.d.qvel[s.rv+1])/desired-float(body_touch)
  if deficit:reward-=.2*self.assistance*min(float(np.mean(deficit)),10.)
  if not np.isfinite(reward):reward=-2.;failed=True
  done=failed or self.elapsed>=self.maxsteps or self.t>=30000
  if failed:reward-=2
  return obs,float(reward),done,trace

def worker(pipe,seed):
 env=Env(seed)
 while True:
  command,payload=pipe.recv()
  if command=='close':break
  if command=='reset':pipe.send(env.reset(True,payload));continue
  y,maxsteps,alpha=payload;o,r,done,_=env.advance(y,assist=alpha)
  if done:o=env.reset(True,maxsteps)
  pipe.send((o,r,done))
 pipe.close()

def main(args):
 global LOCOMOTION,foot_reference,FULL_STATE,ASSIST_OBS
 LOCOMOTION=args.locomotion_reward;FULL_STATE=args.full_state;ASSIST_OBS=args.assist_curriculum
 if args.speed!=1.:
  s.prepare_source(args.speed);phase=np.arange(len(foot_reference))*args.speed;ii=np.arange(len(phase));shape=foot_reference.shape;flat=foot_reference.reshape(len(phase),-1);foot_reference=np.column_stack([np.interp(phase,ii,flat[:,j]) for j in range(flat.shape[1])]).reshape(shape)
 out=s.R/'ppo_muscle'/args.tag;out.mkdir(parents=True,exist_ok=True);json.dump(vars(args),open(out/'config.json','w'),indent=2)
 np.random.seed(args.seed);pipes=[];processes=[]
 for i in range(4):
  pa,ch=mp.get_context('fork').Pipe();p=mp.get_context('fork').Process(target=worker,args=(ch,args.seed+100+i));p.start();pipes.append(pa);processes.append(p)
 import tensorflow as tf
 tf.random.set_seed(args.seed);tf.config.threading.set_intra_op_parallelism_threads(1);tf.config.threading.set_inter_op_parallelism_threads(1)
 for pipe in pipes:pipe.send(('reset',100))
 obs=np.stack([p.recv() for p in pipes]);dim=obs.shape[1]
 def make_net(input_dim):
  inp=tf.keras.Input(shape=(input_dim,));h=tf.keras.layers.Dense(256,activation='tanh')(inp);h=tf.keras.layers.Dense(256,activation='tanh')(h);mu=tf.keras.layers.Dense(126,kernel_initializer='zeros',bias_initializer='zeros')(h);vh=tf.keras.layers.Dense(256,activation='tanh')(inp);vh=tf.keras.layers.Dense(256,activation='tanh')(vh);value=tf.keras.layers.Dense(1)(vh);net=tf.keras.Model(inp,[mu,value])
  return net,inp,mu
 net,inp,mu=make_net(dim);logstd=tf.Variable(np.full(126,-1.2,dtype='f4'));opt=tf.keras.optimizers.Adam(3e-5)
 @tf.function
 def predict(x):return net(x,training=False)
 @tf.function
 def update(x,y,oldlog,adv,returns,oldvalue):
  with tf.GradientTape() as tape:
   mean,v=net(x,training=True);v=tf.squeeze(v,1);ls=tf.clip_by_value(logstd,-3.,0.);lp=-.5*tf.reduce_sum(((y-mean)/tf.exp(ls))**2+2*ls+np.log(2*np.pi),axis=1);ratio=tf.exp(tf.clip_by_value(lp-oldlog,-20,20));policy=-tf.reduce_mean(tf.minimum(ratio*adv,tf.clip_by_value(ratio,.8,1.2)*adv));vf=.5*tf.reduce_mean((v-returns)**2);loss=policy+.5*vf-.0001*tf.reduce_sum(ls)
  variables=net.trainable_variables+[logstd];grads=tape.gradient(loss,variables);grads,_=tf.clip_by_global_norm(grads,.5);opt.apply_gradients(zip(grads,variables));return loss,tf.reduce_mean(oldlog-lp)
 if args.teacher_bc:
  teacher=np.load(s.R/'guarded_contact/v2_full/contact_bw1_lw1000_bw50_it2_dt5_rollout.npz');Q=teacher['qpos'];V=teacher['qvel'];A=teacher['activation'];env=Env(5);X=[];Y=[];BM=[]
  for i in range(0,len(Q),5):
   env.t=i;env.d.qpos[:]=Q[i];env.d.qvel[:]=V[i];X.append(env.obs());Y.append(A[i]);s.FAST=False;s.forces(env.d,A[i]);J=s.dense[s.fw.tid][:,s.fw.dofs];x=(env.d.ten_length[s.fw.tid]*.01-s.fw.slack)/s.fw.l0;vn=(s.dense[s.fw.tid]@V[i]*.01)/(s.fw.l0*s.fw.vmax);neg=np.minimum(vn,0);pos=np.maximum(vn,0);fv=np.where(vn<0,np.maximum(0,(1+neg)/(1-neg/s.fw.hill)),1+(s.fw.ecc-1)*pos/(s.fw.hill+pos));cap=s.fw.F0*np.exp(-((x-1)/s.fw.width)**2)*fv;BM.append(-J.T*cap[None,:]*1e5);s.FAST=True
  X=np.array(X,dtype='f4');Y=np.array(Y,dtype='f4');BM=np.array(BM,dtype='f4');target=np.einsum('nji,ni->nj',BM,Y);scale=np.maximum(np.sqrt(np.mean(target**2,axis=0)),1e-5);BM/=scale[None,:,None];actor=tf.keras.Model(inp,mu);bcopt=tf.keras.optimizers.Adam(3e-4)
  @tf.function
  def bcupdate(x,y,b):
   with tf.GradientTape() as tape:
    mean=actor(x,training=True);ref=tf.clip_by_value((x[:,-126:]+1)/2,.01,.99);prediction=tf.sigmoid(tf.math.log(ref/(1-ref))+mean);torque=tf.einsum('nji,ni->nj',b,prediction-y);loss=tf.reduce_mean(torque**2)+.0001*tf.reduce_mean((prediction-y)**2)
   bcopt.apply_gradients(zip(tape.gradient(loss,actor.trainable_variables),actor.trainable_variables));return loss
  for k in range(args.teacher_bc):
   ix=np.random.randint(0,len(X),256);loss=bcupdate(X[ix],Y[ix],BM[ix])
   if k%500==0:print('BC',k,float(loss),flush=True)
  pred=actor(X).numpy();ref=np.clip((X[:,-126:]+1)/2,.01,.99);activation_pred=1/(1+np.exp(-np.clip(np.log(ref/(1-ref))+pred,-30,30)));bc_report={'samples':len(X),'activation_rmse':float(np.sqrt(np.mean((activation_pred-Y)**2))),'normalized_torque_rmse':float(np.sqrt(np.mean(np.einsum('nji,ni->nj',BM,activation_pred-Y)**2))),'teacher_duration_s':len(Q)*s.dt};json.dump(bc_report,open(out/'bc_report.json','w'),indent=2);print('BC_RESULT',bc_report,flush=True)
 if args.resume_weights:
  previous=json.load(open(pathlib.Path(args.resume_weights).parent.parent/'config.json'));old_dim=dim-(143 if args.full_state and not previous.get('full_state',False) else 0);oldnet,_,_=make_net(old_dim);oldnet.load_weights(args.resume_weights);weights=[]
  for w,nw in zip(oldnet.get_weights(),net.get_weights()):
   if w.shape!=nw.shape:
    assert w.ndim==2 and nw.shape[0]-w.shape[0]==143;w=np.concatenate([w[:-126],np.zeros((143,w.shape[1]),dtype=w.dtype),w[-126:]],axis=0)
   weights.append(w)
  net.set_weights(weights);oldobs=np.concatenate([obs[:,:-269],obs[:,-126:]],axis=1) if old_dim!=dim else obs;oldmean=oldnet(oldobs)[0].numpy();newmean=net(obs)[0].numpy();transfer_error=float(np.max(np.abs(oldmean-newmean)));assert transfer_error<1e-4;json.dump({'max_initial_mean_error':transfer_error,'old_observation_dim':old_dim,'new_observation_dim':dim},open(out/'transfer_validation.json','w'));print('Loaded initialization',args.resume_weights,'transfer_error',transfer_error,flush=True)
 def evaluate(number):
  env=Env(123);o=env.reset(False,6000);logs=[]
  for j in range(6000):
   mean,_=predict(o[None,:]);o,r,done,trace=env.advance(mean.numpy()[0],True);logs.extend(trace)
   if done:break
  arr={k:np.array([r[k] for r in logs]) for k in logs[0]} if logs else {};duration=len(logs)*s.dt
  path=out/f'eval_{number:06d}';path.mkdir(exist_ok=True)
  if arr:np.savez_compressed(path/'rollout.npz',**arr,muscle_ids=np.array([r['id'] for r in s.fw.rows]))
  report={'training_transitions':number,'duration_s':duration,'forward_mm':float(arr['thorax_mm'][-1,0]-arr['thorax_mm'][0,0]) if arr else 0,'min_up':float(arr['up_z'].min()) if arr else None,'not_yet_walking_certified':True,'evaluation_teacher_fraction':float(s.ASSIST)};json.dump(report,open(path/'report.json','w'),indent=2);net.save_weights(str(path/'policy'));np.save(path/'logstd.npy',logstd.numpy());print('EVAL',json.dumps(report),flush=True);return report
 reports=[] if args.skip_initial_eval else [evaluate(0)];history=[];wall=time.time();total=0
 try:
  for iteration in range(args.iterations):
   batch=[];maxsteps=min(6000,500+iteration*50);alpha=max(0.,1-max(0,iteration-20)/150.) if args.assist_curriculum else 0.
   for k in range(128):
    mean,val=predict(obs);mean=mean.numpy();val=val.numpy().ravel();ls=np.clip(logstd.numpy(),-3,0);y=(mean+np.random.normal(size=mean.shape)*np.exp(ls)).astype('f4');lp=(-.5*np.sum(((y-mean)/np.exp(ls))**2+2*ls+np.log(2*np.pi),axis=1)).astype('f4')
    for p,action in zip(pipes,y):p.send(('step',(action,maxsteps,alpha)))
    results=[p.recv() for p in pipes];newobs=np.stack([r[0] for r in results]);reward=np.array([r[1] for r in results],dtype='f4');done=np.array([r[2] for r in results],dtype='f4');batch.append((obs.copy(),y,lp,val,reward,done));obs=newobs
   _,nv=predict(obs);nv=nv.numpy().ravel();gae=np.zeros(4,dtype='f4');adv=[];returns=[]
   for b in batch[::-1]:
    delta=b[4]+.99*nv*(1-b[5])-b[3];gae=delta+.99*.95*(1-b[5])*gae;adv.append(gae.copy());returns.append(gae+b[3]);nv=b[3]
   x=np.concatenate([b[0] for b in batch]);y=np.concatenate([b[1] for b in batch]);lp=np.concatenate([b[2] for b in batch]);v=np.concatenate([b[3] for b in batch]);ad=np.array(adv[::-1]).reshape(-1);ret=np.array(returns[::-1]).reshape(-1);ad=(ad-ad.mean())/(ad.std()+1e-8)
   early_kl=False
   for epoch in range(4):
    ix=np.random.permutation(len(x))
    for start in range(0,len(x),256):
     j=ix[start:start+256];loss,kl=update(x[j],y[j],lp[j],ad[j],ret[j],v[j])
     if float(kl)>.03:early_kl=True;break
    if early_kl:break
   total+=len(x);row={'iteration':iteration,'teacher_fraction':alpha,'transitions':total,'mean_reward':float(np.mean([b[4] for b in batch])),'loss':float(loss),'kl':float(kl),'wall_s':time.time()-wall};history.append(row);print('TRAIN',json.dumps(row),flush=True)
   if (iteration+1)%args.eval_every==0:reports.append(evaluate(total))
  if total and (not reports or reports[-1]['training_transitions']!=total):reports.append(evaluate(total))
 finally:
  for p in pipes:p.send(('close',None))
  for p in processes:p.join(timeout=10)
  json.dump(history,open(out/'history.json','w'),indent=2);json.dump(reports,open(out/'evaluation_summary.json','w'),indent=2)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--tag',default='baseline');p.add_argument('--iterations',type=int,default=40);p.add_argument('--eval-every',type=int,default=10);p.add_argument('--seed',type=int,default=42);p.add_argument('--teacher-bc',type=int,default=0);p.add_argument('--resume-weights',default='');p.add_argument('--locomotion-reward',action='store_true');p.add_argument('--skip-initial-eval',action='store_true');p.add_argument('--speed',type=float,default=1.);p.add_argument('--full-state',action='store_true');p.add_argument('--assist-curriculum',action='store_true');main(p.parse_args())
