import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import json,numpy as np,mujoco
import multitrajectory_ab as b
from guarded_contact_controller import GuardedContactController
ref=json.load(open(b.ROOT/'references.json'))[1];src,groups,a=b.load_ref(ref);results=[]
for weight in [0.,100.]:
 m=mujoco.MjModel.from_binary_path(str(b.MODEL));m.actuator_gainprm[src['joint_actuator_mask']]=0;m.actuator_biasprm[src['joint_actuator_mask']]=0;d=mujoco.MjData(m);t=100
 for k in ['qpos','qvel','act','ctrl','qacc_warmstart']:getattr(d,k)[:]=src[k][t]
 d.qpos[src['joint_qpos_indices'][0]]+=.03;mujoco.mj_forward(m,d);c=GuardedContactController(m,src,b.ROWS,src['joint_dof_indices'],groups,a,leg_omega=300,body_omega=50,body_weight=2,iterations=2,torque_weight=weight);c.set_control_steps(5);B,p,_=c.force_map(d);d.qfrc_applied[:]=p+B@a[t];mujoco.mj_forward(m,d);state=np.empty(mujoco.mj_stateSize(m,mujoco.mjtState.mjSTATE_INTEGRATION));mujoco.mj_getState(m,d,state,mujoco.mjtState.mjSTATE_INTEGRATION);solution,info=c.solve(d,t);after=state.copy();mujoco.mj_getState(m,d,after,mujoco.mjtState.mjSTATE_INTEGRATION);B,p,_=c.force_map(d);tr=((p+B@solution)[c.dofs]-c.torque_target_native[t])/c.torque_scale;err=c.weights*(info['qacc_actual'][c.task]-c.target(d,t)[c.task]);expected=float(err@err+c.ridge*(solution@solution)+weight**2*(tr@tr));assert np.isclose(expected,info['final_native_acceleration_cost'],rtol=1e-9,atol=1e-9);assert np.array_equal(state,after);assert np.all((solution>=0)&(solution<=1));results.append(dict(weight=weight,normalized_torque_squared_error=float(tr@tr),reported_total=info['final_native_acceleration_cost'],independent_total=expected,main_state_unchanged=True))
assert results[1]['normalized_torque_squared_error']<=results[0]['normalized_torque_squared_error']+1e-6
(b.ROOT/'objective_validation.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
