import os;os.environ['MPLCONFIGDIR']='/workspace/fly-walking-run/mpl'
import pathlib,json,numpy as np,matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
import mujoco
from scipy.ndimage import uniform_filter1d,median_filter
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'multitrajectory_ab_20261104';src=np.load('/workspace/fly-walking-run/alternative_references/speed0.5_seed2/walking_6s_5000Hz.npz');s={k:src[k] for k in ['time_s','thorax_xyz_cm','joint_names','joint_qpos_indices','qpos']};aa=np.load(O/'full/speed0.5_seed2_A_torque_first_it1/rollout.npz');bb=np.load(O/'full/speed0.5_seed2_B_torque_first_it1/rollout.npz');a={k:aa[k] for k in aa.files};b={k:bb[k] for k in bb.files};fig,ax=plt.subplots(2,2,figsize=(12,8),layout='constrained');sel=s['time_s']<=2.5;refx=(s['thorax_xyz_cm'][:,0]-s['thorax_xyz_cm'][0,0])*10
ax[0,0].plot(s['time_s'][sel],refx[sel],label='reference 0.5 cm/s');
for q,label in [(a,'A'),(b,'B')]:ax[0,0].plot(q['time_s'],q['thorax_mm'][:,0]-q['thorax_mm'][0,0],label=label)
ax[0,0].set(xlabel='Time (s)',ylabel='Forward displacement (mm)',title='Longer survival did not produce reference locomotion');ax[0,0].legend()
for q,label in [(a,'A'),(b,'B')]:ax[0,1].plot(q['time_s'],q['up_z'],label=label)
ax[0,1].axhline(.7,ls='--',color='gray');ax[0,1].set(xlabel='Time (s)',ylabel='Thorax up-z',title='Actual posture; traces end when stopped');ax[0,1].legend()
col=s['joint_names'].tolist().index('walker/tibia_T3_left');qa=s['joint_qpos_indices'][col];n=len(b['time_s']);ax[1,0].plot(b['time_s'],np.rad2deg(s['qpos'][:n,qa]),label='reference');ax[1,0].plot(b['time_s'],np.rad2deg(b['qpos'][:,qa]),label='B actual');ax[1,0].set(xlabel='Time (s)',ylabel='Left hind tibia angle (degrees)',title='A major joint remains far from its reference');ax[1,0].legend()
model=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb'));body=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');threshold=model.body_subtreemass[body]*np.linalg.norm(model.opt.gravity)*.01;stance=median_filter(b['support_dyne']>threshold,size=(25,1),mode='nearest')
ax[1,1].imshow(stance.T,aspect='auto',origin='upper',extent=[b['time_s'][0],b['time_s'][-1],5.5,-.5],cmap='Greens',vmin=0,vmax=1,interpolation='nearest');ax[1,1].set_yticks(range(6),['LF','RF','LM','RM','LH','RH']);ax[1,1].set(xlabel='Time (s)',title='B foot support: several legs stop alternating')
fig.savefig(O/'comparison_metrics.png',dpi=150);plt.close(fig)
