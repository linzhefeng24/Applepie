"""Native guarded contact allocation with genuine smaller physics steps; source data untouched."""
import pathlib,time,json,argparse,numpy as np,mujoco
import shooting_mpc as s
from guarded_contact_controller import GuardedContactController
from test_feedback_walk import groups

def main(args):
 out=s.R/'solver_comparison_20261103'/args.tag;out.mkdir(parents=True,exist_ok=True);m=s.m;m.opt.timestep=s.dt/args.substeps;s.FAST=True;s.ASSIST=0.;d=mujoco.MjData(m)
 for k in ['qpos','qvel','act','ctrl','qacc_warmstart']:getattr(d,k)[:]=s.src[k][0]
 c=GuardedContactController(m,s.src,s.fw.rows,s.fw.dofs,groups,s.fw.activation,leg_omega=1000,body_omega=50,body_weight=1,iterations=2);c.set_control_steps(5*args.substeps)
 a=s.fw.activation[0].astype(float).copy();start=time.time();logs={k:[] for k in ['time_s','qpos','qvel','activation','up_z','thorax_mm','fiber_min_norm','fiber_max_norm']};controls=[];failure=None;fall=None;maxnative=0.;control_period=5*args.substeps
 for physical in range(round(args.duration/s.dt)*args.substeps):
  t=physical//args.substeps;d.ctrl[:]=s.src['ctrl'][t];force,x=s.forces(d,a)
  if force is None:failure='actual muscle domain';break
  d.qfrc_applied[:]=s.src['qfrc_applied'][t]+force;mujoco.mj_forward(m,d)
  if physical%control_period==0:
   try:c.current_activation=s.fw.activation[t].copy();a,info=c.solve(d,t)
   except Exception as e:failure=str(e);break
   force,x=s.forces(d,a);d.qfrc_applied[:]=s.src['qfrc_applied'][t]+force;d.qacc_warmstart[:]=0;mujoco.mj_forward(m,d);controls.append({'time_s':physical*m.opt.timestep,**{k:v for k,v in info.items() if not isinstance(v,np.ndarray)}})
  up=float(d.xmat[s.thorax].reshape(3,3)[2,2]);maxnative=max(maxnative,float(np.max(np.abs(d.actuator_force[s.mask]))))
  if physical%args.substeps==0:
   vals=dict(time_s=physical*m.opt.timestep,qpos=d.qpos.copy(),qvel=d.qvel.copy(),activation=a.copy(),up_z=up,thorax_mm=d.xpos[s.thorax]*10,fiber_min_norm=float(x.min()),fiber_max_norm=float(x.max()))
   for k,v in vals.items():logs[k].append(v)
  if up<.5:fall=float(d.time);break
  ok,x=s.step(d,a,t)
  if not ok:failure='native warning or domain';break
  if physical%(250*args.substeps)==0:print('t',round(d.time,4),'up',up,'x',d.xpos[s.thorax]*10,'wall',time.time()-start,flush=True)
 arr={k:np.array(v) for k,v in logs.items()};np.savez_compressed(out/'rollout.npz',**arr,muscle_ids=np.array([r['id'] for r in s.fw.rows]));r={'duration_s':float(d.time),'fall_s':fall,'failure':failure,'forward_mm':float(arr['thorax_mm'][-1,0]-arr['thorax_mm'][0,0]),'min_up':float(arr['up_z'].min()),'native_leg_drive_max':maxnative,'fiber_min':float(arr['fiber_min_norm'].min()),'fiber_max':float(arr['fiber_max_norm'].max()),'teacher_fraction':s.ASSIST,'wall_s':time.time()-start};json.dump(r,open(out/'report.json','w'),indent=2);cfg=dict(vars(args),speed=1.,fast_force=True,warmstart_zero_every_reference_frames=5,initial_forward=0,reference_seed=True);json.dump(cfg,open(out/'config.json','w'),indent=2);json.dump(controls,open(out/'controls.json','w'));print('RESULT',r,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--tag',default='guarded_refine4');p.add_argument('--substeps',type=int,default=4);p.add_argument('--duration',type=float,default=6.);main(p.parse_args())
