import pathlib,json,csv,argparse
import numpy as np
from gain_search import ROOT,score

def load(stage):
 rows=[]
 for p in ROOT.glob(f'stage{stage}_worker*.json'):rows.extend(json.load(open(p)))
 return rows

def summarize(stage):
 rows=load(stage);good=[r for r in rows if 'exception' not in r];rank=sorted(good,key=score,reverse=True)
 if good:
  keys=['id','omega','zeta','control_steps','duration_s','displacement_x_mm','displacement_y_mm','late_moving_legs','upright_fraction','mean_angle_error_rad','score','failure','first_sustained_fall_s']
  with open(ROOT/f'stage{stage}_results.csv','w') as f:
   w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
   for r in sorted(good,key=lambda r:r['config']['id']):w.writerow({k:r['config'].get(k,r.get(k)) for k in keys})
 print('stage',stage,'finished',len(rows),'exceptions',len(rows)-len(good))
 for r in rank[:8]:print(r['config'],'forward_mm',round(r['displacement_x_mm'],3),'duration',r['duration_s'],'moving_legs',r['late_moving_legs'],'score',round(score(r),3))
 return rows,rank

def next_stage():
 rows,rank=summarize(1);assert len(rows)==72,'Do not select before entire planned sweep completes'
 chosen=[];seen=set()
 def add(c):
  i=c['config']['id']
  if i not in seen:chosen.append(c['config']);seen.add(i)
 for r in rank[:4]:add(r)
 survivors=[r for r in rank if r['duration_s']>=.649 and r['failure'] is None and r['first_sustained_fall_s'] is None]
 for r in sorted(survivors,key=lambda r:(r['late_moving_legs'],r['displacement_x_mm']),reverse=True)[:4]:add(r)
 for r in sorted(survivors,key=lambda r:r['displacement_x_mm'],reverse=True)[:4]:add(r)
 for r in rank:
  if len(chosen)>=12:break
  add(r)
 (ROOT/'stage2_plan.json').write_text(json.dumps({'selection':'top scoring + leg cycling + forward progress; full planned sweep completed before selection','duration_s':2.,'configs':chosen},indent=2));print('stage2 selected',len(chosen))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--stage',type=int,default=1);p.add_argument('--next',action='store_true');a=p.parse_args()
 if a.next:next_stage()
 else:summarize(a.stage)
