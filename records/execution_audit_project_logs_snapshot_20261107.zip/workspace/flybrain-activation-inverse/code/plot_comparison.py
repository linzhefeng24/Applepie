import pathlib,numpy as np,json
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=pathlib.Path('/workspace/flybrain-activation-inverse');z={k:v for k,v in np.load(R/'output/activation_6s_5000Hz.npz').items()};u={k:v for k,v in np.load(R/'output/activation_upper_capacity.npz').items()};t=z['time_s'];target=z['target_torque_Nm']*1e9;fig,ax=plt.subplots(2,1,figsize=(11,6),constrained_layout=True);k=int(np.argmax(np.mean(target[:,:11]**2,axis=0)));sel=(t>=1)&(t<=1.2)
ax[0].plot(t[sel],target[sel,k],label='Fixed target',color='black',lw=1)
for data,label in [(z,'Default capacity'),(u,'Higher capacity within working bounds')]:
 ax[0].plot(t[sel],data['predicted_torque_Nm'][sel,k]*1e9,label=label,lw=.8);ax[1].plot(t[::10],np.sqrt(np.mean((data['residual_torque_Nm']*1e9)**2,axis=1))[::10],label=label,lw=.8)
ax[0].set_title(str(z['joint_names'][k]));ax[0].set_ylabel('Torque (uN mm)');ax[0].legend(fontsize=8);ax[1].set_ylabel('Residual RMS over 66 DOFs (uN mm)');ax[1].set_xlabel('Recorded time (s)');ax[1].legend(fontsize=8);fig.suptitle('Fixed-trajectory inverse allocation: residuals retained, not a validated muscle reconstruction');fig.savefig(R/'output/torque_fit_comparison.png',dpi=140)
