"""Independent bounded muscle allocation at every recorded state; no temporal prior."""
import pathlib,json,hashlib,time,os
import numpy as np,mujoco
from scipy.optimize import lsq_linear
R=pathlib.Path('/workspace/flybrain-activation-inverse'); S=pathlib.Path('/workspace/fly-walking-run/output')
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for chunk in iter(lambda:f.read(8*1024**2),b''):h.update(chunk)
 return h.hexdigest()
def allocate(A,b,scale,ridge=1e-6):
 # Torque scale fixed for a leg over the recording; never frame dependent.
 n=A.shape[1];C=np.vstack([A/scale,np.sqrt(ridge)*np.eye(n)]);y=np.r_[b/scale,np.zeros(n)]
 fit=lsq_linear(C,y,bounds=(0,1),method='bvls',tol=1e-9,max_iter=200)
 return np.clip(fit.x,0,1),fit.optimality,fit.status

def main():
 source=pathlib.Path(os.environ.get('INVERSE_SOURCE',str(S/'walking_6s_5000Hz.npz')));before=digest(source);z=np.load(source);Q=z['qpos'];V=z['qvel'];tau=z['leg_tau_drive_Nm']*1e9;dofs=z['joint_dof_indices'];names=z['joint_names'].tolist();N=len(Q)
 GP=pathlib.Path(os.environ.get('INVERSE_GEOMETRY',str(R/'model/geometry.json')));MP=pathlib.Path(os.environ.get('INVERSE_MODEL',str(R/'model/muscle_geometry.mjb')));OUT=pathlib.Path(os.environ.get('INVERSE_OUTPUT',str(R/'output')));OUT.mkdir(exist_ok=True,parents=True)
 meta=json.load(open(GP));rows=meta['records'];M=len(rows);m=mujoco.MjModel.from_binary_path(str(MP));d=mujoco.MjData(m)
 tid=np.array([r['tendon_index'] for r in rows]);l0=np.array([r['fiber_length0_m'] for r in rows]);slack=np.array([r['tendon_slack_length_m'] for r in rows]);F0=np.array([r['F0_N'] for r in rows]);vmax=np.array([r['vmax_L0_per_s'] for r in rows]);legs=['LF','RF','LM','RM','LH','RH'];tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right']
 groups=[(np.array([i for i,n in enumerate(names) if n.endswith(tok)]),np.array([i for i,r in enumerate(rows) if r['leg']==leg])) for leg,tok in zip(legs,tokens)]
 a=np.zeros((N,M));length=np.zeros_like(a);velocity=np.zeros_like(a);capacity=np.zeros_like(a);passive=np.zeros_like(a);prediction=np.zeros_like(tau);optimality=np.zeros((N,6));status=np.zeros((N,6),dtype=np.int8);scale=np.array([max(np.sqrt(np.mean(tau[:,j]**2)),1e-6) for j,k in groups]);blocks=[np.empty((N,len(j),len(k)),dtype=np.float32) for j,k in groups]
 width=np.array([r.get('force_length_width',.5) for r in rows]);hill=np.array([r.get('force_velocity_hill_shape',.25) for r in rows]);ecc=np.array([r.get('eccentric_cap',1.5) for r in rows]);ps=np.array([r.get('passive_slack_normalized',1.) for r in rows]);strain=np.array([r.get('passive_strain_at_F0',.5) for r in rows]);pexp=np.array([r.get('passive_exponent',4.) for r in rows])
 start=time.time();max_cross=0.;fd_error=0.
 for t in range(N):
  d.qpos[:]=Q[t];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d)
  dense=np.empty((m.ntendon,m.nv));mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));J=dense[tid].copy();L=d.ten_length[tid]*.01;vf=(J@V[t])*.01;lf=L-slack;x=lf/l0;vn=vf/(l0*vmax)
  neg=np.minimum(vn,0);pos=np.maximum(vn,0);fl=np.exp(-((x-1)/width)**2);fv=np.where(vn<0,np.maximum(0,(1+neg)/(1-neg/hill)),1+(ecc-1)*pos/(hill+pos))
  cap=F0*fl*fv;fp=F0*np.expm1(np.clip(pexp*np.maximum(x-ps,0)/strain,0,30))/np.expm1(pexp)
  moment=-J[:,dofs].T*.01;A=moment*cap[None,:]*1e9;p=moment@fp*1e9
  length[t]=lf;velocity[t]=vf;capacity[t]=cap;passive[t]=fp;prediction[t]=p
  for g,(j,k) in enumerate(groups):
   mat=A[np.ix_(j,k)];sol,opt,st=allocate(mat,tau[t,j]-p[j],scale[g]);a[t,k]=sol;prediction[t,j]+=mat@sol;blocks[g][t]=mat;optimality[t,g]=opt;status[t,g]=st
   other=np.setdiff1d(np.arange(66),j);max_cross=max(max_cross,float(np.max(np.abs(A[np.ix_(other,k)]))))
  if t%3000==0:print('frame',t,'seconds',round(time.time()-start,1),flush=True)
  if t in [0,N//2,N-1]:
   for col in [0,11,33,55]:
    addr=z['joint_qpos_indices'][col];qsave=d.qpos.copy();h=1e-6
    d.qpos[addr]+=h;mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);plus=d.ten_length[tid].copy()
    d.qpos[:]=qsave;d.qpos[addr]-=h;mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);minus=d.ten_length[tid].copy();fd_error=max(fd_error,float(np.max(np.abs((plus-minus)/(2*h)-J[:,dofs[col]]))))
    d.qpos[:]=qsave
 residual=prediction-tau;after=digest(source);assert before==after
 np.savez_compressed(OUT/'activation_6s_5000Hz.npz',time_s=z['time_s'],muscle_ids=np.array([r['id'] for r in rows]),joint_names=np.array(names),activation=a.astype('f4'),target_torque_Nm=z['leg_tau_drive_Nm'],predicted_torque_Nm=prediction*1e-9,residual_torque_Nm=prediction*1e-9-z['leg_tau_drive_Nm'],fiber_length_m=length.astype('f4'),fiber_velocity_m_s=velocity.astype('f4'),active_capacity_N=capacity.astype('f4'),passive_force_N=passive.astype('f4'),solver_status=status,solver_optimality=optimality)
 np.savez_compressed(OUT/'forward_blocks.npz',**{leg:mat for leg,mat in zip(legs,blocks)},**{leg+'_joint_indices':j for leg,(j,k) in zip(legs,groups)},**{leg+'_muscle_indices':k for leg,(j,k) in zip(legs,groups)})
 report={'frames':N,'muscles':M,'joint_dofs':66,'source_sha256_before':before,'source_sha256_after':after,'geometry_sha256':digest(GP),'independent_frame_problem':True,'temporal_regularization':False,'ridge':1e-6,'torque_scale_uN_mm_per_leg':scale.tolist(),'torque_target_rms_uN_mm':float(np.sqrt(np.mean(tau**2))),'residual_rms_uN_mm':float(np.sqrt(np.mean(residual**2))),'relative_residual_L2':float(np.linalg.norm(residual)/np.linalg.norm(tau)),'residual_max_abs_uN_mm':float(np.max(np.abs(residual))),'fraction_activation_at_upper_bound':float(np.mean(a>1-1e-6)),'fraction_activation_at_lower_bound':float(np.mean(a<1e-6)),'fiber_length_nonpositive_count':int(np.count_nonzero(length<=0)),'cross_leg_matrix_max_uN_mm':max_cross,'finite_difference_tendon_derivative_max_abs_cm_per_rad':fd_error,'solver_failure_count':int(np.count_nonzero(status<=0)),'elapsed_s':time.time()-start,'per_leg':{leg:{'target_rms_uN_mm':float(np.sqrt(np.mean(tau[:,j]**2))),'residual_rms_uN_mm':float(np.sqrt(np.mean(residual[:,j]**2)))} for leg,(j,k) in zip(legs,groups)}}
 json.dump(report,open(OUT/'report.json','w'),indent=2);print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
