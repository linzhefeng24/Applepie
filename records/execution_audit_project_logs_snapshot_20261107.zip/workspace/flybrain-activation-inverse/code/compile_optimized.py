import pathlib,json,xml.etree.ElementTree as E
import mujoco,numpy as np
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'optimization';p=O/'optimized_geometry.json';g=json.load(open(p));m=mujoco.MjModel.from_binary_path(str(R/'model/muscle_geometry.mjb'));tree=E.parse(R/'model/muscle_geometry.xml');sites={s.attrib.get('name'):s for s in tree.iter('site') if s.attrib.get('name')}
for r in g['records']:
 r['initial_alignment_at_reference']=r.pop('alignment_at_reference',None)
 for s in r['points']:
  i=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_SITE,s['site']);assert i>=0;m.site_pos[i]=s['pos_cm'];sites[s['site']].set('pos',' '.join(map(str,s['pos_cm'])))
json.dump(g,open(p,'w'),indent=2);mujoco.mj_saveModel(m,str(O/'optimized_geometry.mjb'),None);tree.write(O/'optimized_geometry.xml',encoding='unicode');print('Compiled optimized sites; original model unchanged')
