import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/fly-gain-plots')
import pathlib,json,hashlib,csv
import numpy as np,mujoco
import forward_walk_test as fw
R=fw.R;O=R/'gain_search';fixed=json.load(open(O/'fixed_model_hashes.json'));assert all(hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==v for p,v in fixed.items());stage1=[];stage2=[]
for f in O.glob('stage1_worker*.json'):stage1.extend(json.load(open(f)))
for f in O.glob('stage2_worker*.json'):stage2.extend(json.load(open(f)))
assert len(stage1)==72 and len(stage2)==12;assert len({r['config']['id'] for r in stage1})==72
for stage,rows in [(1,stage1),(2,stage2)]:
 with open(O/f'stage{stage}_physical_results.csv','w') as f:
  fields=['id','omega','zeta','control_steps','duration_s','forward_mm','sideways_mm','net_xy_mm','min_up_z','failure','legacy_contact_revision'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for r in rows:w.writerow(dict(id=r['config']['id'],omega=r['config']['omega'],zeta=r['config']['zeta'],control_steps=r['config']['control_steps'],duration_s=r['duration_s'],forward_mm=r['displacement_x_mm'],sideways_mm=r['displacement_y_mm'],net_xy_mm=r['displacement_xy_mm'],min_up_z=r['min_up_z'],failure=r['failure'],legacy_contact_revision=1))
reports=[];force_error=0.;external=0.;m=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m);dense=np.empty((m.ntendon,m.nv));rng=np.random.default_rng(9)
for cid in [32,41,40]:
 rep=json.load(open(O/'full_validation'/f'candidate_{cid}.json'));z={k:v for k,v in np.load(O/'full_validation'/(rep['tag']+'_rollout.npz')).items()};assert len(z['time_s'])==30000;assert rep['failure'] is None;assert np.all(np.isfinite(z['qpos']));assert np.all(np.isfinite(z['qvel']));assert np.all((z['activation']>=0)&(z['activation']<=1));assert rep['disabled_native_leg_force_max']==0;assert rep['contact_statistics_revision']==2
 for t in rng.choice(30000,10,replace=False):
  d.qpos[:]=z['qpos'][t];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));J=dense[fw.tid];fiber=d.ten_length[fw.tid]*.01-fw.slack;assert np.all(fiber>0);x=fiber/fw.l0;vn=(J@z['qvel'][t]*.01)/(fw.l0*fw.vmax);neg=np.minimum(vn,0);pos=np.maximum(vn,0);fv=np.where(vn<0,np.maximum(0,(1+neg)/(1-neg/fw.hill)),1+(fw.ecc-1)*pos/(fw.hill+pos));cap=fw.F0*np.exp(-((x-1)/fw.width)**2)*fv;fp=fw.F0*np.expm1(np.clip(fw.shape*np.maximum(x-fw.ps,0)/fw.strain,0,30))/np.expm1(fw.shape);force=fp+z['activation'][t]*cap;general=-(J.T@(force*1e5));force_error=max(force_error,float(np.max(np.abs(general[fw.dofs]*1e-7-z['actual_torque_Nm'][t]))));external=max(external,float(np.max(np.abs(np.delete(general,fw.dofs)))))
 reports.append(rep)
assert force_error<1e-14 and external<1e-10
summary={'unique_gain_settings':72,'short_duration_s':.65,'short_survivors':sum(r['duration_s']>=.649 and r['first_sustained_fall_s'] is None and r['failure'] is None for r in stage1),'extended_2s_settings':12,'full_6s_settings':3,'all_full_runs_finite':True,'native_leg_actuators_zero':True,'activations_bounded_0_1':True,'model_hashes_unchanged':True,'live_muscle_torque_recheck_max_error_Nm':force_error,'muscle_force_outside_leg_dofs_max_native':external,'legacy_contact_metrics_excluded_from_final_conclusions':True,'final_contact_statistics_revision':2,'full_results':reports}
json.dump(summary,open(O/'verified_summary.json','w'),indent=2)
with open(O/'full_results.csv','w') as f:
 fields=['id','omega_per_s','zeta','control_timestep_s','forward_mm','sideways_mm','net_xy_mm','angle_error_rad','body_contact_samples','late_moving_legs','normal_six_leg_walk'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for r in reports:w.writerow(dict(id=r['config']['id'],omega_per_s=r['omega_per_s'],zeta=r['zeta'],control_timestep_s=r['control_timestep_s'],forward_mm=r['displacement_x_mm'],sideways_mm=r['displacement_y_mm'],net_xy_mm=r['displacement_xy_mm'],angle_error_rad=r['mean_angle_error_rad'],body_contact_samples=r['body_ground_samples'],late_moving_legs=r['late_moving_legs'],normal_six_leg_walk=r['passes_six_leg_walk_check']))
# Plots only use physical displacement/posture for stage1; force statistics in final are revision2.
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
ws=[350,500,700,1000,1500,2200,3500,6000];zs=[0,.1,.3,.7,1.2,2.];grid=np.full((8,6),np.nan)
for r in stage1:
 c=r['config']
 if c['control_steps']==5 and c['omega'] in ws and c['zeta'] in zs and r['duration_s']>=.649 and r['first_sustained_fall_s'] is None:grid[ws.index(c['omega']),zs.index(c['zeta'])]=r['displacement_x_mm']
fig,ax=plt.subplots(1,3,figsize=(16,5),constrained_layout=True);cmap=plt.get_cmap('viridis').copy();cmap.set_bad('lightgray');im=ax[0].imshow(grid,aspect='auto',cmap=cmap);ax[0].set_xticks(range(6),zs);ax[0].set_yticks(range(8),ws);ax[0].set_xlabel('Damping ratio');ax[0].set_ylabel('Omega (1/s)');ax[0].set_title('0.65 s screen: forward displacement (mm)')
for i in range(8):
 for j in range(6):ax[0].text(j,i,'fall' if np.isnan(grid[i,j]) else f'{grid[i,j]:.1f}',ha='center',va='center',fontsize=8,color='black' if np.isnan(grid[i,j]) else 'white')
fig.colorbar(im,ax=ax[0],shrink=.8)
x=np.arange(3);forward=[r['displacement_x_mm'] for r in reports];side=[r['displacement_y_mm'] for r in reports];ax[1].bar(x-.18,forward,.36,label='Forward');ax[1].bar(x+.18,side,.36,label='Sideways');ax[1].set_xticks(x,[f"w={r['omega_per_s']:g}\nz={r['zeta']:g}, dt={r['control_timestep_s']*1000:g}ms" for r in reports]);ax[1].set_ylabel('Displacement after 6 s (mm)');ax[1].legend();ax[1].set_title('Lateral drift is not forward walking')
duty=np.array([r['late_support_fraction_per_leg'] for r in reports]);im=ax[2].imshow(duty,aspect='auto',vmin=0,vmax=1,cmap='Blues');ax[2].set_xticks(range(6),['LF','RF','LM','RM','LH','RH']);ax[2].set_yticks(range(3),[str(r['config']['id']) for r in reports]);ax[2].set_ylabel('Full validation candidate ID');ax[2].set_title('Support fraction: corrected actual-force solve')
for i in range(3):
 for j in range(6):ax[2].text(j,i,f'{100*duty[i,j]:.0f}%',ha='center',va='center',color='white' if duty[i,j]>.65 else 'black')
fig.savefig(O/'gain_search_summary.png',dpi=150);print(json.dumps({k:v for k,v in summary.items() if k!='full_results'},indent=2))
