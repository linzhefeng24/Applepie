import json,argparse,numpy as np
import periodic_muscle_solver as p
args=argparse.ArgumentParser();args.add_argument('run');a=args.parse_args();out=p.ROOT/a.run;params=json.load(open(out/'config.json'))['params'];p.initialize(params);path=out/'feasibility_candidate.npz'
if not path.exists():path=out/'latest_iterate.npz'
x=np.load(path)['x'];blocks=x[:-2].reshape(params['segments'],p.BLOCK);pglobal=x[-2:];rows=[];defects=[]
state_names=['root_x','root_y','root_z','root_rot_x','root_rot_y','root_rot_z']+[p.mujoco.mj_id2name(p.MODEL,p.mujoco.mjtObj.mjOBJ_JOINT,j) for j in range(1,103)]
for i in range(params['segments']):
 raw=p.simulate_segment(i,blocks[i],blocks[(i+1)%params['segments']],pglobal)[0];eq=raw[:216];g=raw[216:];j=int(abs(eq).argmax());defects.append({'node':i,'dof':state_names[j%108],'type':'position' if j<108 else 'velocity','max_scaled_defect':float(abs(eq[j]))})
 if np.isfinite(params['passive_limit']):
  ratios=(1-g[-126:])*params['passive_limit']
  for k in np.argsort(ratios)[-5:]:rows.append({'node':i,'muscle_model_slot':p.ROWS[k]['id'],'passive_force_over_F0':float(ratios[k])})
report={'candidate_is_a_solution':False,'constraint_maxima_are_along_each_segment':True,'worst_dynamics_defects':sorted(defects,key=lambda r:-r['max_scaled_defect'])[:10],'worst_passive_force_ratios':sorted(rows,key=lambda r:-r['passive_force_over_F0'])[:10],'swing_nodes':p.GAIT_SWING.tolist(),'stance_nodes':p.GAIT_STANCE.tolist()};(out/'constraint_diagnostics.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
