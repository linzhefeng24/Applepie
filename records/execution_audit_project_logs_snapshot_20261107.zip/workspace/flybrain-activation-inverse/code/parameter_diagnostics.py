import pathlib,json,csv
import numpy as np
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'optimization';g=json.load(open(O/'optimized_geometry.json'));old={r['id']:r for r in json.load(open(R/'model/geometry.json'))['records']};pr={r['id']:r for r in json.load(open('/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json'))['muscles']};fields={'specific_stress_Pa':'specific_stress_Pa','vmax_L0_per_s':'vmax_optimal_fiber_lengths_per_s','PCSA_m2':'physiological_cross_sectional_area_m2','F0_N':'max_isometric_force_N','fiber_length0_m':'optimal_fiber_length_m','muscle_volume_m3':'muscle_volume_m3'};summary={key:{'near_lower':[],'near_upper':[]} for key in fields};changes=[]
for r in g['records']:
 b=old[r['id']];e=pr[r['id']]['estimated'];item={'id':r['id'],'F0_before_uN':b['F0_N']*1e6,'F0_after_uN':r['F0_N']*1e6,'F0_ratio':r['F0_N']/b['F0_N'],'fiber_length_ratio':r['fiber_length0_m']/b['fiber_length0_m'],'volume_ratio':r['muscle_volume_m3']/b['muscle_volume_m3'],'sigma_kPa':r['specific_stress_Pa']/1000,'vmax_L0_per_s':r['vmax_L0_per_s'],'max_attachment_move_um':max(np.linalg.norm(np.array(p['pos_cm'])-np.array(q['pos_cm']))*1e4 for p,q in zip(r['points'],b['points']))}
 changes.append(item)
 for field,key in fields.items():
  lo,hi=e[key]['working'];fraction=(r[field]-lo)/(hi-lo)
  if fraction<=.01:summary[field]['near_lower'].append(r['id'])
  if fraction>=.99:summary[field]['near_upper'].append(r['id'])
with open(O/'parameter_changes.csv','w') as f:
 w=csv.DictWriter(f,fieldnames=list(changes[0]));w.writeheader();w.writerows(changes)
summary['compartment_budget_usage']={k:v/g['compartment_budget_max_m3'][k] for k,v in g['compartment_volume_m3'].items()};summary['warning']='Boundary proximity indicates prior sensitivity, not a reason to enlarge bounds automatically; volume and stress are confounded.';json.dump(summary,open(O/'parameter_diagnostics.json','w'),indent=2)
print({k:{b:len(v) for b,v in d.items()} for k,d in summary.items() if k in fields})
