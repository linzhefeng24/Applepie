import json,pathlib,numpy as np
import periodic_muscle_solver as p
params={'segments':8,'substeps':80,'passive_limit':float('inf'),'tolerance':1e-4}
p.initialize(params);x=p.seed_vector(8);blocks=x[:-2].reshape(8,p.BLOCK);par=x[-2:];T,h,ctrl,act=p.period_context(float(par[0]));assert np.max(abs(act[-1]-act[0]))<1e-12
q0,v0=p.decode(blocks[0],0,par);qt=q0.copy();qt[0]+=T*par[1]*.5
assert np.max(abs(p.state_error(q0,v0,qt,v0)))>1
assert np.count_nonzero(p.MODEL.actuator_gainprm[p.SEED['actuator_mask']])==0
checks=[]
for i in [0,7]:
 b=blocks[i];bn=blocks[(i+1)%8];base,qe,ve,_=p.simulate_segment(i,b,bn,par)
 for j in [0,3,12,108,117]:
  step=1e-5;bb=bn.copy();bb[j]+=step;actual=p.simulate_segment(i,b,bb,par)[0];targetq,targetv=p.decode(bb,(i+1)%8,par)
  if i==7:targetq[0]+=T*par[1]*.5
  expected=p.state_error(qe,ve,targetq,targetv)
  err=float(np.max(abs(actual[:216]-expected)));assert err<1e-10
  assert np.array_equal(actual[216:],base[216:]);checks.append({'segment':i,'neighbor_column':j,'absolute_error':err})
obj=p.Problem.__new__(p.Problem);obj.n=8;obj.params={'stage2_running':True};obj.seedblocks=blocks.copy();obj.tracking_calls=0;y=x.copy();y[10]+=.01;y[219]+=.03;analytic=obj.tracking_jac(y);checks_grad=[]
for j in [10,119,219,8*p.BLOCK]:
 yy=y.copy();yy[j]+=1e-6;fd=(obj.tracking(yy)-obj.tracking(y))/1e-6;err=float(abs(fd-analytic[j]));assert err<1e-8;checks_grad.append({'column':j,'absolute_error':err})
report={'secondary_gradient_checks':checks_grad,'passed':True,'real_dofs':108,'filter_periodicity_max_error':float(np.max(abs(act[-1]-act[0]))),'standing_has_nonzero_boundary_defect':True,'native_leg_motors_disabled':True,'boundary_jacobian_checks':checks,'thorax_body_id':p.THORAX,'hard_periodicity_tolerance_scaled':params['tolerance']}
(p.ROOT/'constraint_checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
