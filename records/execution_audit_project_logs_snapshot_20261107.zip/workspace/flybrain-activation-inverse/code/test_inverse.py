import unittest
import numpy as np
from invert import allocate
class AllocationTests(unittest.TestCase):
 def test_feasible(self):
  A=np.array([[2.,0.,1.],[0.,3.,1.]]);b=A@np.array([.2,.3,.4]);a,_,s=allocate(A,b,1)
  self.assertGreater(s,0);self.assertLess(np.linalg.norm(A@a-b),1e-5);self.assertTrue(np.all((a>=0)&(a<=1)))
 def test_impossible_target_kept(self):
  b=np.array([2.]);a,_,_=allocate(np.array([[1.]]),b,1)
  self.assertAlmostEqual(a[0],1.);self.assertEqual(b[0],2.);self.assertGreater(np.linalg.norm(a-b),.99)
 def test_frame_order_independence(self):
  rng=np.random.default_rng(4);A=rng.normal(size=(8,3,5));b=rng.normal(size=(8,3));p=rng.permutation(8)
  forward=np.array([allocate(x,y,1)[0] for x,y in zip(A,b)]);reverse=np.empty_like(forward)
  for i in p:reverse[i]=allocate(A[i],b[i],1)[0]
  np.testing.assert_array_equal(forward,reverse)
if __name__=='__main__':unittest.main()
