"""Freeze a coarse 3-D anatomical routing HYPOTHESIS before reading torque targets.
No action/torque values are used to choose any site, route, sign or capacity.
"""
import pathlib,json,math,xml.etree.ElementTree as E,hashlib
import numpy as np,mujoco
R=pathlib.Path('/workspace/flybrain-activation-inverse');SRC=pathlib.Path('/workspace/fly-walking-run/output');PR=pathlib.Path('/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json')
pr=json.load(open(PR));muscles=pr['muscles'];m=mujoco.MjModel.from_binary_path(str(SRC/'model/walking.mjb'));d=mujoco.MjData(m)
z=np.load(SRC/'walking_6s_5000Hz.npz',allow_pickle=False);Q=z['qpos'];names=z['joint_names'].tolist();qadr=z['joint_qpos_indices'];vadr=z['joint_dof_indices'];q0=Q[0].copy();eps=1e-5
poses=[q0]
for a in qadr:
 for sign in [1,-1]:q=q0.copy();q[a]+=sign*eps;poses.append(q)
poses.extend(Q[np.linspace(0,len(Q)-1,64,dtype=int)])
X=[];Rot=[]
for q in poses:
 d.qpos[:]=q;mujoco.mj_kinematics(m,d);X.append(d.xpos.copy());Rot.append(d.xmat.reshape(m.nbody,3,3).copy())
X=np.asarray(X);Rot=np.asarray(Rot);probe=1+2*len(qadr);rng=np.random.default_rng(20261102);tokens=dict(zip(['LF','RF','LM','RM','LH','RH'],['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right']))
body_cache={}
def body(seg,leg):return mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/'+seg+('_'+tokens[leg] if seg!='thorax' else ''))
def vertices(bid):
 if bid not in body_cache:
  ids=np.flatnonzero(m.geom_bodyid==bid);mesh=[int(i) for i in ids if m.geom_type[i]==int(mujoco.mjtGeom.mjGEOM_MESH)];assert mesh,bid
  target=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,bid);gid=next((i for i in mesh if mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i)==target),mesh[0]);msh=m.geom_dataid[gid];a=m.mesh_vertadr[msh];n=m.mesh_vertnum[msh];V=m.mesh_vert[a:a+n].astype(float);rot=np.zeros(9);mujoco.mju_quat2Mat(rot,m.geom_quat[gid]);V=V@rot.reshape(3,3).T+m.geom_pos[gid];body_cache[bid]=V[::max(1,len(V)//4096)]
 return body_cache[bid]
def point(bid,prox=False,region=None,side=1):
 V=vertices(bid)
 if prox:
  dist=np.linalg.norm(V,axis=1);V=V[(dist>=np.quantile(dist,.05))&(dist<=np.quantile(dist,.45))]
 if region:
  axis,sg=region;threshold=np.quantile(V[:,axis],.6 if sg>0 else .4);select=V[:,axis]>=threshold if sg>0 else V[:,axis]<=threshold
  if np.count_nonzero(select)>5:V=V[select]
 return V[rng.integers(len(V))].copy()
def world(b,p):return np.einsum('nij,j->ni',Rot[:,b],p)+X[:,b]
def lengths(route):
 P=[world(b,p) for b,p in route];return sum(np.linalg.norm(P[i+1]-P[i],axis=1) for i in range(len(P)-1))*.01

def grad(values):return (values[1:probe:2]-values[2:probe:2])/(2*eps)
def desired(row):
 leg=row['leg'];tok=tokens[leg];g=row['id'].split(':')[1];v=np.zeros(66);bid=body('coxa',leg);V=vertices(bid);tip=V[np.argmax(np.linalg.norm(V,axis=1))];P=world(bid,tip)
 hx=grad(P[:,0]);hy=grad(P[:,1])*(-1 if leg[0]=='L' else 1);hz=grad(P[:,2])
 for a in [hx,hy,hz]:
  n=np.linalg.norm(a)
  if n:a/=n
 if g in ['tergopleural_promotor','pleural_promotor','sternal_anterior_rotator']:return hx,'anterior action',False
 if g in ['pleural_remotor_and_abductor','sternal_posterior_rotator']:return -hx-(.4*hy if g=='pleural_remotor_and_abductor' else 0),'posterior action',False
 if g=='sternal_adductor':return hy,'adduction',False
 if g=='coxa_levator_muscle_2':return hz,'unverified raising hypothesis',True
 if g in ['tergotrochanter_extensor','sternotrochanter_extensor','trochanter_extensor','trochanter_flexor','accessory_trochanter_flexor','femur_reductor','trochanter_reductor_muscle_2']:seg='femur';parent='coxa';j='femur'
 elif g in ['tibia_flexor','tibia_extensor','accessory_tibia_flexor','tibial_depressor_muscle_2']:seg='tibia';parent='femur';j='tibia'
 else:seg='tarsus';parent='tibia';j='tarsus'
 bid=body(seg,leg);V=vertices(bid);P=world(bid,V[np.argmax(np.linalg.norm(V,axis=1))]);anchor=X[:,body(parent,leg)];flex=-grad(np.linalg.norm(P-anchor,axis=1));cols=[i for i,n in enumerate(names) if leg_token(n,tok) and ('/'+j+'_'+tok in n or '/'+j+'_twist_'+tok in n)];v[cols]=flex[cols]
 if np.linalg.norm(v)<1e-10:
  k=names.index('walker/'+j+'_'+tok);v[k]=1
 v/=np.linalg.norm(v)
 if g in ['tergotrochanter_extensor','sternotrochanter_extensor','trochanter_extensor','tibia_extensor','tarsus_depressor']:v=-v
 unknown=row['direction']['reference_pose_sign'] is None
 if unknown and rng.random()<.5:v=-v
 return v,'folding-derived coordinate hypothesis' if unknown else 'anatomical flexion/extension',unknown

def leg_token(name,tok):return name.endswith(tok)
def make_route(row):
 leg=row['leg'];g=row['id'].split(':')[1];side=1 if leg[0]=='L' else -1
 if g in ['tergopleural_promotor','pleural_promotor','pleural_remotor_and_abductor','sternal_anterior_rotator','sternal_posterior_rotator','sternal_adductor','coxa_levator_muscle_2']:
  region=(2,1) if g.startswith('tergo') else (2,-1) if g.startswith('sternal') else (1,side)
  b=body('thorax',leg);c=body('coxa',leg);return [(b,point(b,region=region)),(c,point(c,prox=True))]
 if g in ['tergotrochanter_extensor','sternotrochanter_extensor']:
  b=body('thorax',leg);c=body('coxa',leg);f=body('femur',leg);return [(b,point(b,region=(2,1 if g.startswith('tergo') else -1))),(c,point(c)),(f,point(f,prox=True))]
 if g in ['trochanter_extensor','trochanter_flexor','accessory_trochanter_flexor','femur_reductor','trochanter_reductor_muscle_2']:
  b=body('coxa',leg);c=body('femur',leg);return [(b,point(b)),(c,point(c,prox=True))]
 if g in ['tibia_flexor','tibia_extensor','accessory_tibia_flexor','tibial_depressor_muscle_2']:
  b=body('femur',leg);c=body('tibia',leg);return [(b,point(b)),(c,point(c,prox=True))]
 if g in ['long_tendon_muscle_1','long_tendon_muscle_2']:
  segs=['femur','tibia','tarsus','tarsus2','tarsus3','tarsus4','tarsus5','claw'] if g.endswith('_2') else ['tibia','tarsus','tarsus2','tarsus3','tarsus4','tarsus5','claw']
  out=[]
  for i,s in enumerate(segs):
   b=body(s,leg)
   if b>=0:out.append((b,point(b,prox=i>0)))
  return out
 b=body('tibia',leg);c=body('tarsus',leg);return [(b,point(b)),(c,point(c,prox=True))]

xml=E.parse(SRC/'model/walking.xml');root=xml.getroot();compiler=root.find('compiler')
if compiler is None:compiler=E.SubElement(root,'compiler')
compiler.set('meshdir',str(SRC/'model'));compiler.set('texturedir',str(SRC/'model'));tendons=root.find('tendon')
if tendons is None:tendons=E.SubElement(root,'tendon')
bodies={b.get('name'):b for b in root.iter('body')};records=[]
for ix,row in enumerate(muscles):
 target,meaning,unknown=desired(row);target/=max(np.linalg.norm(target),1e-12);e=row['estimated'];lo,hi=e['optimal_fiber_length_m']['working'];preferred=e['optimal_fiber_length_m']['initial'];best=None
 for attempt in range(192):
  route=make_route(row);L=lengths(route);r=-grad(L);rnorm=np.linalg.norm(r);alignment=float(r@target/(rnorm+1e-20));motion=L[probe:];span=float(motion.max()-motion.min());opt=np.clip(max(preferred,span/1.4),lo,hi);lower=max(0.,float(motion.max())-1.7*opt);upper=min(float(motion.min())-.3*opt,e['tendon_slack_length_m']['working'][1]);feasible=lower<=upper and opt>0
  if not unknown and alignment<.15:continue
  score=(1-alignment)+.2*abs(math.log((rnorm+1e-10)/(e['moment_arm_m']['reference_abs_initial']+1e-10)))+(0 if feasible else 10)
  if best is None or score<best[0]:best=(score,route,L,r,opt,lower,upper,alignment,feasible)
 if best is None:raise RuntimeError('No anatomically directed candidate '+row['id'])
 score,route,L,r,opt,lower,upper,alignment,feasible=best
 slack=float(np.clip(L[0]-opt,lower,upper)) if feasible else max(0.,float(L[probe:].min())-.15*opt)
 # Preserve prior initial muscle V and sigma; derive area and F0 after choosing
 # geometrically feasible length, not by fitting any torque sample.
 V=e['muscle_volume_m3']['initial'];area=V/opt;stress=e['specific_stress_Pa']['initial'];F0=area*stress
 if not e['physiological_cross_sectional_area_m2']['working'][0]<=area<=e['physiological_cross_sectional_area_m2']['working'][1]:
  # Stay within the working PCSA window by reducing V only, never invent volume.
  area=min(area,e['physiological_cross_sectional_area_m2']['working'][1]);V=area*opt;F0=area*stress
 name='muscle_'+row['id'].replace(':','__');sp=E.SubElement(tendons,'spatial',name=name,limited='false',stiffness='0',damping='0',width='.00001');points=[]
 for k,(bid,point_local) in enumerate(route):
  bname=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,bid);site=name+'_p'+str(k);E.SubElement(bodies[bname],'site',name=site,pos=' '.join(f'{v:.15g}' for v in point_local),size='.00001',rgba='0 0 0 0');E.SubElement(sp,'site',site=site);points.append(dict(body=bname,pos_cm=point_local.tolist(),site=site))
 records.append(dict(id=row['id'],leg=row['leg'],tendon_name=name,points=points,anatomical_action=meaning,function_hypothesis=unknown,alignment_at_reference=alignment,geometry_role='unvalidated straight-segment/tendon-guide hypothesis; no tissue wrapping reconstructed',working_length_domain_feasible=bool(feasible),fiber_length0_m=float(opt),tendon_slack_length_m=slack,muscle_volume_m3=V,PCSA_m2=area,F0_N=F0,specific_stress_Pa=stress,vmax_L0_per_s=e['vmax_optimal_fiber_lengths_per_s']['initial'],long_tendon_claw_dof_missing=row['id'].split(':')[1].startswith('long_tendon'),uncertainty='long tendon claw rotation absent in donor body; tarsal routing hypothesis only' if row['id'].split(':')[1].startswith('long_tendon') else 'coarse anatomical attachment/routing hypothesis'))
 if ix%20==0:print('geometry',ix,row['id'],flush=True)
path=R/'model/muscle_geometry.xml';xml.write(path,encoding='unicode');new=mujoco.MjModel.from_xml_path(str(path));assert new.nq==m.nq and new.nv==m.nv
for rec in records:rec['tendon_index']=mujoco.mj_name2id(new,mujoco.mjtObj.mjOBJ_TENDON,rec['tendon_name'])
mujoco.mj_saveModel(new,str(R/'model/muscle_geometry.mjb'),None)
meta=dict(seed=20261102,selection_uses='anatomical compartment/action and recorded posture excursion only; NO torque labels',source_model=str(SRC/'model/walking.mjb'),source_prior_sha256=hashlib.sha256(PR.read_bytes()).hexdigest(),geometry_type='coarse3D line/guide routing hypothesis, not measured anatomy',rigid_tendon_assumption=True,records=records)
(R/'model/geometry.json').write_text(json.dumps(meta,indent=2));print('geometry done',len(records),'feasible',sum(x['working_length_domain_feasible'] for x in records),flush=True)
