"""Contact-change-aware bounded muscle controller using native same-state probes.
Actual ground reactions are ALWAYS computed by MuJoCo, never applied from prediction.
"""
import numpy as np,mujoco,time
from scipy.optimize import lsq_linear
from contact_response_fd import NativeContactResponse,leg_basis

class ContactMuscleController:
 def __init__(self,m,source,rows,dofs,groups,reference_activation,leg_omega=100.,body_omega=20.,body_weight=5.,iterations=2):
  self.m=m;self.source=source;self.rows=rows;self.dofs=dofs;self.groups=groups;self.refa=reference_activation;self.probe=NativeContactResponse(m);self.iterations=iterations;self.leg_omega=leg_omega;self.body_omega=body_omega;self.body_weight=body_weight;self.eps=1e-4
  self.root=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'walker/');assert self.root>=0;self.rootq=int(m.jnt_qposadr[self.root]);self.rootv=int(m.jnt_dofadr[self.root]);self.body=np.arange(self.rootv,self.rootv+6);self.task=np.r_[self.body,dofs];self.tid=np.array([r['tendon_index'] for r in rows]);self.dense=np.empty((m.ntendon,m.nv));self.err=np.empty(m.nv)
  get=lambda k:np.array([r[k] for r in rows]);self.l0=get('fiber_length0_m');self.slack=get('tendon_slack_length_m');self.f0=get('F0_N');self.vmax=get('vmax_L0_per_s');self.width=get('force_length_width');self.hill=get('force_velocity_hill_shape');self.ecc=get('eccentric_cap');self.ps=get('passive_slack_normalized');self.strain=get('passive_strain_at_F0');self.shape=get('passive_exponent')
  sigma=np.sqrt(np.mean(source['qacc'][:,dofs]**2,axis=0));self.weights=np.r_[np.full(3,body_weight/981.),np.full(3,body_weight/2000.),1/np.maximum(sigma,2000.)];self.ridge=1e-6
 def force_map(self,d):
  mujoco.mju_sparse2dense(self.dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));J=self.dense[self.tid].copy();fiber=d.ten_length[self.tid]*.01-self.slack
  if np.any(fiber<=0):raise ValueError('nonpositive fiber length')
  x=fiber/self.l0;vn=(J@d.qvel*.01)/(self.l0*self.vmax);neg=np.minimum(vn,0);pos=np.maximum(vn,0);fv=np.where(vn<0,np.maximum(0,(1+neg)/(1-neg/self.hill)),1+(self.ecc-1)*pos/(self.hill+pos));cap=self.f0*np.exp(-((x-1)/self.width)**2)*fv;passive=self.f0*np.expm1(np.clip(self.shape*np.maximum(x-self.ps,0)/self.strain,0,30))/np.expm1(self.shape);B=-J.T*(cap[None,:]*1e5);p=-J.T@(passive*1e5)
  return B,p,-J[:,self.dofs].T
 def target(self,d,t):
  qr=self.source['qpos'][t];vr=self.source['qvel'][t].copy();ar=self.source['qacc'][t].copy();mujoco.mj_differentiatePos(self.m,self.err,1.,d.qpos,qr);qa=self.rootq;va=self.rootv;Ra=np.empty(9);Rr=np.empty(9);mujoco.mju_quat2Mat(Ra,d.qpos[qa+3:qa+7]);mujoco.mju_quat2Mat(Rr,qr[qa+3:qa+7]);rotation=Ra.reshape(3,3).T@Rr.reshape(3,3);vr[va+3:va+6]=rotation@vr[va+3:va+6];ar[va+3:va+6]=rotation@ar[va+3:va+6]
  out=ar.copy();out[self.dofs]+=self.leg_omega**2*self.err[self.dofs]+2*self.leg_omega*(vr[self.dofs]-d.qvel[self.dofs]);out[self.body]+=self.body_omega**2*self.err[self.body]+2*self.body_omega*(vr[self.body]-d.qvel[self.body]);return out
 def solve(self,d,t):
  start=time.time();B,p,moment=self.force_map(d);E=leg_basis(moment,self.groups,self.dofs,self.m.nv);span=float(np.linalg.norm(B-E@(E.T@B))/max(np.linalg.norm(B),1e-20))
  if span>1e-8:E=np.eye(self.m.nv)[:,self.dofs]
  projected=E.T@B;wanted=self.target(d,t);self.probe.set_state(d);a=np.clip(self.refa[t].astype(float),0,1);background=self.source['qfrc_applied'][t].copy()
  def evaluate(x):return self.probe.evaluate(background+p+B@x)
  def cost(acc,x):res=self.weights*(acc[self.task]-wanted[self.task]);return float(res@res+self.ridge*(x@x))
  acc,lam,state=evaluate(a);initial=cost(acc,a);best=initial;pred_error=[];state_changes=[];accepted=0;linearizations=0;nonlinear_evals=1;predicted_qerr=[];linearize_s=0.;consistency_max=0.;ground_response_norm=0.;last_pred=lam.copy();last_actual=lam.copy();last_accpred=acc.copy()
  for it in range(self.iterations):
   tic=time.time();r=self.probe.linearize(background+p+B@a,E,self.eps,central=False);linearize_s+=time.time()-tic;linearizations+=1;consistency_max=max(consistency_max,r['dynamics_response_consistency_relative_error']);ground_response_norm=max(ground_response_norm,float(np.linalg.norm(r['ground_contact_generalized_force_response'])));Aall=r['acceleration_response']@projected;C=self.weights[:,None]*Aall[self.task];b=self.weights*(wanted[self.task]-r['qacc0'][self.task]+Aall[self.task]@a)
   # A same-frame trust region limits crossing many contact regimes at once.
   lo=np.maximum(0,a-.6);hi=np.minimum(1,a+.6);fit=lsq_linear(np.vstack([C,np.sqrt(self.ridge)*np.eye(len(a))]),np.r_[b,np.zeros(len(a))],bounds=(lo,hi),method='bvls',tol=1e-10,max_iter=300);candidate=np.clip(fit.x,0,1)
   if fit.status<=0:raise RuntimeError('bounded acceleration allocation failed')
   direction=candidate-a;improved=False
   for step in [1.,.5,.25,.125]:
    trial=np.clip(a+step*direction,0,1);aa,ll,ss=evaluate(trial);nonlinear_evals+=1;value=cost(aa,trial)
    if value<best-1e-10*max(1.,best):
     delta=projected@(trial-a);lp=r['lambda0']+r['constraint_force_response']@delta;ap=r['qacc0']+r['acceleration_response']@delta;pred_error.append(float(np.linalg.norm(ll-lp)/max(np.linalg.norm(ll-r['lambda0']),np.linalg.norm(lp-r['lambda0']),1e-10)));predicted_qerr.append(float(np.linalg.norm(aa-ap)/max(np.linalg.norm(aa-r['qacc0']),np.linalg.norm(ap-r['qacc0']),1e-10)));state_changes.append(int(np.sum(ss!=r['state0'])));last_pred=lp.copy();last_actual=ll.copy();last_accpred=ap.copy();a=trial;acc=aa;lam=ll;state=ss;best=value;accepted+=1;improved=True;break
   if not improved:break
  # Restore the probe to the selected actual muscle force; main data never mutated.
  acc,lam,state=evaluate(a)
  return a,{'initial_native_acceleration_cost':initial,'final_native_acceleration_cost':best,'accepted_steps':accepted,'linearizations':linearizations,'native_evaluations':nonlinear_evals+1,'contact_force_prediction_relative_errors':pred_error,'acceleration_prediction_relative_errors':predicted_qerr,'contact_state_changes':state_changes,'basis_span_relative_error':span,'basis_rank':E.shape[1],'dynamics_response_consistency_max':consistency_max,'ground_force_response_norm':ground_response_norm,'wall_s':time.time()-start,'linearization_wall_s':linearize_s,'lambda_actual':lam,'lambda_predicted_last':last_pred,'qacc_actual':acc,'qacc_target':wanted,'qacc_predicted_last':last_accpred,'efc_type':self.probe.d.efc_type.copy(),'efc_id':self.probe.d.efc_id.copy()}
