import os;os.environ.update(MUJOCO_GL='egl',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import pathlib,json,time,argparse,numpy as np,mujoco
from scipy.ndimage import median_filter
import forward_walk_test as fw
from test_feedback_walk import groups
from contact_controller import ContactMuscleController
O=fw.R/'contact_feedback';source=dict(fw.src,qacc=fw.raw['qacc']);qa=fw.raw['joint_qpos_indices'];tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right']
def run(bodyweight=5.,legomega=100.,bodyomega=20.,duration=.3,iterations=1,control_steps=10,early_stop=True,save=False,guarded=False,guard_options=None):
 m=mujoco.MjModel.from_binary_path(str(fw.R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m);mask=source['joint_actuator_mask'];m.actuator_gainprm[mask]=0;m.actuator_biasprm[mask]=0
 for k in ['qpos','qvel','act','ctrl','qacc_warmstart']:getattr(d,k)[:]=source[k][0]
 thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');rootghost=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'ghost/');ga=m.jnt_qposadr[rootghost];gv=m.jnt_dofadr[rootghost];ground={i for i in range(m.ngeom) if m.geom_bodyid[i]==0};coreids={i for i in range(m.nbody) if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,i) or '').startswith(('walker/head','walker/abdomen','walker/thorax'))};foot={}
 for i in range(m.ngeom):
  n=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or ''
  if n.startswith('walker/') and any(s in n for s in ['tarsus','claw']):
   for j,tok in enumerate(tokens):
    if tok in n:foot[i]=j
 Controller=ContactMuscleController
 if guarded:
  from guarded_contact_controller import GuardedContactController
  Controller=GuardedContactController
 c=Controller(m,source,fw.rows,fw.dofs,groups,fw.activation,leg_omega=legomega,body_omega=bodyomega,body_weight=bodyweight,iterations=iterations,**(guard_options or {}))
 if hasattr(c,'set_control_steps'):c.set_control_steps(control_steps)
 a=fw.activation[0].astype(float).copy();cf=np.zeros(6);tag=f'contact_bw{bodyweight:g}_lw{legomega:g}_bw{bodyomega:g}_it{iterations}_dt{control_steps}';logs={k:[] for k in ['time_s','qpos','qvel','activation','thorax_mm','up_z','support_dyne','thorax_ground','body_ground','actual_torque_Nm','angle_error_rad','fiber_min_norm','fiber_max_norm']};controls=[];failure=None;fall=None;fallrun=0;native_disabled=0.;wall=time.time();warnings=np.array([w.number for w in d.warning]);debugfile=open(O/(tag+'_control.jsonl'),'w') if save else None
 for t in range(min(round(duration/.0002),len(source['qpos']))):
  if t%10==0:d.qpos[ga:ga+7]=source['qpos'][t,ga:ga+7];d.qvel[gv:gv+6]=source['qvel'][t,gv:gv+6]
  d.ctrl[:]=source['ctrl'][t];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d)
  try:B,p,_=c.force_map(d)
  except Exception as e:failure={'time_s':t*.0002,'reason':str(e)};break
  d.qfrc_applied[:]=source['qfrc_applied'][t]+p+B@a;mujoco.mj_forward(m,d)
  if t%control_steps==0:
   try:
    c.current_activation=a.copy();a,info=c.solve(d,t)
   except Exception as e:failure={'time_s':t*.0002,'reason':'control: '+str(e)};break
   d.qfrc_applied[:]=source['qfrc_applied'][t]+p+B@a;d.qacc_warmstart[:]=0;mujoco.mj_forward(m,d)
   predicted_actual_error=float(np.linalg.norm(d.efc_force-info['lambda_actual'])/max(np.linalg.norm(d.efc_force),1e-10));qaccerror=float(np.linalg.norm(d.qacc-info['qacc_actual'])/max(np.linalg.norm(d.qacc),1e-10));small={k:v for k,v in info.items() if not isinstance(v,np.ndarray)};small.update(time_s=t*.0002,probe_vs_main_actual_contact_relative_error=predicted_actual_error,probe_vs_main_qacc_relative_error=qaccerror,ncon=int(d.ncon),nefc=int(d.nefc));controls.append(small)
   if debugfile:debug=dict(small,lambda_actual=d.efc_force.tolist(),lambda_predicted_last=info['lambda_predicted_last'].tolist(),qacc_target=info['qacc_target'].tolist(),qacc_actual=d.qacc.tolist(),efc_type=d.efc_type.tolist(),efc_id=d.efc_id.tolist());debugfile.write(json.dumps(debug)+'\n')
  native_disabled=max(native_disabled,float(np.max(np.abs(d.actuator_force[mask]))));support=np.zeros(6);touch=False;bodytouch=False
  for j in range(d.ncon):
   con=d.contact[j];g1,g2=int(con.geom1),int(con.geom2);other=g2 if g1 in ground else g1 if g2 in ground else None
   if other is None or con.efc_address<0:continue
   if int(m.geom_bodyid[other])==thorax and con.dist<=0:touch=True
   if int(m.geom_bodyid[other]) in coreids and con.dist<=0:bodytouch=True
   if other in foot:mujoco.mj_contactForce(m,d,j,cf);support[foot[other]]+=max(0.,cf[0])
  up=float(d.xmat[thorax].reshape(3,3)[2,2]);fallrun=fallrun+1 if touch or up<.5 else 0
  if fallrun>=25 and fall is None:fall=t*.0002-24*.0002
  vals=dict(time_s=t*.0002,qpos=d.qpos.copy(),qvel=d.qvel.copy(),activation=a.copy(),thorax_mm=d.xpos[thorax]*10,up_z=up,support_dyne=support,thorax_ground=touch,body_ground=bodytouch,actual_torque_Nm=(p+B@a)[fw.dofs]*1e-7,angle_error_rad=float(np.sqrt(np.mean((d.qpos[qa]-source['qpos'][t,qa])**2))),fiber_min_norm=float(np.min((d.ten_length[c.tid]*.01-c.slack)/c.l0)),fiber_max_norm=float(np.max((d.ten_length[c.tid]*.01-c.slack)/c.l0)))
  for k,v in vals.items():logs[k].append(v)
  mujoco.mj_step(m,d)
  if any(d.warning[i].number>warnings[i] for i in [int(mujoco.mjtWarning.mjWARN_BADQPOS),int(mujoco.mjtWarning.mjWARN_BADQVEL),int(mujoco.mjtWarning.mjWARN_BADQACC)]):failure={'time_s':(t+1)*.0002,'reason':'native numerical warning'};break
  if early_stop and fall is not None:break
  if t%5000==0:print(tag,'t',d.time,'xyz',d.xpos[thorax]*10,'wall',time.time()-wall,flush=True)
 if debugfile:debugfile.close()
 arr={k:np.asarray(v) for k,v in logs.items()};xyz=arr['thorax_mm'];dur=len(xyz)*.0002;weight=m.body_subtreemass[thorax]*np.linalg.norm(m.opt.gravity);stance=median_filter(arr['support_dyne']>weight*.01,size=(25,1),mode='nearest');late=stance[arr['time_s']>=min(.5,dur*.5)];cycle=np.sum(late[1:]!=late[:-1],axis=0);duty=late.mean(axis=0);moving=int(np.sum((cycle>=2)&(duty>.01)&(duty<.99)));delta=xyz[-1,:2]-xyz[0,:2];r={'tag':tag,'body_task_weight':bodyweight,'leg_omega_per_s':legomega,'body_omega_per_s':bodyomega,'control_timestep_s':control_steps*.0002,'sqp_iterations':iterations,'duration_s':dur,'failure':failure,'fall_s':fall,'forward_mm':float(delta[0]),'sideways_mm':float(delta[1]),'net_xy_mm':float(np.linalg.norm(delta)),'min_up_z':float(arr['up_z'].min()),'body_ground_samples':int(arr['body_ground'].sum()),'thorax_ground_samples':int(arr['thorax_ground'].sum()),'angle_error_rad':float(arr['angle_error_rad'].mean()),'fiber_min_norm':float(arr['fiber_min_norm'].min()),'fiber_max_norm':float(arr['fiber_max_norm'].max()),'guarded':guarded,'guard_options':guard_options,'late_support_fraction_per_leg':duty.tolist(),'late_contact_transitions':cycle.tolist(),'late_moving_legs':moving,'native_leg_drive_force_max':native_disabled,'bounded_activation':bool(np.all((arr['activation']>=0)&(arr['activation']<=1))),'controls':len(controls),'mean_frame_cost_ratio':float(np.mean([q['final_native_acceleration_cost']/max(q['initial_native_acceleration_cost'],1e-10) for q in controls])),'mean_probe_wall_s':float(np.mean([q['wall_s'] for q in controls])),'max_probe_vs_main_contact_error':max(q['probe_vs_main_actual_contact_relative_error'] for q in controls),'max_probe_vs_main_acceleration_error':max(q['probe_vs_main_qacc_relative_error'] for q in controls),'wall_s':time.time()-wall};r['normal_walk']=bool(dur>=5.999 and failure is None and fall is None and delta[0]>10 and arr['body_ground'].sum()==0 and moving==6)
 if save:np.savez_compressed(O/(tag+'_rollout.npz'),**arr)
 json.dump(r,open(O/(tag+('_full' if duration>=6 else '_short')+'_report.json'),'w'),indent=2);print('RESULT',json.dumps(r),flush=True);return r
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--weight',type=float,default=5);p.add_argument('--leg-omega',type=float,default=100);p.add_argument('--body-omega',type=float,default=20);p.add_argument('--duration',type=float,default=.3);p.add_argument('--iterations',type=int,default=1);p.add_argument('--steps',type=int,default=10);p.add_argument('--save',action='store_true');p.add_argument('--guarded',action='store_true');a=p.parse_args();run(a.weight,a.leg_omega,a.body_omega,a.duration,a.iterations,a.steps,early_stop=a.duration<6,save=a.save,guarded=a.guarded)
