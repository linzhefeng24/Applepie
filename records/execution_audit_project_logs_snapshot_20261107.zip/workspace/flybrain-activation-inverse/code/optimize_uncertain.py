"""Global bounded anatomical calibration with independent per-frame allocation.
Geometry is a hypothesis; optimizer never changes recorded states or torque targets.
"""
import os
os.environ['TF_CPP_MIN_LOG_LEVEL']='2';os.environ['CUDA_VISIBLE_DEVICES']='-1';os.environ['OMP_NUM_THREADS']='2';os.environ['OPENBLAS_NUM_THREADS']='1'
import pathlib,json,time,hashlib
import numpy as np,mujoco
import tensorflow as tf
from scipy.optimize import lsq_linear
from invert import allocate
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'optimization';O.mkdir(exist_ok=True)
tf.config.threading.set_inter_op_parallelism_threads(1);tf.config.threading.set_intra_op_parallelism_threads(2)
D=tf.float64
T=lambda x:tf.constant(np.asarray(x),dtype=D)
rng=np.random.default_rng(20261103)
meta=json.load(open(R/'model/geometry.json'));rows=meta['records'];M=len(rows);pr=json.load(open('/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json'));pm={r['id']:r for r in pr['muscles']};cs=pr['compartments'];cn=list(cs);ci=np.array([cn.index(pm[r['id']]['compartment']) for r in rows]);NC=len(cn)
z=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');Q=z['qpos'];V=z['qvel'];tm=z['time_s'];names=z['joint_names'].tolist();dofs=z['joint_dof_indices'];tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];legs=['LF','RF','LM','RM','LH','RH'];cols=[np.array([i for i,n in enumerate(names) if n.endswith(tok)]) for tok in tokens];groups=[np.array([i for i,r in enumerate(rows) if r['leg']==leg]) for leg in legs];mi=np.zeros((6,23),int);mask=np.zeros((6,23))
for g,k in enumerate(groups):mi[g,:len(k)]=k;mask[g,:len(k)]=1
leg_of_m=np.array([legs.index(r['leg']) for r in rows]);targetall=z['leg_tau_drive_Nm']*1e9;scale=np.array([np.sqrt(np.mean(targetall[:,j]**2)) for j in cols]);Qv=np.stack([V[:,dofs[j]] for j in cols],axis=1)
# Temporally separated validation and test windows. Neither contributes target gradients.
valmask=((tm>=.8)&(tm<1.2))|((tm>=2.8)&(tm<3.2))|((tm>=4.8)&(tm<5.2));testmask=((tm>=1.8)&(tm<2.2))|((tm>=3.8)&(tm<4.2));trainpool=np.flatnonzero(~(valmask|testmask))
choose=lambda pool,n:pool[np.linspace(0,len(pool)-1,n,dtype=int)]
train=choose(trainpool,192);valid=choose(np.flatnonzero(valmask),96);test=choose(np.flatnonzero(testmask),96);frames=np.r_[train,valid,test,0];F=len(frames);train_ix=np.arange(192);val_ix=np.arange(192,288);test_ix=np.arange(288,384)
np.savez(O/'frame_split.npz',train_frames=train,validation_frames=valid,test_frames=test,seed=20261103)
m=mujoco.MjModel.from_binary_path(str(R/'model/muscle_geometry.mjb'));d=mujoco.MjData(m)
point0=[];bids=[];owner=[];starts=[];ends=[];segowner=[];route_slices=[]
for i,r in enumerate(rows):
 first=len(point0)
 for p in r['points']:
  point0.append(np.array(p['pos_cm'])*.01);bids.append(mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,p['body']));owner.append(i)
 for k in range(first,len(point0)-1):starts.append(k);ends.append(k+1);segowner.append(i)
 route_slices.append((first,len(point0)))
point0=np.array(point0);bids=np.array(bids);owner=np.array(owner);P=len(bids);starts=np.array(starts);ends=np.array(ends);segowner=np.array(segowner);legpoint=leg_of_m[owner]
X=np.empty((F,P,3));Rot=np.empty((F,P,3,3));Jp=np.empty((F,P,11,3));Jr=np.empty_like(Jp)
for f,t in enumerate(frames):
 d.qpos[:]=Q[t];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d)
 X[f]=d.xpos[bids]*.01;Rot[f]=d.xmat[bids].reshape(P,3,3)
 for bid in set(bids):
  jp=np.empty((3,m.nv));jr=np.empty_like(jp);mujoco.mj_jacBody(m,d,jp,jr,int(bid))
  for p in np.flatnonzero(bids==bid):
   js=dofs[cols[legpoint[p]]];Jp[f,p]=jp[:,js].T*.01;Jr[f,p]=jr[:,js].T
 if f%100==0:print('cache',f,flush=True)
world0=np.einsum('fpij,pj->fpi',Rot[-1:],point0)+X[-1:];segl0=np.linalg.norm(world0[0,ends]-world0[0,starts],axis=1);radii=np.full(P,np.inf)
for a,b,L in zip(starts,ends,segl0):radii[a]=min(radii[a],.24*L);radii[b]=min(radii[b],.24*L)
for p,i in enumerate(owner):radii[p]=min(radii[p],pm[rows[i]['id']]['estimated']['attachment_location_uncertainty_m']['working_radius'][1])
def vertices(bid):
 gids=np.flatnonzero((m.geom_bodyid==bid)&(m.geom_type==int(mujoco.mjtGeom.mjGEOM_MESH)));name=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,bid);g=next((g for g in gids if mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,g)==name),gids[0]);mesh=m.geom_dataid[g];a=m.mesh_vertadr[mesh];n=m.mesh_vertnum[mesh];rot=np.empty(9);mujoco.mju_quat2Mat(rot,m.geom_quat[g]);return (m.mesh_vert[a:a+n].astype(float)@rot.reshape(3,3).T+m.geom_pos[g])*.01
meshcache={bid:vertices(bid) for bid in set(bids)};candidates=np.empty((P,16,3))
for p,bid in enumerate(bids):
 pts=meshcache[bid];dist=np.linalg.norm(pts-point0[p],axis=1);pool=pts[dist<=radii[p]+1e-14]
 if len(pool)==0:pool=point0[p:p+1]
 sample=pool[rng.choice(len(pool),15,replace=len(pool)<15)];candidates[p]=np.vstack([point0[p],sample])
# Every attachment is a convex combination within a bounded local mesh region.
# Each segment direction at reference changes by at most asin(.48)<30 degrees.
baseV=np.array([r['muscle_volume_m3'] for r in rows]);baseL=np.array([r['fiber_length0_m'] for r in rows]);baseS=np.array([r['tendon_slack_length_m'] for r in rows]);est=[pm[r['id']]['estimated'] for r in rows]
bounds=lambda key:np.array([e[key]['working'] for e in est])
VL=bounds('muscle_volume_m3');PL=bounds('physiological_cross_sectional_area_m2');LL=bounds('optimal_fiber_length_m');SL=bounds('tendon_slack_length_m');budget=np.array([c['volume_initial_m3']*(.2 if name.startswith('thorax') else .8) for name,c in cs.items()]);budgetmin=np.array([c['volume_initial_m3']*(.01 if name.startswith('thorax') else .2) for name,c in cs.items()]);
# Fiber length is constrained to intersection of its own prior and volume/PCSA compatibility.
Llo=np.maximum(LL[:,0],VL[:,0]/PL[:,1]);Lhi=np.minimum(LL[:,1],VL[:,1]/PL[:,0]);Llo=np.maximum(Llo,.7*baseL);Lhi=np.minimum(Lhi,1.3*baseL)
var={};var['attachment_logits']=tf.Variable(np.tile(np.r_[5.,np.zeros(15)],(P,1)),dtype=D)
for key in ['log_volume','log_stress','log_length','slack_shift','log_vmax','fl_width','fv_shape','eccentric','passive_slack','passive_strain','passive_shape']:var[key]=tf.Variable(np.zeros(M),dtype=D)
XT,RT,JPT,JRT=T(X),T(Rot),T(Jp),T(Jr);CAND=T(candidates);MASK=T(mask);scaleT=T(scale);bV,bL,bS=T(baseV),T(baseL),T(baseS);CI=tf.constant(ci,dtype=tf.int32);OWNER=tf.constant(segowner,dtype=tf.int32)
VEL=T(Qv[frames]);TARGET=T(np.stack([targetall[frames][:,j] for j in cols],axis=1));EPS=tf.constant(1e-24,D)
def geometry(points,ix):
 rot=tf.gather(RT,ix);r=tf.einsum('fpij,pj->fpi',rot,points);pos=tf.gather(XT,ix)+r
 jac=tf.gather(JPT,ix)+tf.linalg.cross(tf.gather(JRT,ix),r[:,:,None,:]+tf.zeros_like(tf.gather(JRT,ix)))
 diff=tf.gather(pos,ends,axis=1)-tf.gather(pos,starts,axis=1);length=tf.sqrt(tf.reduce_sum(diff*diff,axis=2)+EPS);unit=diff/length[:,:,None]
 dj=tf.gather(jac,ends,axis=1)-tf.gather(jac,starts,axis=1);der=tf.einsum('fsi,fsk i->fsk',unit,dj) if False else tf.reduce_sum(unit[:,:,None,:]*dj,axis=-1)
 lengths=tf.transpose(tf.math.unsorted_segment_sum(tf.transpose(length),OWNER,M));deriv=tf.transpose(tf.math.unsorted_segment_sum(tf.transpose(der,[1,0,2]),OWNER,M),[1,0,2]);return lengths,-deriv
# Exact baseline Jacobian verification before optimizing.
Lcheck,Rcheck=geometry(T(point0),tf.constant([F-1]));d.qpos[:]=Q[0];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);dense=np.empty((m.ntendon,m.nv));mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));tid=np.array([r['tendon_index'] for r in rows]);refR=np.stack([-dense[tid[i],dofs[cols[leg_of_m[i]]]]*.01 for i in range(M)]);np.testing.assert_allclose(Rcheck.numpy()[0],refR,atol=1e-13);np.testing.assert_allclose(Lcheck.numpy()[0],d.ten_length[tid]*.01,atol=1e-13);print('analytic geometry verified',P,'sites',flush=True)
known=np.array([not r['function_hypothesis'] for r in rows]);primary=np.argmax(np.abs(refR),axis=1);sign=np.sign(refR[np.arange(M),primary]);refnorm=np.linalg.norm(refR,axis=1)
@tf.function
def model(ix):
 points=tf.reduce_sum(tf.nn.softmax(var['attachment_logits'],axis=1)[:,:,None]*CAND,axis=1);L,Rmom=geometry(points,ix)
 lopt=tf.clip_by_value(bL*tf.exp(var['log_length']),T(Llo),T(Lhi));vlo=tf.maximum(T(VL[:,0]),T(PL[:,0])*lopt);vhi=tf.minimum(T(VL[:,1]),T(PL[:,1])*lopt)
 Vraw=tf.clip_by_value(bV*tf.exp(tf.clip_by_value(var['log_volume'],-5.,5.)),vlo,vhi);mins=tf.math.unsorted_segment_sum(vlo,CI,NC);extra=tf.math.unsorted_segment_sum(Vraw-vlo,CI,NC);factor=tf.minimum(tf.constant(1.,D),tf.maximum(tf.constant(0.,D),T(budget)-mins)/tf.maximum(extra,tf.constant(1e-30,D)));vol=vlo+(Vraw-vlo)*tf.gather(factor,CI)
 used=tf.math.unsorted_segment_sum(vol,CI,NC);room=vhi-vol;rooms=tf.math.unsorted_segment_sum(room,CI,NC);needed=tf.nn.relu(T(budgetmin)-used);vol=vol+room*tf.gather(tf.minimum(tf.constant(1.,D),needed/tf.maximum(rooms,tf.constant(1e-30,D))),CI)
 sigma=30000*tf.exp(tf.clip_by_value(var['log_stress'],np.log(1/3),np.log(2.)));f0=vol/lopt*sigma
 # A single global slack is bounded using all cached kinematics, never batch torque.
 allr=tf.einsum('fpij,pj->fpi',RT,points);allpos=XT+allr;allseg=tf.gather(allpos,ends,axis=1)-tf.gather(allpos,starts,axis=1);alllength=tf.sqrt(tf.reduce_sum(allseg*allseg,axis=-1)+EPS);alllength=tf.transpose(tf.math.unsorted_segment_sum(tf.transpose(alllength),OWNER,M));minimum=tf.reduce_min(alllength,axis=0)
 slack=tf.clip_by_value(bS+.2*bL*tf.tanh(var['slack_shift']),T(SL[:,0]),T(SL[:,1]));slack=tf.minimum(slack,tf.maximum(tf.constant(0.,D),minimum-.15*lopt));fiber=L-slack;x=fiber/lopt
 vel_leg=tf.gather(tf.gather(VEL,ix),leg_of_m,axis=1);vf=tf.reduce_sum(-Rmom*vel_leg,axis=2)
 vmax=30*tf.exp(tf.clip_by_value(var['log_vmax'],np.log(5/30),np.log(100/30)));vn=vf/(lopt*vmax)
 width=.5+.25*tf.tanh(var['fl_width']);hill=.55+.45*tf.tanh(var['fv_shape']-np.arctanh(2/3));ecc=1.5+.4*tf.tanh(var['eccentric']);ecc=tf.clip_by_value(ecc,1.1,2.)
 shortening=tf.maximum(tf.constant(0.,D),(1+tf.minimum(vn,0.))/(1-tf.minimum(vn,0.)/hill));pv=tf.maximum(vn,0.);fv=tf.where(vn<0,shortening,1+(ecc-1)*pv/(hill+pv));fl=tf.exp(-((x-1)/width)**2);cap=f0*fl*fv
 ps=1.05+.15*tf.tanh(var['passive_slack']-np.arctanh(1/3));strain=.5+.3*tf.tanh(var['passive_strain']);shape=5.+3*tf.tanh(var['passive_shape']-np.arctanh(1/3));fp=f0*tf.math.expm1(tf.clip_by_value(shape*tf.maximum(x-ps,0.)/strain,0.,30.))/tf.math.expm1(shape)
 Ap=tf.gather(Rmom*cap[:,:,None]*1e9,mi,axis=1)*MASK[None,:,:,None];A=tf.transpose(Ap,[0,1,3,2]);p=tf.reduce_sum(tf.gather(Rmom*fp[:,:,None]*1e9,mi,axis=1)*MASK[None,:,:,None],axis=2)
 prior=.001*(tf.reduce_mean(tf.math.log(vol/bV)**2)+tf.reduce_mean(var['log_stress']**2)+tf.reduce_mean((tf.math.log(lopt/bL)/.3)**2)+tf.reduce_mean(tf.tanh(var['slack_shift'])**2)+tf.reduce_mean((tf.math.log(vmax/30)/1.2)**2)+tf.reduce_mean(tf.reduce_sum((points-T(point0))**2,axis=1)/T(radii**2+1e-30)))
 prior+=.0001*sum(tf.reduce_mean(tf.tanh(var[k])**2) for k in ['fl_width','fv_shape','eccentric','passive_slack','passive_strain','passive_shape'])
 lengthpen=10*tf.reduce_mean(tf.nn.relu(.15-x)**2+tf.nn.relu(x-1.8)**2)
 return A,p,prior+lengthpen,(points,lopt,slack,vol,sigma,vmax,width,hill,ecc,ps,strain,shape,f0,L,Rmom)
@tf.function
def inner(A,b):
 C=A/scaleT[None,:,None,None];y=b/scaleT[None,:,None];gram=tf.matmul(C,C,transpose_b=True);lip=tf.reduce_max(tf.linalg.eigvalsh(gram),axis=-1)+1e-6;step=1./tf.maximum(lip,1e-12);a=tf.zeros(tf.concat([tf.shape(A)[:2],[23]],axis=0),D);v=a;alpha=tf.constant(1.,D)
 for it in tf.range(250):
  res=tf.linalg.matvec(C,v)-y;grad=tf.linalg.matvec(C,res,transpose_a=True)+1e-6*v;nxt=tf.clip_by_value(v-step[:,:,None]*grad,0.,1.)*MASK;newalpha=(1+tf.sqrt(1+4*alpha*alpha))/2;v=nxt+(alpha-1)/newalpha*(nxt-a);a=nxt;alpha=newalpha
 return a
opt=tf.keras.optimizers.Adam(.025)
@tf.function
def step(ix):
 with tf.GradientTape() as tape:
  A,p,prior,aux=model(ix);target=tf.gather(TARGET,ix);a=tf.stop_gradient(inner(A,target-p));pred=p+tf.linalg.matvec(A,a);fit=tf.reduce_mean(tf.reduce_sum(((pred-target)/scaleT[None,:,None])**2,axis=2));eff=1e-6*tf.reduce_mean(tf.reduce_sum(a*a,axis=2))
  # Preserve known primary action signs at the reference posture; geometry is not free torque columns.
  _,R0=geometry(aux[0],tf.constant([F-1]));primaryR=tf.gather_nd(R0[0],tf.constant(np.c_[np.arange(M),primary],tf.int32));signpen=100*tf.reduce_mean(tf.where(tf.constant(known),tf.nn.relu(-primaryR*T(sign)/T(refnorm+1e-12))**2,tf.zeros(M,D)))
  loss=fit+eff+prior+signpen
 grad=tape.gradient(loss,list(var.values()));grad,_=tf.clip_by_global_norm(grad,10.);opt.apply_gradients(zip(grad,var.values()));return loss,fit,prior

def exact(ix):
 A,p,prior,aux=model(tf.constant(ix,dtype=tf.int32));A=A.numpy();p=p.numpy();targets=TARGET.numpy()[ix];pred=p.copy();acts=np.zeros((len(ix),6,23));objective=0.;fail=0
 for f in range(len(ix)):
  for g in range(6):
   n=len(groups[g]);sol,_,st=allocate(A[f,g,:,:n],targets[f,g]-p[f,g],scale[g]);acts[f,g,:n]=sol;pred[f,g]+=A[f,g]@acts[f,g];fail+=st<=0
 residual=pred-targets;score=float(np.mean(np.sum((residual/scale[None,:,None])**2,axis=2))+1e-6*np.mean(np.sum(acts**2,axis=2))+prior.numpy());r=float(np.linalg.norm(residual)/np.linalg.norm(targets));return score,r,fail

def feasible():
 _,_,_,aux=model(tf.constant(np.arange(F),tf.int32));points,lopt,slack,vol,sigma,*_= [x.numpy() for x in aux];L=aux[-2].numpy();_,r=geometry(T(points),tf.constant([F-1]));r=r.numpy()[0];sign_ok=np.all(r[np.arange(M),primary][known]*sign[known]>=-1e-12);pca=vol/lopt;sums=np.bincount(ci,weights=vol,minlength=NC)
 return bool(sign_ok and np.all(L-slack>.05*lopt) and np.all(sums<=budget*(1+1e-9)) and np.all(sums>=budgetmin*(1-1e-9)) and np.all(pca>=PL[:,0]*(1-1e-9)) and np.all(pca<=PL[:,1]*(1+1e-9)))

if __name__=='__main__':
 warm=O/'round1/best_variables.npz'
 if warm.exists():
  saved=np.load(warm)
  for k,v in var.items():v.assign(saved[k])
 print('start exact baseline',flush=True);history=[];best=np.inf;bestvars=None;start=time.time()
 for it in range(1001):
  if it%25==0:
   score,tr,fail=exact(train_ix);_,vr,vfail=exact(val_ix);ok=feasible();rec={'iteration':it,'train_objective':score,'train_relative_residual':tr,'validation_relative_residual':vr,'hard_constraints_feasible':ok,'solver_failures':fail+vfail,'elapsed_s':time.time()-start};history.append(rec);print(json.dumps(rec),flush=True)
   if ok and score<best:best=score;bestvars={k:v.numpy().copy() for k,v in var.items()};np.savez(O/'best_variables.npz',**bestvars)
   json.dump(history,open(O/'history.json','w'),indent=2)
  if it<1000:
   batch=rng.choice(train_ix,64,replace=False);previous=var['attachment_logits'].numpy().copy();step(tf.constant(batch,tf.int32))
   # Hard action-sign projection: reject only the offending muscle's geometry move.
   pts=tf.reduce_sum(tf.nn.softmax(var['attachment_logits'],axis=1)[:,:,None]*CAND,axis=1);_,rr=geometry(pts,tf.constant([F-1]));rr=rr.numpy()[0];bad=known&(rr[np.arange(M),primary]*sign < -1e-13)
   if np.any(bad):
    current=var['attachment_logits'].numpy();reject=bad[owner];current[reject]=previous[reject];var['attachment_logits'].assign(current)
 if bestvars is None:raise RuntimeError('No hard-constraint-feasible model; do not export labels')
 for k,v in bestvars.items():var[k].assign(v)
 score,tr,_=exact(train_ix);_,vr,_=exact(val_ix);_,te,_=exact(test_ix);_,_,_,aux=model(tf.constant(np.arange(F),tf.int32));arr=[x.numpy() for x in aux];points,lopt,slack,vol,sigma,vmax,width,hill,ecc,ps,strain,shape,f0,L,Rmom=arr
 out={'schema':'globally_calibrated_bounded_muscles_v1','prior_status':'engineering working ranges, not empirical confidence intervals','selection':'lowest training objective among hard-feasible checkpoints; validation/test targets not differentiated','train_relative_residual':tr,'validation_relative_residual':vr,'test_relative_residual':te,'hard_constraints_feasible':feasible(),'frames':{'train':192,'validation':96,'test':96},'compartment_budget_max_m3':dict(zip(cn,budget.tolist())),'compartment_volume_m3':dict(zip(cn,np.bincount(ci,weights=vol,minlength=NC).tolist())),'records':[]}
 for i,r in enumerate(rows):
  item=dict(r);a,b=route_slices[i];item['points']=[dict(p,pos_cm=(points[a+k]*100).tolist()) for k,p in enumerate(r['points'])];item.update(fiber_length0_m=float(lopt[i]),tendon_slack_length_m=float(slack[i]),muscle_volume_m3=float(vol[i]),PCSA_m2=float(vol[i]/lopt[i]),F0_N=float(f0[i]),specific_stress_Pa=float(sigma[i]),vmax_L0_per_s=float(vmax[i]),force_length_width=float(width[i]),force_velocity_hill_shape=float(hill[i]),eccentric_cap=float(ecc[i]),passive_slack_normalized=float(ps[i]),passive_strain_at_F0=float(strain[i]),passive_exponent=float(shape[i]));out['records'].append(item)
 json.dump(out,open(O/'optimized_geometry.json','w'),indent=2);np.savez(O/'geometry_constraint_details.npz',point0_m=point0,points_m=points,point_radius_m=radii,candidate_points_m=candidates,compartment_index=ci,compartment_budget_max_m3=budget,compartment_budget_min_m3=budgetmin,known_action=known,primary_joint=primary,primary_sign=sign,reference_moment_arm=refR)
 print('RESULT',json.dumps({k:v for k,v in out.items() if k not in ['records','compartment_budget_max_m3','compartment_volume_m3']}),flush=True)
