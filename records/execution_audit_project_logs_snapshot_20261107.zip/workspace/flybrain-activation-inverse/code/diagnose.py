import pathlib,json
import numpy as np
from scipy.optimize import lsq_linear
R=pathlib.Path('/workspace/flybrain-activation-inverse');z={k:v for k,v in np.load(R/'output/activation_6s_5000Hz.npz').items()};B={k:v for k,v in np.load(R/'output/forward_blocks.npz').items()};ts=np.linspace(0,len(z['time_s'])-1,256,dtype=int);normtarget=0.;err_signed=0.;err_positive=0.;fail=0
for leg in ['LF','RF','LM','RM','LH','RH']:
 j=B[leg+'_joint_indices'];k=B[leg+'_muscle_indices']
 for t in ts:
  A=B[leg][t].astype(float);target=z['target_torque_Nm'][t,j]*1e9;p=z['predicted_torque_Nm'][t,j]*1e9-A@z['activation'][t,k];b=target-p
  # Unit-norm columns remove strength limits: diagnostic only, not biological labels.
  norms=np.linalg.norm(A,axis=0);C=A/np.maximum(norms,1e-20);x=np.linalg.lstsq(C,b,rcond=1e-10)[0];fit=lsq_linear(C,b,bounds=(0,np.inf),method='bvls',max_iter=500,tol=1e-9)
  normtarget+=target@target;err_signed+=np.sum((C@x-b)**2);err_positive+=np.sum((C@fit.x-b)**2);fail+=fit.status<=0
out={'sample_frames':256,'diagnostic_only_not_activation_labels':True,'unrestricted_signed_force_relative_residual':float(np.sqrt(err_signed/normtarget)),'unbounded_nonnegative_force_relative_residual':float(np.sqrt(err_positive/normtarget)),'failed_nonnegative_solves':int(fail),'interpretation':'Signed-force residual tests span; unbounded nonnegative residual tests force direction cone. Neither relaxes the saved bounded physical labels.'};json.dump(out,open(R/'output/geometry_diagnostic.json','w'),indent=2);print(json.dumps(out,indent=2))
