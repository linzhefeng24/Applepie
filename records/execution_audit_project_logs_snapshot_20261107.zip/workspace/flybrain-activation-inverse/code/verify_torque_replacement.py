import pathlib,json,numpy as np,mujoco
S=pathlib.Path('/workspace/fly-walking-run/output');O=pathlib.Path('/workspace/flybrain-activation-inverse/forward_test');z=np.load(S/'walking_6s_5000Hz.npz');a={k:z[k] for k in ['qpos','qvel','ctrl','act','qacc_warmstart','qfrc_applied','leg_tau_drive_Nm','joint_actuator_mask','joint_dof_indices']};m1=mujoco.MjModel.from_binary_path(str(S/'model/walking.mjb'));m2=mujoco.MjModel.from_binary_path(str(S/'model/walking.mjb'));mask=a['joint_actuator_mask'];m2.actuator_gainprm[mask]=0;m2.actuator_biasprm[mask]=0;d1=mujoco.MjData(m1);d2=mujoco.MjData(m2);errq=0.;errv=0.;errforce=0.
for t in np.linspace(0,len(a['qpos'])-2,100,dtype=int):
 for d,m in [(d1,m1),(d2,m2)]:
  mujoco.mj_resetData(m,d)
  for key in ['qpos','qvel','act','ctrl','qacc_warmstart','qfrc_applied']:getattr(d,key)[:]=a[key][t]
  d.time=t*.0002
 d2.qfrc_applied[a['joint_dof_indices']]+=a['leg_tau_drive_Nm'][t]/1e-7
 mujoco.mj_forward(m1,d1);mujoco.mj_forward(m2,d2);errforce=max(errforce,float(np.max(np.abs((d1.qfrc_actuator+d1.qfrc_applied)-(d2.qfrc_actuator+d2.qfrc_applied)))))
 mujoco.mj_step(m1,d1);mujoco.mj_step(m2,d2);errq=max(errq,float(np.max(np.abs(d1.qpos-d2.qpos))));errv=max(errv,float(np.max(np.abs(d1.qvel-d2.qvel))))
out={'same_state_samples':100,'original_actuators_vs_generalized_torque_max_force_difference_native':errforce,'one_step_qpos_max_difference':errq,'one_step_qvel_max_difference':errv,'interpretation':'One-step replacement identity at identical states; does not promise long open-loop stability.'};assert errforce<1e-10;assert errq<1e-10;assert errv<1e-7;json.dump(out,open(O/'torque_replacement_verification.json','w'),indent=2);print(json.dumps(out,indent=2))
