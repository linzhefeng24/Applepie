import sys,json,time,numpy as np,mujoco
import shooting_mpc as s
speed=float(sys.argv[1]);s.prepare_source(speed);s.FAST=True;s.ASSIST=1.;d=mujoco.MjData(s.m)
for k in ['qpos','qvel','act','ctrl','qacc_warmstart']:getattr(d,k)[:]=s.src[k][0]
logs=[];fail=None
for t in range(30000):
 mujoco.mj_forward(s.m,d);up=d.xmat[s.thorax].reshape(3,3)[2,2]
 if up<.5:fail='fall';break
 logs.append((float(up),d.xpos[s.thorax].copy()*10));ok,x=s.step(d,s.fw.activation[t],t)
 if not ok:fail='model domain or native warning';break
r={'speed':speed,'training_teacher_fraction':1.,'evaluation_auxiliary_force':False,'duration_s':len(logs)*s.dt,'failure':fail,'min_up':min(v[0] for v in logs),'forward_mm':float(logs[-1][1][0]-logs[0][1][0])};print(r);json.dump(r,open(s.R/f'solver_comparison_20261103/teacher_guide_speed{speed}.json','w'),indent=2)
