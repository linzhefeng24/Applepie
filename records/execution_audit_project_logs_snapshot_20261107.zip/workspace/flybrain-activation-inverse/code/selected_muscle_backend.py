"""Default six-leg muscle backend plus explicitly requested upstream LF reference."""
import sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def load_selected_backend(leg=None,coordinate_system=None):
    choice=json.loads((ROOT/'muscle_model_selection.json').read_text())
    if coordinate_system=='flymimic_native':
        if leg not in [None,'LF']:raise NotImplementedError('The unchanged upstream native reference only supports LF.')
        sys.path.insert(0,str(ROOT/'flymimic_adoption'))
        import importlib.util
        spec=importlib.util.spec_from_file_location('flymimic_native_reference_backend',ROOT/'flymimic_adoption/backend.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        return mod.FlyMimicMuscles('LF')
    if choice['selected_family']!='FlyMimic-six-leg':raise ValueError('Unexpected model selection')
    if coordinate_system not in [None,'flybody_native']:raise ValueError('Use flybody_native for the six-leg working model')
    if leg is not None:raise ValueError('Load all six legs with leg=None; backend.groups[leg] gives per-leg channel indices.')
    import importlib.util
    spec=importlib.util.spec_from_file_location('six_leg_muscle_backend',ROOT/'six_leg_model/backend.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod.SixLegMuscles(model_path=choice['native_model'],records_path=choice.get('model_records'))
