"""Check segment resets are a valid state map, not hidden trajectory correction."""
import numpy as np,json
import periodic_muscle_solver as p
params={'segments':8,'substeps':80,'passive_limit':float('inf'),'tolerance':1e-4};p.initialize(params);x=p.seed_vector(8);b=x[:-2].reshape(8,p.BLOCK).copy();par=x[-2:];T,h,ctrl,acts=p.period_context(float(par[0]));p.MODEL.opt.timestep=h
# Continuous oracle: only initialize once. No state reset at the internal boundary.
d=p.mujoco.MjData(p.MODEL);q,v=p.decode(b[0],0,par);d.qpos[:]=q;d.qvel[:]=v;d.act[:]=acts[0]
for k in range(160):
 i=k//80;u=(k%80)/80;a=(1-u)*b[i,216:]+u*b[i+1,216:];d.ctrl[:]=ctrl[k];p.mujoco.mj_kinematics(p.MODEL,d);p.mujoco.mj_comPos(p.MODEL,d);p.mujoco.mj_tendon(p.MODEL,d);force,_,_=p.NATIVE(d,a);d.qfrc_applied[:]=force
 if k%80==0:p.mujoco.mj_forward(p.MODEL,d)
 p.mujoco.mj_step(p.MODEL,d)
# Compose two state maps, passing the ACTUAL first terminal state into the second.
_,qe,ve,_=p.simulate_segment(0,b[0],b[1],par)
rot=np.empty(3);p.mujoco.mju_quat2Vel(rot,qe[3:7],1.);qc=np.r_[qe[:3],rot,qe[7:109]];qc[0]-=T*par[1]*.5/8;vc=ve[:108].copy();vc[0]-=par[1]*.5
bridge=b[1].copy();bridge[:108]=qc/p.QUNIT;bridge[108:216]=vc/p.VUNIT
_,qend,vend,_=p.simulate_segment(1,bridge,b[2],par)
e=p.state_error(qend,vend,d.qpos,d.qvel);err=float(abs(e).max());assert err<1e-8,err
result={'passed':True,'continuous_vs_composed_actual_state_map_max_scaled_error':err,'continuous_oracle_internal_state_resets':0,'composed_map_uses_actual_terminal_state':True,'act_filter_phase_error':float(abs(d.act-acts[160]).max())};(p.ROOT/'shooting_flow_check.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
