import ctypes,pathlib,numpy as np
class NativeForce:
 def __init__(self,m,rows):
  self.m=m;self.params=np.array([[r[k] for k in ['fiber_length0_m','tendon_slack_length_m','F0_N','vmax_L0_per_s','force_length_width','force_velocity_hill_shape','eccentric_cap','passive_slack_normalized','passive_strain_at_F0','passive_exponent']] for r in rows],dtype='f8');self.tid=np.array([r['tendon_index'] for r in rows],dtype='i4');self.lib=ctypes.CDLL(str(pathlib.Path(__file__).with_name('muscle_force_native.so')));self.f=self.lib.muscle_force
  p=ctypes.c_void_p;self.f.argtypes=[ctypes.c_int,ctypes.c_int]+[p]*11;self.f.restype=ctypes.c_int
 def __call__(self,d,a):
  a=np.ascontiguousarray(a,dtype='f8');force=np.zeros(self.m.nv);limits=np.empty(len(a)+2)
  arrays=[self.tid,d.ten_J_rowadr,d.ten_J_rownnz,d.ten_J_colind,d.ten_J,d.ten_length,d.qvel,self.params,a,force,limits]
  ok=self.f(len(a),self.m.nv,*[ctypes.c_void_p(v.ctypes.data) for v in arrays]);return force,limits[2:],bool(ok)
