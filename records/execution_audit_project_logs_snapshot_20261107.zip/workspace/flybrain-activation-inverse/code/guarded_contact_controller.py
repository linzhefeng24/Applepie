"""Contact-aware QP with pose-domain planning and nonlinear one-period rollout guard.
Neither predicted reactions nor corrective generalized torques are applied to main data.
"""
import numpy as np,mujoco,time,osqp
from scipy.ndimage import gaussian_filter1d
from scipy import sparse
from contact_controller import ContactMuscleController
from contact_response_fd import NativeContactResponse,leg_basis

class GuardedContactController(ContactMuscleController):
 def __init__(self,*args,body_accel_mode="raw",rotation_weight_multiplier=1.,foot_weight=0.,foot_omega=150.,joint_task_multiplier=1.,torque_weight=0.,foot_cache_path=None,**kwargs):
  super().__init__(*args,**kwargs);self.torque_weight=float(torque_weight);self.torque_target_native=self.source['leg_tau_drive_Nm']/1e-7;self.torque_scale=np.ones(len(self.dofs))
  for ji,_ in self.groups:self.torque_scale[ji]=max(float(np.sqrt(np.mean(self.torque_target_native[:,ji]**2))),1e-5)
  self.body_accel_mode=body_accel_mode;self.rotation_weight_multiplier=rotation_weight_multiplier;self.weights[3:6]*=rotation_weight_multiplier;self.weights[6:]*=joint_task_multiplier;self.foot_weight=foot_weight;self.foot_omega=foot_omega;self.joint_task_multiplier=joint_task_multiplier;self.foot_task=None
  if body_accel_mode!='raw':
   self.source=dict(self.source);acc=self.source['qacc'].copy()
   if body_accel_mode=='smooth':acc[:,self.body]=gaussian_filter1d(acc[:,self.body],50.,axis=0,mode='nearest')
   elif body_accel_mode=='zero':acc[:,self.body]=0
   else:raise ValueError('body_accel_mode')
   self.source['qacc']=acc
  self.geometry=mujoco.MjData(self.m);self.guard=NativeContactResponse(self.m);self.control_steps=5;self.lookahead=.001;self.domain_penalty=1e6;self.xmin=.05;self.xmax=2.;self.joint_tolerance=.02;self.enforce_joint_guard=False
  if foot_weight>0:
   from foot_trajectory_task import FootTrajectoryTask
   import pathlib
   body=mujoco.mj_name2id(self.m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');cache=pathlib.Path(foot_cache_path or '/workspace/flybrain-activation-inverse/guarded_contact/reference_foot_task.npz');self.foot_task=FootTrajectoryTask(self.m,self.source,body,self.rootv,cache,omega=foot_omega)
  self.jids=np.array([np.flatnonzero(self.m.jnt_dofadr==v)[0] for v in self.dofs]);self.qadr=self.m.jnt_qposadr[self.jids];self.limited=self.m.jnt_limited[self.jids]>0;self.loq=self.m.jnt_range[self.jids,0]-.01;self.hiq=self.m.jnt_range[self.jids,1]+.01
 def set_control_steps(self,n):self.control_steps=int(n);self.lookahead=max(.001,self.control_steps*float(self.m.opt.timestep))
 def domain_state(self,d):
  x=(d.ten_length[self.tid]*.01-self.slack)/self.l0;v=(self.dense[self.tid]@d.qvel*.01)/self.l0;J=self.dense[self.tid].copy()*.01/self.l0[:,None];eps=min(1e-4,.005/max(1.,np.linalg.norm(d.qvel[self.dofs])));lengths=[]
  for sign in [1,-1]:
   self.geometry.qpos[:]=d.qpos;mujoco.mj_integratePos(self.m,self.geometry.qpos,d.qvel,sign*eps);mujoco.mj_kinematics(self.m,self.geometry);mujoco.mj_comPos(self.m,self.geometry);mujoco.mj_tendon(self.m,self.geometry);lengths.append((self.geometry.ten_length[self.tid]*.01-self.slack)/self.l0)
  curve=(lengths[0]+lengths[1]-2*x)/(eps*eps)
  return x,v,J,curve
 def check_rollout(self,main,a,t):
  key=a.tobytes()
  if key in self.guard_cache:return self.guard_cache[key]
  self.guard.set_state(main);g=self.guard.d;warning0=np.array([z.number for z in g.warning]);minimum=np.inf;maximum=-np.inf;excursion=0.;reason=None
  ghost=mujoco.mj_name2id(self.m,mujoco.mjtObj.mjOBJ_JOINT,'ghost/');ga=self.m.jnt_qposadr[ghost];gv=self.m.jnt_dofadr[ghost]
  for k in range(self.control_steps):
   idx=min(t+int(np.floor(k*float(self.m.opt.timestep)/.0002+1e-9)),len(self.source['qpos'])-1)
   if idx%10==0:g.qpos[ga:ga+7]=self.source['qpos'][idx,ga:ga+7];g.qvel[gv:gv+6]=self.source['qvel'][idx,gv:gv+6]
   g.ctrl[:]=self.source['ctrl'][idx];mujoco.mj_kinematics(self.m,g);mujoco.mj_comPos(self.m,g);mujoco.mj_tendon(self.m,g)
   try:B,p,_=self.force_map(g)
   except ValueError:
    xx=(g.ten_length[self.tid]*.01-self.slack)/self.l0;minimum=min(minimum,float(xx.min()));maximum=max(maximum,float(xx.max()));reason='fiber domain';break
   g.qfrc_applied[:]=self.source['qfrc_applied'][idx]+p+B@a
   if k==0:g.qacc_warmstart[:]=0
   mujoco.mj_forward(self.m,g);mujoco.mj_step(self.m,g)
   if any(g.warning[i].number>warning0[i] for i in [int(mujoco.mjtWarning.mjWARN_BADQPOS),int(mujoco.mjtWarning.mjWARN_BADQVEL),int(mujoco.mjtWarning.mjWARN_BADQACC)]):reason='native numerical warning';break
   mujoco.mj_kinematics(self.m,g);mujoco.mj_comPos(self.m,g);mujoco.mj_tendon(self.m,g);x=(g.ten_length[self.tid]*.01-self.slack)/self.l0;minimum=min(minimum,float(x.min()));maximum=max(maximum,float(x.max()));q=g.qpos[self.qadr];exc=float(max(np.max((self.m.jnt_range[self.jids,0]-q)[self.limited]),np.max((q-self.m.jnt_range[self.jids,1])[self.limited]),0));excursion=max(excursion,exc)
   if not np.all(np.isfinite(g.qpos)) or not np.all(np.isfinite(x)):reason='nonfinite prediction';break
   if minimum<.02 or maximum>1.98:reason='predicted fiber domain';break
   if self.enforce_joint_guard and excursion>self.joint_tolerance:reason='predicted joint range';break
  result={'safe':reason is None,'reason':reason,'min_predicted_fiber_norm':float(minimum),'max_predicted_fiber_norm':float(maximum),'max_predicted_joint_excursion_rad':excursion};self.guard_cache[key]=result;return result
 def solve(self,d,t):
  started=time.time();B,p,moment=self.force_map(d);x,xdot,Jlen,curve=self.domain_state(d);E=leg_basis(moment,self.groups,self.dofs,self.m.nv);span=float(np.linalg.norm(B-E@(E.T@B))/max(np.linalg.norm(B),1e-20))
  if span>1e-8:E=np.eye(self.m.nv)[:,self.dofs]
  projected=E.T@B;target=self.target(d,t);footJ=footgoal=None;footinfo={}
  if self.foot_task is not None:footJ,footgoal,footinfo=self.foot_task.task(d,t)
  background=self.source['qfrc_applied'][t].copy();self.probe.set_state(d);a=np.clip(np.asarray(getattr(self,'current_activation',self.refa[t]),dtype=float),0,1);self.guard_cache={};h=self.lookahead;poseJ=np.vstack([Jlen,np.eye(self.m.nv)[self.dofs[self.limited]]]);lower=np.r_[np.full(len(a),self.xmin),self.loq[self.limited]];upper=np.r_[np.full(len(a),self.xmax),self.hiq[self.limited]]
  bias_base=np.r_[x+h*xdot+.5*h*h*curve,d.qpos[self.qadr[self.limited]]+h*d.qvel[self.dofs[self.limited]]]
  def evaluate(aa):return self.probe.evaluate(background+p+B@aa)
  def costs(acc,aa):
   rr=self.weights*(acc[self.task]-target[self.task]);track=float(rr@rr+self.ridge*(aa@aa))
   if self.torque_weight:
    tr=self.torque_weight*((p+B@aa)[self.dofs]-self.torque_target_native[t])/self.torque_scale;track+=float(tr@tr)
   if footJ is not None:
    fr=self.foot_weight/981.*(footJ@acc-footgoal);track+=float(fr@fr)
   pred=bias_base+.5*h*h*(poseJ@acc);violation=np.maximum(lower-pred,0)+np.maximum(pred-upper,0);return track,track+self.domain_penalty*float(violation@violation)
  acc,lam,state=evaluate(a);initial_track,merit=costs(acc,a);initial_merit=merit;initial_guard=self.check_rollout(d,a,t);best_safe=initial_guard['safe'];initial_safe=best_safe;chosen_seed='current_actual_activation'
  reference=np.clip(self.refa[t].astype(float),0,1)
  if not np.array_equal(reference,a):
   ra,rl,rs=evaluate(reference);rt,rm=costs(ra,reference)
   if rm<merit or not best_safe:
    rg=self.check_rollout(d,reference,t)
    if rg['safe']:a=reference;acc=ra;lam=rl;state=rs;merit=rm;best_safe=True;chosen_seed='reference_candidate'
  last_pred=lam.copy();last_accpred=acc.copy();accepted=0;linearizations=0;pred_errors=[];qerrors=[];changes=[];qp_status=[];qp_slacks=[];consistency=0.;ground_response=0.;linears=0.;last_r=None
  for it in range(self.iterations):
   ts=time.time();r=self.probe.linearize(background+p+B@a,E,self.eps,central=False);linears+=time.time()-ts;last_r=r;linearizations+=1;consistency=max(consistency,r['dynamics_response_consistency_relative_error']);ground_response=max(ground_response,float(np.linalg.norm(r['ground_contact_generalized_force_response'])));A=r['acceleration_response']@projected;C=self.weights[:,None]*A[self.task];yy=self.weights*(target[self.task]-r['qacc0'][self.task]+A[self.task]@a)
   if footJ is not None:
    CA=self.foot_weight/981.*(footJ@A);yb=self.foot_weight/981.*(footgoal-footJ@r['qacc0']+(footJ@A)@a);C=np.vstack([C,CA]);yy=np.r_[yy,yb]
   if self.torque_weight:
    C=np.vstack([C,self.torque_weight*B[self.dofs]/self.torque_scale[:,None]]);yy=np.r_[yy,self.torque_weight*(self.torque_target_native[t]-p[self.dofs])/self.torque_scale]
   baseacc=r['qacc0']-A@a;D=.5*h*h*(poseJ@A);offset=bias_base+.5*h*h*(poseJ@baseacc);n=len(a);ns=len(lower);H=C.T@C+self.ridge*np.eye(n);g=-C.T@yy;P=sparse.block_diag((2*H,2*self.domain_penalty*sparse.eye(ns)),format='csc');q=np.r_[2*g,np.zeros(ns)];cons=sparse.bmat([[sparse.eye(n),None],[sparse.csc_matrix(D),sparse.eye(ns)]],format='csc');lo=np.r_[np.zeros(n),lower-offset];hi=np.r_[np.ones(n),upper-offset]
   costscale=max(1.,self.domain_penalty,float(np.max(np.abs(H))),float(np.max(np.abs(g))));solver=osqp.OSQP();solver.setup(P=sparse.triu(P/costscale).tocsc(),q=q/costscale,A=cons,l=lo,u=hi,verbose=False,eps_abs=1e-4,eps_rel=1e-4,max_iter=1500,polishing=True,warm_starting=True);seedstate=offset+D@a;seedslack=np.clip(seedstate,lower,upper)-seedstate;solver.warm_start(x=np.r_[a,seedslack]);fit=solver.solve(raise_error=False);qp_status.append(fit.info.status)
   if fit.x is None or not np.all(np.isfinite(fit.x[:n])):break
   candidate=np.clip(fit.x[:n],0,1);qp_slacks.append(float(np.linalg.norm(fit.x[n:])));direction=candidate-a;improved=False
   for rate in [1.,.5,.25,.125,.0625]:
    trial=np.clip(a+rate*direction,0,1);aa,ll,ss=evaluate(trial);track,value=costs(aa,trial)
    if (value<merit-1e-9*max(1.,merit) or not best_safe):
     check=self.check_rollout(d,trial,t)
     if not check['safe']:continue
     delta=projected@(trial-a);pred=r['lambda0']+r['constraint_force_response']@delta;ap=r['qacc0']+r['acceleration_response']@delta;pred_errors.append(float(np.linalg.norm(ll-pred)/max(np.linalg.norm(ll-r['lambda0']),np.linalg.norm(pred-r['lambda0']),1e-10)));qerrors.append(float(np.linalg.norm(aa-ap)/max(np.linalg.norm(aa-r['qacc0']),np.linalg.norm(ap-r['qacc0']),1e-10)));changes.append(int(np.sum(ss!=r['state0'])));a=trial;acc=aa;lam=ll;state=ss;merit=value;best_safe=True;last_pred=pred;last_accpred=ap;accepted+=1;improved=True;break
   if not improved:break
  if not best_safe:
   # Deterministic feasible fallbacks, evaluated only in the independent guard.
   feasible=[]
   for trial in [np.zeros_like(a),np.ones_like(a),np.full_like(a,.5),np.clip(self.refa[t],0,1)]:
    check=self.check_rollout(d,trial,t)
    if check['safe']:
     aa,ll,ss=evaluate(trial);track,value=costs(aa,trial);feasible.append((value,trial.copy(),aa,ll,ss))
   if not feasible:raise RuntimeError('no activation certified within next control-period muscle/joint domain; '+str(initial_guard))
   merit,a,acc,lam,state=min(feasible,key=lambda v:v[0]);last_pred=lam.copy();last_accpred=acc.copy()
  acc,lam,state=evaluate(a);final_track,final_merit=costs(acc,a);guard=self.check_rollout(d,a,t);assert guard['safe']
  return a,{'initial_native_acceleration_cost':initial_track,'final_native_acceleration_cost':final_track,'initial_merit_cost':initial_merit,'final_merit_cost':final_merit,'accepted_steps':accepted,'linearizations':linearizations,'native_evaluations':len(self.guard_cache),'contact_force_prediction_relative_errors':pred_errors,'acceleration_prediction_relative_errors':qerrors,'contact_state_changes':changes,'basis_span_relative_error':span,'basis_rank':E.shape[1],'dynamics_response_consistency_max':consistency,'ground_force_response_norm':ground_response,'wall_s':time.time()-started,'linearization_wall_s':linears,'lambda_actual':lam,'lambda_predicted_last':last_pred,'qacc_actual':acc,'qacc_target':target,'qacc_predicted_last':last_accpred,'efc_type':self.probe.d.efc_type.copy(),'efc_id':self.probe.d.efc_id.copy(),'initial_guard_safe':initial_safe,'chosen_seed':chosen_seed,'no_temporal_activation_penalty':True,'final_guard_safe':True,'guard_checks':len(self.guard_cache),'guard_rejections':sum(not z['safe'] for z in self.guard_cache.values()),'min_predicted_fiber_norm':guard['min_predicted_fiber_norm'],'max_predicted_fiber_norm':guard['max_predicted_fiber_norm'],'max_predicted_joint_excursion_rad':guard['max_predicted_joint_excursion_rad'],'qp_status':qp_status,'qp_domain_slack_norm':qp_slacks,'domain_penalty':self.domain_penalty,'domain_lookahead_s':h,'torque_weight':self.torque_weight,'selected_reference_torque_rms_error_native':float(np.sqrt(np.mean(((p+B@a)[self.dofs]-self.torque_target_native[t])**2))),'body_accel_mode':self.body_accel_mode,'rotation_weight_multiplier':self.rotation_weight_multiplier,'foot_task_weight':self.foot_weight,'foot_task_omega':self.foot_omega,'joint_task_multiplier':self.joint_task_multiplier,**footinfo}
