"""Hierarchical periodic multiple shooting. No reference loss in feasibility restoration.
Cyclic shooting nodes are targets, NEVER substituted into accepted free simulations.
"""
import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MUJOCO_GL='egl')
import pathlib,json,time,argparse,functools,concurrent.futures,numpy as np,mujoco
from scipy import sparse
from scipy.optimize import least_squares,minimize,Bounds,NonlinearConstraint,BFGS
from native_muscle_force import NativeForce
R=pathlib.Path('/workspace/flybrain-activation-inverse');ROOT=R/'periodic_20261104';ROWS=json.load(open(R/'optimization/optimized_geometry.json'))['records'];SEED0=np.load(ROOT/'reference_cycle.npz');SEED={k:SEED0[k] for k in SEED0.files};META=json.load(open(ROOT/'seed_metadata.json'));NC=216;BLOCK=342;NREAL=108;TOKENS=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];PARAMS={};MODEL=None;DATA=None;NATIVE=None
QUNIT=np.r_[np.full(3,.01),np.full(3,.1),np.full(102,.5)];VUNIT=np.r_[np.ones(3),np.full(3,10.),np.full(102,50.)];STATEUNIT=np.r_[QUNIT,VUNIT];QSCALE=np.r_[np.full(3,.01),np.full(105,.1)];VSCALE=np.r_[np.ones(3),np.full(105,10.)];ESCALE=np.r_[QSCALE,VSCALE]
def initialize(params):
 global PARAMS,MODEL,DATA,NATIVE,CTRLCOEFF,BASEQ,FOOTIDS,NONFOOT,GEOMS,TYPES,SIZES,WEIGHT,THORAX,GAIT_SWING,GAIT_STANCE,LOQ,HIQ,LO,HI
 PARAMS=params;MODEL=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb'));MODEL.actuator_gainprm[SEED['actuator_mask']]=0;MODEL.actuator_biasprm[SEED['actuator_mask']]=0;MODEL.opt.disableflags|=int(mujoco.mjtDisableBit.mjDSBL_WARMSTART);DATA=mujoco.MjData(MODEL);NATIVE=NativeForce(MODEL,ROWS);fraction=params.get('passive_prior_fraction',0.);assert 0<=fraction<=1
 NATIVE.params[:,7]+=fraction*(1.2-NATIVE.params[:,7]);NATIVE.params[:,8]+=fraction*(.8-NATIVE.params[:,8]);BASEQ=SEED['qpos'][0].copy();n=params['segments'];ix=np.floor(np.arange(n)*len(SEED['qpos'])/n).astype(int);CTRLCOEFF=SEED['ctrl'][ix].copy();CTRLCOEFF[:,SEED['actuator_mask']]=0.
 if params.get('nonleg_controls','source')=='mean':CTRLCOEFF[:,:5]=np.mean(SEED['ctrl'][:,:5],axis=0)
 assert np.all(MODEL.actuator_dyntype==2) and np.all(MODEL.actuator_actadr==np.arange(MODEL.na));assert not MODEL.actuator_actearly.any()
 GEOMS=np.array([i for i in range(MODEL.ngeom) if (mujoco.mj_id2name(MODEL,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('walker/') and (MODEL.geom_contype[i] or MODEL.geom_conaffinity[i])]);TYPES=MODEL.geom_type[GEOMS];SIZES=MODEL.geom_size[GEOMS];assert set(TYPES)<=set([2,3,4,5]);FOOTIDS=[]
 for tok in TOKENS:
  FOOTIDS.append(np.array([k for k,i in enumerate(GEOMS) if tok in (mujoco.mj_id2name(MODEL,mujoco.mjtObj.mjOBJ_GEOM,int(i)) or '') and any(s in (mujoco.mj_id2name(MODEL,mujoco.mjtObj.mjOBJ_GEOM,int(i)) or '') for s in ['tarsus','claw'])],dtype=int));assert len(FOOTIDS[-1])
 NONFOOT=np.array([k for k in range(len(GEOMS)) if k not in set(np.concatenate(FOOTIDS).tolist())]);heights=[]
 for k in ix:
  DATA.qpos[:]=SEED['qpos'][k];mujoco.mj_kinematics(MODEL,DATA);heights.append(geometry_metrics(DATA)[0])
 heights=np.array(heights);GAIT_SWING=np.argmax(heights,axis=0);GAIT_STANCE=np.argmin(heights,axis=0)
 footset=set(np.concatenate(FOOTIDS).tolist());NONFOOT=np.array([k for k in range(len(GEOMS)) if k not in footset]);body=mujoco.mj_name2id(MODEL,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');THORAX=body;WEIGHT=float(MODEL.body_subtreemass[body]*np.linalg.norm(MODEL.opt.gravity));LOQ=MODEL.jnt_range[1:103,0].copy();HIQ=MODEL.jnt_range[1:103,1].copy()
 qlo=np.r_[[-.02,-.02,.08],[-.35,-.35,-.2],LOQ];qhi=np.r_[[.02,.02,.18],[.35,.35,.2],HIQ];vlo=np.r_[[-5,-5,-5],np.full(3,-20.),np.full(102,-500.)];vhi=-vlo;LO=np.r_[qlo/QUNIT,vlo/VUNIT,np.zeros(126)];HI=np.r_[qhi/QUNIT,vhi/VUNIT,np.ones(126)];period_context.cache_clear()
def quaternion(r):
 out=np.empty(4);angle=np.linalg.norm(r)
 if angle<1e-14:return np.array([1.,0,0,0])
 mujoco.mju_axisAngle2Quat(out,r/angle,angle);return out
def decode(block,index,globalp,end=False):
 n=PARAMS['segments'];T=globalp[0]*.1;speed=globalp[1]*.5;phase=(index+int(end))/n;q=BASEQ.copy();qc=block[:108]*QUNIT;q[:3]=qc[:3];q[0]+=phase*T*speed;q[3:7]=quaternion(qc[3:6]);q[7:109]=qc[6:];v=np.zeros(MODEL.nv);v[:108]=block[108:216]*VUNIT;v[0]+=speed;return q,v
@functools.lru_cache(maxsize=16)
def period_context(tnorm):
 T=tnorm*.1;n=PARAMS['segments'];ns=PARAMS['substeps'];count=n*ns;h=T/count;ph=np.arange(count)/ns;node=np.floor(ph).astype(int)%n;u=ph-np.floor(ph);ctrl=(1-u[:,None])*CTRLCOEFF[node]+u[:,None]*CTRLCOEFF[(node+1)%n];beta=h/MODEL.actuator_dynprm[:,0];ret=1-beta;acc=np.zeros(MODEL.na)
 for c in ctrl:acc=ret*acc+beta*c
 initial=acc/(1-ret**count);acts=np.empty((count+1,MODEL.na));acts[0]=initial
 for i,c in enumerate(ctrl):acts[i+1]=ret*acts[i]+beta*c
 return T,h,ctrl,acts

def geometry_metrics(d):
 pos=d.geom_xpos[GEOMS];rz=d.geom_xmat[GEOMS].reshape(-1,3,3)[:,2,:];support=SIZES[:,0].copy();cap=TYPES==3;support[cap]+=SIZES[cap,1]*abs(rz[cap,2]);ell=TYPES==4;support[ell]=np.sqrt(np.sum((rz[ell]*SIZES[ell])**2,axis=1));cyl=TYPES==5;support[cyl]=SIZES[cyl,1]*abs(rz[cyl,2])+SIZES[cyl,0]*np.sqrt(np.maximum(0,1-rz[cyl,2]**2));height=pos[:,2]-support;return np.array([height[ix].min() for ix in FOOTIDS]),float(height[NONFOOT].min())
def foot_forces(d):
 force=np.zeros(6);cf=np.zeros(6);mapping={int(GEOMS[i]):j for j,ids in enumerate(FOOTIDS) for i in ids}
 for k in range(d.ncon):
  c=d.contact[k];g1,g2=int(c.geom1),int(c.geom2);other=g2 if g1==0 else g1 if g2==0 else None
  if other in mapping and c.efc_address>=0:mujoco.mj_contactForce(MODEL,d,k,cf);force[mapping[other]]+=max(0.,cf[0])
 return force

def state_error(q,v,targetq,targetv):
 err=np.empty(MODEL.nv);mujoco.mj_differentiatePos(MODEL,err,1.,targetq,q);return np.r_[err[:108]/QSCALE,(v[:108]-targetv[:108])/VSCALE]
def gait_at_node(i,z,fn):
 n=PARAMS['segments'];out=[fn.sum()/WEIGHT-.5]
 if PARAMS.get('gait_mode','tripod')=='source_phases':
  for j in range(6):
   if i==GAIT_SWING[j]:out.append((z[j]-.003)/.005)
   if i==GAIT_STANCE[j]:out.extend([(.0005-z[j])/.005,fn[j]/WEIGHT-.05])
 else:
  groups=[[0,3,4],[1,2,5]]
  for group,phase in zip(groups,[n//4,3*n//4]):
   if i==phase:out.extend((z[group]-.003)/.005)
   if i==(phase+n//2)%n:out.extend((.0005-z[group])/.005);out.extend(fn[group]/WEIGHT-.05)
 return np.array(out)

def simulate_segment(i,block,nextblock,p):
 T,h,ctrl,acts=period_context(float(p[0]));MODEL.opt.timestep=h;ns=PARAMS['substeps'];mujoco.mj_resetData(MODEL,DATA);q,v=decode(block,i,p);DATA.qpos[:]=q;DATA.qvel[:]=v;DATA.act[:]=acts[i*ns];DATA.time=i*T/PARAMS['segments'];xmin=np.full(126,np.inf);xmax=-xmin;qmin=np.full(102,np.inf);qmax=-qmin;fmin=np.full(6,np.inf);coremin=np.inf;zmin=np.inf;zmax=-np.inf;upmin=np.inf;failed=False;initial_gait=None;first_torque=None
 a0=block[216:];a1=nextblock[216:]
 for k in range(ns+1):
  alpha=k/ns;a=(1-alpha)*a0+alpha*a1;DATA.ctrl[:]=ctrl[(i*ns+k)%len(ctrl)];mujoco.mj_kinematics(MODEL,DATA);mujoco.mj_comPos(MODEL,DATA);mujoco.mj_tendon(MODEL,DATA);force,x,valid=NATIVE(DATA,a);xmin=np.minimum(xmin,x);xmax=np.maximum(xmax,x);qmin=np.minimum(qmin,DATA.qpos[7:109]);qmax=np.maximum(qmax,DATA.qpos[7:109]);footz,corez=geometry_metrics(DATA);fmin=np.minimum(fmin,footz);coremin=min(coremin,corez);zmin=min(zmin,DATA.qpos[2]);zmax=max(zmax,DATA.qpos[2]);upmin=min(upmin,DATA.xmat[THORAX].reshape(3,3)[2,2]);DATA.qfrc_applied[:]=force
  if k==0:
   mujoco.mj_forward(MODEL,DATA);initial_gait=gait_at_node(i,footz,foot_forces(DATA));first_torque=force[SEED['joint_dof_indices']]*1e-7
  if k==ns:break
  previous=np.array([w.number for w in DATA.warning]);mujoco.mj_step(MODEL,DATA)
  if any(DATA.warning[j].number>previous[j] for j in [int(mujoco.mjtWarning.mjWARN_BADQPOS),int(mujoco.mjtWarning.mjWARN_BADQVEL),int(mujoco.mjtWarning.mjWARN_BADQACC)]) or not np.all(np.isfinite(DATA.qvel)) or np.max(abs(DATA.qvel))>1e7:failed=True;break
 qend=DATA.qpos.copy();vend=DATA.qvel.copy();nextindex=(i+1)%PARAMS['segments'];qt,vt=decode(nextblock,nextindex,p)
 if i==PARAMS['segments']-1:qt[0]+=T*p[1]*.5
 eq=state_error(qend,vend,qt,vt);g=np.r_[xmin-.02,1.98-xmax,(qmin-LOQ+.001)/.1,(HIQ-qmax+.001)/.1,(zmin-.08)/.01,(.18-zmax)/.01,(upmin-.85)/.1,(coremin+.00005)/.005,(fmin+.0002)/.005,initial_gait, -1. if failed else 1.]
 if np.isfinite(PARAMS['passive_limit']):
  ps=NATIVE.params[:,7];strain=NATIVE.params[:,8];shape=NATIVE.params[:,9];ratio=np.expm1(np.clip(shape*np.maximum(xmax-ps,0)/strain,0,30))/np.expm1(shape);g=np.r_[g,1-ratio/PARAMS['passive_limit']]
 eq=np.nan_to_num(eq,nan=1e6,posinf=1e6,neginf=-1e6);g=np.nan_to_num(g,nan=-1e6,posinf=1e6,neginf=-1e6);return np.r_[eq,g],qend,vend,first_torque

def local_eval(task):
 i,bi,bn,p=task;return simulate_segment(i,bi,bn,p)
def local_jac(task):
 i,bi,bn,p=task;base,qe,ve,_=simulate_segment(i,bi,bn,p);d0=np.empty((len(base),BLOCK));dn=np.zeros((len(base),BLOCK));dg=np.empty((len(base),2));eps=PARAMS.get('finite_difference_step',1e-6)
 for j in range(BLOCK):
  step=eps if bi[j]+eps<=HI[j] else -eps;v=bi.copy();v[j]+=step;d0[:,j]=(simulate_segment(i,v,bn,p)[0]-base)/step
 for j in range(NC):
  v=bn.copy();v[j]+=eps;qt,vt=decode(v,(i+1)%PARAMS['segments'],p)
  if i==PARAMS['segments']-1:qt[0]+=p[0]*.1*p[1]*.5
  dn[:216,j]=(state_error(qe,ve,qt,vt)-base[:216])/eps
 for j in range(NC,BLOCK):
  step=eps if bn[j]+eps<=HI[j] else -eps;v=bn.copy();v[j]+=step;dn[:,j]=(simulate_segment(i,bi,v,p)[0]-base)/step
 for j in range(2):
  v=p.copy();v[j]+=eps;dg[:,j]=(simulate_segment(i,bi,bn,v)[0]-base)/eps
 return base,d0,dn,dg

class Problem:
 def __init__(self,params,workers):
  self.params=params;self.n=params['segments'];initialize(params);self.pool=concurrent.futures.ProcessPoolExecutor(max_workers=workers,initializer=initialize,initargs=(params,)) if workers>1 else None;self.cachex=None;self.cache=None;self.jacx=None;self.jac=None;self.history=[];self.started=time.time();self.tracking_calls=0
 def tasks(self,x):
  blocks=x[:-2].reshape(self.n,BLOCK);p=x[-2:];return [(i,blocks[i].copy(),blocks[(i+1)%self.n].copy(),p.copy()) for i in range(self.n)]
 def evaluate(self,x):
  if self.cachex is not None and np.array_equal(self.cachex,x):return self.cache
  tasks=self.tasks(x);rr=list(self.pool.map(local_eval,tasks)) if self.pool else [local_eval(t) for t in tasks];self.cachex=x.copy();self.cache=rr;return rr
 def raw(self,x):return np.concatenate([r[0] for r in self.evaluate(x)])
 def feasibility(self,x):
  rr=self.evaluate(x);y=np.concatenate([np.r_[r[0][:216],np.minimum(r[0][216:],0)] for r in rr]);return y
 def rawjac(self,x):
  if self.jacx is not None and np.array_equal(self.jacx,x):return self.jac
  tasks=self.tasks(x);rr=list(self.pool.map(local_jac,tasks)) if self.pool else [local_jac(t) for t in tasks];triples=[];ncols=len(x);offset=0
  for i,(base,di,dn,dg) in enumerate(rr):
   nr=len(base);ii=np.arange(offset,offset+nr);jj=np.arange(BLOCK);triples.append(sparse.coo_matrix((di.ravel(),(np.repeat(ii,BLOCK),np.tile(i*BLOCK+jj,nr))),shape=(sum(len(r[0]) for r in rr),ncols)));triples.append(sparse.coo_matrix((dn.ravel(),(np.repeat(ii,BLOCK),np.tile(((i+1)%self.n)*BLOCK+jj,nr))),shape=triples[-1].shape));triples.append(sparse.coo_matrix((dg.ravel(),(np.repeat(ii,2),np.tile(np.arange(ncols-2,ncols),nr))),shape=triples[-1].shape));offset+=nr
  self.jac=sum(triples).tocsr();self.jac.eliminate_zeros();self.jacx=x.copy();self.cachex=x.copy();self.cache=[(r[0],None,None,None) for r in rr];eq=max(np.max(abs(r[0][:216])) for r in rr);ineq=min(np.min(r[0][216:]) for r in rr);row={'jacobian_evaluation':len(self.history),'max_scaled_dynamics_defect':float(eq),'min_scaled_physical_constraint':float(ineq),'constraint_residual_l2':float(np.linalg.norm(self.feasibility(x))),'wall_s':time.time()-self.started};self.history.append(row);
  if self.params.get('output_dir'):
   out=pathlib.Path(self.params['output_dir']);np.savez_compressed(out/'latest_iterate.npz',x=x);(out/'history.json').write_text(json.dumps(self.history,indent=2))
  print('FEASIBILITY',json.dumps(row),flush=True);return self.jac
 def feasibility_jac(self,x):
  J=self.rawjac(x);active=np.concatenate([np.r_[np.ones(216),r[0][216:]<=0] for r in self.cache]);return sparse.diags(active)@J
 def feasible(self,x):
  rr=self.evaluate(x);eq=max(np.max(abs(r[0][:216])) for r in rr);g=min(np.min(r[0][216:]) for r in rr);return bool(eq<=self.params['tolerance'] and g>=-self.params['tolerance'])
 def tracking(self,x):
  self.tracking_calls+=1;assert self.params.get('stage2_running',False) or self.feasible(x),'Reference loss forbidden in infeasible stage';blocks=x[:-2].reshape(self.n,BLOCK);qref=self.seedblocks[:,:108];vref=self.seedblocks[:,108:216];cost=float(np.mean((blocks[:,:108]-qref)**2)+.05*np.mean((blocks[:,108:216]-vref)**2)+.0001*np.mean(np.diff(np.r_[blocks[:,216:],blocks[:1,216:]],axis=0)**2));return cost
 def tracking_jac(self,x):
  blocks=x[:-2].reshape(self.n,BLOCK);grad=np.zeros_like(blocks);grad[:,:108]=2*(blocks[:,:108]-self.seedblocks[:,:108])/(self.n*108);grad[:,108:216]=.1*(blocks[:,108:216]-self.seedblocks[:,108:216])/(self.n*108);a=blocks[:,216:];grad[:,216:]=.0002*(2*a-np.roll(a,1,axis=0)-np.roll(a,-1,axis=0))/(self.n*126);return np.r_[grad.ravel(),0.,0.]
 def close(self):
  if self.pool:self.pool.shutdown()

def seed_vector(n):
 ix=np.floor(np.arange(n)*len(SEED['qpos'])/n).astype(int);Q=SEED['qpos'][ix].copy();V=SEED['qvel'][ix].copy();T=META['initial_period_s'];speed=float((SEED['qpos'][-1,0]-SEED['qpos'][0,0])/max((len(SEED['qpos'])-1)*.0002,1e-9));speed=np.clip(speed,.2,1.5);blocks=[]
 for i in range(n):
  rot=np.empty(3);mujoco.mju_quat2Vel(rot,Q[i,3:7],1.);q=np.r_[Q[i,:3],rot,Q[i,7:109]];q[0]-=Q[0,0]+i/n*T*speed;q[1]-=Q[0,1];v=V[i,:108].copy();v[0]-=speed;block=np.r_[q/QUNIT,v/VUNIT,SEED['activation'][ix[i]]];blocks.append(np.clip(block,LO+1e-7,HI-1e-7))
 return np.r_[np.array(blocks).ravel(),T/.1,speed/.5]

def free_validation(x,params,cycles=1,save_path=None):
 initialize(params);n=params['segments'];ns=params['substeps'];blocks=x[:-2].reshape(n,BLOCK);p=x[-2:];T,h,ctrl,acts=period_context(float(p[0]));MODEL.opt.timestep=h;d=mujoco.MjData(MODEL);q0,v0=decode(blocks[0],0,p);d.qpos[:]=q0;d.qvel[:]=v0;d.act[:]=acts[0];ends=[];records=[];invalid=False;ming=np.inf;coremin=np.inf;upmin=np.inf;passivemax=0.;max_native_leg=0.;gaitmin=np.inf;stop_reason=None;steps=0;bad_muscles=[]
 for k in range(n*ns*cycles):
  phase=k%(n*ns);i=phase//ns;u=(phase%ns)/ns;a=(1-u)*blocks[i,216:]+u*blocks[(i+1)%n,216:];d.ctrl[:]=ctrl[phase];mujoco.mj_kinematics(MODEL,d);mujoco.mj_comPos(MODEL,d);mujoco.mj_tendon(MODEL,d);force,fiber,ok=NATIVE(d,a);d.qfrc_applied[:]=force
  if not ok or not np.all(np.isfinite(d.qvel)):
   invalid=True;stop_reason='muscle_length_domain' if not ok else 'nonfinite_velocity';bad_muscles=[{'id':ROWS[j]['id'],'normalized_fiber_length':float(fiber[j])} for j in np.flatnonzero((fiber<=.02)|(fiber>=1.98)|~np.isfinite(fiber))];break
  footz,corez=geometry_metrics(d);up=float(d.xmat[THORAX].reshape(3,3)[2,2]);coremin=min(coremin,corez);upmin=min(upmin,up)
  ps=NATIVE.params[:,7];strain=NATIVE.params[:,8];shape=NATIVE.params[:,9];ratio=np.expm1(np.clip(shape*np.maximum(fiber-ps,0)/strain,0,30))/np.expm1(shape);passivemax=max(passivemax,float(ratio.max()))
  g=np.r_[fiber-.02,1.98-fiber,(d.qpos[7:109]-LOQ+.001)/.1,(HIQ-d.qpos[7:109]+.001)/.1,(d.qpos[2]-.08)/.01,(.18-d.qpos[2])/.01,(up-.85)/.1,(corez+.00005)/.005,(footz+.0002)/.005]
  if np.isfinite(params['passive_limit']):g=np.r_[g,1-ratio/params['passive_limit']]
  ming=min(ming,float(g.min()))
  if phase%ns==0:
   mujoco.mj_forward(MODEL,d);gaitmin=min(gaitmin,float(gait_at_node(i,footz,foot_forces(d)).min()))
  max_native_leg=max(max_native_leg,float(np.max(abs(d.actuator_force[SEED['actuator_mask']]))))
  if k%max(1,round(.001/h))==0:records.append((k*h,d.qpos.copy(),d.qvel.copy(),a.copy(),force.copy(),fiber.copy()))
  prev=np.array([w.number for w in d.warning]);mujoco.mj_step(MODEL,d);steps+=1
  if any(d.warning[j].number>prev[j] for j in [int(mujoco.mjtWarning.mjWARN_BADQPOS),int(mujoco.mjtWarning.mjWARN_BADQVEL),int(mujoco.mjtWarning.mjWARN_BADQACC)]):invalid=True;stop_reason='native_numerical_warning';break
  if (k+1)%(n*ns)==0:
   cycle=(k+1)//(n*ns);target=q0.copy();target[0]+=cycle*T*p[1]*.5;err=state_error(d.qpos,d.qvel,target,v0);ends.append({'cycle':cycle,'max_scaled_actual_closure_error':float(np.max(abs(err))),'leg_angle_rms_deg':float(np.rad2deg(np.sqrt(np.mean(((d.qpos[SEED['joint_qpos_indices']]-q0[SEED['joint_qpos_indices']]))**2)))),'native_act_filter_error':float(np.max(abs(d.act-acts[0]))),'leg_angle_max_error_deg':float(np.rad2deg(np.max(abs(d.qpos[SEED['joint_qpos_indices']]-q0[SEED['joint_qpos_indices']])))),'leg_velocity_rms_error_rad_s':float(np.sqrt(np.mean((d.qvel[SEED['joint_dof_indices']]-v0[SEED['joint_dof_indices']])**2))),'body_translation_closure_error_mm':float(np.linalg.norm(err[:3])*.1),'body_orientation_closure_error_deg':float(np.rad2deg(np.linalg.norm(err[3:6])*.1))})
 result={'period_s':T,'stride_mm':T*p[1]*.5*10,'speed_mm_s':p[1]*5,'physics_step_s':h,'requested_cycles':cycles,'completed_cycles':len(ends),'invalid_model_or_native_warning':invalid,'actual_terminal_checks':ends,'no_state_resets_after_initialization':True,'periodic_controls_by_construction':True,'minimum_scaled_path_constraint':float(ming),'minimum_scaled_gait_constraint':float(gaitmin),'minimum_nonfoot_clearance_cm':float(coremin),'minimum_body_up_z':float(upmin),'maximum_passive_force_over_F0':float(passivemax),'maximum_native_leg_actuator_force':float(max_native_leg),'actual_progress_mm':float((d.qpos[0]-q0[0])*10),'simulated_time_s':steps*h,'stop_reason':stop_reason,'invalid_muscles':bad_muscles}
 if save_path and records:np.savez_compressed(save_path,time_s=[r[0] for r in records],qpos=[r[1] for r in records],qvel=[r[2] for r in records],activation=[r[3] for r in records],muscle_ids=[r['id'] for r in ROWS],muscle_generalized_torque_Nm=np.array([r[4][SEED['joint_dof_indices']]*1e-7 for r in records]),qfrc_applied_native=[r[4] for r in records],normalized_fiber_length=[r[5] for r in records],physics_step_s=h,candidate_only=True)
 return result

def validation_passes(result,tolerance,cycles):
 return bool(not result['invalid_model_or_native_warning'] and result['completed_cycles']==cycles and result['minimum_scaled_path_constraint']>=-tolerance and result['minimum_scaled_gait_constraint']>=-tolerance and result['maximum_native_leg_actuator_force']<1e-12 and all(r['max_scaled_actual_closure_error']<=tolerance and r['native_act_filter_error']<=1e-9 for r in result['actual_terminal_checks']))

def lo_bound(n):return np.r_[np.tile(LO,n),.8,.4]
def hi_bound(n):return np.r_[np.tile(HI,n),1.8,3.]

def main(args):
 out=ROOT/args.tag;out.mkdir(exist_ok=True);params={'segments':args.segments,'substeps':args.substeps,'passive_limit':args.passive_limit,'tolerance':1e-4,'output_dir':str(out),'gait_mode':args.gait_mode,'passive_prior_fraction':args.passive_prior_fraction,'nonleg_controls':args.nonleg_controls,'finite_difference_step':args.finite_difference_step};(out/'config.json').write_text(json.dumps(dict(vars(args),params=params),indent=2));problem=Problem(params,args.workers);(out/'effective_muscle_parameters.json').write_text(json.dumps({'muscle_ids':[r['id'] for r in ROWS],'passive_slack':NATIVE.params[:,7].tolist(),'passive_strain':NATIVE.params[:,8].tolist(),'prior_ranges':{'passive_slack':[.9,1.2],'passive_strain':[.2,.8]},'status':'engineering prior ranges, not measured confidence intervals'},indent=2));x0=seed_vector(args.segments);reference_seed=x0.copy();
 if args.resume:
  prev=np.load(args.resume)['x'];old=prev[:-2].reshape(-1,BLOCK);nold=len(old);ph=np.arange(args.segments)*nold/args.segments;j=np.floor(ph).astype(int);u=ph-j;new=(1-u[:,None])*old[j]+u[:,None]*old[(j+1)%nold];x0=np.r_[new.ravel(),prev[-2:]];x0=np.minimum(np.maximum(x0,lo_bound(args.segments)+1e-8),hi_bound(args.segments)-1e-8)
 problem.seedblocks=reference_seed[:-2].reshape(args.segments,BLOCK).copy();lo=np.r_[np.tile(LO,args.segments),.8,.4];hi=np.r_[np.tile(HI,args.segments),1.8,3.];np.savez_compressed(out/'initial_guess.npz',x=x0);initial=free_validation(x0,params,1,out/'initial_guess_free_rollout.npz');(out/'initial_free_validation.json').write_text(json.dumps(initial,indent=2));initialize(params)
 try:
  fit=least_squares(problem.feasibility,x0,jac=problem.feasibility_jac,bounds=(lo,hi),method='trf',tr_solver='lsmr',x_scale='jac',max_nfev=args.evaluations,ftol=1e-8,xtol=1e-8,gtol=1e-8,tr_options={'regularize':True,'maxiter':300},verbose=0);x=fit.x;feasible=problem.feasible(x);np.savez_compressed(out/'feasibility_candidate.npz',x=x);(out/'history.json').write_text(json.dumps(problem.history,indent=2));free=free_validation(x,params,1,out/'candidate_free_rollout.npz');(out/'candidate_free_validation.json').write_text(json.dumps(free,indent=2));initialize(params);actual_ok=validation_passes(free,params['tolerance'],1)
  stage2=False
  if feasible and actual_ok and args.stage2_iterations>0:
   stage2=True;params['stage2_running']=True;problem.params['stage2_running']=True;raw=problem.raw(x);lb=[];ub=[]
   for rr in problem.evaluate(x):lb.extend(np.r_[np.zeros(216),np.zeros(len(rr[0])-216)]);ub.extend(np.r_[np.zeros(216),np.full(len(rr[0])-216,np.inf)])
   constraint=NonlinearConstraint(problem.raw,np.array(lb),np.array(ub),jac=problem.rawjac,hess=lambda x,v:sparse.csr_matrix((len(x),len(x))));second=minimize(problem.tracking,x,method='trust-constr',jac=problem.tracking_jac,hess=BFGS(),bounds=Bounds(lo,hi),constraints=[constraint],options={'maxiter':args.stage2_iterations,'sparse_jacobian':True,'factorization_method':'AugmentedSystem','verbose':0,'gtol':1e-7});
   if problem.feasible(second.x):
    check=free_validation(second.x,params,1)
    if validation_passes(check,params['tolerance'],1):x=second.x
   initialize(params)
  final=free_validation(x,params,max(2,int(np.ceil(6/(x[-2]*.1)))) if actual_ok and feasible else 1,out/'final_free_rollout.npz');(out/'final_free_validation.json').write_text(json.dumps(final,indent=2));report={'solver_status':int(fit.status),'solver_message':fit.message,'function_evaluations':fit.nfev,'cost':float(fit.cost),'optimality':float(fit.optimality),'multiple_shooting_feasible':feasible,'actual_one_period_closed':actual_ok,'stage2_executed':stage2,'reference_loss_calls_before_feasibility':0,'reference_loss_total_calls':problem.tracking_calls,'hard_boundary_elimination':True,'full_real_walker_dofs':108,'filter_states_analytically_periodic':59,'minimum_speed_mm_s':2.,'all_six_legs_swing_and_stance_constraints':True,'constraint_tolerance_scaled':params['tolerance'],'final_validation':final,'bounded_passive_constraint':bool(np.isfinite(params['passive_limit'])),'accepted_periodic_walking':bool(np.isfinite(params['passive_limit']) and feasible and actual_ok and validation_passes(final,params['tolerance'],final['requested_cycles'])),'source_torque_reference_in_secondary_objective':False,'warning':'Unconverged shooting nodes are not a physical walking trajectory. No model infeasibility theorem is claimed.'};(out/'report.json').write_text(json.dumps(report,indent=2));print('REPORT',json.dumps(report),flush=True)
 finally:problem.close()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--tag',default='bounded_passive');p.add_argument('--resume');p.add_argument('--finite-difference-step',type=float,default=1e-6);p.add_argument('--passive-prior-fraction',type=float,default=0.);p.add_argument('--nonleg-controls',choices=['source','mean'],default='source');p.add_argument('--gait-mode',choices=['tripod','source_phases'],default='source_phases');p.add_argument('--segments',type=int,default=16);p.add_argument('--substeps',type=int,default=80);p.add_argument('--passive-limit',type=float,default=10.);p.add_argument('--evaluations',type=int,default=20);p.add_argument('--workers',type=int,default=4);p.add_argument('--stage2-iterations',type=int,default=20);main(p.parse_args())
