"""Additional initial-state check, explicitly separate from start-from-rest trials."""
import pathlib,json,argparse,numpy as np,mujoco
from scipy.ndimage import median_filter
import multitrajectory_ab as b
ROOT=b.ROOT;BASE=pathlib.Path('/workspace/fly-walking-run/alternative_references/speed0.75_seed7');SOURCE=BASE/'walking_9s_5000Hz.npz'
def create():
 v=json.load(open(BASE/'validation.json'));assert v['passes_walking_checks'];z0=np.load(SOURCE);z={k:z0[k] for k in z0.files};N=len(z['time_s']);refs=[]
 for phase in [.6,1.3,2.4]:
  tag='steady075_t'+str(phase).replace('.','p');out=ROOT/'steady_sources'/tag;out.mkdir(parents=True,exist_ok=True);i0=round(phase/.0002);i1=i0+30000;data={k:(a[i0:i1].copy() if a.ndim>0 and len(a)==N else a.copy()) for k,a in z.items()};start=float(z['time_s'][i0]);data['time_s']-=start;mask=(z['action_time_s']>=start-1e-9)&(z['action_time_s']<start+6-1e-9);data['action_time_s']=z['action_time_s'][mask]-start;data['action_real']=z['action_real'][mask];data['final_qpos']=z['qpos'][i1];data['final_qvel']=z['qvel'][i1];data['source_reference_frame']=np.arange(i0,i1);assert len(data['time_s'])==30000 and np.allclose(np.diff(data['time_s']),.0002,atol=1e-12,rtol=0);assert not data['body_ground_contact'].any();assert data['thorax_up_z'].min()>.7;path=out/'walking_6s_5000Hz.npz';np.savez_compressed(path,**data);meta={'original_source':str(SOURCE),'source_phase_start_s':phase,'initialization':'Already walking reference qpos/qvel/act at this phase, ONE initialization only; no walker restoration during evaluation','duration_s':6,'not_a_time_warp':True,'forward_mm':float((data['thorax_xyz_cm'][-1,0]-data['thorax_xyz_cm'][0,0])*10)};(out/'metadata.json').write_text(json.dumps(meta,indent=2));refs.append(dict(id=tag,source=str(path),seed=str(ROOT/'cache'/(tag+'_seed.npz')),foot_cache=str(ROOT/'cache'/(tag+'_feet.npz')),speed=.75,yaw=0.,initialization_phase_s=phase))
 (ROOT/'steady_references.json').write_text(json.dumps(refs,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--stage',choices=['create','prepare','screen','full'],required=True);a=p.parse_args()
 if a.stage=='create':create()
 elif a.stage=='prepare':
  import concurrent.futures
  refs=json.load(open(ROOT/'steady_references.json'))
  with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:
   for r in pool.map(b.prepare,refs):print('PREPARED',r,flush=True)
 else:
  refs=json.load(open(ROOT/'steady_references.json'));jobs=[]
  if a.stage=='screen':
   profiles=[b.PROFILES[0],dict(name='body_priority',omega=300.,torque_weight=1.,body_weight=10.,body_omega=100.,rotation_weight=2.,body_accel='smooth')]
   for ref in refs:
    for profile in profiles:
     for method in ['A','B']:
      cfg=dict(profile,method=method,iterations=1);jobs.append(dict(ref=ref,cfg=cfg,stage='steady_screen',duration=1.,tag=ref['id']+'_'+method+'_'+profile['name']+'_it1'))
   result=b.batch(jobs,3);(ROOT/'steady_screen_results.json').write_text(json.dumps(result,indent=2))
  else:
   rr=json.load(open(ROOT/'steady_screen_results.json'));best=max([r for r in rr if 'config' in r],key=lambda r:r['score']);ref=next(r for r in refs if r['id']==best['ref']);pair=[r for r in rr if r['ref']==ref['id'] and r.get('config',{}).get('name')==best['config']['name']]
   for row in pair:jobs.append(dict(ref=ref,cfg=row['config'],stage='steady_full',duration=6.,tag=row['tag']))
   result=b.batch(jobs,2);(ROOT/'steady_full_results.json').write_text(json.dumps(result,indent=2))
