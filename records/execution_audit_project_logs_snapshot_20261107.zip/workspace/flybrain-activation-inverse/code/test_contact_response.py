import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import pathlib,json,numpy as np,mujoco
from contact_response import response
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'contact_feedback';z=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');Q=z['qpos'];V=z['qvel'];ACT=z['act'];CTRL=z['ctrl'];WARM=z['qacc_warmstart'];TAU=z['leg_tau_drive_Nm'];D=z['joint_dof_indices'];mask=z['joint_actuator_mask'];m=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb'));m.actuator_gainprm[mask]=0;m.actuator_biasprm[mask]=0;m.opt.iterations=100;m.opt.tolerance=1e-12;d=mujoco.MjData(m);rng=np.random.default_rng(2);records=[]
for t in [0,100,500,2000,5000,10000,15000,20000,25000]:
 mujoco.mj_resetData(m,d);d.qpos[:]=Q[t];d.qvel[:]=V[t];d.act[:]=ACT[t];d.ctrl[:]=CTRL[t];d.qfrc_applied[D]=TAU[t]/1e-7;mujoco.mj_forward(m,d);r=response(m,d);J=r['J'];H=r['H'];jar=r['jar'];dferr=[]
 for _ in range(3):
  direction=rng.normal(size=d.nefc);eps=1e-5*max(1.,np.linalg.norm(jar))/max(1.,np.linalg.norm(direction))
  mujoco.mj_constraintUpdate(m,d,jar+eps*direction,None,0);plus=d.efc_force.copy();mujoco.mj_constraintUpdate(m,d,jar-eps*direction,None,0);minus=d.efc_force.copy();fd=(plus-minus)/(2*eps);pred=-H@direction;dferr.append(float(np.linalg.norm(fd-pred)/max(np.linalg.norm(fd),np.linalg.norm(pred),1e-15)))
 # Perturb input joint torques at the same state; ground reactions re-solved by MuJoCo.
 mujoco.mj_constraintUpdate(m,d,jar,None,1);applied=d.qfrc_applied.copy();force0=r['lambda0'];acc0=r['qacc0'];dq=rng.normal(size=m.nv);dq[:]=0;dq[D]=rng.normal(size=len(D));dq*=1e-6;pred_acc=r['P']@dq;pred_force=r['contact_force_sensitivity']@dq
 d.qfrc_applied[:]=applied+dq;mujoco.mj_forward(m,d);plus_acc=d.qacc.copy();plus_force=d.efc_force.copy()
 d.qfrc_applied[:]=applied-dq;mujoco.mj_forward(m,d);minus_acc=d.qacc.copy();minus_force=d.efc_force.copy();fd_acc=(plus_acc-minus_acc)/2;fd_force=(plus_force-minus_force)/2
 rec={'frame':t,'contacts':int(d.ncon),'nefc':int(d.nefc),'cone_rows':int(np.sum(r['state']==4)),'constraint_Hessian_relative_error':max(dferr),'acceleration_response_relative_error':float(np.linalg.norm(fd_acc-pred_acc)/max(np.linalg.norm(fd_acc),np.linalg.norm(pred_acc),1e-15)),'contact_force_response_relative_error':float(np.linalg.norm(fd_force-pred_force)/max(np.linalg.norm(fd_force),np.linalg.norm(pred_force),1e-15))};records.append(rec);print(json.dumps(rec),flush=True)
json.dump(records,open(O/'local_response_test.json','w'),indent=2)
