import sys,pathlib,json,numpy as np,mujoco
from scipy.linalg import eigvalsh
import shooting_mpc as s
from contact_response_fd import NativeContactResponse,leg_basis
from test_feedback_walk import groups
m=s.m;d=mujoco.MjData(m);mass=np.empty((m.nv,m.nv));out=[];s.FAST=False;probe=NativeContactResponse(m)
for frame in [0,500,2500,5000,10000]:
 for k in ['qpos','qvel','act','ctrl','qacc_warmstart']:getattr(d,k)[:]=s.src[k][frame]
 a=s.fw.activation[frame].astype(float);f,x=s.forces(d,a);d.qfrc_applied[:]=f;mujoco.mj_forward(m,d);J=s.dense[s.fw.tid];vn=(J@d.qvel*.01)/(s.fw.l0*s.fw.vmax);fl=np.exp(-((x-1)/s.fw.width)**2);dfv=np.where(vn<0,np.where(vn>-1,(1+1/s.fw.hill)/(1-vn/s.fw.hill)**2,0),(s.fw.ecc-1)*s.fw.hill/(s.fw.hill+vn)**2);dfv=np.nan_to_num(dfv);damp=J.T@np.diag(a*s.fw.F0*fl*dfv*1e3/(s.fw.l0*s.fw.vmax))@J;stiff=J.T@np.diag(np.where(x>s.fw.ps,s.fw.F0*s.fw.shape*np.exp(np.clip(s.fw.shape*(x-s.fw.ps)/s.fw.strain,-30,30))/(s.fw.strain*s.fw.l0*np.expm1(s.fw.shape))*1e3,0))@J;mujoco.mj_fullM(m,mass,d.qM);ix=np.ix_(s.fw.dofs,s.fw.dofs);gamma=eigvalsh(damp[ix],mass[ix])[-1];omega=np.sqrt(max(0,eigvalsh(stiff[ix],mass[ix])[-1]));E=leg_basis(-J[:,s.fw.dofs].T,groups,s.fw.dofs,m.nv);probe.set_state(d);r=probe.linearize(f,E,1e-4,central=False);response=r['acceleration_response']@E.T;gcontact=max(np.linalg.eigvals(response@damp).real);out.append(dict(frame=frame,unconstrained_leg_max_damping_rate_per_s=float(gamma),dt_gamma=float(.0002*gamma),passive_omega_per_s=float(omega),dt_omega=float(.0002*omega),contact_local_dt_gamma=float(.0002*gcontact)));print(out[-1],flush=True)
json.dump(out,open(s.R/'solver_comparison_20261103/stiffness_diagnostic.json','w'),indent=2)
