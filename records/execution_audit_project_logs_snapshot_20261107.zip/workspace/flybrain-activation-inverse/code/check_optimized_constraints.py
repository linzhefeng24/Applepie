import json,pathlib,numpy as np
R=pathlib.Path('/workspace/flybrain-activation-inverse');o=json.load(open(R/'optimization/optimized_geometry.json'));p=json.load(open('/workspace/flybrain-muscle-rebuild/priors/parameter_priors.json'));pm={r['id']:r for r in p['muscles']};details=np.load(R/'optimization/geometry_constraint_details.npz');checks=[]
for r in o['records']:
 e=pm[r['id']]['estimated']
 for field,key in [('fiber_length0_m','optimal_fiber_length_m'),('tendon_slack_length_m','tendon_slack_length_m'),('muscle_volume_m3','muscle_volume_m3'),('PCSA_m2','physiological_cross_sectional_area_m2'),('F0_N','max_isometric_force_N'),('specific_stress_Pa','specific_stress_Pa'),('vmax_L0_per_s','vmax_optimal_fiber_lengths_per_s')]:
  lo,hi=e[key]['working'];v=r[field];checks.append(lo-1e-12*max(abs(lo),1e-15)<=v<=hi+1e-12*max(abs(hi),1e-15))
points=details['points_m'];p0=details['point0_m'];radii=details['point_radius_m'];displacement=np.linalg.norm(points-p0,axis=1);assert np.all(displacement<=radii+1e-14);assert all(checks)
for name,v in o['compartment_volume_m3'].items():assert v<=o['compartment_budget_max_m3'][name]*(1+1e-10)
assert o['hard_constraints_feasible'];print('All scalar ranges, local attachment radii and shared compartment budgets passed')
