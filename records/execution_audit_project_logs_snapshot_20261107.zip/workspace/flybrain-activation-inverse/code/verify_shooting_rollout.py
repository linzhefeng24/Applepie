"""Reexecute recorded activations without MPC; independently audit actual contacts."""
import sys,json,pathlib,numpy as np,mujoco
import shooting_mpc as s
from scipy.ndimage import median_filter
out=pathlib.Path(sys.argv[1]);zfile=np.load(out/'rollout.npz');z={k:zfile[k] for k in zfile.files};config=json.load(open(out/'config.json'));s.prepare_source(config.get('speed',1.));s.FAST=config.get('fast_force',False)
m=s.m;d=mujoco.MjData(m);audit=mujoco.MjData(m);integration=np.empty(mujoco.mj_stateSize(m,s.spec))
for k in ['qpos','qvel','act','ctrl','qacc_warmstart']:getattr(d,k)[:]=s.src[k][0]
core={i for i in range(m.nbody) if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,i) or '').startswith(('walker/head','walker/abdomen','walker/thorax'))};ground={i for i in range(m.ngeom) if m.geom_bodyid[i]==0};tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];feet={}
for i in range(m.ngeom):
 n=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or ''
 if n.startswith('walker/') and any(k in n for k in ['tarsus','claw']):
  for j,tok in enumerate(tokens):
   if tok in n:feet[i]=j
if config.get('initial_forward',0):mujoco.mj_forward(m,d)
maxq=0.;maxv=0.;native=0.;outside=0.;supports=[];touches=[];cf=np.zeros(6);torques=[]
for t,a in enumerate(z['activation']):
 mujoco.mj_forward(m,d);maxq=max(maxq,float(np.max(np.abs(d.qpos-z['qpos'][t]))));maxv=max(maxv,float(np.max(np.abs(d.qvel-z['qvel'][t]))));f,x=s.forces(d,a)
 if f is None:print('INVALID REPLAY',t,maxq,maxv,x.min(),x.max());break
 mujoco.mj_getState(m,d,integration,s.spec);mujoco.mj_setState(m,audit,integration,s.spec);audit.qfrc_applied[:]=s.src['qfrc_applied'][t]+f;mujoco.mj_forward(m,audit);native=max(native,float(np.max(np.abs(audit.actuator_force[s.mask]))));nonleg=f.copy();nonleg[s.fw.dofs]=0;outside=max(outside,float(np.max(np.abs(nonleg))));support=np.zeros(6);touch=False
 for j in range(audit.ncon):
  con=audit.contact[j];g1,g2=int(con.geom1),int(con.geom2);other=g2 if g1 in ground else g1 if g2 in ground else None
  if other is None or con.efc_address<0:continue
  if int(m.geom_bodyid[other]) in core and con.dist<=0:touch=True
  if other in feet:mujoco.mj_contactForce(m,audit,j,cf);support[feet[other]]+=max(0.,cf[0])
 supports.append(support);touches.append(touch);torques.append(f[s.fw.dofs]*1e-7)
 if t%100==0:print('replay',t,'qerr',maxq,'verr',maxv,flush=True)
 if not s.step(d,a,t)[0]:break
stance=median_filter(np.array(supports)>m.body_subtreemass[s.thorax]*np.linalg.norm(m.opt.gravity)*.01,size=(25,1),mode='nearest');cycle=np.sum(stance[1:]!=stance[:-1],axis=0)
r={'independent_replay_max_qpos_error':maxq,'independent_replay_max_qvel_error':maxv,'native_leg_drive_max':native,'muscle_force_outside_leg_dofs_max_native':outside,'body_ground_samples':sum(touches),'foot_contact_transitions':cycle.tolist(),'foot_support_fraction':stance.mean(axis=0).tolist(),'activation_bounds_pass':bool(np.all((z['activation']>=0)&(z['activation']<=1))),'all_finite':bool(all(np.all(np.isfinite(z[k])) for k in z if z[k].dtype.kind in 'fiu'))}
np.savez_compressed(out/'audited_contacts_torque.npz',support_native=np.array(supports),body_ground=np.array(touches),leg_torque_Nm=np.array(torques));json.dump(r,open(out/'verification.json','w'),indent=2);print(json.dumps(r,indent=2))
