"""Check recorded labels, preserved supervision and frame-independent replay."""
import pathlib,json
import numpy as np
from invert import allocate
R=pathlib.Path('/workspace/flybrain-activation-inverse');z=np.load(R/'output/activation_6s_5000Hz.npz');blocks=np.load(R/'output/forward_blocks.npz');source=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');report=json.load(open(R/'output/report.json'))
np.testing.assert_array_equal(z['time_s'],source['time_s']);np.testing.assert_allclose(z['target_torque_Nm'],source['leg_tau_drive_Nm'],rtol=1e-15,atol=1e-25)
np.testing.assert_allclose(z['predicted_torque_Nm']-z['target_torque_Nm'],z['residual_torque_Nm'],rtol=1e-12,atol=1e-22)
a=z['activation'];assert np.all(np.isfinite(a));assert np.all((a>=0)&(a<=1));assert np.all(z['solver_status']>0);assert report['fiber_length_nonpositive_count']==0;assert report['cross_leg_matrix_max_uN_mm']<1e-8;assert report['finite_difference_tendon_derivative_max_abs_cm_per_rad']<1e-6;assert report['source_sha256_before']==report['source_sha256_after']
# Re-solve saved float32 matrices in deliberately shuffled frame order.
rng=np.random.default_rng(2);max_replay=0
for g,leg in enumerate(['LF','RF','LM','RM','LH','RH']):
 B=blocks[leg];j=blocks[leg+'_joint_indices'];k=blocks[leg+'_muscle_indices'];scale=report['torque_scale_uN_mm_per_leg'][g]
 for t in rng.choice(len(a),8,replace=False):
  passive=z['predicted_torque_Nm'][t,j]*1e9-B[t]@a[t,k];b=z['target_torque_Nm'][t,j]*1e9-passive;new,_,_=allocate(B[t].astype(float),b,scale)
  # Float32 storage perturbs ambiguous allocation; compare forward torques.
  max_replay=max(max_replay,float(np.max(np.abs(B[t]@(new-a[t,k])))))
assert max_replay<1e-4,max_replay
out={'fixed_source_labels_match':True,'all_180000_leg_frame_solves_succeeded':True,'activation_bounds_pass':True,'finite_difference_pass':True,'no_cross_leg_force_leakage':True,'shuffled_saved_matrix_replay_max_torque_difference_uN_mm':max_replay}
json.dump(out,open(R/'output/verification.json','w'),indent=2);print(json.dumps(out,indent=2))
