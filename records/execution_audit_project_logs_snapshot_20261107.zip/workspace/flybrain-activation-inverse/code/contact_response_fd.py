"""Same-state native response including soft contact, friction AND noslip stage."""
import numpy as np,mujoco
from scipy.linalg import cho_factor,cho_solve
from contact_response import constraint_jacobian

def leg_basis(moment,groups,dofs,nv):
 columns=[]
 for js,ms in groups:
  U,s,_=np.linalg.svd(moment[np.ix_(js,ms)],full_matrices=False);rank=int(np.sum(s>max(1e-14,s[0]*1e-11))) if len(s) else 0
  for k in range(rank):v=np.zeros(nv);v[dofs[js]]=U[:,k];columns.append(v)
 return np.column_stack(columns) if columns else np.zeros((nv,0))

class NativeContactResponse:
 def __init__(self,m):
  self.m=m;self.d=mujoco.MjData(m);self.spec=int(mujoco.mjtState.mjSTATE_INTEGRATION);self.state=np.empty(mujoco.mj_stateSize(m,self.spec));self.warm=np.zeros(m.nv)
 def set_state(self,main):
  mujoco.mj_getState(self.m,main,self.state,self.spec);mujoco.mj_setState(self.m,self.d,self.state,self.spec);self.warm[:]=0;self.d.qacc_warmstart[:]=self.warm;mujoco.mj_forward(self.m,self.d)
 def evaluate(self,force,full=False):
  self.d.qfrc_applied[:]=force;self.d.qacc_warmstart[:]=self.warm
  if full:mujoco.mj_forward(self.m,self.d)
  else:mujoco.mj_forwardSkip(self.m,self.d,int(mujoco.mjtStage.mjSTAGE_VEL),1)
  return self.d.qacc.copy(),self.d.efc_force.copy(),self.d.efc_state.copy()
 def linearize(self,force,E,epsilon=1e-4,central=False):
  a0,f0,s0=self.evaluate(force);A=np.empty((self.m.nv,E.shape[1]));F=np.empty((len(f0),E.shape[1]))
  for k in range(E.shape[1]):
   ap,fp,_=self.evaluate(force+epsilon*E[:,k])
   if central:am,fm,_=self.evaluate(force-epsilon*E[:,k]);A[:,k]=(ap-am)/(2*epsilon);F[:,k]=(fp-fm)/(2*epsilon)
   else:A[:,k]=(ap-a0)/epsilon;F[:,k]=(fp-f0)/epsilon
  self.evaluate(force)
  # Explicitly put the measured contact-force variation into the equations:
  # M da = du + J.T d_lambda. This includes ground contact and joint limits.
  J=constraint_jacobian(self.m,self.d);M=np.empty((self.m.nv,self.m.nv));mujoco.mj_fullM(self.m,M,self.d.qM);rhs=E+J.T@F;Aphysics=cho_solve(cho_factor(M,lower=True,check_finite=False),rhs,check_finite=False);consistency=float(np.linalg.norm(Aphysics-A)/max(np.linalg.norm(A),1e-20));types=self.d.efc_type.copy();ground=np.zeros(self.d.nefc,dtype=bool)
  for row in np.flatnonzero(types>=int(mujoco.mjtConstraint.mjCNSTR_CONTACT_FRICTIONLESS)):
   contact=self.d.contact[int(self.d.efc_id[row])];g1,g2=int(contact.geom1),int(contact.geom2)
   ground[row]=(g1>=0 and self.m.geom_bodyid[g1]==0) or (g2>=0 and self.m.geom_bodyid[g2]==0)
  return {'qacc0':a0,'lambda0':f0,'state0':s0,'acceleration_response':Aphysics,'measured_acceleration_response':A,'constraint_force_response':F,'mass_matrix':M,'ground_constraint_row_mask':ground,'constraint_jacobian':J,'ground_contact_generalized_force_response':J[ground].T@F[ground],'other_constraint_generalized_force_response':J[~ground].T@F[~ground],'dynamics_response_consistency_relative_error':consistency,'basis':E,'epsilon':epsilon,'method':'native_forwardSkip including noslip'}
