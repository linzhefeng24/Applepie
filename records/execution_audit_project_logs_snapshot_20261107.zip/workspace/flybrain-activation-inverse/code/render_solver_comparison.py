import os;os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/workspace/fly-walking-run/mesa',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
import pathlib,json,subprocess,numpy as np,mujoco
from PIL import Image,ImageDraw,ImageFont
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'solver_comparison_20261103';paths=[pathlib.Path('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz'),R/'ppo_muscle/torque_bc_ppo60k/eval_010240/rollout.npz',R/'shooting_mpc/slow_quarter_reuse/rollout.npz',R/'ppo_muscle/torque_bc/eval_000000/rollout.npz'];qs=[np.load(p)['qpos'] for p in paths];titles=['原控制器参考：原速','PPO：近6秒，但没有正常前进','直接轨迹优化：1/4速度目标','力矩监督神经网络：原速目标'];subtitles=['参考记录，非肌肉激活控制','近乎原地，未通过行走验收','约1.48秒失稳；前进约6毫米','约0.63秒失稳；向后约1.4毫米'];m=mujoco.MjModel.from_binary_path(str(R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m)
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
m.vis.quality.shadowsize=1024;m.vis.quality.offsamples=2;renderer=mujoco.Renderer(m,height=480,width=640);opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0;font={sz:ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',sz) for sz in [18,20,22]};out=O/'fly_solver_trials_not_walking_20261103_light.mp4';writer=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x960','-r','50','-i','-','-an','-c:v','libx264','-preset','fast','-bf','0','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
for frame in range(300):
 t=frame/50;panels=[]
 for q in qs:
  d.qpos[:]=q[min(round(t/.0002),len(q)-1)];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_camlight(m,d);renderer.update_scene(d,camera=1,scene_option=opt);panels.append(renderer.render().copy())
 im=Image.fromarray(np.concatenate([np.concatenate(panels[:2],axis=1),np.concatenate(panels[2:],axis=1)],axis=0));draw=ImageDraw.Draw(im)
 for k,q in enumerate(qs):
  x=(k%2)*640;y=(k//2)*480;draw.rectangle([x,y,x+640,y+82],fill='black');draw.rectangle([x,y+392,x+640,y+480],fill='black')
  stopped=t>=(len(q)*.0002);status='已停止：显示末帧' if stopped else '按实际仿真时间播放（1×）';texts=[(titles[k],10,22,'white'),(subtitles[k],46,18,'yellow'),(f'仿真时间 {min(t,(len(q)-1)*.0002):.3f} s',398,20,'white'),(status,438,18,'orange' if stopped else 'white')]
  for text,dy,sz,color in texts:
   box=draw.textbbox((0,0),text,font=font[sz]);draw.text((x+(640-box[2]+box[0])/2,y+dy),text,font=font[sz],fill=color)
 writer.stdin.write(np.asarray(im).tobytes())
 if frame==50:im.save(O/'comparison_preview.png')
writer.stdin.close();assert writer.wait()==0;renderer.close();(O/'video_provenance.json').write_text(json.dumps({'paths':[str(p) for p in paths],'physical_duration_s':[len(q)*.0002 for q in qs],'frames':300,'fps':50,'playback_speed':1,'stopped_panels_held_and_labeled':True,'archived_free_simulation_states':True},indent=2));print('video ready',out)
