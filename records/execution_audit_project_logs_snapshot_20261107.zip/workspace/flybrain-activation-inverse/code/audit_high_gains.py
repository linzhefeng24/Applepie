import os;os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/fly-high-gain-plots')
import pathlib,json,csv,hashlib
import numpy as np,mujoco
import forward_walk_test as fw
O=fw.R/'high_gain_search';fixed=json.load(open(O/'fixed_hashes.json'));assert all(hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==v for p,v in fixed.items());screen=[]
for p in O.glob('worker_*.json'):screen.extend(json.load(open(p)))
matched=json.load(open(O/'matched_damping_results.json'));assert len(screen)==30 and len(matched)==10
reps=[json.load(open(O/f'full_{i}.json'))[0] for i in [7,1,14]];m=mujoco.MjModel.from_binary_path(str(fw.R/'optimization/optimized_geometry.mjb'));d=mujoco.MjData(m);dense=np.empty((m.ntendon,m.nv));err=0.;outside=0.;rng=np.random.default_rng(31)
for r in reps:
 z={k:v for k,v in np.load(O/'full'/(r['tag']+'_rollout.npz')).items()};assert len(z['time_s'])==30000;assert r['failure'] is None;assert np.all(np.isfinite(z['qpos']));assert np.all(np.isfinite(z['qvel']));assert np.all((z['activation']>=0)&(z['activation']<=1));assert r['disabled_native_leg_force_max']==0;assert r['sampled_allocation_kkt_relative_max']<1e-5
 sat=float(np.mean((z['activation']<1e-6)|(z['activation']>1-1e-6)));assert abs(sat-r['activation_at_zero_fraction']-r['activation_at_one_fraction'])<1e-12
 for t in rng.choice(30000,12,replace=False):
  d.qpos[:]=z['qpos'][t];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_tendon(m,d);mujoco.mju_sparse2dense(dense,d.ten_J.reshape(-1),d.ten_J_rownnz,d.ten_J_rowadr,d.ten_J_colind.reshape(-1));J=dense[fw.tid];fiber=d.ten_length[fw.tid]*.01-fw.slack;assert np.all(fiber>0);x=fiber/fw.l0;vn=(J@z['qvel'][t]*.01)/(fw.l0*fw.vmax);neg=np.minimum(vn,0);pos=np.maximum(vn,0);fv=np.where(vn<0,np.maximum(0,(1+neg)/(1-neg/fw.hill)),1+(fw.ecc-1)*pos/(fw.hill+pos));cap=fw.F0*np.exp(-((x-1)/fw.width)**2)*fv;fp=fw.F0*np.expm1(np.clip(fw.shape*np.maximum(x-fw.ps,0)/fw.strain,0,30))/np.expm1(fw.shape);general=-(J.T@((fp+z['activation'][t]*cap)*1e5));err=max(err,float(np.max(np.abs(general[fw.dofs]*1e-7-z['actual_torque_Nm'][t]))));outside=max(outside,float(np.max(np.abs(np.delete(general,fw.dofs)))))
assert err<1e-14 and outside<1e-10
fields=['omega','zeta','control_steps','duration_s','forward_mm','sideways_mm','boundary_activation_fraction','kkt_relative_max','fall_s','failure']
for name,records in [('screen',screen+matched),('full',reps)]:
 with open(O/(name+'_results.csv'),'w') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for r in records:w.writerow(dict(omega=r['config']['omega'],zeta=r['config']['zeta'],control_steps=r['config']['control_steps'],duration_s=r['duration_s'],forward_mm=r['displacement_x_mm'],sideways_mm=r['displacement_y_mm'],boundary_activation_fraction=r['activation_at_zero_fraction']+r['activation_at_one_fraction'],kkt_relative_max=r['sampled_allocation_kkt_relative_max'],fall_s=r['first_sustained_fall_s'],failure=r['failure']))
summary={'short_config_count':40,'full_6s_count':3,'model_parameters_unchanged':True,'all_full_runs_finite':True,'activations_0_1':True,'native_leg_actuators_zero':True,'max_native_torque_recheck_error_Nm':err,'max_muscle_force_outside_leg_dofs_native':outside,'contact_statistics':'after actual force application (revision2)','full_allocation_tolerance':1e-12,'max_full_sampled_kkt_relative':max(r['sampled_allocation_kkt_relative_max'] for r in reps),'normal_walk_successes':sum(r['passes_six_leg_walk_check'] for r in reps),'full_results':reps};json.dump(summary,open(O/'verified_summary.json','w'),indent=2)
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,2,figsize=(10,4),constrained_layout=True);labels=[str(int(r['omega_per_s'])) for r in reps];ax[0].bar(labels,[r['displacement_x_mm'] for r in reps],color='teal');ax[0].set_xlabel('Omega (1/s), zeta=.5, control dt=.2ms');ax[0].set_ylabel('Reference-direction progress after 6s (mm)');ax[0].set_title('Higher gain did not increase progress');ax[1].bar(labels,[100*(r['activation_at_zero_fraction']+r['activation_at_one_fraction']) for r in reps],color='darkorange');ax[1].set_ylim(0,105);ax[1].set_xlabel('Omega (1/s)');ax[1].set_ylabel('Activation outputs at 0 or 1 (%)');ax[1].set_title('Commands approach on/off allocation');fig.savefig(O/'high_gain_summary.png',dpi=150);print(json.dumps({k:v for k,v in summary.items() if k!='full_results'},indent=2))
