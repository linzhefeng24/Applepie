"""Reproducible multi-stage gain search. Muscle/body parameters stay frozen."""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import pathlib,json,argparse,time,hashlib
import numpy as np
import test_feedback_walk as fb
ROOT=fb.fw.R/'gain_search';ROOT.mkdir(exist_ok=True)

def score(r):
 if r.get('exception'):return -1e6
 survival=r['duration_s']/r.get('requested_duration_s',.65);speed=r['displacement_x_mm']/max(r['duration_s'],.001);lateral=abs(r['displacement_y_mm'])/max(r['duration_s'],.001)
 # Progress and sustained leg cycling, not just staying upright or large path length.
 return 4*survival+2*r['upright_fraction']+.5*r['late_moving_legs']+.2*speed-.05*lateral-.3*r['mean_angle_error_rad']-4*(r['first_sustained_fall_s'] is not None)-8*(r['failure'] is not None)

def plan():
 c=[]
 for w in [350,500,700,1000,1500,2200,3500,6000]:
  for z in [0,.1,.3,.7,1.2,2.]:c.append(dict(omega=w,zeta=z,control_steps=5))
 for w in [500,1000,2200,5000]:
  for z in [0,.3,1.]:
   for step in [1,2]:c.append(dict(omega=w,zeta=z,control_steps=step))
 rng=np.random.default_rng(20261102);rng.shuffle(c)
 for i,x in enumerate(c):x['id']=i
 (ROOT/'plan.json').write_text(json.dumps({'seed':20261102,'duration_s':.65,'configs':c},indent=2))
 hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [fb.fw.R/'optimization/optimized_geometry.json',fb.fw.R/'optimization/optimized_geometry.mjb']};(ROOT/'fixed_model_hashes.json').write_text(json.dumps(hashes,indent=2));print(len(c),'configurations')

def worker(shard,stage):
 fb.O=ROOT/('stage'+str(stage));fb.O.mkdir(exist_ok=True);allc=json.load(open(ROOT/('plan.json' if stage==1 else 'stage2_plan.json')))['configs'];configs=[c for i,c in enumerate(allc) if i%3==shard];path=ROOT/f'stage{stage}_worker{shard}.json';records=json.load(open(path)) if path.exists() else [];done={r['config']['id'] for r in records};duration=.65 if stage==1 else 2.
 for c in configs:
  if c['id'] in done:continue
  try:
   r=fb.run('muscle_pd',c['omega'],c['zeta'],duration=duration,weight='plain',control_steps=c['control_steps'],save_rollout=stage>1);r['requested_duration_s']=duration;r['config']=c;r['score']=score(r)
  except Exception as e:r={'exception':str(e),'config':c,'score':-1e6}
  records.append(r);tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(records,indent=2));tmp.replace(path);print('RECORD',json.dumps(r),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--plan',action='store_true');p.add_argument('--shard',type=int,default=0);p.add_argument('--stage',type=int,default=1);a=p.parse_args()
 if a.plan:plan()
 else:worker(a.shard,a.stage)
