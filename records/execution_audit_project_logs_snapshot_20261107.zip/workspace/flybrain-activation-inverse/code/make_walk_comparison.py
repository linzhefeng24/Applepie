import pathlib,json,subprocess
R=pathlib.Path('/workspace/flybrain-activation-inverse');O=R/'forward_test';font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';reports={k:json.load(open(O/(k+'_report.json'))) for k in ['torque','muscle']}
def title(text,y=14,size=23,color='white',enable=None):
 s=f"drawtext=fontfile={font}:text='{text}':x=(w-tw)/2:y={y}:fontsize={size}:fontcolor={color}:shadowcolor=black:shadowx=1:shadowy=1"
 if enable:s+=f":enable='{enable}'"
 return s
for key,text in [('torque','原始力矩轨迹重放'),('muscle','优化肌肉激活重放')]:
 r=reports[key];f='drawbox=x=0:y=0:w=iw:h=52:color=black@0.75:t=fill,'+title(text);f+=','+title(f"位移 {r['displacement_xy_mm']:.2f} mm",y=448,size=21)
 if r['failure']:
  when=r['failure']['time_s'];f+=',drawbox=x=0:y=202:w=iw:h=80:color=black@0.8:t=fill:enable=\'gte(t,'+str(when)+')\','+title('模型超出有效范围，末帧冻结',y=215,size=23,color='yellow',enable=f'gte(t,{when})');f+=','+title(f'停止时刻 {when:.4f} s',y=248,size=21,color='yellow',enable=f'gte(t,{when})')
 elif not r['passes_walking_checks']:
  verdict=f"约 {r['first_sustained_fall_s']:.2f} s 后倒地" if r['first_sustained_fall_s'] is not None else '未通过持续行走检查'
  f+=','+title(verdict,y=412,size=21,color='yellow')
 else:f+=','+title('通过持续行走检查',y=412,size=21,color='lime')
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(O/(key+'_raw.mp4')),'-vf',f,'-an','-c:v','libx264','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(O/(key+'_replay.mp4'))],check=True)
# All panels use source camera 1, 640x480, 50fps, six simulated seconds.
ref='/workspace/fly-walking-run/output/walking.mp4';head='drawbox=x=0:y=0:w=iw:h=52:color=black@0.75:t=fill,'+title('原控制器行走记录')+','+title('位移 120.23 mm；原闭环控制器',y=448,size=21)
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',ref,'-i',str(O/'torque_replay.mp4'),'-i',str(O/'muscle_replay.mp4'),'-filter_complex',f'[0:v]{head},setpts=PTS-STARTPTS[a];[1:v]setpts=PTS-STARTPTS[b];[2:v]setpts=PTS-STARTPTS[c];[a][b][c]hstack=inputs=3,fps=50,tpad=stop_mode=clone:stop_duration=0.04,settb=expr=1/50,setpts=N[v]','-map','[v]','-r','50','-frames:v','300','-bf','0','-an','-c:v','libx264','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'walking_comparison.mp4')],check=True)
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(O/'torque_replay.mp4'),'-i',str(O/'muscle_replay.mp4'),'-filter_complex','[0:v][1:v]hstack=inputs=2[v]','-map','[v]','-r','50','-frames:v','300','-bf','0','-an','-c:v','libx264','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'torque_vs_muscle.mp4')],check=True)
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss','1','-i',str(O/'walking_comparison.mp4'),'-frames:v','1',str(O/'comparison_preview.png')],check=True)
print('Comparison videos ready')
