# Sequential endpoint optimization with more corrections

Physical duration 0.2 s, ten consecutive 20 ms intervals. During each interval only its muscle commands are changed. Frozen earlier and untouched later commands are checked. Actual complete physical state (position, velocity, muscle activation, warmstart) propagates continuously, without resetting to reference.

Each of 130 muscles receives a constant command offset within the current interval, applied to the existing 10 kHz command profile and clipped to [0,1]. Native MuJoCo muscle dynamics, body mechanics, ground contacts and adhesion remain enabled. No height, orientation or velocity penalty; no injected rescue forces. All model parameters and initial states match the preceding experiment.

Each interval permits at most 30 bounded local Gauss–Newton corrections with positive/negative finite-difference sensitivities and nonlinear rollout line search. Stop target: aggregate endpoint joint-angle RMSE below 1 degree. Stop on stagnation after five rounds each improving by less than 0.001 degree or rejecting the candidate. A finite round limit and a stagnation threshold do not establish reachability or global optimality. Aggregate RMSE below 1 degree would not mean every individual joint is within 1 degree.

The preceding three-round experiment is retained unchanged in segment_20ms. New data are in segment_20ms_more. Predictions must match actual propagated execution; independently replay all saved commands before reporting results. The reference is simulated teacher motion, not a living fly recording.
