import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import importlib.util,json,time,argparse
import numpy as np,mujoco
from mujoco import rollout
from scipy.optimize import lsq_linear
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('terminal_stage',R.parent/'terminal_priority_20261105/problem.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
ap=argparse.ArgumentParser();ap.add_argument('--segment-ms',type=float,default=20);ap.add_argument('--inner',type=int,default=3);args=ap.parse_args();OUT=R/f'segment_{args.segment_ms:g}ms_more';OUT.mkdir(exist_ok=True)
p=mod.JointTrajectory();m=p.m;seed={k:v for k,v in np.load(R.parent/'uniform_activation_20261105/optimized_rollout.npz').items()};planned=seed['all_control_10000Hz'].copy();original=planned.copy();initial=seed['initial_state'].copy();d=mujoco.MjData(m);mujoco.mj_setState(m,d,initial,mujoco.mjtState.mjSTATE_FULLPHYSICS);d.qacc_warmstart[:]=seed['initial_warmstart'];d.ctrl[:]=planned[0]
nc=round(args.segment_ms/1000/m.opt.timestep);assert p.steps%nc==0;segments=p.steps//nc;srcq=p.reference['qpos'];data=[mujoco.MjData(m) for _ in range(4)];snapshots=[];controls=[];history=[];inner_history=[];amin=1.;amax=0.;clock=time.monotonic();offset0=1+m.nq+m.nv;max_prediction_error=0.
for seg in range(segments):
 start=seg*nc;stop=start+nc;frozen_past=planned[:start].copy();frozen_future=planned[stop:].copy();base=planned[start:stop].copy();offset=np.zeros(130);loamp=-base[:,p.ids].max(axis=0);hiamp=1-base[:,p.ids].min(axis=0);state=np.empty(len(initial));mujoco.mj_getState(m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);warm=d.qacc_warmstart.copy();frame=round(stop*m.opt.timestep/.0002);target=srcq[frame,p.qadrs];sample=np.arange(9,nc,10);refpath=srcq[np.rint((start+sample+1)*m.opt.timestep/.0002).astype(int)][:,p.qadrs]
 def forecast(amps):
  amps=np.atleast_2d(amps);C=np.broadcast_to(base,(len(amps),*base.shape)).copy();C[:,:,p.ids]=np.clip(base[None,:,p.ids]+amps[:,None,:],0,1);S,_=rollout.rollout(m,data,state[None],C,initial_warmstart=warm[None],persistent_pool=True);qe=S[:,-1,1:1+m.nq][:,p.qadrs];errors=qe-target[None];endcost=np.mean(errors**2,axis=1);pathcost=np.mean((S[:,sample,1:1+m.nq][:,:,p.qadrs]-refpath[None])**2,axis=(1,2));valid=np.isfinite(S).all(axis=(1,2))&np.isclose(S[:,-1,0],state[0]+nc*m.opt.timestep,atol=1e-8);endcost=np.where(valid,endcost,1e6);return errors,endcost,pathcost,qe
 e,c,path,qend=forecast(offset);baseline=float(c[0]);initial_segment_error=float(np.sqrt(baseline)*180/np.pi);trust=.25;count=0;stalled=0
 for inner in range(args.inner):
  e,c,path,qend=forecast(offset);res=e[0].copy()
  if np.sqrt(np.mean(res**2))<1*np.pi/180:break
  hp=np.minimum(.002,hiamp-offset);hm=-np.minimum(.002,offset-loamp);ip=np.flatnonzero(hp>1e-10);im=np.flatnonzero(hm<-1e-10);probes=[]
  for i in ip:x=offset.copy();x[i]+=hp[i];probes.append(x)
  for i in im:x=offset.copy();x[i]+=hm[i];probes.append(x)
  pe,pc,_,_=forecast(probes);Jp=np.zeros((66,130));Jm=np.zeros_like(Jp)
  for k,i in enumerate(ip):
   if pc[k]<1e5:Jp[:,i]=(pe[k]-res)/hp[i]
  for k,i in enumerate(im):
   if pc[len(ip)+k]<1e5:Jm[:,i]=(pe[len(ip)+k]-res)/hm[i]
  gp=Jp.T@res;gm=Jm.T@res;inc=np.where(hiamp-offset>1e-9,-gp,-np.inf);dec=np.where(offset-loamp>1e-9,gm,-np.inf);positive=inc>=dec;active=np.flatnonzero(np.maximum(inc,dec)>1e-11)
  if not len(active):break
  J=np.where(positive[None],Jp,Jm)[:,active];ridge=max(np.linalg.norm(J,'fro')/np.sqrt(len(active))*.01,1e-7);A=np.vstack([J,ridge*np.eye(len(active))]);b=np.r_[-res,np.zeros(len(active))];lower=np.where(positive[active],0,np.maximum(loamp[active]-offset[active],-trust));upper=np.where(positive[active],np.minimum(hiamp[active]-offset[active],trust),0);fit=lsq_linear(A,b,bounds=(lower,upper),method='bvls',tol=1e-8,max_iter=200);delta=np.zeros(130);delta[active]=fit.x;scales=np.array([1.,.5,.25,.125,.0625]);candidate=np.clip(offset[None]+scales[:,None]*delta,loamp,hiamp);ce,cc,cp,_=forecast(candidate);j=int(np.lexsort((cp,cc))[0]);accepted=bool(cc[j]<c[0]-1e-12)
  if accepted:
   improvement=float(np.sqrt(c[0])-np.sqrt(cc[j]))*180/np.pi;offset=candidate[j].copy();trust=min(.5,trust*1.2);stalled=stalled+1 if improvement<.001 else 0
  else:trust*=.5;stalled+=1
  if stalled>=5:break
  count+=1;inner_history.append(dict(segment=seg+1,iteration=inner+1,accepted=accepted,terminal_rmse_deg=float(np.sqrt(cc[j] if accepted else c[0])*180/np.pi),active_directions=len(active)))
 e,c,path,qend=forecast(offset);prediction=qend[0].copy();selected=base.copy();selected[:,p.ids]=np.clip(base[:,p.ids]+offset[None],0,1);planned[start:stop]=selected;assert np.array_equal(planned[:start],frozen_past) and np.array_equal(planned[stop:],frozen_future)
 for k in range(nc):
  d.ctrl[:]=selected[k];mujoco.mj_step(m,d);amin=min(amin,float(d.act[p.adrs].min()));amax=max(amax,float(d.act[p.adrs].max()))
  if (start+k)%2==1:
   s=np.empty(len(initial));mujoco.mj_getState(m,d,s,mujoco.mjtState.mjSTATE_FULLPHYSICS);snapshots.append(s);controls.append(d.ctrl.copy())
 difference=float(np.max(abs(d.qpos[p.qadrs]-prediction)));assert difference<1e-9,difference;max_prediction_error=max(max_prediction_error,difference);actual=float(np.sqrt(np.mean((d.qpos[p.qadrs]-target)**2))*180/np.pi);baseline_endpoint=seed['joint_angle_rad'][stop//2-1]-seed['target_joint_angle'][stop//2-1];vref=p.src['qvel'][frame,p.dofs]
 row=dict(segment=seg+1,start_time_s=start*m.opt.timestep,end_time_s=stop*m.opt.timestep,initial_local_forecast_rmse_deg=initial_segment_error,optimized_endpoint_rmse_deg=actual,original_whole_trajectory_program_endpoint_rmse_deg=float(np.sqrt(np.mean(baseline_endpoint**2))*180/np.pi),inner_updates=count,endpoint_velocity_rmse_rad_s=float(np.sqrt(np.mean((d.qvel[p.dofs]-vref)**2))),prediction_execution_joint_max_error_rad=difference,past_and_future_controls_unchanged=True,wall_s=time.monotonic()-clock);history.append(row);(OUT/'segment_history.json').write_text(json.dumps(history,indent=2));(OUT/'inner_history.json').write_text(json.dumps(inner_history,indent=2));np.savez_compressed(OUT/'checkpoint.npz',full_state=np.asarray(snapshots),all_control_10000Hz=planned,initial_state=initial);print(json.dumps(row),flush=True)
s=np.asarray(snapshots);C=np.asarray(controls);q=s[:,1:1+m.nq];qv=s[:,1+m.nq:offset0];a=s[:,offset0:][:,p.adrs];targets=srcq[np.rint(s[:,0]/.0002).astype(int)][:,p.qadrs];errors=q[:,p.qadrs]-targets
np.savez_compressed(OUT/'rollout_5000Hz.npz',time_s=s[:,0],qpos=q,qvel=qv,activation=a,excitation=C[:,p.ids],full_state=s,all_control_10000Hz=planned,initial_state=initial,initial_warmstart=seed['initial_warmstart'],joint_angle_rad=q[:,p.qadrs],target_joint_angle=targets,qerror_rad=errors,muscle_ids=seed['muscle_ids'],joint_names=seed['joint_names'])
assert not np.any(d.qfrc_applied) and not np.any(d.xfrc_applied) and 0<=amin<=amax<=1
report=dict(method='sequential frozen-prefix segment endpoint optimization; only current segment muscle commands changed',duration_s=.2,segment_duration_s=args.segment_ms/1000,segments=segments,max_inner_updates=args.inner,target_endpoint_rmse_deg=1.0,stop_after_stalled_rounds=5,terminal_rmse_deg=history[-1]['optimized_endpoint_rmse_deg'],path_rmse_deg=float(np.sqrt(np.mean(errors**2))*180/np.pi),max_terminal_joint_error_deg=float(np.max(abs(errors[-1]))*180/np.pi),baseline_terminal_rmse_deg=float(np.sqrt(np.mean((seed['joint_angle_rad'][-1]-seed['target_joint_angle'][-1])**2))*180/np.pi),baseline_path_rmse_deg=float(np.sqrt(np.mean((seed['joint_angle_rad']-seed['target_joint_angle'])**2))*180/np.pi),activation_min_all_physics_steps=amin,activation_max_all_physics_steps=amax,initial_state_fixed=True,intermediate_state_resets=False,only_current_interval_modified=True,max_prediction_execution_joint_error_rad=max_prediction_error,height_penalty=0,orientation_penalty=0,velocity_penalty=0,muscle_parameters_changed=False,extra_forces=False,walking_validated=False,wall_s=time.monotonic()-clock,limits=['Finite local updates per segment, no global optimality or exact endpoint feasibility guarantee.','Position matching alone does not fix velocity or activation for the next segment; all states are propagated physically.'])
(OUT/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
