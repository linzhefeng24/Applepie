from pathlib import Path
import os,json,importlib.util,copy,hashlib
os.environ['MPLCONFIGDIR']='/tmp/mpl-sequential'
import numpy as np,mujoco
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;O=R/'segment_20ms_more'
spec=importlib.util.spec_from_file_location('seq_problem',R.parent/'terminal_priority_20261105/problem.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);p=mod.JointTrajectory();m=p.m
z=dict(np.load(O/'rollout_5000Hz.npz'));seed=dict(np.load(R.parent/'uniform_activation_20261105/optimized_rollout.npz'));d=mujoco.MjData(m);mujoco.mj_setState(m,d,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.qacc_warmstart[:]=z['initial_warmstart'];err=0.;amin=1.;amax=0.
for i,c in enumerate(z['all_control_10000Hz']):
 d.ctrl[:]=c;mujoco.mj_step(m,d);amin=min(amin,float(d.act[p.adrs].min()));amax=max(amax,float(d.act[p.adrs].max()))
 if i%2:
  s=np.empty(z['full_state'].shape[1]);mujoco.mj_getState(m,d,s,mujoco.mjtState.mjSTATE_FULLPHYSICS);err=max(err,float(np.max(abs(s-z['full_state'][i//2]))))
assert err<1e-9 and 0<=amin<=amax<=1
other=np.setdiff1d(np.arange(m.nu),p.ids);assert np.array_equal(z['all_control_10000Hz'][:,other],seed['all_control_10000Hz'][:,other]);assert not np.any(d.qfrc_applied) and not np.any(d.xfrc_applied)
v=dict(passed=True,independent_replay_max_full_state_error=err,nonmuscle_controls_unchanged=True,activation_min=amin,activation_max=amax,no_extra_applied_forces=True);(O/'validation.json').write_text(json.dumps(v,indent=2))
h=json.loads((O/'segment_history.json').read_text());t=z['time_s'];new=np.sqrt(np.mean(z['qerror_rad']**2,axis=1))*180/np.pi;old=np.sqrt(np.mean((seed['joint_angle_rad']-seed['target_joint_angle'])**2,axis=1))*180/np.pi
prior=dict(np.load(R/'segment_20ms/rollout_5000Hz.npz'));priorerror=np.sqrt(np.mean(prior['qerror_rad']**2,axis=1))*180/np.pi
fig,ax=plt.subplots(figsize=(9,4));ax.plot(t,old,label='Previous whole-program solution');ax.plot(t,priorerror,label='Sequential, 3 rounds',alpha=.7);ax.plot(t,new,label='Sequential, up to 30 rounds');ax.scatter([x['end_time_s'] for x in h],[x['optimized_endpoint_rmse_deg'] for x in h],s=18);ax.set(xlabel='Time (s)',ylabel='Joint-angle RMSE (deg)');ax.legend();ax.grid(alpha=.25);fig.tight_layout();fig.savefig(O/'comparison.png',dpi=160)
C=Path('/workspace/flybrain-muscle-rebuild/brain.json');M=Path('/workspace/flybrain-recovered/brain.json');assert C.read_bytes()==M.read_bytes();b=json.loads(C.read_text());before=copy.deepcopy(b);backup=R/'brain_before.json'
if not backup.exists():backup.write_bytes(C.read_bytes())
id='six_leg_sequential_local_segments_more_20261106';report=json.loads((O/'report.json').read_text());run=dict(id=id,date='2026-11-06',previous_experiment_id='six_leg_uniform_activation_offsets_20261105',report=report,validation=v,segment_history=h,height_penalty=0,muscle_parameters_changed=False,walking_validated=False,artifacts=[dict(path=str(x),sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in O.iterdir() if x.suffix in ['.json','.npz','.png']]);runs=b['muscle_activation_inference_experiments']['runs'];runs[:]=[x for x in runs if x['id']!=id];runs.append(run);b['neuromusculoskeletal_model']['current_readiness']['latest_sequential_segment_experiment_id']=id;b['version']='3.4.13-sequential-local-segments-more';b['date']='2026-11-06'
for k in before:
 if k not in ['version','date','neuromusculoskeletal_model','muscle_activation_inference_experiments']:assert b[k]==before[k]
blob=(json.dumps(b,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
for x in [C,M]:tmp=x.with_suffix('.sequential.tmp');tmp.write_bytes(blob);os.replace(tmp,x)
print(json.dumps(dict(report=report,validation=v),indent=2))
