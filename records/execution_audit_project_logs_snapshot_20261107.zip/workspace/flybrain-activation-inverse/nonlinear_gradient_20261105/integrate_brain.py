from pathlib import Path
import json,copy,hashlib,os
R=Path(__file__).resolve().parent;C=Path('/workspace/flybrain-muscle-rebuild/brain.json');M=Path('/workspace/flybrain-recovered/brain.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads(C.read_text());assert b==json.loads(M.read_text());before=copy.deepcopy(b);backup=R/'brain_before_gradient_trial.json'
if not backup.exists():backup.write_bytes(C.read_bytes())
report=json.loads((R/'report.json').read_text());validation=json.loads((R/'validation.json').read_text());assert validation['passed'];assert report['final_loss']<report['initial_loss'];assert report['final_all_physics_activation_bounds'][0]>=0 and report['final_all_physics_activation_bounds'][1]<=1
run=dict(id='six_leg_nonlinear_gradient_20261105',date='2026-11-05',role='short-horizon end-to-end nonlinear native rollout excitation optimization, preliminary not walking validation',previous_experiment_id='six_leg_contact_closed_loop_20261104',report=report,validation=validation,method_document={'format':'markdown','text':(R/'README.md').read_text()},artifacts=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(R.iterdir()) if p.is_file() and p.suffix in ['.py','.json','.npz','.png','.mp4','.md'] and p.name not in ['brain_before_gradient_trial.json','brain_integration.json']],walking_validated=False)
runs=b['muscle_activation_inference_experiments']['runs'];runs[:]=[x for x in runs if x['id']!=run['id']];runs.append(run)
n=b['neuromusculoskeletal_model'];n['current_readiness']['latest_nonlinear_gradient_experiment_id']=run['id'];n['current_muscle_model_overview']['short_horizon_gradient_trial']={'experiment_id':run['id'],'method':report['method'],'horizon_s':report['seconds'],'not_exact_backpropagation':True,'single_shooting':True,'walking_validated':False,'selected_model_and_default_parameters_unchanged':True}
b['version']='3.4.5-short-horizon-nonlinear-gradient';b['date']='2026-11-05'
for k,v in before.items():
 if k not in ['version','date','neuromusculoskeletal_model','muscle_activation_inference_experiments']:assert b[k]==v,k
blob=(json.dumps(b,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
for p in [C,M]:tmp=p.with_name(p.name+'.gradient.tmp');tmp.write_bytes(blob);os.replace(tmp,p)
assert C.read_bytes()==M.read_bytes();out=dict(passed=True,version=b['version'],mirrors_identical=True,prior_biological_evidence_preserved=True,walking_validated=False,brain_sha256=sha(C));(R/'brain_integration.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
