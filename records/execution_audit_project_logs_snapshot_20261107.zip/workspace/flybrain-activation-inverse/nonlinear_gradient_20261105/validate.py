from pathlib import Path
import json,numpy as np,mujoco
from problem import Problem,R
p=Problem(seconds=.02);u=p.seed();c,d=p.evaluate([u,u],save=R/'validation_rollout.npz');assert c[0]==c[1]
z=np.load(R/'validation_rollout.npz');data=mujoco.MjData(p.m);mujoco.mj_setState(p.m,data,p.initial,mujoco.mjtState.mjSTATE_FULLPHYSICS);ctrl=z['all_control'];saved=[];amin=1.;amax=0.
for i in range(p.steps):
 data.ctrl[:]=ctrl[i];mujoco.mj_step(p.m,data);amin=min(amin,float(data.act[p.adrs].min()));amax=max(amax,float(data.act[p.adrs].max()))
 if i in set(p.sample):saved.append(data.qpos.copy())
err=float(np.max(np.abs(np.asarray(saved)-z['qpos'])));assert err<1e-10,err;assert 0<=amin<=amax<=1
assert np.max(np.abs(data.qfrc_applied))==0 and np.max(np.abs(data.xfrc_applied))==0
r=dict(passed=True,identical_rollout_losses=True,compiled_rollout_vs_python_mj_step_max_q_error=err,activation_min_all_physics_steps=amin,activation_max_all_physics_steps=amax,extra_force_or_torque_used=False,only_initial_state_set=True,explicit_native_activation_limits=True)
(R/'validation.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
