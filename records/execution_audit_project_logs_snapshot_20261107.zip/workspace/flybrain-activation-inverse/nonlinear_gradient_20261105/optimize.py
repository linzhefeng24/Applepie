import os
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import json,time,argparse
import numpy as np
from problem import Problem,R
parser=argparse.ArgumentParser();parser.add_argument('--iterations',type=int,default=24);parser.add_argument('--seconds',type=float,default=.2);parser.add_argument('--directions',type=int,default=8);args=parser.parse_args()
p=Problem(seconds=args.seconds);rng=np.random.default_rng(20261105);start=time.monotonic();seeds=np.array([p.seed('closed_loop'),p.seed('open_loop')]);c,ds=p.evaluate(seeds);which=int(np.argmin(c));u=seeds[which].copy();loss=float(c[which]);initial_loss=loss;initial_details=ds[which];p.evaluate(u,save=R/'initial_rollout.npz');initial_u=u.copy();m=np.zeros_like(u);v=np.zeros_like(u);history=[]
print('initial',json.dumps(dict(seed=['closed_loop','open_loop'][which],details=initial_details,seconds=args.seconds,parameters=u.size)),flush=True)
for it in range(args.iterations):
 eps=max(.008,.04*(.95**it));delta=rng.choice([-1.,1.],size=(args.directions,*u.shape));plus=np.clip(u+eps*delta,0,1);minus=np.clip(u-eps*delta,0,1);cs,_=p.evaluate(np.concatenate([plus,minus]));g=np.mean(((cs[:args.directions]-cs[args.directions:])/(2*eps))[:,None,None]*delta,axis=0)
 # Gradient of a randomly smoothed, box-projected rollout objective, not exact backprop.
 # Adam moment preconditioning; reject every step whose true nonlinear rollout loss rises.
 m=.8*m+.2*g;v=.95*v+.05*g*g;mh=m/(1-.8**(it+1));vh=v/(1-.95**(it+1));direction=mh/(np.sqrt(vh)+1e-8)
 steps=np.array([.08,.04,.02])*.98**it;candidates=np.clip(u[None]-steps[:,None,None]*direction[None],0,1);cc,dd=p.evaluate(candidates);j=int(np.argmin(cc));accepted=bool(cc[j]<loss-1e-8)
 if accepted:u=candidates[j].copy();loss=float(cc[j]);bestdetails=dd[j]
 else:bestdetails=p.evaluate(u)[1][0]
 row=dict(iteration=it+1,loss=loss,accepted=accepted,step_size=float(steps[j]) if accepted else 0.,finite_difference_epsilon=eps,gradient_norm=float(np.linalg.norm(g)),details=bestdetails,wall_s=time.monotonic()-start);history.append(row);print(json.dumps(row),flush=True)
 (R/'history.json').write_text(json.dumps(history,indent=2));np.savez_compressed(R/'checkpoint.npz',control_knots=u,initial_control_knots=initial_u)
final_c,final_d=p.evaluate(u,save=R/'optimized_rollout.npz');report=dict(method='projected Adam with antithetic finite-difference stochastic gradient estimates and nonlinear rollout step acceptance',not_exact_backpropagation=True,shooting='single shooting, one fixed initial state; no intermediate state resets',seconds=args.seconds,iterations=args.iterations,directions_per_gradient=args.directions,control_block_s=p.blocksteps*p.m.opt.timestep,control_parameters=u.size,seed=['closed_loop','open_loop'][which],initial_loss=initial_loss,final_loss=float(final_c[0]),initial=initial_details,final=final_d[0],accepted_steps=sum(x['accepted'] for x in history),wall_s=time.monotonic()-start,optimized_muscle_parameters=False,kinetics='default unchanged',retained_controls='all original 11 controls replayed identically in baseline and optimized runs',activation_bounds=[0,1],excitation_bounds=[0,1],walking_validated=False,limitations=['Only a short horizon was optimized, not a complete walking cycle.','Gradient is a stochastic finite-difference estimate of a smoothed projected objective, not exact differentiation of contact switches.','Contact and friction are simulated natively; no claim of hard zero ground penetration.','Optimizes blockwise excitation, not arbitrary independent controls at every physics sample.'])
(R/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
