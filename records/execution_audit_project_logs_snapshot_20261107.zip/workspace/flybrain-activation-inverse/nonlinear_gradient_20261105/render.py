import os
os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/tmp/gradient-mesa',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import numpy as np,mujoco,imageio
from PIL import Image,ImageDraw
from problem import R,BASE
m=mujoco.MjModel.from_xml_path(str(BASE/'bounded_refined_muscles.xml'));d=mujoco.MjData(m);renderer=mujoco.Renderer(m,height=240,width=320);opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
zs=[np.load(R/'initial_rollout.npz'),np.load(R/'optimized_rollout.npz')]
with imageio.get_writer(R/'gradient_comparison_02s.mp4',fps=10,codec='libx264',quality=8) as writer:
 for t in np.arange(.001,.2,.01):
  frames=[]
  for z,label in zip(zs,['Initial excitation','Gradient optimized']):
   j=int(np.argmin(abs(z['time_s']-t)));d.qpos[:]=z['qpos'][j];d.qvel[:]=z['qvel'][j];d.time=z['time_s'][j];mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=opt);im=Image.fromarray(renderer.render());draw=ImageDraw.Draw(im);draw.rectangle((0,0,320,36),fill='black');draw.text((4,3),label,fill='white');draw.text((4,18),f't={z["time_s"][j]:.3f}s | 0.1x | NOT walking proof',fill='white');frames.append(np.asarray(im))
  writer.append_data(np.concatenate(frames,axis=1))
renderer.close();print('Saved-state comparison rendered; no resimulation.')
