from pathlib import Path
import numpy as np,json,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from problem import Problem,R,BASE
p=Problem();u=np.load(R/'checkpoint.npz');c,d=p.evaluate(u['initial_control_knots'],save=R/'initial_rollout.npz');co,do=p.evaluate(u['control_knots'],save=R/'optimized_rollout.npz');report=json.loads((R/'report.json').read_text());assert abs(co[0]-report['final_loss'])<1e-9;assert abs(c[0]-report['initial_loss'])<1e-9
report['final_all_physics_activation_bounds']=[do[0]['activation_min'],do[0]['activation_max']]
assert 0<=do[0]['activation_min']<=do[0]['activation_max']<=1
report['joint_rmse_improvement_fraction']=1-do[0]['joint_rmse_deg']/d[0]['joint_rmse_deg'];report['loss_improvement_fraction']=1-co[0]/c[0];report['model_sha256']=hashlib.sha256((BASE/'bounded_refined_muscles.xml').read_bytes()).hexdigest();report['source_trajectory_sha256']=hashlib.sha256(Path('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz').read_bytes()).hexdigest()
# Out-of-horizon continuation: both runs replay the identical original seed after 0.2 s.
p2=Problem(seconds=.6);base=p2.seed();extension=base.copy();extension[:len(u['control_knots'])]=u['control_knots'];_,db=p2.evaluate(base,save=R/'continuation_baseline.npz');_,de=p2.evaluate(extension,save=R/'continuation_optimized_prefix.npz');report['continuation_06s']={'baseline':db[0],'optimized_prefix_then_identical_original_tail':de[0],'description':'Only first 0.2 s was optimized; subsequent excitation identical in both open-loop continuations. This is not an optimized 0.6 s controller.'}
(R/'report.json').write_text(json.dumps(report,indent=2))
a=np.load(R/'initial_rollout.npz');b=np.load(R/'optimized_rollout.npz');history=json.loads((R/'history.json').read_text());fig,axs=plt.subplots(2,1,figsize=(9,6),constrained_layout=True)
for z,label in [(a,'Initial blockwise excitation'),(b,'Gradient optimized')]:axs[0].plot(z['time_s'],np.sqrt(np.mean(z['qerror_rad']**2,axis=1))*180/np.pi,label=label)
axs[0].set(xlabel='Time (s)',ylabel='Joint RMSE (deg)');axs[0].legend();axs[1].plot([0]+[x['iteration'] for x in history],[report['initial_loss']]+[x['loss'] for x in history]);axs[1].set(xlabel='Gradient iteration',ylabel='Nonlinear rollout loss')
for ax in axs:ax.grid(alpha=.3)
fig.savefig(R/'comparison.png',dpi=150);plt.close(fig);print(json.dumps(report,indent=2))
