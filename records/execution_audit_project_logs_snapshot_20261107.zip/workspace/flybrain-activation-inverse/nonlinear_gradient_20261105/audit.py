import json,numpy as np,mujoco
from scipy.ndimage import median_filter
from problem import Problem,R
p=Problem(seconds=.6);m=p.m;d=mujoco.MjData(m);bid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];geo={}
for i in range(m.ngeom):
 name=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or ''
 if name.startswith('walker/') and any(x in name for x in ['tarsus','claw']):
  for j,t in enumerate(tokens):
   if t in name:geo[i]=j
results={};cf=np.zeros(6)
for case in ['initial_rollout','optimized_rollout','continuation_baseline','continuation_optimized_prefix']:
 z=np.load(R/(case+'.npz'));xyz=[];up=[];chest=[];support=[];penetration=[]
 for j,s in enumerate(z['full_state_1kHz']):
  mujoco.mj_setState(m,d,s,mujoco.mjtState.mjSTATE_FULLPHYSICS);d.ctrl[:]=z['all_control'][min(round(z['time_s'][j]/m.opt.timestep)-1,len(z['all_control'])-1)];mujoco.mj_forward(m,d);xyz.append(d.xpos[bid].copy()*10);up.append(float(d.xmat[bid].reshape(3,3)[2,2]));touch=False;normal=np.zeros(6);pen=0.
  for i in range(d.ncon):
   c=d.contact[i];g1,g2=int(c.geom1),int(c.geom2);other=g2 if m.geom_bodyid[g1]==0 else g1 if m.geom_bodyid[g2]==0 else None
   if other is None:continue
   pen=max(pen,-float(c.dist));touch=touch or m.geom_bodyid[other]==bid
   if other in geo and c.efc_address>=0:mujoco.mj_contactForce(m,d,i,cf);normal[geo[other]]+=max(0.,cf[0])
  chest.append(bool(touch));support.append(normal);penetration.append(pen)
 xyz=np.asarray(xyz);support=np.asarray(support);stance=median_filter(support>m.body_subtreemass[bid]*np.linalg.norm(m.opt.gravity)*.01,size=(5,1),mode='nearest')
 results[case]=dict(duration_s=float(z['time_s'][-1]),displacement_xyz_mm=(xyz[-1]-xyz[0]).tolist(),min_thorax_up_z=min(up),thorax_ground_contact_samples=sum(chest),support_fraction=float(np.mean(np.any(stance,axis=1))),per_leg_contact_transitions=dict(zip(['LF','RF','LM','RM','LH','RH'],np.sum(stance[1:]!=stance[:-1],axis=0).tolist())),max_sampled_ground_penetration_um=max(penetration)*1e4,joint_rmse_deg=float(np.sqrt(np.mean(z['qerror_rad']**2))*180/np.pi),normal_walking_validated=False)
 np.savez_compressed(R/(case+'_contact_audit.npz'),time_s=z['time_s'],thorax_mm=xyz,up_z=up,support_dyne=support,thorax_ground=chest)
(R/'contact_audit.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
