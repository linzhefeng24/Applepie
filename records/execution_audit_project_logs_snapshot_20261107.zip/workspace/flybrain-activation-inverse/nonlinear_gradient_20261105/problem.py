import os
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import json,time
import numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent
BASE=R.parent/'six_leg_model/closed_loop_contact_20261104'
class Problem:
 def __init__(self,seconds=.2,threads=4,block_s=.02):
  self.m=mujoco.MjModel.from_xml_path(str(BASE/'bounded_refined_muscles.xml'));m=self.m
  self.rows=json.load(open(R.parent/'six_leg_model/activation_refine_20261104/records.json'))['records'];self.ids=np.array([r['actuator_index'] for r in self.rows]);self.adrs=m.actuator_actadr[self.ids]
  self.src=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');self.dofs=self.src['joint_dof_indices'];self.qadrs=self.src['joint_qpos_indices'];self.steps=round(seconds/m.opt.timestep);self.sample=np.arange(9,self.steps,10);self.times=(self.sample+1)*m.opt.timestep;self.frames=np.minimum(np.rint(self.times/.0002).astype(int),len(self.src['time_s'])-1)
  self.blocksteps=round(block_s/m.opt.timestep);self.blocks=int(np.ceil(self.steps/self.blocksteps));self.blockids=np.minimum(np.arange(self.steps)//self.blocksteps,self.blocks-1)
  old=mujoco.MjModel.from_xml_path('/workspace/fly-walking-run/output/model/walking.xml');self.retained=[]
  for i in range(old.nu):
   j=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_ACTUATOR,mujoco.mj_id2name(old,mujoco.mjtObj.mjOBJ_ACTUATOR,i))
   if j>=0:self.retained.append((i,j))
  assert len(self.retained)==11
  d=mujoco.MjData(m);d.qpos[:]=self.src['qpos'][0];d.qvel[:]=self.src['qvel'][0];d.act[self.adrs]=np.load(R.parent/'six_leg_model/activation_refine_20261104/activation_6s_5000Hz.npz')['activation'][0]
  for i,j in self.retained:
   d.ctrl[j]=self.src['ctrl'][0,i]
   if m.actuator_actadr[j]>=0 and old.actuator_actadr[i]>=0:d.act[m.actuator_actadr[j]]=self.src['act'][0,old.actuator_actadr[i]]
  mujoco.mj_forward(m,d);self.initial=np.empty(mujoco.mj_stateSize(m,mujoco.mjtState.mjSTATE_FULLPHYSICS));mujoco.mj_getState(m,d,self.initial,mujoco.mjtState.mjSTATE_FULLPHYSICS)
  self.data=[mujoco.MjData(m) for _ in range(threads)];self.probe=mujoco.MjData(m);self.moment=np.empty((m.nu,m.nv));self.ctrl=np.zeros((self.steps,m.nu));f=np.minimum(np.arange(self.steps)//2,len(self.src['time_s'])-1)
  for i,j in self.retained:self.ctrl[:,j]=self.src['ctrl'][f,i]
  self.refq=self.src['qpos'][self.frames];self.refv=self.src['qvel'][self.frames];self.reftau=self.src['leg_tau_drive_Nm'][self.frames];self.tauscale=max(np.sqrt(np.mean(self.reftau**2)),1e-12)
  self.rootq=int(m.jnt_qposadr[mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,'walker/')]);self.qscale=np.maximum(np.std(self.src['qpos'][:,self.qadrs],axis=0),.2)
 def seed(self,kind='closed_loop'):
  if kind=='closed_loop':z=np.load(BASE/'bounded_default/rollout.npz');u=z['excitation'];step=np.minimum(np.arange(self.steps)//20,len(u)-1);full=u[step]
  else:full=np.load(R.parent/'six_leg_model/activation_refine_20261104/excitation_default.npz')['excitation'][:self.steps]
  return np.array([np.mean(full[self.blockids==j],axis=0) for j in range(self.blocks)])
 def evaluate(self,U,save=None):
  U=np.asarray(U);U=U[None] if U.ndim==2 else U;assert np.all((U>=0)&(U<=1))
  ctrl=np.broadcast_to(self.ctrl,(len(U),*self.ctrl.shape)).copy();ctrl[:,:,self.ids]=U[:,self.blockids,:]
  states,_=rollout.rollout(self.m,self.data,self.initial[None],ctrl,persistent_pool=True)
  costs=[];details=[]
  for k in range(len(U)):
   s=states[k,self.sample];q=s[:,1:1+self.m.nq];v=s[:,1+self.m.nq:1+self.m.nq+self.m.nv];a=s[:,1+self.m.nq+self.m.nv:][:,self.adrs]
   e=q[:,self.qadrs]-self.refq[:,self.qadrs];qcost=float(np.mean((e/self.qscale)**2));vcost=float(np.mean(((v[:,self.dofs]-self.refv[:,self.dofs])/100)**2))
   r=self.rootq;pos=(q[:,r:r+3]-self.refq[:,r:r+3]);body=float(np.mean((pos/np.array([.05,.05,.03]))**2));dot=np.clip(np.abs(np.sum(q[:,r+3:r+7]*self.refq[:,r+3:r+7],axis=1)),0,1);rot=float(np.mean((2*np.arccos(dot)/.3)**2))
   tau=[];up=[];pen=[];groundforce=[]
   # Native force at 100 Hz samples; full nonlinear rollouts retain 10 kHz contacts.
   for j in range(0,len(self.sample),10):
    d=self.probe;mujoco.mj_setState(self.m,d,s[j],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.ctrl[:]=ctrl[k,self.sample[j]];mujoco.mj_forward(self.m,d)
    mujoco.mju_sparse2dense(self.moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);tau.append((self.moment[self.ids].T@d.actuator_force[self.ids])[self.dofs]*1e-7)
    bid=mujoco.mj_name2id(self.m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');up.append(float(d.xmat[bid].reshape(3,3)[2,2]));pen.append(max([max(0.,-float(d.contact[c].dist)) for c in range(d.ncon) if self.m.geom_bodyid[d.contact[c].geom1]==0 or self.m.geom_bodyid[d.contact[c].geom2]==0],default=0.))
   taucost=float(np.mean(((np.asarray(tau)-self.reftau[::10])/self.tauscale)**2));effort=float(np.mean(U[k]**2));smooth=float(np.mean(np.diff(U[k],axis=0)**2)) if self.blocks>1 else 0.
   cost=qcost+.02*vcost+.5*body+.5*rot+.002*taucost+.001*effort+.002*smooth
   if not np.isfinite(states[k]).all() or not np.allclose(states[k,:,0],np.arange(1,self.steps+1)*self.m.opt.timestep,atol=1e-7):cost=1e8
   details.append(dict(loss=cost,qcost=qcost,velocity_cost=vcost,body_position_cost=body,body_orientation_cost=rot,torque_cost=taucost,joint_rmse_deg=float(np.sqrt(np.mean(e*e))*180/np.pi),minimum_sampled_up_z=min(up),maximum_sampled_penetration_um=max(pen)*1e4,activation_min=float(states[k,:,1+self.m.nq+self.m.nv:][:,self.adrs].min()),activation_max=float(states[k,:,1+self.m.nq+self.m.nv:][:,self.adrs].max())));costs.append(cost)
  if save:
   np.savez_compressed(save,time_s=self.times,full_state_1kHz=s,qpos=q,qvel=v,activation=a,excitation=ctrl[-1,self.sample][:,self.ids],control_knots=U[-1],all_control=ctrl[-1],initial_state=self.initial,muscle_ids=np.array([r['id'] for r in self.rows]),joint_names=self.src['joint_names'],qerror_rad=e)
   h=np.arange(1,self.steps,2);off=1+self.m.nq+self.m.nv
   np.savez_compressed(str(save).replace('.npz','_5000Hz.npz'),time_s=(h+1)*self.m.opt.timestep,activation=states[-1,h,off:][:,self.adrs],excitation=ctrl[-1,h][:,self.ids],joint_angle_rad=states[-1,h,1:1+self.m.nq][:,self.qadrs],muscle_ids=np.array([r['id'] for r in self.rows]),joint_names=self.src['joint_names'])
  return np.array(costs),details
