import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/mpl-coupled-terminal')
from pathlib import Path
import sys,json,numpy as np,mujoco,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;R=ROOT/'uniform_refined';sys.path.insert(0,str(ROOT.parent/'terminal_priority_20261105'));from problem import JointTrajectory,BASE
p=JointTrajectory();z={k:v for k,v in np.load(R/'optimized_rollout.npz').items()};checkpoint=np.load(R/'checkpoint.npz');expected=np.clip(checkpoint['base_control_knots']+checkpoint['uniform_amplitude'][None],0,1);uniform_error=float(np.max(abs(expected-z['control_knots'])));assert uniform_error<1e-12
m=p.m;d=mujoco.MjData(m);mujoco.mj_setState(m,d,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.ctrl[:]=z['initial_ctrl'];mujoco.mj_forward(m,d);err=0.;amin=1.;amax=0.
for j,ctrl in enumerate(z['all_control_10000Hz']):
 d.ctrl[:]=ctrl;mujoco.mj_step(m,d);amin=min(amin,float(d.act[p.adrs].min()));amax=max(amax,float(d.act[p.adrs].max()))
 if j%2==1:
  state=np.empty(len(p.initial));mujoco.mj_getState(m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);err=max(err,float(np.max(abs(state-z['full_state'][j//2]))))
assert err<1e-9 and 0<=amin<=amax<=1 and not np.any(d.qfrc_applied) and not np.any(d.xfrc_applied)
report=json.loads((R/'report.json').read_text());angleerr=z['joint_angle_rad'][-1]-z['target_joint_angle'][-1];names=p.reference['joint_names'].tolist();summary=dict(initial=report['initial'],final=report['final'],max_terminal_error_deg=float(np.max(abs(angleerr))*180/np.pi),all_errors_zero=report['all_joint_terminal_errors_below_tolerance'],joints_below_1deg=int(np.sum(abs(angleerr)*180/np.pi<1)),worst_joints=[dict(joint=names[i],error_deg=float(angleerr[i]*180/np.pi)) for i in np.argsort(-abs(angleerr))[:10]],height_penalty=0,walking_validated=False)
validation=dict(passed=True,all_times_uniform_offsets_verified=True,uniform_control_reconstruction_error=uniform_error,actual_full_state_replay_max_error=err,activation_min_all_physics_steps=amin,activation_max_all_physics_steps=amax,height_penalty=0,extra_forces=False,model_sha256=hashlib.sha256((BASE/'bounded_refined_muscles.xml').read_bytes()).hexdigest());(R/'summary.json').write_text(json.dumps(summary,indent=2));(R/'validation.json').write_text(json.dumps(validation,indent=2))
initial={k:v for k,v in np.load(ROOT/'initial_rollout.npz').items()};best={k:v for k,v in np.load(ROOT/'best_rollout.npz').items()};fig,axs=plt.subplots(2,1,figsize=(9,7),constrained_layout=True)
for a,label in [(initial,'Initial'),(best,'Uniform sequential best'),(z,'Coupled uniform amplitudes')]:
 e=a['joint_angle_rad']-a['target_joint_angle'];axs[0].plot(a['time_s'],np.sqrt(np.mean(e*e,axis=1))*180/np.pi,label=label)
i=names.index('walker/tarsus_T2_right');axs[1].plot(z['time_s'],z['target_joint_angle'][:,i]*180/np.pi,label='Reference',color='black',ls='--')
for a,label in [(initial,'Initial'),(best,'Uniform sequential best'),(z,'Coupled uniform amplitudes')]:axs[1].plot(a['time_s'],a['joint_angle_rad'][:,i]*180/np.pi,label=label)
axs[0].set(ylabel='Joint RMSE (deg)');axs[1].set(xlabel='Time (s)',ylabel='Right middle tarsus (deg)')
for ax in axs:ax.legend();ax.grid(alpha=.3)
fig.savefig(R/'comparison.png',dpi=150);plt.close(fig);print(json.dumps({'summary':summary,'validation':validation},indent=2))
