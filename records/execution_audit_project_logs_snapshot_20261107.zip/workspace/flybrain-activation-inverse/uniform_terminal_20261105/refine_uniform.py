import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,numpy as np
from scipy.optimize import lsq_linear
ROOT=Path(__file__).resolve().parent;R=ROOT/'uniform_refined';R.mkdir(exist_ok=True);sys.path.insert(0,str(ROOT.parent/'terminal_priority_20261105'));from problem import JointTrajectory
p=JointTrajectory();old=np.load(ROOT/'coupled_uniform/checkpoint.npz');base=old['base_control_knots'].copy();amp=old['uniform_amplitude'].copy();lower=-base.max(axis=0);upper=1-base.min(axis=0);clock=time.monotonic();history=[];trust=.05;Jplus=None;Jminus=None;rejects=0;since_refresh=0
_,di=p.evaluate(np.clip(base+amp[None],0,1),save=R/'initial_rollout.npz');initial=di[0]
for it in range(24):
 U=np.clip(base+amp[None],0,1);cost,dd=p.evaluate(U);r=p.terminal_errors[0].copy()
 if max(abs(r))<.001*np.pi/180:break
 fresh=Jplus is None or since_refresh>=4 or rejects>=2
 if fresh:
  hp=np.minimum(.002,upper-amp);hm=-np.minimum(.002,amp-lower);ii_p=np.flatnonzero(hp>1e-10);ii_m=np.flatnonzero(hm<-1e-10);probes=[]
  for i in ii_p:
   a=amp.copy();a[i]+=hp[i];probes.append(np.clip(base+a[None],0,1))
  for i in ii_m:
   a=amp.copy();a[i]+=hm[i];probes.append(np.clip(base+a[None],0,1))
  pc,_=p.evaluate(np.asarray(probes));rp=p.terminal_errors.copy();Jplus=np.zeros((66,130));Jminus=np.zeros_like(Jplus)
  for j,i in enumerate(ii_p):Jplus[:,i]=(rp[j]-r)/hp[i]
  for j,i in enumerate(ii_m):Jminus[:,i]=(rp[len(ii_p)+j]-r)/hm[i]
  since_refresh=0
 gp=Jplus.T@r;gm=Jminus.T@r;canp=(upper-amp)>1e-9;canm=(amp-lower)>1e-9;plus_gain=np.where(canp,-gp,-np.inf);minus_gain=np.where(canm,gm,-np.inf);positive=plus_gain>=minus_gain;gain=np.maximum(plus_gain,minus_gain);active=np.flatnonzero(gain>1e-10)
 if len(active)==0:
  history.append(dict(iteration=it+1,status='no descending coordinate direction detected at current finite difference scale',wall_s=time.monotonic()-clock));break
 J=np.where(positive[None],Jplus,Jminus);AA=J[:,active];ridge=max(np.linalg.norm(AA,'fro')/np.sqrt(len(active))*.01,1e-7);A=np.vstack([AA,ridge*np.eye(len(active))]);b=np.r_[-r,np.zeros(len(active))];lo=np.where(positive[active],0.,np.maximum(lower[active]-amp[active],-trust));hi=np.where(positive[active],np.minimum(upper[active]-amp[active],trust),0.);fit=lsq_linear(A,b,bounds=(lo,hi),method='bvls',tol=1e-8,max_iter=300);delta=np.zeros(130);delta[active]=fit.x;scales=np.array([1.,.5,.25,.125,.0625]);newamps=np.clip(amp[None]+scales[:,None]*delta,lower,upper);candidates=np.clip(base[None]+newamps[:,None,:],0,1);cc,details=p.evaluate(candidates);rr=p.terminal_errors.copy();j=int(np.lexsort((cc[:,1],cc[:,0]))[0]);accepted=bool(cc[j,0]<cost[0,0]-1e-12)
 if accepted:
  actualdelta=newamps[j]-amp;dr=rr[j]-r;resid=dr-J@actualdelta;denom=float(actualdelta@actualdelta)
  if denom>1e-20:
   update=np.outer(resid,actualdelta)/denom;Jplus+=update;Jminus+=update
  amp=newamps[j].copy();out=details[j];rejects=0;since_refresh+=1;trust=min(.1,trust*1.2) if scales[j]>=.5 else max(.003,trust*.6)
 else:out=dd[0];rejects+=1;trust=max(.001,trust*.5);since_refresh=4
 h=dict(iteration=it+1,accepted=accepted,full_directional_jacobian_refreshed=fresh,terminal_rmse_deg=out['terminal_rmse_deg'],path_rmse_deg=out['path_rmse_deg'],active_muscle_directions=len(active),step_size=float(scales[j]) if accepted else 0.,trust_radius=trust,wall_s=time.monotonic()-clock);history.append(h);(R/'history.json').write_text(json.dumps(history,indent=2));np.savez_compressed(R/'checkpoint.npz',base_control_knots=base,uniform_amplitude=amp);p.evaluate(np.clip(base+amp[None],0,1),save=R/'checkpoint_rollout.npz');print(json.dumps(h),flush=True)
 if rejects>=3:break
_,df=p.evaluate(np.clip(base+amp[None],0,1),save=R/'optimized_rollout.npz');error=p.terminal_errors[0];report=dict(method='whole-trajectory per-muscle uniform offsets; separate feasible increase/decrease derivatives, bounded joint residual solve, exact rollout acceptance and secant updates',initial=initial,final=df[0],maximum_terminal_error_deg=float(np.max(abs(error))*180/np.pi),all_joint_terminal_errors_below_tolerance=bool(np.max(abs(error))<.001*np.pi/180),tolerance_deg=.001,iterations=len(history),height_penalty=0,orientation_penalty=0,velocity_penalty=0,torque_penalty=0,all_times_same_requested_offset_per_muscle=True,muscle_parameters_changed=False,extra_forces=False,intermediate_state_resets=False,walking_validated=False,wall_s=time.monotonic()-clock,stopping_reason='tolerance reached' if max(abs(error))<.001*np.pi/180 else ('no accepted descent in consecutive local attempts' if rejects>=3 else 'finite refinement budget; not a global impossibility proof'))
(R/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
