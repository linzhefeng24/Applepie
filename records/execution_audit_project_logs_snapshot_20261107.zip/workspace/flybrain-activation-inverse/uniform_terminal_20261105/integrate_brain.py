from pathlib import Path
import json,copy,hashlib,os
R=Path(__file__).resolve().parent;C=Path('/workspace/flybrain-muscle-rebuild/brain.json');M=Path('/workspace/flybrain-recovered/brain.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads(C.read_text());assert b==json.loads(M.read_text());before=copy.deepcopy(b)
backup=R/'brain_before_uniform_terminal.json'
if not backup.exists():backup.write_bytes(C.read_bytes())
summary=json.loads((R/'summary.json').read_text());validation=json.loads((R/'validation.json').read_text());assert validation['passed'];report=json.loads((R/'report.json').read_text());pilot=R.parent/'terminal_priority_20261105';assets=[]
for root in [R,pilot]:
 for p in sorted(root.iterdir()):
  if p.is_file() and p.suffix in ['.py','.json','.npz','.png','.md'] and p.name not in ['brain_before_uniform_terminal.json','brain_integration.json']:assets.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
run=dict(id='six_leg_joint_terminal_uniform_correction_20261105',date='2026-11-05',previous_experiment_id='six_leg_angle_only_tracking_audit_20261105',role='whole-trajectory terminal-priority pilot followed by explicitly requested uniform flexor/extensor command offsets across all time blocks',terminal_priority_pilot=json.loads((pilot/'report.json').read_text()),uniform_correction_report=report,summary=summary,validation=validation,history=json.loads((R/'history.json').read_text()),superseded_trial={'directory':str(R.parent/'proportional_terminal_20261105'),'status':'interrupted when user requested uniform all-time shifts; not treated as a completed result'},method_document={'format':'markdown','text':(R/'README.md').read_text()},artifacts=assets,muscle_parameters_changed=False,all_joint_terminal_errors_zero=summary['all_joint_terminal_errors_zero'],walking_validated=False)
runs=b['muscle_activation_inference_experiments']['runs'];runs[:]=[x for x in runs if x['id']!=run['id']];runs.append(run)
n=b['neuromusculoskeletal_model'];n['current_readiness']['latest_whole_trajectory_terminal_experiment_id']=run['id'];n['current_readiness']['latest_terminal_correction_converged_to_zero']=False;n['current_muscle_model_overview']['joint_terminal_correction_policy']={'experiment_id':run['id'],'requested_rule':'same signed command offset at every time block: increase desired-direction group, decrease opposing group; replay and repeat','height_penalty':0,'actual_activation_simulated_not_overwritten':True,'command_bounds':[0,1],'best_terminal_RMSE_deg':summary['best_observed']['terminal_rmse_deg'],'all_errors_zero':summary['all_joint_terminal_errors_zero'],'note':'Individual zero crossings are not simultaneous all-joint convergence; shared muscles/contact and command saturation were recorded.'}
b['version']='3.4.8-whole-trajectory-uniform-terminal-correction';b['date']='2026-11-05'
for k,v in before.items():
 if k not in ['version','date','neuromusculoskeletal_model','muscle_activation_inference_experiments']:assert b[k]==v,k
blob=(json.dumps(b,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
for p in [C,M]:tmp=p.with_name(p.name+'.terminal.tmp');tmp.write_bytes(blob);os.replace(tmp,p)
assert C.read_bytes()==M.read_bytes();out=dict(passed=True,version=b['version'],mirrors_identical=True,prior_biological_evidence_preserved=True,height_penalty=0,all_joint_terminal_errors_zero=False,brain_sha256=sha(C));(R/'brain_integration.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
