import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/mpl-uniform-terminal')
from pathlib import Path
import sys,json,numpy as np,mujoco,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'terminal_priority_20261105'));from problem import JointTrajectory,BASE
p=JointTrajectory();history=json.loads((R/'history.json').read_text());initial=np.load(R/'initial_rollout.npz')['control_knots'].copy();u=initial.copy();ids=[row['id'] for row in p.rows];snapshots=[initial.copy()];best=initial.copy();bestscore=json.loads((R/'report.json').read_text())['initial']['terminal_rmse_deg'];bestit=0;coupling_controls=[];event_indices=[]
for h in history:
 if h.get('accepted'):
  direction=np.zeros(130)
  for name in h['increased_muscles']:direction[ids.index(name)]=1
  for name in h['decreased_muscles']:direction[ids.index(name)]=-1
  u=np.clip(u+h['uniform_offset']*direction[None],0,1)
  if h['terminal_rmse_deg']<bestscore:bestscore=h['terminal_rmse_deg'];best=u.copy();bestit=h['iteration']
 if h['iteration'] in [1,2,3]:coupling_controls.append(u.copy());event_indices.append(h['iteration'])
check=np.load(R/'checkpoint.npz')['control_knots'];assert np.max(abs(u-check))<1e-12
_,di=p.evaluate(initial);_,db=p.evaluate(best,save=R/'best_rollout.npz');_,dl=p.evaluate(u);assert abs(dl[0]['terminal_rmse_deg']-json.loads((R/'report.json').read_text())['final']['terminal_rmse_deg'])<1e-9
coupling=[]
if coupling_controls:
 p.evaluate(np.array(coupling_controls));legnames=p.reference['joint_names'].tolist();a=legnames.index('walker/tarsus_T3_right');b=legnames.index('walker/tibia_T3_right')
 coupling=[dict(iteration=i,right_hind_tarsus_error_deg=float(e[a]*180/np.pi),right_hind_tibia_error_deg=float(e[b]*180/np.pi)) for i,e in zip(event_indices,p.terminal_errors)]
z={k:v for k,v in np.load(R/'best_rollout.npz').items()};d=mujoco.MjData(p.m);mujoco.mj_setState(p.m,d,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.ctrl[:]=z['initial_ctrl'];mujoco.mj_forward(p.m,d);err=0.;amin=1.;amax=0.
for j,ctrl in enumerate(z['all_control_10000Hz']):
 d.ctrl[:]=ctrl;mujoco.mj_step(p.m,d);amin=min(amin,float(d.act[p.adrs].min()));amax=max(amax,float(d.act[p.adrs].max()))
 if j%2==1:
  state=np.empty(len(p.initial));mujoco.mj_getState(p.m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);err=max(err,float(np.max(abs(state-z['full_state'][j//2]))))
assert err<1e-9 and 0<=amin<=amax<=1;assert not np.any(d.qfrc_applied) and not np.any(d.xfrc_applied)
# Quantify saturation of the group repeatedly unable to improve the right middle tarsus.
fail=next((h for h in reversed(history) if h.get('target_joint')=='walker/tarsus_T2_right' and not h.get('accepted') and 'increased_muscles' in h),None);saturation={}
if fail:
 inc=[ids.index(n) for n in fail['increased_muscles']];dec=[ids.index(n) for n in fail['decreased_muscles']];saturation=dict(increase_group_at_one_fraction=float(np.mean(u[:,inc]>.999999)),decrease_group_at_zero_fraction=float(np.mean(u[:,dec]<.000001)))
initial_z={k:v for k,v in np.load(R/'initial_rollout.npz').items()};target=initial_z['target_joint_angle'];ea=initial_z['joint_angle_rad']-target;eb=z['joint_angle_rad']-z['target_joint_angle'];end=eb[-1];names=p.reference['joint_names'].tolist();summary=dict(initial=di[0],best_observed=db[0],best_iteration=bestit,final_iterative=dl[0],all_joint_terminal_errors_zero=bool(np.max(abs(end))*180/np.pi<=.001),best_maximum_terminal_error_deg=float(np.max(abs(end))*180/np.pi),joints_below_1deg=int(np.sum(abs(end)*180/np.pi<1)),joints_below_01deg=int(np.sum(abs(end)*180/np.pi<.1)),total_joints=len(end),target_zero_events=sum(h.get('root_found',False) for h in history),distinct_zeroed_joints=len({h['target_joint'] for h in history if h.get('root_found',False)}),right_middle_tarsus_uniform_direction_saturation=saturation,coupling_example=coupling,worst_best_endpoint_joints=[dict(joint=names[i],error_deg=float(end[i]*180/np.pi)) for i in np.argsort(-abs(end))[:10]],height_penalty=0,walking_validated=False)
(R/'summary.json').write_text(json.dumps(summary,indent=2));validation=dict(passed=True,uniform_updates_reconstructed_from_history=True,final_control_reconstruction_max_error=float(np.max(abs(u-check))),best_control_python_replay_full_state_max_error=err,activation_min_all_physics_steps=amin,activation_max_all_physics_steps=amax,extra_forces=False,height_penalty=0,model_sha256=hashlib.sha256((BASE/'bounded_refined_muscles.xml').read_bytes()).hexdigest());(R/'validation.json').write_text(json.dumps(validation,indent=2))
fig,axs=plt.subplots(2,1,figsize=(9,7),constrained_layout=True);hs=[h for h in history if 'terminal_rmse_deg' in h];v=np.array([di[0]['terminal_rmse_deg']]+[h['terminal_rmse_deg'] for h in hs]);axs[0].plot(np.arange(len(v)),v,label='Current sequential state');axs[0].plot(np.arange(len(v)),np.minimum.accumulate(v),label='Best observed');axs[0].set(xlabel='Joint correction',ylabel='Terminal joint RMSE (deg)');axs[0].legend()
for e,label in [(ea,'Initial'),(eb,'Best observed')]:axs[1].plot(z['time_s'],np.sqrt(np.mean(e**2,axis=1))*180/np.pi,label=label)
axs[1].set(xlabel='Time (s)',ylabel='Joint RMSE (deg)');axs[1].legend()
for ax in axs:ax.grid(alpha=.3)
fig.savefig(R/'comparison.png',dpi=150);plt.close(fig);print(json.dumps({'summary':summary,'validation':validation},indent=2))
