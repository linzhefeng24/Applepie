import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,numpy as np
from scipy.optimize import lsq_linear
ROOT=Path(__file__).resolve().parent;R=ROOT/'coupled_uniform';R.mkdir(exist_ok=True);sys.path.insert(0,str(ROOT.parent/'terminal_priority_20261105'));from problem import JointTrajectory
p=JointTrajectory();base=np.load(ROOT/'best_rollout.npz')['control_knots'];amp=np.zeros(130);lower=-np.max(base,axis=0);upper=1-np.min(base,axis=0);clock=time.monotonic();history=[];trust=.25;rejects=0
_,init=p.evaluate(base,save=R/'initial_rollout.npz');initial=init[0]
for it in range(8):
 U=np.clip(base+amp[None],0,1);cost,details=p.evaluate(U);r=p.terminal_errors[0].copy()
 if np.max(abs(r))<.001*np.pi/180:break
 hp=np.minimum(.02,upper-amp);hm=-np.minimum(.02,amp-lower);plus=np.clip(base[None]+amp[None,None,:]+np.eye(130)[:,None,:]*hp[:,None,None],0,1);minus=np.clip(base[None]+amp[None,None,:]+np.eye(130)[:,None,:]*hm[:,None,None],0,1);np_=np.sum(abs(plus-U[None]),axis=(1,2));nm=np.sum(abs(minus-U[None]),axis=(1,2));positive=np_>=nm;h=np.where(positive,hp,hm);probes=np.where(positive[:,None,None],plus,minus);_,_=p.evaluate(probes);rp=p.terminal_errors.copy();J=np.zeros((66,130));valid=abs(h)>1e-12;J[:,valid]=((rp[valid]-r)/h[valid,None]).T
 ridge=max(np.linalg.norm(J,'fro')/np.sqrt(130)*.005,1e-8);A=np.vstack([J,ridge*np.eye(130)]);b=np.r_[-r,np.zeros(130)];lo=np.maximum(lower-amp,-trust);hi=np.minimum(upper-amp,trust);fit=lsq_linear(A,b,bounds=(lo,hi),method='bvls',tol=1e-8,max_iter=300);delta=fit.x;scales=np.array([1.,.5,.25,.125,.0625,2.]);newamps=np.clip(amp[None]+scales[:,None]*delta,lower,upper);candidates=np.clip(base[None]+newamps[:,None,:],0,1);cc,dd=p.evaluate(candidates);j=int(np.lexsort((cc[:,1],cc[:,0]))[0]);accepted=bool(cc[j,0]<cost[0,0]-1e-12)
 if accepted:amp=newamps[j].copy();rejects=0;trust=min(.5,trust*1.25);out=dd[j]
 else:rejects+=1;trust*=.5;out=details[0]
 row=dict(iteration=it+1,accepted=accepted,terminal_rmse_deg=out['terminal_rmse_deg'],path_rmse_deg=out['path_rmse_deg'],Jacobian_rank=int(np.linalg.matrix_rank(J,tol=max(np.linalg.norm(J,2)*1e-6,1e-10))),least_squares_success=bool(fit.success),trust_radius=trust,step_size=float(scales[j]) if accepted else 0.,wall_s=time.monotonic()-clock);history.append(row);np.savez_compressed(R/'checkpoint.npz',uniform_amplitude=amp,base_control_knots=base);p.evaluate(np.clip(base+amp[None],0,1),save=R/'checkpoint_rollout.npz');(R/'history.json').write_text(json.dumps(history,indent=2));print(json.dumps(row),flush=True)
 if rejects>=3:break
_,final=p.evaluate(np.clip(base+amp[None],0,1),save=R/'optimized_rollout.npz');error=p.terminal_errors[0];report=dict(method='coupled terminal-angle least squares with one uniform whole-trajectory offset per muscle, nonlinear line search',initial=initial,final=final[0],uniform_offsets=amp.tolist(),maximum_terminal_error_deg=float(np.max(abs(error))*180/np.pi),all_joint_errors_below_tolerance=bool(np.max(abs(error))<.001*np.pi/180),tolerance_deg=.001,height_penalty=0,orientation_penalty=0,all_times_same_requested_offset_per_muscle=True,muscle_parameters_changed=False,extra_forces=False,walking_validated=False,iterations=len(history),wall_s=time.monotonic()-clock,limit='Finite local joint optimization, not a proof of full-space reachability or global optimality.')
(R/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
