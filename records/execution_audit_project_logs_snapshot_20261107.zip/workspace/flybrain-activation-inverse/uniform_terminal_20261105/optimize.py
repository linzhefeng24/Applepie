import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,numpy as np,mujoco
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'terminal_priority_20261105'));from problem import JointTrajectory
p=JointTrajectory();m=p.m;clock=time.monotonic();names=p.reference['joint_names'].tolist();blocked=set();tol=.001*np.pi/180;moment=np.zeros((m.nu,m.nv));d=mujoco.MjData(m)
if (R/'history.json').exists() and (R/'checkpoint.npz').exists():
 u=np.load(R/'checkpoint.npz')['control_knots'].copy();history=json.loads((R/'history.json').read_text());seed=np.load(R/'initial_rollout.npz')['control_knots'];_,dd=p.evaluate(seed);initial=dd[0]
 for row in reversed(history):
  if row.get('accepted'):break
  blocked.add(names.index(row['target_joint']))
else:
 u=np.load(R.parent/'terminal_priority_20261105/optimized_rollout.npz')['control_knots'].copy();c,dd=p.evaluate(u,save=R/'initial_rollout.npz');initial=dd[0];history=[]
stopping_reason='iteration budget reached';best_seen=min([initial['terminal_rmse_deg']]+[h.get('terminal_rmse_deg',1e6) for h in history])
# Fixed groups defined by signed active torque at the reference endpoint pose.
# A positive offset drives the desired angle direction at that reference pose.
d.qpos[:]=p.reference['qpos'][1000];d.qvel[:]=0.;d.act[p.adrs]=.5;mujoco.mj_forward(m,d);mujoco.mju_sparse2dense(moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);gain=np.array([mujoco.mju_muscleGain(d.actuator_length[i],d.actuator_velocity[i],m.actuator_lengthrange[i],m.actuator_acc0[i],m.actuator_gainprm[i,:9]) for i in p.ids]);B=(moment[p.ids].T*gain[None])[p.dofs]
for it in range(len(history),60):
 cost,details=p.evaluate(u);e=p.terminal_errors[0].copy();order=np.argsort(-abs(e));options=[int(i) for i in order if int(i) not in blocked and abs(e[i])>tol]
 if not options:stopping_reason='no remaining joint can improve under tested uniform direction rule';break
 j=options[0];coeff=B[j];active=abs(coeff)>1e-12
 if not active.any():blocked.add(j);history.append(dict(iteration=it+1,target_joint=names[j],status='no_direct_active_muscle_in_reference_mapping',error_deg=float(e[j]*180/np.pi)));continue
 direction=-np.sign(e[j])*np.sign(coeff);direction[~active]=0.;base=u.copy();offsets=np.array([.001,.002,.005,.01,.02,.04,.08,.16,.32,.64,1.]);candidates=np.clip(base[None]+offsets[:,None,None]*direction[None,None,:],0,1);cc,cd=p.evaluate(candidates);errors=p.terminal_errors[:,j].copy();trace=[dict(offset=0.,error_deg=float(e[j]*180/np.pi),terminal_rmse_deg=details[0]['terminal_rmse_deg'],path_rmse_deg=details[0]['path_rmse_deg'])]+[dict(offset=float(s),error_deg=float(er*180/np.pi),terminal_rmse_deg=di['terminal_rmse_deg'],path_rmse_deg=di['path_rmse_deg']) for s,er,di in zip(offsets,errors,cd)]
 previous_s=0.;previous_e=e[j];bracket=None
 for s,er in zip(offsets,errors):
  if previous_e*er<=0:bracket=[previous_s,float(s),float(previous_e),float(er)];break
  previous_s=float(s);previous_e=float(er)
 best_index=int(np.argmin(abs(errors)));best_s=float(offsets[best_index]);best_error=float(errors[best_index]);bestU=candidates[best_index].copy();bestdetails=cd[best_index];root_found=False
 if bracket is not None:
  lo,hi,elo,ehi=bracket
  for k in range(18):
   mid=.5*(lo+hi);test=np.clip(base+mid*direction[None],0,1);tc,td=p.evaluate(test);er=float(p.terminal_errors[0,j]);trace.append(dict(offset=mid,error_deg=float(er*180/np.pi),terminal_rmse_deg=td[0]['terminal_rmse_deg'],path_rmse_deg=td[0]['path_rmse_deg']))
   if abs(er)<abs(best_error):best_s=mid;best_error=er;bestU=test.copy();bestdetails=td[0]
   if abs(er)<=tol:root_found=True;break
   if elo*er<=0:hi=mid;ehi=er
   else:lo=mid;elo=er
 accepted=bool(abs(best_error)<abs(e[j])-1e-10)
 if accepted:u=bestU;blocked.clear()
 else:blocked.add(j)
 row=dict(iteration=it+1,target_joint=names[j],before_error_deg=float(e[j]*180/np.pi),after_error_deg=float(best_error*180/np.pi) if accepted else float(e[j]*180/np.pi),accepted=accepted,uniform_offset=float(best_s) if accepted else 0.,root_found=root_found,all_times_same_requested_shift=True,increased_muscles=[p.rows[i]['id'] for i in np.flatnonzero(direction>0)],decreased_muscles=[p.rows[i]['id'] for i in np.flatnonzero(direction<0)],terminal_rmse_deg=bestdetails['terminal_rmse_deg'] if accepted else details[0]['terminal_rmse_deg'],path_rmse_deg=bestdetails['path_rmse_deg'] if accepted else details[0]['path_rmse_deg'],full_direction_saturation_tested=True,trace=trace,wall_s=time.monotonic()-clock)
 history.append(row)
 if row['terminal_rmse_deg']<best_seen:best_seen=row['terminal_rmse_deg'];np.savez_compressed(R/'best_control_knots.npz',control_knots=u)
 (R/'history.json').write_text(json.dumps(history,indent=2));np.savez_compressed(R/'checkpoint.npz',control_knots=u);p.evaluate(u,save=R/'checkpoint_rollout.npz');print(json.dumps({k:v for k,v in row.items() if k!='trace'}),flush=True)
 if len(history)>=28:
  recent=[h.get('terminal_rmse_deg',1e6) for h in history[-16:]];earlier=[initial['terminal_rmse_deg']]+[h.get('terminal_rmse_deg',1e6) for h in history[:-16]]
  if min(recent)>=min(earlier)-.001:stopping_reason='best whole-terminal error did not improve over 16 consecutive joint corrections';break
final,fd=p.evaluate(u,save=R/'optimized_rollout.npz');e=p.terminal_errors[0];report=dict(method='uniform signed muscle-command offset at every time block, scalar offset scan and zero-crossing bisection, sequential largest-error joint',initial=initial,final=fd[0],terminal_error_deg=e.tolist(),joint_names=names,maximum_terminal_error_deg=float(np.max(abs(e))*180/np.pi),all_terminal_errors_zero_within_tolerance=bool(np.max(abs(e))<=tol),tolerance_deg=.001,iterations=len(history),all_times_uniform_before_0_1_clipping=True,height_penalty=0,orientation_penalty=0,torque_penalty=0,muscle_parameters_changed=False,extra_forces=False,intermediate_state_resets=False,walking_validated=False,stopping_reason=stopping_reason,wall_s=time.monotonic()-clock,limits=['Groups are fixed using active torque signs at the reference endpoint, not muscle names alone.','One group update can alter other joints; their errors are measured and revisited.','Finite sequential trial; clipping limits commands to 0..1. No global reachability or optimality claim.'])
(R/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
