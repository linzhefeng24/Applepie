import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,importlib.util,time,argparse,numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--segments',type=int,default=1);ap.add_argument('--sweeps',type=int,default=3);args=ap.parse_args();O=R/f'coordinate_{args.segments}segments';O.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('jointprob',R.parent/'terminal_priority_20261105/problem.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);p=mod.JointTrajectory();m=p.m
seed=dict(np.load(R.parent/'uniform_activation_20261105/optimized_rollout.npz'));old=dict(np.load(R.parent/'sequential_segments_20261106/segment_20ms_more/rollout_5000Hz.npz'));initial=seed['initial_state'];planned=old['all_control_10000Hz'].copy();d=mujoco.MjData(m);mujoco.mj_setState(m,d,initial,mujoco.mjtState.mjSTATE_FULLPHYSICS);d.qacc_warmstart[:]=seed['initial_warmstart'];names=p.reference['joint_names'];ids=seed['muscle_ids'];data=[mujoco.MjData(m) for _ in range(4)];snapshots=[];history=[];segments=[];clock=time.monotonic();all_control=[];offset0=1+m.nq+m.nv
for seg in range(args.segments):
 start=seg*200;stop=start+200;base=planned[start:stop].copy();B=base[:,p.ids];lo=-B.max(axis=0);hi=1-B.min(axis=0);amp=np.zeros(130);state=np.empty(len(initial));mujoco.mj_getState(m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);warm=d.qacc_warmstart.copy();target=p.reference['qpos'][stop//2,p.qadrs];frozenpast=planned[:start].copy();frozenfuture=planned[stop:].copy()
 def sim(X,states=False):
  X=np.atleast_2d(X);C=np.broadcast_to(base,(len(X),*base.shape)).copy();C[:,:,p.ids]=np.clip(B[None]+X[:,None],0,1);S,_=rollout.rollout(m,data,state[None],C,initial_warmstart=warm[None],persistent_pool=True);E=S[:,-1,1:1+m.nq][:,p.qadrs]-target;assert np.isfinite(S).all();return (E,S) if states else E
 e=sim(amp)[0];baseline=e.copy();print('BEGIN',seg+1,float(np.sqrt(np.mean(e**2))*180/np.pi),flush=True);priority=int(np.flatnonzero(names=='walker/tibia_T3_right')[0]);rounds=[]
 for sweep in range(args.sweeps):
  queue=list(np.argsort(abs(e))[::-1][:14]);queue=([priority]+[j for j in queue if j!=priority]) if sweep==0 else queue
  for j in queue:
   if abs(e[j])<.5*np.pi/180:continue
   # Local leg commands plus every other muscle on selected audit passes, so cross-leg contact routes are tested too.
   parts=str(names[j]).rsplit('_',2);leg=('L' if parts[-1]=='left' else 'R')+{'T1':'F','T2':'M','T3':'H'}[parts[-2]];local=np.array([str(i).startswith(leg+':') for i in ids]);ix=np.arange(130) if sweep==args.sweeps-1 else np.flatnonzero(local)
   before=e.copy();a_before=amp.copy();probes=[];steps=[]
   for i in ix:
    hp=min(.05,hi[i]-amp[i]);hm=min(.05,amp[i]-lo[i]);xp=amp.copy();xm=amp.copy();xp[i]+=hp;xm[i]-=hm;probes.extend([xp,xm]);steps.append(hp+hm)
   P=sim(probes);J=np.zeros(130)
   for k,i in enumerate(ix):
    if steps[k]>1e-10:J[i]=(P[2*k,j]-P[2*k+1,j])/steps[k]
   direction=-np.sign(e[j]*J);order=ix[np.argsort(abs(J[ix]))[::-1]];candidate=[amp.copy()];labels=[dict(kind='unchanged')]
   for subset in [order[:6],order[:12],order]:
    for scale in [.03,.1,.3,.6,1.]:
     for sign in [1,-1]:
      move=np.zeros(130);sg=sign*direction[subset];move[subset]=np.where(sg>=0,hi[subset]-amp[subset],lo[subset]-amp[subset]);candidate.append(np.clip(amp+scale*move,lo,hi));labels.append(dict(kind='group',size=len(subset),fraction=scale,sign=sign))
   for i in order[:12]:
    for bound in [lo[i],hi[i]]:
     x=amp.copy();x[i]=bound;candidate.append(x);labels.append(dict(kind='single_to_boundary',muscle=str(ids[i]),offset=float(bound)))
   C=np.asarray(candidate);E=sim(C);k=int(np.argmin(abs(E[:,j])));chosen=C[k];ce=E[k]
   # Refine an overshoot by actual nonlinear bisection along its command displacement.
   crossing=np.flatnonzero(E[:,j]*e[j]<0)
   if len(crossing):
    k0=int(crossing[np.argmin(abs(E[crossing,j]))]);dest=C[k0];l=0.;h=1.
    for b in range(12):
     mid=(l+h)/2;x=amp+mid*(dest-amp);ee=sim(x)[0]
     if abs(ee[j])<abs(ce[j]):chosen=x;ce=ee;k=-1
     if ee[j]*e[j]>0:l=mid
     else:h=mid
   accepted=bool(abs(ce[j])<abs(e[j])-1e-9)
   if accepted:amp=chosen.copy();e=ce.copy()
   changed=np.flatnonzero(abs(e-before)>.5*np.pi/180);row=dict(segment=seg+1,sweep=sweep+1,joint=str(names[j]),before_error_deg=float(before[j]*180/np.pi),after_error_deg=float(e[j]*180/np.pi),accepted=accepted,global_rmse_before_deg=float(np.sqrt(np.mean(before**2))*180/np.pi),global_rmse_after_deg=float(np.sqrt(np.mean(e**2))*180/np.pi),max_error_after_deg=float(np.max(abs(e))*180/np.pi),selected=(dict(kind='bisected_group') if k==-1 else labels[k]),affected_joints=[dict(joint=str(names[q]),before_deg=float(before[q]*180/np.pi),after_deg=float(e[q]*180/np.pi)) for q in changed],changed_muscles=[dict(id=str(ids[q]),offset_before=float(a_before[q]),offset_after=float(amp[q])) for q in np.flatnonzero(abs(amp-a_before)>1e-9)],wall_s=time.monotonic()-clock);history.append(row);(O/'corrections.json').write_text(json.dumps(history,indent=2));print(json.dumps({k:v for k,v in row.items() if k not in ['affected_joints','changed_muscles']}),flush=True)
  rounds.append(dict(sweep=sweep+1,rmse_deg=float(np.sqrt(np.mean(e**2))*180/np.pi),max_error_deg=float(np.max(abs(e))*180/np.pi)));np.savez_compressed(O/f'segment_{seg+1}_sweep_{sweep+1}.npz',offset=amp,error_rad=e,joint_names=names,muscle_ids=ids)
  if np.max(abs(e))<1*np.pi/180:break
 predicted,S=sim(amp,True);chosen=base.copy();chosen[:,p.ids]=np.clip(B+amp[None],0,1);planned[start:stop]=chosen;assert np.array_equal(planned[:start],frozenpast) and np.array_equal(planned[stop:],frozenfuture)
 for k in range(200):
  d.ctrl[:]=chosen[k];mujoco.mj_step(m,d);assert np.all((d.act[p.adrs]>=0)&(d.act[p.adrs]<=1))
  if k%2:
   ss=np.empty(len(initial));mujoco.mj_getState(m,d,ss,mujoco.mjtState.mjSTATE_FULLPHYSICS);snapshots.append(ss)
 assert np.max(abs(d.qpos[p.qadrs]-S[0,-1,1:1+m.nq][p.qadrs]))<1e-9
 segments.append(dict(segment=seg+1,time_s=stop*.0001,baseline_rmse_deg=float(np.sqrt(np.mean(baseline**2))*180/np.pi),final_rmse_deg=float(np.sqrt(np.mean(e**2))*180/np.pi),sweeps=rounds,max_error_deg=float(np.max(abs(e))*180/np.pi)));(O/'segment_history.json').write_text(json.dumps(segments,indent=2));np.savez_compressed(O/'checkpoint.npz',full_state=np.asarray(snapshots),all_control_10000Hz=planned,initial_state=initial)
ss=np.asarray(snapshots);q=ss[:,1:1+m.nq];v=ss[:,1+m.nq:offset0];times=ss[:,0];targetq=p.reference['qpos'][np.rint(times/.0002).astype(int)][:,p.qadrs];err=q[:,p.qadrs]-targetq
np.savez_compressed(O/'rollout_5000Hz.npz',time_s=times,full_state=ss,qpos=q,qvel=v,activation=ss[:,offset0:][:,p.adrs],excitation=planned[1:args.segments*200:2][:,p.ids],all_control_10000Hz=planned[:args.segments*200],initial_state=initial,initial_warmstart=seed['initial_warmstart'],joint_angle_rad=q[:,p.qadrs],target_joint_angle=targetq,qerror_rad=err,muscle_ids=ids,joint_names=names)
report=dict(method='cyclic individual-joint correction accepting collateral error; native nonlinear group scans, single-muscle boundary scans and bisection; no aggregate-loss veto',segments=segments,duration_s=args.segments*.02,terminal_rmse_deg=float(np.sqrt(np.mean(err[-1]**2))*180/np.pi),path_rmse_deg=float(np.sqrt(np.mean(err**2))*180/np.pi),max_terminal_error_deg=float(np.max(abs(err[-1]))*180/np.pi),height_penalty=0,muscle_parameters_changed=False,initial_state_changed=False,only_current_segment_controls_changed=True,intermediate_state_resets=False,walking_validated=False,wall_s=time.monotonic()-clock);(O/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
