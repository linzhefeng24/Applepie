import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,importlib.util,numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('jointprob',R.parent/'terminal_priority_20261105/problem.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);p=mod.JointTrajectory();m=p.m
seed=dict(np.load(R.parent/'uniform_activation_20261105/optimized_rollout.npz'));old=dict(np.load(R.parent/'sequential_segments_20261106/segment_20ms_more/rollout_5000Hz.npz'));state=seed['initial_state'];warm=seed['initial_warmstart'];base=old['all_control_10000Hz'][:200].copy();target=p.reference['qpos'][100,p.qadrs];names=p.reference['joint_names'];ids=seed['muscle_ids'];data=[mujoco.MjData(m) for _ in range(4)]
def sim(U):
 U=np.atleast_3d(U) if np.asarray(U).ndim==1 else np.asarray(U);C=np.broadcast_to(base,(len(U),*base.shape)).copy();C[:,:,p.ids]=U;S,_=rollout.rollout(m,data,state[None],C,initial_warmstart=warm[None],persistent_pool=True);E=S[:,-1,1:1+m.nq][:,p.qadrs]-target;return E,S
B=base[:,p.ids];e,s=sim(B[None]);order=np.argsort(abs(e[0]))[::-1];print('TOP',[(str(names[j]),float(e[0,j]*180/np.pi)) for j in order[:8]],flush=True)
probes=[];labels=[]
for i in range(130):
 for delta in [-.05,.05]:
  u=B.copy();u[:,i]=np.clip(u[:,i]+delta,0,1);probes.append(u);labels.append((i,delta))
pe,_=sim(probes);J=np.zeros((66,130))
for i in range(130):J[:,i]=(pe[2*i+1]-pe[2*i])/.1
rows=[]
for j in order[:6]:
 leg=str(names[j]).rsplit('_',2)[-2:];legcode={'T1':'F','T2':'M','T3':'H'}[leg[0]];side='L' if leg[1]=='left' else 'R';mask=np.array([str(x).startswith(side+legcode) for x in ids]);print('MUSCLE_IDS',str(ids[0]),'MASK',sum(mask),flush=True)
 # Muscle record IDs may encode the leg in a different field; use joint mechanics rather than infer anatomy from IDs.
 idx=np.argsort(abs(J[j]))[::-1][:12];direction=-np.sign(e[0,j]*J[j]);local=np.zeros(130);local[idx]=direction[idx]
 U=[];meta=[]
 for frac in [0,.02,.05,.1,.2,.4,.7,1,2]:
  U.append(np.clip(B+frac*local[None],0,1));meta.append(dict(kind='top12_group',offset=frac))
 for i in idx[:6]:
  for frac in [.1,.4,1,2]:
   u=B.copy();u[:,i]=np.clip(u[:,i]+frac*direction[i],0,1);U.append(u);meta.append(dict(kind='single',muscle=str(ids[i]),offset=float(frac*direction[i])))
 E,S=sim(U);entries=[]
 for k,meta0 in enumerate(meta):
  entry=dict(**meta0,joint_error_deg=float(E[k,j]*180/np.pi),all_joint_rmse_deg=float(np.sqrt(np.mean(E[k]**2))*180/np.pi),max_joint_error_deg=float(np.max(abs(E[k]))*180/np.pi));entries.append(entry)
 row=dict(joint=str(names[j]),baseline_error_deg=float(e[0,j]*180/np.pi),influential_muscles=[dict(id=str(ids[i]),endpoint_slope_rad=float(J[j,i]),command_min=float(B[:,i].min()),command_max=float(B[:,i].max())) for i in idx],scans=entries);rows.append(row);best=min(entries,key=lambda x:abs(x['joint_error_deg']));print(json.dumps(dict(joint=str(names[j]),best_single_joint=best,group=entries[:9])),flush=True)
(R/'first_segment_scans.json').write_text(json.dumps(rows,indent=2));np.savez_compressed(R/'first_segment_sensitivity.npz',J=J,baseline_error_rad=e[0],joint_names=names,muscle_ids=ids)
