exec(open('/workspace/flybrain-activation-inverse/manual_segment_audit_20261106/inspect_first.py').read().split('probes=[]')[0])
from scipy.optimize import lsq_linear
import time
clock=time.monotonic();lo=-B.max(axis=0);hi=1-B.min(axis=0);j=int(np.flatnonzero(names=='walker/tibia_T3_right')[0]);amp=np.zeros(130);best=None
history0=json.loads((R/'coordinate_1segments/corrections.json').read_text())
for row in history0:
 for x in row['changed_muscles']:amp[int(np.flatnonzero(ids==x['id'])[0])]=x['offset_after']
 if row['joint']==str(names[j]) and (best is None or abs(row['after_error_deg'])<best[0]):best=(abs(row['after_error_deg']),amp.copy())
amp=best[1];hist=[];rng=np.random.default_rng(20261106)
def evaluate(X):
 X=np.atleast_2d(X);return sim(np.clip(B[None]+X[:,None],0,1))[0]
for it in range(40):
 e=evaluate(amp)[0];baseerr=float(e[j]);probes=[];steps=[]
 if abs(baseerr)<.01*np.pi/180:break
 for i in range(130):
  hp=min(.03,hi[i]-amp[i]);hm=min(.03,amp[i]-lo[i]);xp=amp.copy();xm=amp.copy();xp[i]+=hp;xm[i]-=hm;probes.extend([xp,xm]);steps.append(hp+hm)
 E=evaluate(probes);J=np.array([(E[2*i,j]-E[2*i+1,j])/steps[i] if steps[i]>1e-10 else 0 for i in range(130)]);active=np.flatnonzero(hi-lo>1e-10);ridge=max(np.linalg.norm(J)*.003,1e-8);A=np.vstack([J[None,active],ridge*np.eye(len(active))]);bb=np.r_[-baseerr,np.zeros(len(active))];fit=lsq_linear(A,bb,bounds=(lo[active]-amp[active],hi[active]-amp[active]),method='bvls',max_iter=200,tol=1e-10);delta=np.zeros(130);delta[active]=fit.x;sg=-np.sign(baseerr*J);bound=np.where(sg>=0,hi,lo);candidates=[amp.copy()];labels=['unchanged']
 for frac in [1.,.5,.2,.05,.01]:candidates.append(np.clip(amp+frac*delta,lo,hi));labels.append('bounded_scalar_GN')
 for frac in [.05,.2,.5,1.]:candidates.append(amp+frac*(bound-amp));labels.append('full_group_to_boundary')
 for i in np.argsort(abs(J))[::-1][:15]:
  for b in [lo[i],hi[i]]:
   x=amp.copy();x[i]=b;candidates.append(x);labels.append('single_to_boundary')
 # Keep testing nonlocal alternatives when the local slope is not useful.
 for k in range(64):
  if k<32:x=np.clip(amp+rng.normal(0,[.05,.2,.5,1][k%4],130),lo,hi)
  else:x=lo+(hi-lo)*rng.integers(0,2,130)
  candidates.append(x);labels.append('nonlocal_bounded_trial')
 C=np.asarray(candidates);EE=evaluate(C);k=int(np.argmin(abs(EE[:,j])));selected=C[k].copy();ee=EE[k].copy();cross=np.flatnonzero(EE[:,j]*baseerr<0)
 if len(cross):
  dest=C[int(cross[np.argmin(abs(EE[cross,j]))])];l=0.;h=1.
  for _ in range(14):
   f=(l+h)/2;xx=amp+f*(dest-amp);ex=evaluate(xx)[0]
   if abs(ex[j])<abs(ee[j]):selected=xx;ee=ex;k=-1
   if ex[j]*baseerr>0:l=f
   else:h=f
 changed=bool(abs(ee[j])<abs(baseerr)-1e-10)
 if changed:amp=selected
 row=dict(iteration=it+1,joint=str(names[j]),before_deg=baseerr*180/np.pi,after_deg=float(ee[j]*180/np.pi),accepted=changed,method='bisected' if k==-1 else labels[k],global_rmse_deg=float(np.sqrt(np.mean(ee**2))*180/np.pi),wall_s=time.monotonic()-clock);hist.append(row);(R/'focused_right_tibia_history.json').write_text(json.dumps(hist,indent=2));np.savez_compressed(R/'focused_right_tibia_checkpoint.npz',offset=amp,error_rad=ee,joint_names=names,muscle_ids=ids);print(json.dumps(row),flush=True)
print('FINAL',json.dumps(hist[-1] if hist else dict(target_reached=True)),flush=True)
