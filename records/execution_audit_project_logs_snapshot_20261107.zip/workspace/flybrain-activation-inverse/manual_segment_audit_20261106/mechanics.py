exec(open('/workspace/flybrain-activation-inverse/manual_segment_audit_20261106/inspect_first.py').read().split('probes=[]')[0])
d=mujoco.MjData(m);moment=np.zeros((m.nu,m.nv));out=[]
for ti in [0, .005,.01,.015,.02]:
 k=max(0,min(199,round(ti/.0001)-1));ss=state if ti==0 else s[0,k];mujoco.mj_setState(m,d,ss,mujoco.mjtState.mjSTATE_FULLPHYSICS);d.ctrl[:]=base[k];mujoco.mj_forward(m,d);mujoco.mju_sparse2dense(moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);entry=dict(time_s=ti,joints=[])
 for name in ['walker/femur_T1_left','walker/tibia_T3_right','walker/tarsus_T1_left']:
  jid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_JOINT,name);qa=m.jnt_qposadr[jid];do=m.jnt_dofadr[jid];mus=np.flatnonzero(abs(moment[p.ids,do])>1e-10);r=dict(name=name,angle_deg=float(d.qpos[qa]*180/np.pi),reference_deg=float(p.reference['qpos'][round(ti/.0002),qa]*180/np.pi),velocity=float(d.qvel[do]),joint_range_deg=(m.jnt_range[jid]*180/np.pi).tolist(),stiffness=float(m.jnt_stiffness[jid]),damping=float(m.dof_damping[do]),passive_torque=float(d.qfrc_passive[do]),actuator_torque=float(d.qfrc_actuator[do]),constraint_torque=float(d.qfrc_constraint[do]),muscles=[dict(id=str(ids[i]),u=float(d.ctrl[p.ids[i]]),a=float(d.act[p.adrs[i]]),moment=float(moment[p.ids[i],do]),force=float(d.actuator_force[p.ids[i]]),length=float(d.actuator_length[p.ids[i]]),lengthrange=m.actuator_lengthrange[p.ids[i]].tolist()) for i in mus]);entry['joints'].append(r)
 out.append(entry)
(R/'first_segment_mechanics.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
