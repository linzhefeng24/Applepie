exec(open('/workspace/flybrain-activation-inverse/manual_segment_audit_20261106/inspect_first.py').read().split('probes=[]')[0])
d=mujoco.MjData(m);moment=np.zeros((m.nu,m.nv));out=[];refs={k:p.src[k] for k in ['qvel','qacc','leg_tau_drive_Nm']};jointidx=[int(np.flatnonzero(names==x)[0]) for x in ['walker/femur_T1_left','walker/tibia_T3_right','walker/tarsus_T1_left']]
for ti in [0,.005,.01,.015,.02]:
 f=round(ti/.0002);d.qpos[:]=p.reference['qpos'][f];d.qvel[:]=refs['qvel'][f];d.ctrl[:]=base[min(199,round(ti/.0001))];forces=[]
 for a in [0.,1.]:
  d.act[p.adrs]=a;mujoco.mj_forward(m,d);forces.append(d.actuator_force[p.ids].copy())
 mujoco.mju_sparse2dense(moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind)
 for j in jointidx:
  tau0=moment[p.ids,p.dofs[j]]*forces[0]*1e-7;tau1=moment[p.ids,p.dofs[j]]*forces[1]*1e-7;lo=float(np.minimum(tau0,tau1).sum());hi=float(np.maximum(tau0,tau1).sum());teacher=float(refs['leg_tau_drive_Nm'][f,j]);out.append(dict(time_s=ti,joint=str(names[j]),teacher_drive_torque_Nm=teacher,muscle_instantaneous_torque_min_Nm=lo,muscle_instantaneous_torque_max_Nm=hi,teacher_torque_inside_instantaneous_interval=bool(lo<=teacher<=hi),reference_velocity_rad_s=float(d.qvel[p.dofs[j]]),joint_damping_torque_Nm=float(-m.dof_damping[p.dofs[j]]*d.qvel[p.dofs[j]]*1e-7)))
(R/'reference_torque_capacity.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
