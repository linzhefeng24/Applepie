from pathlib import Path
import os,json,importlib.util,numpy as np,mujoco
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/mpl-all-segments')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('joint_problem',R.parent/'terminal_priority_20261105/problem.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod);p=mod.JointTrajectory();m=p.m;z=dict(np.load(R/'rollout_5000Hz.npz'));seed=dict(np.load(R.parent/'uniform_activation_20261105/optimized_rollout.npz'));d=mujoco.MjData(m);mujoco.mj_setState(m,d,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.qacc_warmstart[:]=z['initial_warmstart'];err=0.;amin=1.;amax=0.;assert np.array_equal(z['initial_state'],seed['initial_state']);others=np.setdiff1d(np.arange(m.nu),p.ids);assert np.array_equal(z['all_control_10000Hz'][:,others],seed['all_control_10000Hz'][:,others])
for k,c in enumerate(z['all_control_10000Hz']):
 d.ctrl[:]=c;mujoco.mj_step(m,d);amin=min(amin,float(d.act[p.adrs].min()));amax=max(amax,float(d.act[p.adrs].max()));assert not np.any(d.qfrc_applied) and not np.any(d.xfrc_applied)
 if k%2:
  ss=np.empty(z['full_state'].shape[1]);mujoco.mj_getState(m,d,ss,mujoco.mjtState.mjSTATE_FULLPHYSICS);err=max(err,float(np.max(abs(ss-z['full_state'][k//2]))))
assert err<1e-9 and 0<=amin<=amax<=1
report=json.loads((R/'report.json').read_text());h=json.loads((R/'segment_history.json').read_text());assert len(h)==10 and all(x['past_and_future_controls_unchanged'] for x in h)
validation=dict(passed=True,independent_replay_max_full_state_error=err,activation_min_all_physics_steps=amin,activation_max_all_physics_steps=amax,excitation_min=float(z['excitation'].min()),excitation_max=float(z['excitation'].max()),initial_state_unchanged=True,nonmuscle_controls_unchanged=True,no_extra_applied_forces=True,all_ten_segments_completed=True,all_saved_times_on_same_trajectory=True)
(R/'validation.json').write_text(json.dumps(validation,indent=2));fig,ax=plt.subplots(figsize=(10,4));comparisons=[]
for label,path in [('Whole-program baseline',R.parent/'uniform_activation_20261105/optimized_rollout.npz'),('3 rounds per segment',R.parent/'sequential_segments_20261106/segment_20ms/rollout_5000Hz.npz'),('More rounds per segment',R.parent/'sequential_segments_20261106/segment_20ms_more/rollout_5000Hz.npz'),('Current: cyclic + joint refinement',R/'rollout_5000Hz.npz')]:
 zz=dict(np.load(path));e=zz['joint_angle_rad']-zz['target_joint_angle'];rmse=np.sqrt(np.mean(e**2,axis=1))*180/np.pi;ax.plot(zz['time_s'],rmse,label=label,linewidth=2 if path.parent==R else 1,alpha=1 if path.parent==R else .65);comparisons.append(dict(label=label,terminal_rmse_deg=float(rmse[-1]),path_rmse_deg=float(np.sqrt(np.mean(e**2))*180/np.pi)))
ax.set(xlabel='Time (s)',ylabel='Joint-angle RMSE (deg)');ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout();fig.savefig(R/'comparison.png',dpi=160);(R/'comparison_metrics.json').write_text(json.dumps(comparisons,indent=2))
lines=['# All ten sequential segments','', 'Each interval is 20 ms. Only its muscle commands are optimized; the actual state passes continuously to the next interval. No height or velocity penalties, no resets, no extra torques, no model parameter changes.','', 'Individual-joint corrections accept collateral error. Bounded joint polishing and nonlocal trials then seek a compromise. Every actually evaluated candidate is archived by aggregate endpoint angle error; the best candidate is executed. This is a finite local search, not a global optimum or proof of feasibility.','', '| End time (s) | Endpoint RMSE (deg) | Max error (deg) | Worst joint |','|---|---:|---:|---|']
for row in h:lines.append(f"| {row['time_s']:.2f} | {row['endpoint_rmse_deg']:.3f} | {row['max_endpoint_error_deg']:.3f} | {row['worst_joints'][0]['joint']} |")
lines+=['','Physical trajectory duration is only 0.2 seconds. The video renders saved actual states versus the simulated reference, at 0.05x playback speed. This does not establish sustained normal walking.'];(R/'README.md').write_text('\n'.join(lines)+'\n');print(json.dumps(dict(report=report,validation=validation,comparisons=comparisons),indent=2))
