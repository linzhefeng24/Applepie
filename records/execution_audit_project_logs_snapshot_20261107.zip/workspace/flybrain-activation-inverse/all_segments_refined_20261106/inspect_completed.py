import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,numpy as np,mujoco
R=Path(__file__).resolve().parent;m=mujoco.MjModel.from_xml_path(str(R.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));records=json.loads((R.parent/'six_leg_model/activation_refine_20261104/records.json').read_text())['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];src=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');qadrs=src['joint_qpos_indices'];dofs=src['joint_dof_indices'];names=src['joint_names'];h=json.loads((R/'segment_history.json').read_text());z=dict(np.load(R/'checkpoint.npz'));mom=np.zeros((m.nu,m.nv));out=[]
for row in h:
 seg=row['segment'];state=z['full_state'][seg*100-1];d=mujoco.MjData(m);mujoco.mj_setState(m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);d.ctrl[:]=z['all_control_10000Hz'][seg*200-1];mujoco.mj_forward(m,d);mujoco.mju_sparse2dense(mom,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);forces=[]
 actualact=d.act.copy();actualforce=d.actuator_force[ids].copy()
 for a in [0,1]:d.act[adrs]=a;mujoco.mj_forward(m,d);forces.append(d.actuator_force[ids].copy())
 for worst in row['worst_joints'][:3]:
  j=int(np.flatnonzero(names==worst['joint'])[0]);dof=dofs[j];tau0=mom[ids,dof]*forces[0]*1e-7;tau1=mom[ids,dof]*forces[1]*1e-7;active=np.flatnonzero(abs(mom[ids,dof])>1e-9);desired=np.where((tau1-tau0)*(-np.sign(worst['error_deg']))>=0,1.,0.);entry=dict(segment=seg,time_s=row['time_s'],joint=worst['joint'],error_deg=worst['error_deg'],velocity_rad_s=float(d.qvel[dof]),actual_muscle_torque_Nm=float((mom[ids,dof]*actualforce*1e-7).sum()),instantaneous_torque_min_Nm=float(np.minimum(tau0,tau1).sum()),instantaneous_torque_max_Nm=float(np.maximum(tau0,tau1).sum()),muscles=[dict(id=records[i]['id'],u=float(d.ctrl[ids[i]]),a=float(actualact[adrs[i]]),command_for_torque_toward_target=float(desired[i])) for i in active]);out.append(entry)
(R/'completed_joint_mechanics.json').write_text(json.dumps(out,indent=2));print(json.dumps([dict(segment=r['segment'],joint=r['joint'],error_deg=r['error_deg'],direct_channels=len(r['muscles']),channels_already_commanded_toward_target_boundary=sum(abs(x['u']-x['command_for_torque_toward_target'])<1e-6 for x in r['muscles'])) for r in out],indent=2))
