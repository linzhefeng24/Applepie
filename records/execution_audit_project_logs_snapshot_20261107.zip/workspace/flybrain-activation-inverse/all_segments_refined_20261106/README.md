# All ten sequential segments

Each interval is 20 ms. Only its muscle commands are optimized; the actual state passes continuously to the next interval. No height or velocity penalties, no resets, no extra torques, no model parameter changes.

Individual-joint corrections accept collateral error. Bounded joint polishing and nonlocal trials then seek a compromise. Every actually evaluated candidate is archived by aggregate endpoint angle error; the best candidate is executed. This is a finite local search, not a global optimum or proof of feasibility.

| End time (s) | Endpoint RMSE (deg) | Max error (deg) | Worst joint |
|---|---:|---:|---|
| 0.02 | 5.350 | 23.019 | walker/femur_T1_left |
| 0.04 | 5.706 | 24.795 | walker/femur_T3_right |
| 0.06 | 10.057 | 44.792 | walker/femur_T1_right |
| 0.08 | 12.668 | 55.823 | walker/femur_T3_left |
| 0.10 | 11.052 | 39.774 | walker/tibia_T3_right |
| 0.12 | 11.416 | 56.177 | walker/tibia_T3_right |
| 0.14 | 11.312 | 34.154 | walker/femur_T1_right |
| 0.16 | 10.184 | 32.780 | walker/tarsus_T2_left |
| 0.18 | 9.960 | 31.672 | walker/femur_T3_right |
| 0.20 | 10.830 | 35.128 | walker/tarsus_T3_right |

Physical trajectory duration is only 0.2 seconds. The video renders saved actual states versus the simulated reference, at 0.05x playback speed. This does not establish sustained normal walking.
