from pathlib import Path
import json
r=Path(__file__).resolve().parent
h=r/'segment_history.json'
if h.exists():
 try:print('COMPLETED',[(x['segment'],round(x['endpoint_rmse_deg'],3),round(x['max_endpoint_error_deg'],3),x['rollouts']) for x in json.loads(h.read_text())])
 except json.JSONDecodeError:pass
s=(r/'run.log').read_text().splitlines()
for line in s[-2:]:
 try:
  x=json.loads(line);print({k:v for k,v in x.items() if k not in ['changed_muscles','worst_joints','affected_joints']})
 except json.JSONDecodeError:print(line[:200])
