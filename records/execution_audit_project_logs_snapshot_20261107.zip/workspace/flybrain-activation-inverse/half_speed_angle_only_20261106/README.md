# Half-speed reference, angle-only fitting

Reference q_target(t)=q_original(t/2), with physical time 0..0.4 s covering original phase 0..0.2 s. Reference angular velocity is halved for diagnostics only and is not penalized. Each interval is 20 ms in physical time: twenty sequential intervals, each covering 10 ms of original reference motion.

Muscle parameters, activation dynamics, physical timestep, initial state, force bounds and gravity are unchanged. Prior input profiles are stretched in time as initial guesses; amplitudes are not automatically halved. Retained nonmuscle controls (including adhesion) are stretched to the same motion phase. Required muscle forces are recomputed by full nonlinear dynamics, not scaled from old torques.

Only current-interval muscle inputs are modified. All actual states pass continuously to the next interval. No height or velocity penalty, state reset or rescue force is used. Every muscle has one uniform offset per selected seed interval. Cyclic joint corrections can temporarily disturb other joints; joint polishing and nonlocal trials are verified by full simulation, and the lowest aggregate endpoint angle error found is executed. This finite search is not a certificate of global optimality.

| Segment | Physical time (s) | Original phase (s) | Original-speed angle RMSE (deg) | Half-speed angle RMSE (deg) | Half-speed max error (deg) |
|---|---:|---:|---:|---:|---:|
| 1 | 0.02 | 0.01 | 2.880 | 1.474 | 5.471 |
| 2 | 0.04 | 0.02 | 5.350 | 3.791 | 16.299 |
| 3 | 0.06 | 0.03 | 6.090 | 3.672 | 12.095 |
| 4 | 0.08 | 0.04 | 5.706 | 4.367 | 14.722 |
| 5 | 0.10 | 0.05 | 6.509 | 6.345 | 23.297 |
| 6 | 0.12 | 0.06 | 10.057 | 10.260 | 38.930 |
| 7 | 0.14 | 0.07 | 12.448 | 12.086 | 42.100 |
| 8 | 0.16 | 0.08 | 12.668 | 11.608 | 42.916 |
| 9 | 0.18 | 0.09 | 12.691 | 10.470 | 36.304 |
| 10 | 0.20 | 0.10 | 11.052 | 10.631 | 44.415 |
| 11 | 0.22 | 0.11 | 10.696 | 11.359 | 47.616 |
| 12 | 0.24 | 0.12 | 11.416 | 11.003 | 42.215 |
| 13 | 0.26 | 0.13 | 11.082 | 12.114 | 44.263 |
| 14 | 0.28 | 0.14 | 11.312 | 14.712 | 47.881 |
| 15 | 0.30 | 0.15 | 11.230 | 15.000 | 53.088 |
| 16 | 0.32 | 0.16 | 10.184 | 14.201 | 52.178 |
| 17 | 0.34 | 0.17 | 9.788 | 13.172 | 51.061 |
| 18 | 0.36 | 0.18 | 9.960 | 13.404 | 53.397 |
| 19 | 0.38 | 0.19 | 10.618 | 13.526 | 57.705 |
| 20 | 0.40 | 0.20 | 10.830 | 14.365 | 56.740 |

Comparisons include a separate new physical replay of old angle-only inputs stretched by 2 without refitting. Original-speed and half-speed pose errors are compared at matching original motion phase.

The video covers the complete physical 0.4 s at playback 0.05x (8 seconds). Left is the retimed simulated reference; right is the actual new muscle-driven fit. Cameras follow each body separately; compare posture and leg movement rather than world displacement. This short trial does not establish sustained normal walking.
