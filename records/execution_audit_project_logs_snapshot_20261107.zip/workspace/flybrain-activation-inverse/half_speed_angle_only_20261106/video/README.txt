Left: original 0.2 s reference motion retimed to 0.4 s (q(t/2), qvel(t/2)/2). Right: actual bounded muscle-driven result, twenty 20 ms intervals, angle-only objective.
Complete physical trial 0.4 seconds; playback eight seconds at 0.05x. The reference is simulated, not a real fly recording.
Saved actual states rendered without pose correction or intermediate resets. Cameras follow each body separately, so compare posture and leg motion rather than world displacement.
