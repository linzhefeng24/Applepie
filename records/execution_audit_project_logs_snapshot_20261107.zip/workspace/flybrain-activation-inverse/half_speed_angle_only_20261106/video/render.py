import os
os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/tmp/half-speed-review-mesa',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,numpy as np,mujoco,imageio
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;root=R.parent.parent;m=mujoco.MjModel.from_xml_path(str(root/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));d=mujoco.MjData(m);z=dict(np.load(R.parent/'rollout_5000Hz.npz'));ref=dict(np.load(R.parent/'retimed_reference_5000Hz.npz'));qadrs=ref['joint_qpos_indices'];dofs=ref['joint_dof_indices'];renderer=mujoco.Renderer(m,height=360,width=480);opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');measurements=[];frames=120;fps=15
with imageio.get_writer(R/'half_speed_angle_only_vs_reference_005x.mp4',fps=fps,codec='libx264',quality=8,macro_block_size=2) as writer:
 for frame in range(frames):
  t=frame/(frames-1)*.4;ri=int(np.argmin(abs(ref['time_s']-t)));k=int(np.argmin(abs(z['time_s']-t)));panels=[]
  for label,side in [('Reference: original motion at 0.5x','reference'),('Muscle fit: angle-only, 20 x 20 ms','fit')]:
   if side=='reference':d.qpos[:]=ref['qpos'][ri];d.qvel[:]=ref['qvel'][ri]
   elif frame==0:d.qpos[:]=z['initial_state'][1:1+m.nq];d.qvel[:]=z['initial_state'][1+m.nq:1+m.nq+m.nv]
   else:d.qpos[:]=z['qpos'][k];d.qvel[:]=z['qvel'][k]
   d.time=t;mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=opt);im=Image.fromarray(renderer.render());dr=ImageDraw.Draw(im);dr.rectangle((0,0,480,49),fill='black');dr.text((7,5),label,fill='white');dr.text((7,23),f't={t:.3f}s | source phase={t/2:.3f}s | playback 0.05x',fill='white');panels.append(np.asarray(im));measurements.append(dict(time_s=t,source_reference_time_s=t/2,panel=side,thorax_xyz_mm=(d.xpos[thorax]*10).tolist(),angle_rmse_deg=float(np.sqrt(np.mean((d.qpos[qadrs]-ref['qpos'][ri,qadrs])**2))*180/np.pi),velocity_rmse_rad_s=float(np.sqrt(np.mean((d.qvel[dofs]-ref['qvel'][ri,dofs])**2)))))
  combined=np.concatenate(panels,axis=1);writer.append_data(combined)
  if frame in [0,60,119]:Image.fromarray(combined).save(R/f'frame_{frame:03d}.png')
  if frame%30==0:print('rendered',frame,'/',frames,flush=True)
renderer.close();(R/'render_measurements.json').write_text(json.dumps(measurements,indent=2));(R/'README.txt').write_text('Left: original 0.2 s reference motion retimed to 0.4 s (q(t/2), qvel(t/2)/2). Right: actual bounded muscle-driven result, twenty 20 ms intervals, angle-only objective.\nComplete physical trial 0.4 seconds; playback eight seconds at 0.05x. The reference is simulated, not a real fly recording.\nSaved actual states rendered without pose correction or intermediate resets. Cameras follow each body separately, so compare posture and leg motion rather than world displacement.\n');print('Finished',flush=True)
