import os
os.environ.update(MUJOCO_GL='egl',MESA_SHADER_CACHE_DIR='/tmp/slow-review-mesa',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,numpy as np,mujoco,imageio
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;model=R.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml';m=mujoco.MjModel.from_xml_path(str(model));d=mujoco.MjData(m)
z={k:v for k,v in np.load(R.parent/'uniform_activation_20261105/optimized_rollout.npz').items()};source=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');reference=source['qpos'];refv=source['qvel'];reference_time=source['time_s'];qadrs=source['joint_qpos_indices'];renderer=mujoco.Renderer(m,height=360,width=480);option=mujoco.MjvOption();option.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;option.sitegroup[:]=0
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
fps=15;speed=.05;duration=.2;frames=round(duration/speed*fps);thorax=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');measurements=[]
with imageio.get_writer(R/'reference_vs_latest_005x.mp4',fps=fps,codec='libx264',quality=8,macro_block_size=2) as writer:
 for frame in range(frames):
  t=(frame/(frames-1))*duration;idx=int(np.argmin(abs(z['time_s']-t)));ri=int(np.argmin(abs(reference_time-t)));panels=[]
  for side in ['reference','latest']:
   if side=='reference':d.qpos[:]=reference[ri];d.qvel[:]=refv[ri]
   else:d.qpos[:]=z['qpos'][idx];d.qvel[:]=z['qvel'][idx]
   d.time=t;mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=option);im=Image.fromarray(renderer.render());dr=ImageDraw.Draw(im);dr.rectangle((0,0,480,48),fill='black');label='Reference simulation' if side=='reference' else 'Latest muscle activation replay';dr.text((7,5),label,fill='white');dr.text((7,23),f't={t:.3f} s | 0.05x speed | 0.2 s trial',fill='white');panels.append(np.asarray(im))
   if side=='latest':measurements.append(dict(time_s=t,thorax_xyz_mm=(d.xpos[thorax]*10).tolist(),up_z=float(d.xmat[thorax].reshape(3,3)[2,2]),leg_angle_rmse_deg=float(np.sqrt(np.mean((d.qpos[qadrs]-reference[ri,qadrs])**2))*180/np.pi)))
  combined=np.concatenate(panels,axis=1);writer.append_data(combined)
  if frame in [0,frames//2,frames-1]:Image.fromarray(combined).save(R/f'frame_{frame:03d}.png')
  if frame%15==0:print('rendered',frame,'/',frames,flush=True)
renderer.close();(R/'render_measurements.json').write_text(json.dumps(measurements,indent=2));(R/'README.txt').write_text('Left: original simulated reference. Right: latest actual muscle-driven trajectory (uniform_activation_20261105).\nOnly saved qpos/qvel rendered; no resimulation or pose correction applied to results.\nPhysical trajectory: 0.2 seconds; playback: approximately 4 seconds, 0.05x speed.\nCamera follows each body independently, so compare posture and leg motion; camera following does not preserve forward-displacement comparison.\nThe target is simulated reference motion, not a real fly recording.\n');print('Finished',flush=True)
