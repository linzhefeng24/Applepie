Left: original simulated reference. Right: latest actual muscle-driven trajectory (uniform_activation_20261105).
Only saved qpos/qvel rendered; no resimulation or pose correction applied to results.
Physical trajectory: 0.2 seconds; playback: approximately 4 seconds, 0.05x speed.
Camera follows each body independently, so compare posture and leg motion; camera following does not preserve forward-displacement comparison.
The target is simulated reference motion, not a real fly recording.
