import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,time,numpy as np
from scipy.optimize import lsq_linear
from problem import ActivationOffsets,ROOT
p=ActivationOffsets();offset=np.zeros(130);clock=time.monotonic();_,di=p.evaluate(offset,save=ROOT/'initial_rollout.npz');initial=di[0];history=[];trust=.1;Jp=Jm=None;age=0;rejects=0
print('INITIAL',json.dumps(initial),flush=True)
for it in range(16):
 cost,dd=p.evaluate(offset);r=p.terminal_errors[0].copy()
 if np.max(abs(r))<.001*np.pi/180:break
 refresh=Jp is None or age>=4 or rejects>=2
 if refresh:
  hp=np.minimum(.002,p.upper-offset);hm=-np.minimum(.002,offset-p.lower);ip=np.flatnonzero(hp>1e-10);im=np.flatnonzero(hm<-1e-10);probes=[]
  for i in ip:v=offset.copy();v[i]+=hp[i];probes.append(v)
  for i in im:v=offset.copy();v[i]+=hm[i];probes.append(v)
  pc,_=p.evaluate(np.asarray(probes));rp=p.terminal_errors.copy();Jp=np.zeros((66,130));Jm=np.zeros_like(Jp)
  for k,i in enumerate(ip):
   if pc[k,0]<1e5:Jp[:,i]=(rp[k]-r)/hp[i]
  for k,i in enumerate(im):
   if pc[len(ip)+k,0]<1e5:Jm[:,i]=(rp[len(ip)+k]-r)/hm[i]
  age=0
 gp=Jp.T@r;gm=Jm.T@r;inc=np.where(p.upper-offset>1e-9,-gp,-np.inf);dec=np.where(offset-p.lower>1e-9,gm,-np.inf);positive=inc>=dec;active=np.flatnonzero(np.maximum(inc,dec)>1e-10)
 if not len(active):break
 J=np.where(positive[None],Jp,Jm);A0=J[:,active];ridge=max(np.linalg.norm(A0,'fro')/np.sqrt(len(active))*.01,1e-7);A=np.vstack([A0,ridge*np.eye(len(active))]);b=np.r_[-r,np.zeros(len(active))];lo=np.where(positive[active],0,np.maximum(p.lower[active]-offset[active],-trust));hi=np.where(positive[active],np.minimum(p.upper[active]-offset[active],trust),0);fit=lsq_linear(A,b,bounds=(lo,hi),method='bvls',tol=1e-8,max_iter=300);delta=np.zeros(130);delta[active]=fit.x;scales=np.array([1.,.5,.25,.125,.0625]);candidates=np.clip(offset[None]+scales[:,None]*delta,p.lower,p.upper);cc,cd=p.evaluate(candidates);rr=p.terminal_errors.copy();j=int(np.lexsort((cc[:,1],cc[:,0]))[0]);accepted=bool(cc[j,0]<cost[0,0]-1e-12)
 if accepted:
  step=candidates[j]-offset;resid=(rr[j]-r)-J@step;denom=float(step@step)
  if denom>1e-20:Jp+=np.outer(resid,step)/denom;Jm+=np.outer(resid,step)/denom
  offset=candidates[j].copy();out=cd[j];age+=1;rejects=0;trust=min(.2,trust*1.2) if scales[j]>=.5 else max(.003,trust*.6)
 else:out=dd[0];rejects+=1;age=4;trust=max(.001,trust*.5)
 h=dict(iteration=it+1,accepted=accepted,full_directional_derivatives=refresh,terminal_rmse_deg=out['terminal_rmse_deg'],path_rmse_deg=out['path_rmse_deg'],activation_tracking_rmse=out['desired_activation_tracking_rmse'],active_muscles=len(active),trust_radius=trust,wall_s=time.monotonic()-clock);history.append(h);(ROOT/'history.json').write_text(json.dumps(history,indent=2));np.savez_compressed(ROOT/'checkpoint.npz',activation_offsets=offset);p.evaluate(offset,save=ROOT/'checkpoint_rollout.npz');print(json.dumps(h),flush=True)
 if rejects>=3:break
_,df=p.evaluate(offset,save=ROOT/'optimized_rollout.npz');e=p.terminal_errors[0];report=dict(method='uniform activation target offsets including initial activation; inverse native activation dynamics produces bounded excitation, coupled terminal-angle correction',initial=initial,final=df[0],iterations=len(history),maximum_terminal_error_deg=float(np.max(abs(e))*180/np.pi),all_errors_zero=bool(np.max(abs(e))<.001*np.pi/180),tolerance_deg=.001,initial_qpos_and_qvel_fixed=True,initial_muscle_activation_optimized=True,intermediate_activation_overwrites=False,height_penalty=0,orientation_penalty=0,muscle_parameters_changed=False,extra_forces=False,walking_validated=False,wall_s=time.monotonic()-clock,stopping_reason='target tolerance reached' if max(abs(e))<.001*np.pi/180 else ('no accepted descent in consecutive local trials' if rejects>=3 else 'finite coupled offset refinement; no global infeasibility claim'))
(ROOT/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
