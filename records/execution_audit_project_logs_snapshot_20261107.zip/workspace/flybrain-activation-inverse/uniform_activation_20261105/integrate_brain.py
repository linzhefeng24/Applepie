from pathlib import Path
import json,hashlib,copy,os
R=Path(__file__).resolve().parent;C=Path('/workspace/flybrain-muscle-rebuild/brain.json');M=Path('/workspace/flybrain-recovered/brain.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads(C.read_text());assert b==json.loads(M.read_text());old=copy.deepcopy(b);backup=R/'brain_before_activation_offsets.json'
if not backup.exists():backup.write_bytes(C.read_bytes())
report=json.loads((R/'report.json').read_text());summary=json.loads((R/'summary.json').read_text());validation=json.loads((R/'validation.json').read_text());assert validation['passed'];id='six_leg_uniform_activation_offsets_20261105'
assets=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(R.iterdir()) if p.is_file() and p.name not in ['brain_before_activation_offsets.json','brain_integration.json'] and p.suffix in ['.json','.npz','.py','.png','.md']]
run=dict(id=id,date='2026-11-05',previous_experiment_id='six_leg_uniform_refined_terminal_20261105',role='uniform whole-trajectory activation targets including free estimated initial muscle activation, inverse native dynamics and bounded executable excitation',report=report,summary=summary,validation=validation,method_document={'format':'markdown','text':(R/'README.md').read_text()},artifacts=assets,height_penalty=0,muscle_parameters_changed=False,initial_body_state_and_velocity_changed=False,initial_muscle_activation_optimized=True,walking_validated=False)
runs=b['muscle_activation_inference_experiments']['runs'];runs[:]=[x for x in runs if x['id']!=id];runs.append(run);n=b['neuromusculoskeletal_model'];n['current_readiness']['latest_whole_trajectory_terminal_experiment_id']=id;n['current_readiness']['latest_terminal_correction_converged_to_zero']=summary['all_errors_zero'];n['current_muscle_model_overview']['joint_terminal_correction_policy'].update(experiment_id=id,requested_rule='one uniform whole-trajectory target activation offset per muscle, including initial activation; bounded native excitation inferred and actual activation recorded',height_penalty=0,best_terminal_RMSE_deg=summary['final']['terminal_rmse_deg'],all_errors_zero=summary['all_errors_zero'],initial_muscle_state_optimized_in_latest_trial=True,note='Desired activation translations may be dynamically infeasible under 0..1 excitation; actual activation and tracking error are recorded. Individual zero events do not imply simultaneous all-joint convergence.')
b['version']='3.4.11-uniform-activation-terminal-offsets';b['date']='2026-11-05'
for k,v in old.items():
 if k not in ['version','date','neuromusculoskeletal_model','muscle_activation_inference_experiments']:assert b[k]==v,k
blob=(json.dumps(b,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
for p in [C,M]:tmp=p.with_name(p.name+'.activation.tmp');tmp.write_bytes(blob);os.replace(tmp,p)
assert C.read_bytes()==M.read_bytes();out=dict(passed=True,version=b['version'],mirrors_identical=True,prior_biological_evidence_preserved=True,height_penalty=0,all_errors_zero=summary['all_errors_zero'],brain_sha256=sha(C));(R/'brain_integration.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
