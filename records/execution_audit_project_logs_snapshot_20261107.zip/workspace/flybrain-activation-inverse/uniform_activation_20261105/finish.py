import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR='/tmp/mpl-uniform-activation')
from pathlib import Path
import json,numpy as np,mujoco,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from problem import ActivationOffsets,ROOT
p=ActivationOffsets();z={k:v for k,v in np.load(ROOT/'optimized_rollout.npz').items()};report=json.loads((ROOT/'report.json').read_text());delta=z['activation_offsets'];desired=np.clip(p.a_base[2::2]+delta,0,1);derr=float(np.max(abs(desired-z['desired_activation'])));assert derr<1e-9
m=p.m;d=mujoco.MjData(m);mujoco.mj_setState(m,d,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.qacc_warmstart[:]=z['initial_warmstart'];amax=0.;amin=1.;error=0.
for k,ctrl in enumerate(z['all_control_10000Hz']):
 d.ctrl[:]=ctrl;mujoco.mj_step(m,d);amin=min(amin,float(d.act[p.adrs].min()));amax=max(amax,float(d.act[p.adrs].max()))
 if k%2==1:
  state=np.empty(len(p.initial));mujoco.mj_getState(m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);error=max(error,float(np.max(abs(state-z['full_state'][k//2]))))
assert error<1e-8 and 0<=amin<=amax<=1 and not np.any(d.qfrc_applied) and not np.any(d.xfrc_applied)
mask=np.ones(len(p.initial),dtype=bool);mask[p.off+p.adrs]=False;init_other_error=float(np.max(abs(z['initial_state'][mask]-z['original_initial_state'][mask])));assert init_other_error==0
# Required raw excitation for the translated activation target, before physical 0..1 clipping.
a=z['initial_state'][p.off:][p.adrs].copy();rawmin=1.;rawmax=0.;violations=0
for k in range(p.p.steps):
 target=np.clip(p.a_base[k+1]+delta,0,1);factor=.5+1.5*a;tau=np.where(target>a,p.ta*factor,p.td/factor);raw=a+(target-a)*tau/m.opt.timestep;rawmin=min(rawmin,float(raw.min()));rawmax=max(rawmax,float(raw.max()));violations+=int(np.sum((raw<-1e-6)|(raw>1+1e-6)));u=np.clip(raw,0,1);tau=np.where(u>a,p.ta*factor,p.td/factor);a=np.clip(a+m.opt.timestep*(u-a)/tau,0,1)
angleerr=z['joint_angle_rad']-z['target_joint_angle'];end=angleerr[-1];names=p.p.reference['joint_names'].tolist();tracking=z['activation']-z['desired_activation'];i=int(np.argmax(np.mean(tracking**2,axis=0)));neutral={k:v for k,v in np.load(ROOT/'initial_rollout.npz').items()};baseline={k:v for k,v in np.load(ROOT.parent/'uniform_terminal_20261105/uniform_refined/optimized_rollout.npz').items()};neutral_joint_error=float(np.max(abs(neutral['joint_angle_rad']-baseline['joint_angle_rad'])));assert neutral_joint_error<1e-5
summary=dict(initial=report['initial'],final=report['final'],max_terminal_error_deg=float(np.max(abs(end))*180/np.pi),all_errors_zero=report['all_errors_zero'],joint_errors_deg=end.tolist(),worst_terminal_joints=[dict(joint=names[j],error_deg=float(end[j]*180/np.pi)) for j in np.argsort(-abs(end))[:10]],actual_vs_uniform_target_activation_RMSE=float(np.sqrt(np.mean(tracking**2))),worst_activation_target_muscle=str(z['muscle_ids'][i]),required_raw_excitation_min=rawmin,required_raw_excitation_max=rawmax,required_excitation_out_of_bounds_fraction_excluding_roundoff=violations/(p.p.steps*130),initial_muscle_activation_optimized=True,initial_body_and_velocity_fixed=True,height_penalty=0,walking_validated=False)
validation=dict(passed=True,desired_activation_offset_uniformity_error=derr,full_native_python_replay_max_state_error=error,neutral_offset_baseline_joint_max_error_rad=neutral_joint_error,initial_nonmuscle_state_unchanged_error=init_other_error,activation_min_every_physics_step=amin,activation_max_every_physics_step=amax,extra_forces=False,intermediate_activation_overwrites=False,height_penalty=0,model_sha256=hashlib.sha256((ROOT.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml').read_bytes()).hexdigest());(ROOT/'summary.json').write_text(json.dumps(summary,indent=2));(ROOT/'validation.json').write_text(json.dumps(validation,indent=2))
fig,axs=plt.subplots(3,1,figsize=(9,9),constrained_layout=True)
for a,label in [(neutral,'Initial'),(z,'Uniform activation targets')]:axs[0].plot(a['time_s'],np.sqrt(np.mean((a['joint_angle_rad']-a['target_joint_angle'])**2,axis=1))*180/np.pi,label=label)
axs[0].set(ylabel='Joint RMSE (deg)');j=names.index('walker/tarsus_T2_right');axs[1].plot(z['time_s'],z['target_joint_angle'][:,j]*180/np.pi,label='Reference',ls='--',color='black')
for a,label in [(neutral,'Initial'),(z,'Uniform activation targets')]:axs[1].plot(a['time_s'],a['joint_angle_rad'][:,j]*180/np.pi,label=label)
axs[1].set(ylabel='Right middle tarsus (deg)');axs[2].plot(z['time_s'],z['desired_activation'][:,i],label='Uniform-shift target');axs[2].plot(z['time_s'],z['activation'][:,i],label='Actual native activation');axs[2].set(xlabel='Time (s)',ylabel='Activation 0..1',title=str(z['muscle_ids'][i]))
for ax in axs:ax.legend();ax.grid(alpha=.3)
fig.savefig(ROOT/'comparison.png',dpi=150);plt.close(fig);print(json.dumps({'summary':summary,'validation':validation},indent=2))
