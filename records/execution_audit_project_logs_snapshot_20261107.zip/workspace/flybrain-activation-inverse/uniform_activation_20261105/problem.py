import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import importlib.util,json,numpy as np,mujoco
from mujoco import rollout
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('terminal_phase_problem',ROOT.parent/'terminal_priority_20261105/problem.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
class ActivationOffsets:
 def __init__(self):
  self.p=mod.JointTrajectory();p=self.p;self.m=p.m;m=p.m;self.off=1+m.nq+m.nv;self.adrs=p.adrs;self.ids=p.ids
  base=np.load(ROOT.parent/'uniform_terminal_20261105/uniform_refined/optimized_rollout.npz');ctrl=base['all_control_10000Hz'];self.original_controls=ctrl.copy();self.initial=base['initial_state'].copy();self.original_warm=p.warm.copy();state,_=rollout.rollout(m,p.data,self.initial[None],ctrl[None],initial_warmstart=p.warm[None],persistent_pool=True);self.a_base=np.vstack([self.initial[self.off:][self.adrs],state[0,:,self.off:][:,self.adrs]]);self.base_q=state[0,:,1:1+m.nq].copy();self.lower=-self.a_base.max(axis=0);self.upper=1-self.a_base.min(axis=0);self.ta=m.actuator_dynprm[self.ids,0];self.td=m.actuator_dynprm[self.ids,1];assert np.all(m.actuator_dynprm[self.ids,2]==0);self.warm_probe=mujoco.MjData(m)
 def evaluate(self,offsets,save=None):
  z=np.atleast_2d(offsets);p=self.p;m=p.m;nb=len(z);ctrl=np.broadcast_to(p.ctrl,(nb,*p.ctrl.shape)).copy();initial=np.broadcast_to(self.initial,(nb,len(self.initial))).copy();a=np.clip(self.a_base[0]+z,0,1);initial[:,self.off+self.adrs]=a;clipped=np.zeros(nb,dtype=int)
  for k in range(p.steps):
   desired=np.clip(self.a_base[k+1]+z,0,1);factor=.5+1.5*a;tau=np.where(desired>a,self.ta*factor,self.td/factor);raw=a+(desired-a)*tau/m.opt.timestep;u=np.clip(raw,0,1);clipped+=np.sum((raw<0)|(raw>1),axis=1);ctrl[:,k,self.ids]=u;tau_actual=np.where(u>a,self.ta*factor,self.td/factor);a=np.clip(a+m.opt.timestep*(u-a)/tau_actual,0,1)
  warm=[]
  for k in range(nb):
   d=self.warm_probe;mujoco.mj_setState(m,d,initial[k],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.ctrl[:]=ctrl[k,0];d.qacc_warmstart[:]=self.original_warm;mujoco.mj_forward(m,d);warm.append(d.qacc_warmstart.copy())
  warm=np.asarray(warm);states,_=rollout.rollout(m,p.data,initial,ctrl,initial_warmstart=warm,persistent_pool=True);q=states[:,p.sample,1:1+m.nq][:,:,p.qadrs];e=q-p.target[None];terminal=np.mean(e[:,-1]**2,axis=1);path=np.mean(e**2,axis=(1,2));valid=np.isfinite(states).all(axis=(1,2))&np.all(np.isclose(states[:,:,0],p.end_times[None],atol=1e-8),axis=1);terminal=np.where(valid,terminal,1e6);path=np.where(valid,path,1e6);self.terminal_errors=e[:,-1].copy();details=[]
  for k in range(nb):
   actual=states[k,:,self.off:][:,self.adrs];desired=np.clip(self.a_base[1:]+z[k],0,1);details.append(dict(terminal_mse_rad2=float(terminal[k]),path_mse_rad2=float(path[k]),terminal_rmse_deg=float(np.sqrt(terminal[k])*180/np.pi),path_rmse_deg=float(np.sqrt(path[k])*180/np.pi),desired_activation_tracking_rmse=float(np.sqrt(np.mean((actual-desired)**2))),inverse_excitation_clipping_fraction=float(clipped[k]/(p.steps*130))))
  if save:
   h=np.arange(1,p.steps,2);s=states[-1];act=s[:,self.off:][:,self.adrs];assert np.all((act>=0)&(act<=1));np.savez_compressed(save,time_s=s[h,0],full_state=s[h],qpos=s[h,1:1+m.nq],qvel=s[h,1+m.nq:self.off],activation=act[h],desired_activation=np.clip(self.a_base[h+1]+z[-1],0,1),excitation=ctrl[-1,h][:,self.ids],all_control_10000Hz=ctrl[-1],initial_state=initial[-1],original_initial_state=self.initial,initial_warmstart=warm[-1],activation_offsets=z[-1],joint_angle_rad=s[h,1:1+m.nq][:,p.qadrs],target_joint_angle=p.reference['qpos'][np.rint(s[h,0]/.0002).astype(int)][:,p.qadrs],muscle_ids=np.array([r['id'] for r in p.rows]),joint_names=p.reference['joint_names']);details[-1].update(activation_all_physics_steps_min=float(act.min()),activation_all_physics_steps_max=float(act.max()),maximum_terminal_error_deg=float(np.max(abs(e[-1,-1]))*180/np.pi))
  return np.column_stack([terminal,path]),details
