# Dynamic periodic replay attempt

Source: `half_speed_angle_only_20261106`, 0.4 s, 20 × 20 ms intervals.
The original model and original result are preserved. `solve.py` uses the same
`bounded_refined_muscles.xml` model rather than the later hind-leg candidate.

The optimization changes excitation offsets across all 20 intervals and the
initial physical pose and velocity. It does not impose reference joint positions
on the evolving body, reset intermediate states, or add applied forces. It seeks
relative periodicity: root forward translation is permitted, while other actual
body coordinates, velocities and internal actuator states should repeat. The
render-only ghost is excluded from closure.

For each proposed periodic excitation, `act.c` iterates the model's actual Euler
activation recurrence to obtain a periodic initial internal activation. These
initial states are only set before the first simulation step. The MuJoCo rollout
then independently evolves every muscle state; measured terminal differences
verify this recurrence. There are no activation replacements at cycle boundaries.
A short cubic input blend makes excitation endpoints identical as well.

Closure receives the main objective weight. A reference-angle term and forward
travel term retain a preference for locomotion rather than a static solution.
There is no absolute body-height penalty; vertical return is part of the periodic
boundary condition. This is a finite local, randomized-subspace Gauss–Newton
search, not a global optimization or a proof of infeasibility.

`validate.py` runs the selected inputs for 20 consecutive cycles without any
physical state reset, and independently checks one cycle via `mj_step`.
`validation.json` is the authoritative outcome; a periodic input or periodic
activation alone is not a claim of stable walking.

## Requirement audit after user feedback

This attempt did not implement closure as a hard equality. It combined soft
closure, tracking, a 4 mm forward-displacement preference, and weak parameter
regularization. In particular, the accepted structured shooting update worsened
both angular closure RMS and reference tracking RMS while improving the composite
objective. The user explicitly requires closure plus reference tracking; a
prescribed forward-displacement objective is extraneous to those requirements.
This result must therefore be reported as a failed exploratory solver attempt,
not as evidence that the user's requested periodic gait is infeasible.

There are 2,600 control offsets. Exploratory iterations used only 20 mixed search
directions at a time; the refinement added a full initial-state Jacobian but only
18 coherent control directions. Neither phase computed the full control-to-error
Jacobian or its rank. No conclusion about insufficient muscle strength, rank
loss, or global infeasibility follows from these local searches.

A corrected formulation should treat periodic physical state matching as an
explicit equality (allowing free root forward translation), retain reference
tracking as the objective, preserve full simulator dynamics and input bounds, and
check free continuous replay. Additional translational-distance or absolute-height
objectives should not be silently introduced.
