from pathlib import Path
R=Path(__file__).resolve().parent
# Load problem definitions without launching the exploratory optimizer.
exec(compile((R/'solve.py').read_text().split('x=np.zeros(nvar);')[0],str(R/'solve.py'),'exec'))
x=np.load(R/'parameters_checkpoint.npz')['parameters'];r,met=evaluate(x);r=r[0];current=met[0];logs=[];print('START',json.dumps(current),flush=True)
for it in range(3):
 # Complete coordinate Jacobian for the initial pose/velocity; structured input directions are added separately.
 directions=[]
 for j in range(nuvar,nvar):
  d=np.zeros(nvar);d[j]=1;directions.append(d)
 for leg in range(6):
  lix=np.flatnonzero([str(v['id']).startswith(['LF','RF','LM','RM','LH','RH'][leg]+':') for v in rows])
  for wave in [np.ones(20),np.sin(np.arange(20)*2*np.pi/20),np.cos(np.arange(20)*2*np.pi/20)]:
   d=np.zeros(nvar);a=d[:nuvar].reshape(20,130);a[:,lix]=wave[:,None];directions.append(d)
 D=np.array(directions);h=.04;xp=np.clip(x+h*D,lo,hi);actual=((xp-x)*D).sum(axis=1)/np.sum(D*D,axis=1);good=abs(actual)>1e-9;D=D[good];xp=xp[good];actual=actual[good]
 rr,_=evaluate(xp);J=((rr-r[None])/actual[:,None]).T;ridge=max(np.linalg.norm(J,'fro')/np.sqrt(len(D))*.03,1e-6);step=np.linalg.lstsq(np.vstack([J,ridge*np.eye(len(D))]),np.r_[-r,np.zeros(len(D))],rcond=None)[0];step=np.clip(step,-2,2);direction=step@D;XX=np.clip(x[None]+np.array([1,.5,.2,.05,.01])[:,None]*direction,lo,hi);EE,MM=evaluate(XX);j=int(np.argmin([v['loss'] for v in MM]));accepted=MM[j]['loss']<current['loss']
 if accepted:x=XX[j];r=EE[j];current=MM[j]
 row=dict(iteration=it+1,accepted=accepted,evaluations=evaluations,wall_s=time.monotonic()-started,**current);logs.append(row);print(json.dumps(row),flush=True);(R/'shooting_refinement_history.json').write_text(json.dumps(logs,indent=2));evaluate(x,save=R/'optimized_cycle.npz');np.savez_compressed(R/'parameters_checkpoint.npz',parameters=x)
 if not accepted:break
(R/'optimization_result.json').write_text(json.dumps(dict(metrics=current,initial_exploratory_rounds=json.load(open(R/'optimization_history.json')),shooting_refinement_rounds=logs,wall_s=time.monotonic()-started,evaluations=evaluations,model_unchanged=True,no_intermediate_resets=True,no_extra_forces=True,original_seed='half_speed_angle_only_20261106',duration_s=.4,segments=20,periodic_activation_computed_for_initial_state=True,initial_pose_velocity_optimized=True,absolute_height_penalty=0,not_a_certificate_of_infeasibility=True),indent=2));print('DONE',flush=True)
