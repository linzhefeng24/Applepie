import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import numpy as np,mujoco,json,time
from mujoco import rollout
R=Path(__file__).resolve().parent;P=R.parent/'half_speed_angle_only_20261106';z=np.load(P/'rollout_5000Hz.npz');m=mujoco.MjModel.from_xml_path(str(R.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));src=np.load(P/'retimed_reference_5000Hz.npz');qa=src['joint_qpos_indices'];vd=src['joint_dof_indices'];init=z['initial_state'];ctrl=z['all_control_10000Hz'];data=[mujoco.MjData(m) for _ in range(4)];s=time.monotonic();S,_=rollout.rollout(m,data,init[None],np.tile(ctrl,(10,1))[None],initial_warmstart=z['initial_warmstart'][None],persistent_pool=True);print('seconds',time.monotonic()-s,flush=True);S=S[0];off=1+m.nq+m.nv
rows=[]
for k in range(10):
 st=S[(k+1)*4000-1];dq=st[1+qa]-init[1+qa];dv=st[1+m.nq+vd]-init[1+m.nq+vd];rows.append(dict(cycle=k+1,angle_closure_rms_deg=float(np.sqrt(np.mean(dq*dq))*180/np.pi),angle_closure_max_deg=float(max(abs(dq))*180/np.pi),velocity_closure_rms_rad_s=float(np.sqrt(np.mean(dv*dv))),activation_closure_rms=float(np.sqrt(np.mean((st[off:]-init[off:])**2))),forward_mm=float((st[1]-init[1])*10)))
print(json.dumps(rows),flush=True);(R/'baseline_replay.json').write_text(json.dumps(rows,indent=2));np.savez_compressed(R/'baseline_replay.npz',state=S[19::20],initial_state=init,controls_one_cycle=ctrl)
print('dims',m.nq,m.nv,m.na,m.nu,'dt',m.opt.timestep,'dyn',np.unique(m.actuator_dyntype,return_counts=True),'integrator',m.opt.integrator,flush=True)
