import os
os.environ.update(MUJOCO_GL='egl',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',LP_NUM_THREADS='2',MESA_SHADER_CACHE_DIR='/tmp/periodic-replay-mesa')
from pathlib import Path
import numpy as np,mujoco,imageio,json
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;m=mujoco.MjModel.from_xml_path(str(R.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));old=np.load(R/'baseline_replay.npz');new=np.load(R/'twenty_cycle_replay.npz');renderer=mujoco.Renderer(m,height=480,width=640);d=mujoco.MjData(m);opt=mujoco.MjvOption();opt.sitegroup[:]=0;opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False
for i in range(m.ngeom):
 if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
qa=new['joint_qpos_indices']
def image(z,f,label):
 I=z['initial_state'];s=I if f==0 else z['full_state' if 'full_state' in z.files else 'state'][f*5-1];mujoco.mj_setState(m,d,s,mujoco.mjtState.mjSTATE_FULLPHYSICS);mujoco.mj_forward(m,d);renderer.update_scene(d,camera=1,scene_option=opt);renderer.scene.flags[mujoco.mjtRndFlag.mjRND_REFLECTION]=False;renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW]=False;im=Image.fromarray(renderer.render());dr=ImageDraw.Draw(im);dr.rectangle((0,0,640,63),fill='black');dr.text((8,7),label,fill='white');dr.text((8,25),f't={f*.01:.2f} s | cycle {min(int((f*.01+1e-8)/.4)+1,5)}/5 | 4x slow motion',fill='white');dr.text((8,43),f'No state resets | forward={(s[1]-I[1])*10:.2f} mm',fill='white');return np.asarray(im)
with imageio.get_writer(R/'periodic_attempt_continuous_comparison.mp4',fps=25,codec='libx264',quality=8,macro_block_size=2) as writer:
 for f in range(200):
  im=np.concatenate([image(old,f,'Original 0.4 s inputs repeated'),image(new,f,'Periodic shooting attempt: repeated inputs')],axis=1);writer.append_data(im)
  if f in [0,100,199]:Image.fromarray(im).save(R/f'comparison_frame_{f:03d}.png')
  if f%50==0:print('frame',f,flush=True)
renderer.close();(R/'video_manifest.json').write_text(json.dumps(dict(physical_duration_s=2,display_duration_s=8,cycles=5,fps=25,frames=200,slowdown=4,no_state_resets=True,not_kinematic_playback=True),indent=2));print('DONE',flush=True)
