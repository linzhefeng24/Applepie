import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import numpy as np,mujoco,json,time,ctypes
from mujoco import rollout
from scipy.optimize import lsq_linear
R=Path(__file__).resolve().parent;P=R.parent/'half_speed_angle_only_20261106';z=np.load(P/'rollout_5000Hz.npz');ref=np.load(P/'retimed_reference_5000Hz.npz');m=mujoco.MjModel.from_xml_path(str(R.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));qa=ref['joint_qpos_indices'];vd=ref['joint_dof_indices'];initial=z['initial_state'].copy();base=z['all_control_10000Hz'].copy();rows=json.load(open(R.parent/'six_leg_model/activation_refine_20261104/records.json'))['records'];ids=np.array([r['actuator_index'] for r in rows]);adrs=m.actuator_actadr[ids];N=len(base);dt=m.opt.timestep;off=1+m.nq+m.nv;data=[mujoco.MjData(m) for _ in range(4)];rng=np.random.default_rng(20261107);lib=ctypes.CDLL(str(R/'act.so'));fn=lib.periodic;ptr=np.ctypeslib.ndpointer;fn.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_double,ptr(np.float64,flags='C_CONTIGUOUS'),ptr(np.int32,flags='C_CONTIGUOUS'),ptr(np.float64,flags='C_CONTIGUOUS'),ptr(np.float64,flags='C_CONTIGUOUS')];types=np.ascontiguousarray(m.actuator_dyntype,dtype=np.int32);prm=np.ascontiguousarray(m.actuator_dynprm);target=ref['qpos'][np.arange(100,2001,100)][:,qa];sample=np.arange(199,N,200);deg=180/np.pi;started=time.monotonic();history=[];evaluations=0
# All variable magnitudes are dimensionless. Full initial actual body state is allowed to vary;
# no changes to model parameters, and no state replacement inside any trajectory.
nuvar=20*130;nvar=nuvar+66+66+9
scale=np.r_[np.full(nuvar,.12),np.full(66,.12),np.full(66,12.),[.004,.02,.02,.02,.2,.2,.2,3.,3.]]
lo=np.r_[np.full(nuvar,-1.),np.full(66,-.6),np.full(66,-100.),[-.02,-.25,-.25,-.25,-1.,-1.,-1.,-30.,-30.]]/scale
hi=-lo
# Initial body parameters: dz, rotation xyz, velocity xyz, angular velocity xy (yaw held initial).
def decode(X):
 X=np.atleast_2d(X);W=X*scale;B=len(X);C=np.broadcast_to(base,(B,*base.shape)).copy();C[:,:,ids]=np.clip(base[None,:,ids]+W[:,:nuvar].reshape(B,20,130).repeat(200,axis=1),0,1)
 # Both ends of the excitation use one shared boundary value; short cubic blend preserves the interior seed.
 length=50;f=np.linspace(0,1,length);blend=3*f*f-2*f*f*f
 for b in range(B):
  seam=(C[b,0]+C[b,-1])/2
  C[b,:length]=seam[None]*(1-blend[:,None])+C[b,:length]*blend[:,None]
  C[b,-length:]=C[b,-length:]*(1-blend[:,None])+seam[None]*blend[:,None]
 A=np.empty((B,m.na));fn(B,N,m.na,dt,C,types,prm,A)
 I=np.broadcast_to(initial,(B,len(initial))).copy();I[:,1+qa]+=W[:,nuvar:nuvar+66];I[:,1+m.nq+vd]+=W[:,nuvar+66:nuvar+132];I[:,off:]=A
 for b in range(B):
  w=W[b,-9:];I[b,3]+=w[0];rot=np.zeros(m.nv);rot[3:6]=w[1:4];mujoco.mj_integratePos(m,I[b,1:1+m.nq],rot,1.);I[b,1+m.nq:1+m.nq+3]+=w[4:7];I[b,1+m.nq+3:1+m.nq+5]+=w[7:9]
 return np.ascontiguousarray(I),C

def evaluate(X,save=None):
 global evaluations
 X=np.atleast_2d(X);I,C=decode(X);S,_=rollout.rollout(m,data,I,C,persistent_pool=True);evaluations+=len(X);res=[];metrics=[]
 for b,s in enumerate(S):
  end=s[-1];q0=I[b,1:1+m.nq];q1=end[1:1+m.nq];v0=I[b,1+m.nq:off];v1=end[1+m.nq:off];dq=np.empty(m.nv);mujoco.mj_differentiatePos(m,dq,1.,q0,q1);dqleg=dq[vd];dvleg=(v1-v0)[vd];da=end[off:]-I[b,off:];path=s[sample][:,1+qa]-target;advance=(q1[0]-q0[0])*10
  # Closure has priority. Absolute height is not penalized; only return of relative vertical state.
  qclose=dq[1:108]/.1;qclose[:2]/=.2
  vclose=(v1-v0)[:108]/10.;vclose[:3]/=.1
  rr=np.r_[qclose/np.sqrt(len(qclose)),vclose/np.sqrt(108),da/.1/np.sqrt(m.na),.15*path.ravel()/.3/np.sqrt(path.size),2*(advance-4.)/4.,.015*X[b]/np.sqrt(nvar)]
  valid=np.isfinite(s).all() and abs(end[0]-.4)<1e-8
  if not valid:rr=np.full_like(rr,1e5)
  res.append(rr);metrics.append(dict(loss=float(rr@rr),angle_closure_rms_deg=float(np.sqrt(np.mean(dqleg*dqleg))*deg),angle_closure_max_deg=float(max(abs(dqleg))*deg),velocity_closure_rms_rad_s=float(np.sqrt(np.mean(dvleg*dvleg))),activation_closure_max=float(max(abs(da))),path_reference_rmse_deg=float(np.sqrt(np.mean(path*path))*deg),forward_mm=float(advance),root_vertical_closure_mm=float(dq[2]*10),valid=bool(valid)))
 if save:
  np.savez_compressed(save,initial_state=I[0],all_control_10000Hz=C[0],full_state=S[0,19::20],time_s=S[0,19::20,0],qpos=S[0,19::20,1:1+m.nq],qvel=S[0,19::20,1+m.nq:off],activation=S[0,19::20,off:][:,adrs],excitation=C[0,19::20][:,ids],parameters=X[0],joint_qpos_indices=qa,joint_dof_indices=vd,muscle_ids=z['muscle_ids'],joint_names=z['joint_names'])
 return np.array(res),metrics
x=np.zeros(nvar);r,met=evaluate(x,save=R/'periodic_activation_seed.npz');r=r[0];current=met[0];print('INITIAL',json.dumps(current),flush=True);(R/'periodic_activation_seed_metrics.json').write_text(json.dumps(current,indent=2));trust=1.
for it in range(16):
 # A rotating, bounded random subspace mixes all 20 time segments with initial pose/velocity corrections.
 K=20;D=rng.normal(size=(K,nvar));D[:,:nuvar]/=np.sqrt(20)
 if it%3==0:
  # coherent muscle offsets in time complement independent temporal search directions
  D[:6,:nuvar]=np.tile(rng.normal(size=(6,1,130)),(1,20,1)).reshape(6,nuvar)/2
 D/=np.maximum(np.sqrt(np.mean(D*D,axis=1))[:,None],1e-9)
 h=.08;xp=np.clip(x+h*D,lo,hi);xm=np.clip(x-h*D,lo,hi);rp,_=evaluate(xp);rm,_=evaluate(xm);J=((rp-rm)/(2*h)).T;ridge=max(np.linalg.norm(J,'fro')/np.sqrt(K)*.1,1e-5)
 step=np.linalg.lstsq(np.vstack([J,ridge*np.eye(K)]),np.r_[-r,np.zeros(K)],rcond=None)[0];step=np.clip(step,-trust,trust);direction=step@D
 candidates=np.clip(x[None]+np.array([1,.5,.2,.05])[:,None]*direction,lo,hi)
 rr,mm=evaluate(candidates);j=int(np.argmin([v['loss'] for v in mm]));before=current['loss'];accepted=mm[j]['loss']<before
 if accepted:x=candidates[j];r=rr[j];current=mm[j];trust=min(2.,trust*1.1)
 else:trust=max(.15,trust*.7)
 row=dict(iteration=it+1,accepted=accepted,evaluations=evaluations,wall_s=time.monotonic()-started,**current);history.append(row);print(json.dumps(row),flush=True);(R/'optimization_history.json').write_text(json.dumps(history,indent=2));np.savez_compressed(R/'parameters_checkpoint.npz',parameters=x)
 if it%4==3 or it==15:evaluate(x,save=R/'optimized_cycle.npz')
 if current['angle_closure_max_deg']<.1 and current['velocity_closure_rms_rad_s']<.01 and current['activation_closure_max']<1e-6:break
(R/'optimization_result.json').write_text(json.dumps(dict(metrics=current,history=history,wall_s=time.monotonic()-started,evaluations=evaluations,model_unchanged=True,no_intermediate_resets=True,no_extra_forces=True,original_seed='half_speed_angle_only_20261106',duration_s=.4,segments=20,periodic_activation_computed_for_initial_state=True,initial_pose_velocity_optimized=True,absolute_height_penalty=0,not_a_certificate_of_infeasibility=True),indent=2));evaluate(x,save=R/'optimized_cycle.npz');print('DONE',flush=True)
