import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,csv,numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'terminal_priority_20261105'));from problem import JointTrajectory
p=JointTrajectory();m=p.m;rng=np.random.default_rng(20261105);u=np.load(R.parent/'terminal_priority_20261105/optimized_rollout.npz')['control_knots'].copy();start=time.monotonic();cost,details=p.evaluate(u,save=R/'initial_rollout.npz');initial=details[0];history=[];blocked=set();expanded=set();max_suffix_error=0.;names=p.reference['joint_names'].tolist();tokens=['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right'];legs=['LF','RF','LM','RM','LH','RH'];moment=np.empty((m.nu,m.nv))

def prefix_cache(U):
 d=mujoco.MjData(m);mujoco.mj_setState(m,d,p.initial,mujoco.mjtState.mjSTATE_FULLPHYSICS);d.ctrl[:]=p.initial_ctrl;mujoco.mj_forward(m,d);ctrl=p.ctrl.copy();ctrl[:,p.ids]=U[p.blockids];snap=[];warm=[]
 for k in range(p.steps):
  if k%p.blocksteps==0:
   s=np.empty(len(p.initial));mujoco.mj_getState(m,d,s,mujoco.mjtState.mjSTATE_FULLPHYSICS);snap.append(s);warm.append(d.qacc_warmstart.copy())
  d.ctrl[:]=ctrl[k];mujoco.mj_step(m,d)
 return ctrl,snap,warm,d.qpos.copy()

def redistribute(g,error,lower,upper):
 du=np.zeros_like(g);free=np.abs(g)>1e-12
 for _ in range(len(g)+1):
  rem=-error-float(g@du)
  if abs(rem)<1e-10 or not free.any():break
  candidate=du.copy();candidate[free]+=rem*g[free]/max(float(g[free]@g[free]),1e-30);hit=free&((candidate<lower)|(candidate>upper));du[free]=np.clip(candidate[free],lower[free],upper[free])
  if not hit.any():break
  free[hit]=False
 return du,-error-float(g@du)

for it in range(10):
 c,dd=p.evaluate(u);base=c[0].copy();e=p.terminal_errors[0].copy();order=np.argsort(-abs(e));target=next((int(j) for j in order if int(j) not in blocked),int(order[0]));name=names[target]
 if np.max(abs(e))<.1*np.pi/180:break
 ctrl,snap,warm,baseq=prefix_cache(u);assert np.max(abs(baseq[p.qadrs]-p.target[-1]-e))<1e-9
 direct=set();d=mujoco.MjData(m)
 for s in snap:
  mujoco.mj_setState(m,d,s,mujoco.mjtState.mjSTATE_FULLPHYSICS);mujoco.mj_forward(m,d);mujoco.mju_sparse2dense(moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);direct.update(np.flatnonzero(abs(moment[p.ids,p.dofs[target]])>1e-12).tolist())
 scope='direct_paths'
 if target in expanded:
  leg=next(leg for leg,tok in zip(legs,tokens) if name.endswith(tok));direct.update(k for k,row in enumerate(p.rows) if row['leg']==leg);scope='whole_leg'
 muscles=np.array(sorted(direct),dtype=int)
 if len(muscles)==0:blocked.add(target);continue
 J=np.zeros((len(p.qadrs),p.blocks*len(muscles)));parameters=[]
 for block in range(p.blocks):
  first=block*p.blocksteps;h=np.where(u[block,muscles]<=.5,.02,-.02);batch=np.broadcast_to(ctrl[first:],(len(muscles)+1,*ctrl[first:].shape)).copy()
  for k,mus in enumerate(muscles):batch[k,:p.blocksteps,p.ids[mus]]+=h[k]
  states,_=rollout.rollout(m,p.data,snap[block][None],batch,initial_warmstart=warm[block][None],persistent_pool=True);ends=states[:,-1,1:1+m.nq][:,p.qadrs];check=float(np.max(abs(ends[-1]-baseq[p.qadrs])));max_suffix_error=max(max_suffix_error,check);assert check<1e-9,check
  J[:,block*len(muscles):(block+1)*len(muscles)]=((ends[:-1]-baseq[p.qadrs])/h[:,None]).T;parameters.extend((block,int(k)) for k in muscles)
 g=J[target];x=np.array([u[b,k] for b,k in parameters]);du,remaining=redistribute(g,e[target],-x,1-x);scales=np.array([.125,.25,.5,1.,1.5,2.,4.,8.]);candidates=np.broadcast_to(u,(len(scales),*u.shape)).copy()
 for j,scale in enumerate(scales):
  for k,(block,mus) in enumerate(parameters):candidates[j,block,mus]=np.clip(x[k]+scale*du[k],0,1)
 cc,cd=p.evaluate(candidates);ee=p.terminal_errors.copy();target_improve=abs(ee[:,target])<abs(e[target])-1e-9;global_improve=cc[:,0]<base[0]-1e-12;eligible=np.flatnonzero(target_improve&global_improve);accepted=len(eligible)>0
 if accepted:
  j=int(eligible[np.lexsort((cc[eligible,1],abs(ee[eligible,target])))[0]]);u=candidates[j].copy();chosen=ee[j];chosen_cost=cc[j];blocked.clear();expanded.discard(target)
 else:
  j=int(np.argmin(abs(ee[:,target])));chosen=e;chosen_cost=base
  if target in expanded:blocked.add(target)
  else:expanded.add(target)
 np.savez_compressed(R/f'sensitivity_{it+1:02d}.npz',J_terminal=J,parameter_block=np.array([b for b,k in parameters]),parameter_muscle=np.array([k for b,k in parameters]),muscle_ids=np.array([r['id'] for r in p.rows]),target_joint=name,terminal_error=e,proportional_delta=du,current_control=x,linear_remaining_error=remaining)
 with (R/f'time_allocation_{it+1:02d}.csv').open('w') as f:
  w=csv.writer(f);w.writerow(['time_begin_s','time_end_s','muscle_id','terminal_rad_per_excitation','current_u','proportional_delta_u','linear_terminal_correction_rad'])
  for k,(block,mus) in enumerate(parameters):w.writerow([block*.02,(block+1)*.02,p.rows[mus]['id'],g[k],x[k],du[k],g[k]*du[k]])
 h=dict(iteration=it+1,target_joint=name,scope=scope,parameters=len(parameters),target_before_deg=float(e[target]*180/np.pi),target_after_deg=float(chosen[target]*180/np.pi),accepted=bool(accepted),scale=float(scales[j]) if accepted else 0.,terminal_rmse_deg=float(np.sqrt(chosen_cost[0])*180/np.pi),path_rmse_deg=float(np.sqrt(chosen_cost[1])*180/np.pi),max_terminal_error_deg=float(np.max(abs(chosen))*180/np.pi),linear_unallocated_error_deg=float(remaining*180/np.pi),best_target_only_candidate_error_deg=float(ee[j,target]*180/np.pi),suffix_replay_max_error=max_suffix_error,wall_s=time.monotonic()-start);history.append(h);(R/'history.json').write_text(json.dumps(history,indent=2));np.savez_compressed(R/'checkpoint.npz',control_knots=u);print(json.dumps(h),flush=True)
final,fd=p.evaluate(u,save=R/'optimized_rollout.npz');e=p.terminal_errors[0];report=dict(method='sequential worst-terminal-joint proportional sensitivity allocation over muscle/time blocks, bounded redistribution and nonlinear multiplier search',horizon_s=.2,control_parameters=1300,iterations=len(history),initial=initial,final=fd[0],max_terminal_error_deg=float(np.max(abs(e))*180/np.pi),converged_to_requested_near_zero=bool(np.max(abs(e))<.1*np.pi/180),numerical_joint_tolerance_deg=.1,height_penalty=0,orientation_penalty=0,muscle_parameters_changed=False,extra_forces=False,intermediate_state_resets=False,suffix_replay_max_error=max_suffix_error,wall_s=time.monotonic()-start,stopping_reason='all joint terminal errors below tolerance' if np.max(abs(e))<.1*np.pi/180 else 'finite trial iteration budget reached; not a convergence or infeasibility proof',walking_validated=False)
(R/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
