import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import json,time,numpy as np
from problem import JointTrajectory,R
p=JointTrajectory();rng=np.random.default_rng(20261105);clock=time.monotonic();seeds=p.seeds();cost,details=p.evaluate(seeds);bi=int(np.lexsort((cost[:,1],cost[:,0]))[0]);u=seeds[bi].copy();current=cost[bi].copy();initial=current.copy();p.evaluate(u,save=R/'initial_rollout.npz');history=[];m=np.zeros_like(u);v=np.zeros_like(u);best_terminal=float(np.sqrt(current[0]));terminal_cap=None
print('INITIAL',json.dumps(dict(seed_index=bi,details=details[bi],parameters=u.size)),flush=True)
for it in range(24):
 stage='terminal' if it<16 else 'path_with_terminal_bound';eps=max(.012,.06*.96**it);delta=rng.choice([-1.,1.],size=(8,*u.shape));plus=np.clip(u+eps*delta,0,1);minus=np.clip(u-eps*delta,0,1);probes=np.concatenate([plus,minus]);cc,_=p.evaluate(probes);gT=np.mean(((cc[:8,0]-cc[8:,0])/(2*eps))[:,None,None]*delta,axis=0);gP=np.mean(((cc[:8,1]-cc[8:,1])/(2*eps))[:,None,None]*delta,axis=0)
 if stage=='terminal':g=gT
 else:
  if terminal_cap is None:terminal_cap=best_terminal+.05*np.pi/180
  g=gP.copy();dot=float(np.sum(gP*gT))
  if dot<0:g-=dot/max(float(np.sum(gT*gT)),1e-16)*gT
  m[:]=0;v[:]=0
 m=.8*m+.2*g;v=.95*v+.05*g*g;direction=(m/(1-.8**(it+1)))/(np.sqrt(v/(1-.95**(it+1)))+1e-10);steps=np.array([.08,.04,.02])*.98**it;gradient=np.clip(u[None]-steps[:,None,None]*direction[None],0,1);mutnoise=rng.normal(size=(8,*u.shape));mask=rng.random(mutnoise.shape)<.25;sigma=.08*.97**it;mutants=np.clip(u+sigma*mutnoise*mask,0,1);candidates=np.concatenate([gradient,mutants]);vc,_=p.evaluate(candidates);allU=np.concatenate([u[None],probes,candidates]);allC=np.vstack([current,cc,vc])
 if stage=='terminal':
  j=int(np.lexsort((allC[:,1],allC[:,0]))[0])
 else:
  eligible=np.flatnonzero(np.sqrt(allC[:,0])<=terminal_cap+1e-12);j=int(eligible[np.lexsort((allC[eligible,0],allC[eligible,1]))[0]])
 accepted=j!=0;u=allU[j].copy();current=allC[j].copy();best_terminal=min(best_terminal,float(np.sqrt(current[0])))
 if terminal_cap is not None:terminal_cap=min(terminal_cap,best_terminal+.05*np.pi/180)
 h=dict(iteration=it+1,stage=stage,accepted=accepted,terminal_rmse_deg=float(np.sqrt(current[0])*180/np.pi),path_rmse_deg=float(np.sqrt(current[1])*180/np.pi),terminal_cap_deg=None if terminal_cap is None else float(terminal_cap*180/np.pi),wall_s=time.monotonic()-clock);history.append(h);print(json.dumps(h),flush=True);(R/'history.json').write_text(json.dumps(history,indent=2));np.savez_compressed(R/'checkpoint.npz',control_knots=u,initial_control_knots=seeds[bi])
final,fd=p.evaluate(u,save=R/'optimized_rollout.npz');report=dict(method='joint full-horizon single-shooting search with projected stochastic-gradient and evolutionary candidates',objective='terminal joint-angle error first; then path error with terminal RMSE capped within 0.05 degree of best terminal result',horizon_s=.2,control_blocks=10,control_parameters=1300,iterations=24,initial_seed_index=bi,initial=details[bi],final=fd[0],terminal_cap_deg=float(terminal_cap*180/np.pi),height_penalty=0,orientation_penalty=0,velocity_penalty=0,torque_penalty=0,muscle_parameters_changed=False,intermediate_state_resets=False,walking_validated=False,wall_s=time.monotonic()-clock,limitations=['Finite stochastic/evolutionary search, not a globally optimal solution.','Reference is the existing simulated trajectory, not a measured live-fly trajectory.','Only 0.2 s jointly optimized, not an entire walking bout.'])
(R/'report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
