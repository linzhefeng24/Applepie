import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,numpy as np,mujoco
from mujoco import rollout
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'nonlinear_gradient_20261105'))
import importlib.util
spec=importlib.util.spec_from_file_location('prior_nonlinear_problem',R.parent/'nonlinear_gradient_20261105/problem.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
BASE=old.BASE
class JointTrajectory(old.Problem):
 def __init__(self):
  super().__init__(seconds=.2,threads=4,block_s=.02);self.reference={k:self.src[k] for k in ['qpos','ctrl','joint_names']};t=0.;times=[]
  for _ in range(self.steps):times.append(t);t+=self.m.opt.timestep
  self.end_times=np.array(times)+self.m.opt.timestep;f=np.rint(np.asarray(times)/.0002).astype(int);self.ctrl[:]=0.
  for i,j in self.retained:self.ctrl[:,j]=self.reference['ctrl'][f,i]
  self.target=self.reference['qpos'][np.rint(self.end_times[self.sample]/.0002).astype(int)][:,self.qadrs]
  self.fresh={k:v for k,v in np.load(R.parent/'angle_only_audit_20261105/moving_start/rollout_5000Hz.npz').items()};self.initial=self.fresh['initial_state'].copy();d=mujoco.MjData(self.m);mujoco.mj_setState(self.m,d,self.initial,mujoco.mjtState.mjSTATE_FULLPHYSICS)
  initial_ctrl=np.load(R.parent/'position_direction_20261105/hybrid/rollout_5000Hz.npz')['all_control'][0];self.initial_ctrl=initial_ctrl.copy();d.ctrl[:]=initial_ctrl;mujoco.mj_forward(self.m,d);self.warm=d.qacc_warmstart.copy()
 def seeds(self):
  full=self.fresh['excitation'];indices=np.minimum(np.arange(self.blocks)*self.blocksteps//2,len(full)-1);fresh=full[indices].copy();previous=np.load(R.parent/'nonlinear_gradient_20261105/optimized_rollout.npz')['control_knots'];return np.array([fresh,self.seed('closed_loop'),previous])
 def evaluate(self,U,save=None):
  U=np.asarray(U);U=U[None] if U.ndim==2 else U;assert U.shape[1:]==(self.blocks,130) and np.all((U>=0)&(U<=1));ctrl=np.broadcast_to(self.ctrl,(len(U),*self.ctrl.shape)).copy();ctrl[:,:,self.ids]=U[:,self.blockids]
  states,_=rollout.rollout(self.m,self.data,self.initial[None],ctrl,initial_warmstart=self.warm[None],persistent_pool=True)
  q=states[:,self.sample,1:1+self.m.nq][:,:,self.qadrs];e=q-self.target[None];terminal=np.mean(e[:,-1]**2,axis=1);path=np.mean(e**2,axis=(1,2));valid=np.isfinite(states).all(axis=(1,2))&np.all(np.isclose(states[:,:,0],self.end_times[None],atol=1e-8),axis=1);terminal=np.where(valid,terminal,1e6);path=np.where(valid,path,1e6)
  self.terminal_errors=e[:,-1].copy();self.path_errors=e.copy()
  details=[dict(terminal_mse_rad2=float(t),path_mse_rad2=float(v),terminal_rmse_deg=float(np.sqrt(t)*180/np.pi),path_rmse_deg=float(np.sqrt(v)*180/np.pi)) for t,v in zip(terminal,path)]
  if save:
   s=states[-1];h=np.arange(1,self.steps,2);off=1+self.m.nq+self.m.nv;a=s[:,off:][:,self.adrs]
   assert np.all((a>=0)&(a<=1));np.savez_compressed(save,time_s=s[h,0],full_state=s[h],qpos=s[h,1:1+self.m.nq],qvel=s[h,1+self.m.nq:off],activation=a[h],excitation=ctrl[-1,h][:,self.ids],all_control_10000Hz=ctrl[-1],initial_state=self.initial,initial_ctrl=self.initial_ctrl,control_knots=U[-1],joint_angle_rad=s[h,1:1+self.m.nq][:,self.qadrs],target_joint_angle=self.reference['qpos'][np.rint(s[h,0]/.0002).astype(int)][:,self.qadrs],muscle_ids=np.array([r['id'] for r in self.rows]),joint_names=self.reference['joint_names'])
   details[-1]['activation_all_physics_steps_min']=float(a.min());details[-1]['activation_all_physics_steps_max']=float(a.max())
  return np.column_stack([terminal,path]),details
