import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import json,time,sys,ctypes,numpy as np,mujoco,osqp
from scipy import sparse
from mujoco import rollout
R=Path(__file__).resolve().parent;OLD=R.parent/'half_speed_angle_only_20261106';raw=np.load(R/'optimization_seed_only.npz');ref=np.load(R/'reference_10000Hz.npz');MODEL=R.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml';m=mujoco.MjModel.from_xml_path(str(MODEL));m.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_WARMSTART)
qa=ref['joint_qpos_indices'];vd=ref['joint_dof_indices'];records=json.load(open(R.parent/'six_leg_model/activation_refine_20261104/records.json'))['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];assert np.array_equal(m.actuator_actadr,np.arange(m.na));ns=20;steps=63;nv=108;na=m.na;nx=2*nv+na;nu=len(ids);block=nx+nu;nvar=ns*block+1;ne=ns*nx;off=1+m.nq+m.nv;dt=m.opt.timestep;T=ns*steps*dt;data=[mujoco.MjData(m) for _ in range(4)];qs=np.r_[[.01]*3,[.1]*3,[.3]*(nv-6)];vs=np.r_[[.3]*3,[10.]*3,[50.]*(nv-6)];asc=np.full(na,.2);qbase=ref['qpos'][np.arange(ns)*steps].copy();vbase=ref['qvel'][np.arange(ns)*steps].copy();retained=np.setdiff1d(np.arange(m.nu),ids);basefull=raw['all_control_10000Hz'];ret=np.array([basefull[i*steps:(i+1)*steps].mean(axis=0) for i in range(ns)]);target=ref['qpos'][np.arange(ns)*steps][:,qa];targetend=ref['qpos'][-1,qa];start=time.monotonic();history=[];evalcount=0;fdh=.001
# Variables: all actual body coordinates/velocities and all internal activations at
# every shooting node, all 2,600 segment muscle commands, and a free translation.
lo=np.full(nvar,-np.inf);hi=-lo
for i in range(ns):
 b=i*block;lo[b+2*nv+adrs]=0;hi[b+2*nv+adrs]=1/asc[adrs];lo[b+nx:b+block]=0;hi[b+nx:b+block]=1
# Anchor the arbitrary global x origin only; do not constrain travel distance.
lo[0]=hi[0]=0

def log(kind,**kw):
 row=dict(kind=kind,wall_s=time.monotonic()-start,evaluations=evalcount,**kw);print(json.dumps(row,default=lambda v:v.item() if isinstance(v,np.generic) else v.tolist()),flush=True);(R/'status.json').write_text(json.dumps(row,indent=2,default=lambda v:v.item() if isinstance(v,np.generic) else v.tolist()));return row

def decode(x,i):
 b=x[i*block:(i+1)*block];q=qbase[i].copy();tangent=np.zeros(m.nv);tangent[:nv]=b[:nv]*qs;mujoco.mj_integratePos(m,q,tangent,1.);v=vbase[i].copy();v[:nv]+=b[nv:2*nv]*vs;a=b[2*nv:nx]*asc;return q,v,a

def node_state(x,i):
 q,v,a=decode(x,i);return np.r_[i*steps*dt,q,v,a]

def controls(x,i):
 u=ret[i].copy();u[ids]=x[i*block+nx:(i+1)*block];return np.broadcast_to(u,(steps,m.nu)).copy()

def defect(end,x,i):
 j=(i+1)%ns;q,v,a=decode(x,j)
 if i==ns-1:q[0]+=x[-1]*.1
 dq=np.empty(m.nv);mujoco.mj_differentiatePos(m,dq,1.,q,end[1:1+m.nq]);return np.r_[dq[:nv]/qs,(end[1+m.nq:off][:nv]-v[:nv])/vs,(end[off:]-a)/asc]

actlib=ctypes.CDLL(str(R/'periodic_activation.so'));periodicfn=actlib.periodic_nodes;arrayptr=np.ctypeslib.ndpointer
periodicfn.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_double,arrayptr(np.float64,flags='C_CONTIGUOUS'),arrayptr(np.int32,flags='C_CONTIGUOUS'),arrayptr(np.float64,flags='C_CONTIGUOUS'),arrayptr(np.float64,flags='C_CONTIGUOUS')]
dynkind=np.ascontiguousarray(m.actuator_dyntype,dtype=np.int32);dynprm=np.ascontiguousarray(m.actuator_dynprm)
def project_activation(x):
 commands=ret.copy()
 for i in range(ns):commands[i,ids]=x[i*block+nx:(i+1)*block]
 repeat=max(1,int(np.ceil(4.0/(8*T))));commands=np.tile(commands,(repeat,1));allvalues=np.empty((ns*repeat,na));periodicfn(ns*repeat,steps,na,dt,commands,dynkind,dynprm,allvalues);values=allvalues[:ns]
 for i in range(ns):
  sl=slice(i*block+2*nv,i*block+nx);x[sl]=values[i]/asc
  fixed=i*block+2*nv+retained
  if np.all(lo[fixed]==hi[fixed]):x[fixed]=lo[fixed]
 return values

def evaluate(x,save=False):
 global evalcount
 project_activation(x)
 I=np.array([node_state(x,i) for i in range(ns)]);C=np.array([controls(x,i) for i in range(ns)]);S,_=rollout.rollout(m,data,I,C,persistent_pool=True);evalcount+=ns;E=np.array([defect(S[i,-1],x,i) for i in range(ns)]);angles=np.array([decode(x,i)[0][qa] for i in range(ns)]);err=angles-target;enderr=angles[0]-targetend;tracking=float(np.mean(err*err));feas=float(np.linalg.norm(E));metrics=dict(defect_l2=feas,defect_max=float(abs(E).max()),node_angle_reference_rms_deg=float(np.sqrt(tracking)*180/np.pi),node_end_reference_rms_deg=float(np.sqrt(np.mean(enderr**2))*180/np.pi),free_displacement_mm=float(x[-1]),finite=bool(np.isfinite(S).all()))
 if save:np.savez_compressed(R/'shooting_candidate.npz',variables=x,node_states=I,segment_controls=C,node_end_states=S[:,-1],scaled_dynamics_defects=E,model_disable_warmstart=True)
 return E.ravel(),metrics,S[:,-1]

def jacobian(x,E,ends,refresh=None,old=None):
 global evalcount
 J=sparse.lil_matrix((ne,nvar)) if old is None else old.tolil(copy=True)
 for i in (range(ns) if refresh is None else refresh):
  b=i*block;state=node_state(x,i);ctrl=controls(x,i);M=np.zeros((nx,block));cols=list(range(nx+nu));tic=time.monotonic()
  for first in range(0,len(cols),64):
   selected=cols[first:first+64];I=[];C=[];hs=[]
   for col in selected:
    step=fdh
    if x[b+col]+step>hi[b+col]:step=-step
    if x[b+col]+step<lo[b+col] or lo[b+col]==hi[b+col]:hs.append(0.);I.append(state);C.append(ctrl);continue
    xx=x.copy();xx[b+col]+=step;I.append(node_state(xx,i));C.append(controls(xx,i));hs.append(step)
   S,_=rollout.rollout(m,data,np.array(I),np.array(C),persistent_pool=True);evalcount+=len(I)
   for k,(col,h) in enumerate(zip(selected,hs)):
    if h:M[:,col]=(defect(S[k,-1],x,i)-E[i*nx:(i+1)*nx])/h
  row=slice(i*nx,(i+1)*nx);J[row,:]=0;J[row,b:b+block]=M
  j=(i+1)%ns;jb=j*block;N=-np.eye(nx)
  # The scalar positions, velocities and activations have exact negative identity derivatives.
  # Quaternion tangent coordinates require the local manifold derivative.
  for col in range(3,6):
   xx=x.copy();xx[jb+col]+=fdh;N[:,col]=(defect(ends[i],xx,i)-E[i*nx:(i+1)*nx])/fdh
  J[row,jb:jb+nx]=J[row,jb:jb+nx]+N
  if i==ns-1:J[i*nx,nvar-1]=-.1/qs[0]
  log('jacobian_segment_complete',segment=i+1,seconds=time.monotonic()-tic,full_control_columns=nu,full_start_state_columns=nx)
 return J.tocsc()

def qpcorrection(x,E,J,tracking=False):
 # Explicit equality SQP in the tracking phase. Feasibility restoration uses an
 # elastic residual variable but never labels a nonzero defect as a feasible orbit.
 trust=.6;lower=np.maximum(lo-x,-trust);upper=np.minimum(hi-x,trust);lower[-1]=max(lo[-1]-x[-1],-3);upper[-1]=min(hi[-1]-x[-1],3)
 for node in range(ns):
  sl=slice(node*block+2*nv,node*block+nx);lower[sl]=np.maximum(lo[sl]-x[sl],-2.5);upper[sl]=np.minimum(hi[sl]-x[sl],2.5)
  sl=slice(node*block+nx,(node+1)*block);lower[sl]=lo[sl]-x[sl];upper[sl]=hi[sl]-x[sl]
 if not tracking:
  physical_rows=np.concatenate([np.arange(i*nx,i*nx+2*nv) for i in range(ns)]);nm=len(physical_rows);injection=sparse.csc_matrix((np.ones(nm),(physical_rows,np.arange(nm))),shape=(ne,nm));P=sparse.diags(np.r_[np.full(nvar,1e-7),np.ones(nm)],format='csc');q=np.zeros(nvar+nm);A=sparse.vstack([sparse.hstack([J,-injection]),sparse.hstack([sparse.eye(nvar),sparse.csc_matrix((nvar,nm))])],format='csc');l=np.r_[-E,lower];u=np.r_[-E,upper]
 else:
  diag=np.full(nvar,1e-7);g=np.zeros(nvar)
  for i in range(ns):
   index=i*block+vd;diag[index]+=qs[vd]**2;g[index]+=x[index]*qs[vd]**2
  # At node 0, the periodic end also contributes the original reference endpoint.
  index=vd;diag[index]+=qs[vd]**2;g[index]+=(decode(x,0)[0][qa]-targetend)*qs[vd]
  P=sparse.diags(diag,format='csc');q=g;A=sparse.vstack([J,sparse.eye(nvar)],format='csc');l=np.r_[-E,lower];u=np.r_[-E,upper]
 solver=osqp.OSQP();solver.setup(P=P,q=q,A=A,l=l,u=u,verbose=False,eps_abs=(1e-7 if tracking else min(1e-5,max(1e-8,np.linalg.norm(E)*1e-5))),eps_rel=(1e-7 if tracking else min(1e-5,max(1e-8,np.linalg.norm(E)*1e-5))),max_iter=8000,polishing=True,adaptive_rho=True);res=solver.solve();log('qp_result',tracking=tracking,status=res.info.status,iterations=res.info.iter,primal_residual=float(res.info.prim_res),dual_residual=float(res.info.dual_res))
 if res.x is None or not np.isfinite(res.x).all() or 'infeasible' in res.info.status:return None
 step=res.x[:nvar];predicted=E+J@step;log('linear_model_prediction',physical_residual_l2=float(np.linalg.norm(predicted.reshape(ns,nx)[:,:2*nv])),activation_residual_max=float(abs(predicted.reshape(ns,nx)[:,2*nv:]).max()),activation_constraints_hard=True);return step

x=np.zeros(nvar)
for i in range(ns):
 b=i*block;s=raw['initial_state'] if i==0 else raw['full_state'][i*steps-1];x[b+2*nv:b+nx]=s[off:]/asc;x[b+nx:b+block]=basefull[i*steps:(i+1)*steps,ids].mean(axis=0)
x[-1]=(ref['qpos'][-1,0]-ref['qpos'][0,0])*10
if (R/'checkpoint.npz').exists():x=np.load(R/'checkpoint.npz')['variables']
# Exactly solve the fixed-input retained filter periodic states (no numerical search).
beta=(1-dt/m.actuator_dynprm[retained,0])**steps;acc=np.zeros(len(retained))
for node in range(ns):acc=beta*acc+(1-beta)*ret[node,retained]
a0=acc/(1-beta**ns);act=a0.copy();known=[]
for node in range(ns):
 ix=node*block+2*nv+retained;known.append(act.copy());x[ix]=act/asc[retained];lo[ix]=hi[ix]=x[ix];act=beta*act+(1-beta)*ret[node,retained]
(R/'retained_periodic_reduction.json').write_text(json.dumps(dict(retained_actuator_ids=retained.tolist(),periodic_node_activation=np.array(known).tolist(),end_minus_start_max=float(abs(act-a0).max()),source='Exact Euler recurrence for fixed retained controls; physical activation states are set only at optimization nodes and initial free-replay state, never reset during validation.'),indent=2))
E,metrics,ends=evaluate(x,save=True);log('initial',**metrics);J=None
resume_iteration=0
if (R/'checkpoint.npz').exists():
 resume_iteration=int(np.load(R/'checkpoint.npz')['iteration'])
 if (R/'history.json').exists():history=json.load(open(R/'history.json'))
 if (R/'constraint_jacobian.npz').exists():J=sparse.load_npz(R/'constraint_jacobian.npz')
for iteration in range(resume_iteration,resume_iteration+10):
 if iteration==resume_iteration and J is not None and os.environ.get('REUSE_FULL_JACOBIAN_ONCE')=='1':refresh=[]
 elif J is None or iteration%4==0:refresh=None
 else:refresh=list(np.argsort(np.linalg.norm(E.reshape(ns,nx),axis=1))[::-1][:4])
 J=jacobian(x,E,ends,refresh=refresh,old=J);sparse.save_npz(R/'constraint_jacobian.npz',J)
 tracking=metrics['defect_max']<1e-5;step=qpcorrection(x,E,J,tracking)
 if step is None:log('no_qp_step',iteration=iteration+1);break
 accepted=False;best=None
 for alpha in [1.,.5,.2,.05,.01]:
  xx=np.minimum(np.maximum(x+alpha*step,lo),hi);EE,MM,end=evaluate(xx)
  # Feasibility is lexicographically prior to tracking; no displacement or height objective.
  ok=(MM['defect_l2']<metrics['defect_l2']-1e-9) if not tracking else (MM['defect_max']<1e-5 and MM['node_angle_reference_rms_deg']<metrics['node_angle_reference_rms_deg'])
  if ok and (best is None or MM['defect_l2']<best[2]['defect_l2']):best=(xx,EE,MM,end,alpha)
 if best is not None:
  oldx=x.copy();oldE=E.copy();x,E,metrics,ends,alpha=best;accepted=True;prediction=oldE+J@(x-oldx);log('nonlinear_step_check',line_alpha=float(alpha),linear_prediction_l2=float(np.linalg.norm(prediction)),actual_l2=float(np.linalg.norm(E)),prediction_error_l2=float(np.linalg.norm(E-prediction)))
  # Sparse block secant updates between complete derivative refreshes.
  for i in range(ns):
   j=(i+1)%ns;cols=np.r_[np.arange(i*block,(i+1)*block),np.arange(j*block,j*block+nx),[nvar-1] if i==ns-1 else []].astype(int);dx=(x-oldx)[cols];den=float(dx@dx)
   if den>1e-14:
    sl=slice(i*nx,(i+1)*nx);JJ=J[sl][:,cols].toarray();correction=(E-oldE)[sl]-JJ@dx;JJ+=np.outer(correction,dx)/den;JL=J.tolil();JL[sl,cols]=JJ;J=JL.tocsc()
  sparse.save_npz(R/'constraint_jacobian.npz',J)
  np.savez_compressed(R/'checkpoint.npz',variables=x,iteration=iteration+1)
 row=log('iteration',iteration=int(iteration+1),accepted=accepted,**metrics);history.append(row);(R/'history.json').write_text(json.dumps(history,indent=2));evaluate(x,save=True)
 if not accepted:log('stalled_refresh_next',iteration=iteration+1);J=None
 if tracking and metrics['node_angle_reference_rms_deg']<1:break
log('finished',**metrics);(R/'result.json').write_text(json.dumps(dict(metrics=metrics,history=history,variables=nvar,equality_constraints=ne,control_variables=ns*nu,explicit_cyclic_state_constraints=True,tracking_only_objective=True,forward_distance_objective=False,absolute_height_penalty=False,finite_search=True,free_rollout_validation_pending=True),indent=2))
