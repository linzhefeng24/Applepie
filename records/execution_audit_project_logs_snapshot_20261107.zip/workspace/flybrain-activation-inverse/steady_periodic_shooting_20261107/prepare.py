import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import numpy as np,mujoco,json
from scipy.interpolate import CubicHermiteSpline,BPoly
from scipy.optimize import lsq_linear
R=Path(__file__).resolve().parent;B=R.parent;raw=np.load(B/'reference_gait_period_20261107/representative_reference_cycle.npz');src=np.load('/workspace/fly-walking-run/output/walking_6s_5000Hz.npz');m=mujoco.MjModel.from_xml_path(str(B/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));old=mujoco.MjModel.from_xml_path('/workspace/fly-walking-run/output/model/walking.xml');records=json.load(open(B/'six_leg_model/activation_refine_20261104/records.json'))['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];retained=np.setdiff1d(np.arange(m.nu),ids);t=raw['time_s'];T=float(t[-1]);steps=63;ns=20;times=np.arange(ns*steps+1)*m.opt.timestep;assert abs(times[-1]-T)<1e-10
q=raw['qpos'].copy();v=raw['qvel'].copy();scalar=np.r_[np.arange(3),np.arange(7,109)];qd=v[:,np.r_[np.arange(3),np.arange(6,108)]];dq=q[-1,scalar]-q[0,scalar];dq[0]=0.;dv=qd[-1]-qd[0];correction=BPoly.from_derivatives([0,T],[[dq/2,dv/2],[-dq/2,-dv/2]])
y=q[:,scalar]+correction(t);yd=qd+correction.derivative()(t);spl=CubicHermiteSpline(t,y,yd);Q=np.broadcast_to(q[0],(len(times),m.nq)).copy();V=np.zeros((len(times),m.nv));ACC=np.zeros_like(V);Q[:,scalar]=spl(times);V[:,np.r_[np.arange(3),np.arange(6,108)]]=spl(times,1);ACC[:,np.r_[np.arange(3),np.arange(6,108)]]=spl(times,2)
# The body orientation is a seed only, not imposed on the evolving physical body.
Q[:,3:7]=q[0,3:7];V[:,3:6]=0;Q[:,109:]=q[0,109:];V[:,108:]=0
qa=src['joint_qpos_indices'];vd=src['joint_dof_indices'];C=np.zeros((ns*steps,m.nu));source_times=float(raw['original_time_s'][0])+.5*times[:-1];ix=np.clip(np.rint(source_times/.0002).astype(int),0,len(src['time_s'])-1)
for j in retained:
 name=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_ACTUATOR,int(j));k=mujoco.mj_name2id(old,mujoco.mjtObj.mjOBJ_ACTUATOR,name);assert k>=0;C[:,j]=src['ctrl'][ix,k]
# Periodic fixed-input filter values at nodes, using the same segment means as the solver.
ret=np.array([C[i*steps:(i+1)*steps].mean(axis=0) for i in range(ns)]);beta=(1-m.opt.timestep/m.actuator_dynprm[retained,0])**steps;acc=np.zeros(len(retained))
for i in range(ns):acc=beta*acc+(1-beta)*ret[i,retained]
a=acc/(1-beta**ns);known=[]
for i in range(ns):known.append(a.copy());a=beta*a+(1-beta)*ret[i,retained]
known=np.array(known);D=mujoco.MjData(m);mom=np.empty((m.nu,m.nv));alphas=[];fit=[]
for i in range(ns):
 k=i*steps;D.qpos[:]=Q[k];D.qvel[:]=V[k];D.act[:]=0.;D.act[retained]=known[i];D.ctrl[:]=ret[i];D.qacc[:]=ACC[k];mujoco.mj_inverse(m,D);desired=D.qfrc_inverse.copy();D.act[adrs]=0;mujoco.mj_forward(m,D);base=D.qfrc_actuator.copy();f0=D.actuator_force.copy();mujoco.mju_sparse2dense(mom,D.actuator_moment,D.moment_rownnz,D.moment_rowadr,D.moment_colind);D.act[adrs]=1;mujoco.mj_forward(m,D);gain=D.actuator_force-f0;A=(mom[ids].T*gain[ids])[vd];b=(desired-base)[vd];norm=max(np.linalg.norm(A),1e-12);sol=lsq_linear(np.vstack([A/norm,1e-4*np.eye(len(ids))]),np.r_[b/norm,np.zeros(len(ids))],bounds=(0,1),method='bvls',max_iter=200);alphas.append(sol.x);fit.append(float(np.linalg.norm(A@sol.x-b)/max(np.linalg.norm(b),1e-12)))
alpha=np.array(alphas);derivative=(np.roll(alpha,-1,axis=0)-np.roll(alpha,1,axis=0))/(2*T/ns);p=m.actuator_dynprm[ids];s=.5+1.5*alpha;tau=np.where(derivative>=0,p[None,:,0]*s,p[None,:,1]/s);U=np.clip(alpha+tau*derivative,0,1)
for i in range(ns):C[i*steps:(i+1)*steps,ids]=U[i]
off=1+m.nq+m.nv;state=np.zeros((len(times),1+m.nq+m.nv+m.na));state[:,0]=times;state[:,1:1+m.nq]=Q;state[:,1+m.nq:off]=V
for i in range(len(times)):
 node=min(i//steps,ns-1);state[i,off+retained]=known[node];state[i,off+adrs]=alpha[node]
np.savez_compressed(R/'reference_10000Hz.npz',time_s=times,qpos=Q,qvel=V,qacc=ACC,joint_names=src['joint_names'],joint_qpos_indices=qa,joint_dof_indices=vd)
np.savez_compressed(R/'optimization_seed_only.npz',initial_state=state[0],full_state=state[1:],all_control_10000Hz=C,static_inverse_alpha=alpha,muscle_ids=np.array([r['id'] for r in records]),joint_names=src['joint_names'])
report=dict(period_s=T,segments=ns,segment_steps=steps,segment_duration_s=T/ns,source_original_interval_s=[float(raw['original_time_s'][0]),float(raw['original_time_s'][-1])],reference_speed_factor=.5,reference_leg_angle_seam_max_deg=float(abs(Q[-1,qa]-Q[0,qa]).max()*180/np.pi),reference_leg_velocity_seam_max_rad_s=float(abs(V[-1,vd]-V[0,vd]).max()),inverse_seed_relative_torque_errors=fit,optimization_seed_is_not_physical_rollout=True,no_model_force_or_geometry_changes=True,no_rescue_forces=True)
(R/'preparation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
