import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import numpy as np,mujoco,json
from mujoco import rollout
R=Path(__file__).resolve().parent;z=np.load(R/'static_equilibrium_refined.npz');m=mujoco.MjModel.from_xml_path(str(R.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));m.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_WARMSTART);I=z['initial_state'].copy();I[0]=0;N=30000;C=np.broadcast_to(z['control'],(N,m.nu)).copy();S,_=rollout.rollout(m,[mujoco.MjData(m)],I[None],C[None]);S=S[0];d=mujoco.MjData(m);body=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');off=1+m.nq+m.nv;rows=[]
for k in np.arange(999,N,1000):
 mujoco.mj_setState(m,d,S[k],mujoco.mjtState.mjSTATE_FULLPHYSICS);d.ctrl[:]=z['control'];mujoco.mj_forward(m,d);hit=any((m.geom_bodyid[d.contact[c].geom1]==0 and m.geom_bodyid[d.contact[c].geom2]==body) or (m.geom_bodyid[d.contact[c].geom2]==0 and m.geom_bodyid[d.contact[c].geom1]==body) for c in range(d.ncon));rows.append(dict(time_s=float(d.time),body_up=float(d.xmat[body].reshape(3,3)[2,2]),torso_ground=bool(hit),actual_velocity_max=float(abs(d.qvel[:108]).max()),body_translation_mm=(d.qpos[:3]*10).tolist()))
np.savez_compressed(R/'static_relaxation.npz',full_state=S[99::100],initial_state=I,control=z['control'],terminal_state=S[-1]);report=dict(samples=rows,final_velocity_max=float(abs(S[-1,1+m.nq:off][:108]).max()),upright_no_torso_ground_all=all(r['body_up']>.95 and not r['torso_ground'] for r in rows),no_resets=True,no_applied_forces=True,initialization_only=True);(R/'static_relaxation_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
