# Steady reference period branch

This branch preserves the same muscle model and full explicit periodic-state
multiple shooting formulation as `explicit_periodic_shooting_20261107`. It uses
the previously closed reference cycle from source time 0.587..0.650 s at half
speed: 0.126 s physical period, 20 intervals of 6.3 ms. The original 0.4 s branch
is retained separately. Body orientation in the initial reference is a seed;
it is not imposed during physical simulations.

Preparation closes reference scalar coordinates and velocities smoothly and
estimates initial muscle commands with contact-aware inverse dynamics and bounded
force allocation. The static inverse is only a seed and may have significant
unachievable residual torque. Model geometry, force capacities and time constants
are not changed. There is no forward-distance target, absolute-height penalty,
extra force or physical state reset during validation.

`optimization_seed_only.npz` and shooting nodes are NOT physical free rollouts.
Only the separate continuous native simulation can establish periodic walking.
The native internal activation recurrence is projected onto a periodic response
for each trial input, while body-state and contact consistency are enforced by
explicit shooting equalities. See the sibling branch README for algorithm details.
