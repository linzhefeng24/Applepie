import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import numpy as np,mujoco,json,osqp,time
from scipy import sparse
R=Path(__file__).resolve().parent;ref=np.load(R/'reference_10000Hz.npz');seed=np.load(R/'optimization_seed_only.npz');m=mujoco.MjModel.from_xml_path(str(R.parent/'six_leg_model/closed_loop_contact_20261104/bounded_refined_muscles.xml'));m.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_WARMSTART);d=mujoco.MjData(m);records=json.load(open(R.parent/'six_leg_model/activation_refine_20261104/records.json'))['records'];ids=np.array([r['actuator_index'] for r in records]);adrs=m.actuator_actadr[ids];retained=np.setdiff1d(np.arange(m.nu),ids);nv=108;qa=ref['joint_qpos_indices'];vd=ref['joint_dof_indices'];qbar=ref['qpos'].mean(axis=0);qbar[3:7]=ref['qpos'][0,3:7];qbar[3:7]/=np.linalg.norm(qbar[3:7]);qbar[109:]=ref['qpos'][0,109:];ret=seed['all_control_10000Hz'].mean(axis=0);qi=np.r_[2,np.arange(7,109)];scale=np.r_[.01,np.full(102,.3),np.ones(130)];n=len(scale);lo=np.r_[-5,np.full(102,-3.4),np.zeros(130)];hi=np.r_[3,np.full(102,3.4),np.ones(130)]
for j in range(m.njnt):
 adr=m.jnt_qposadr[j]
 if 7<=adr<109 and m.jnt_limited[j]:
  k=1+adr-7;lo[k]=max(lo[k],(m.jnt_range[j,0]-qbar[adr])/.3);hi[k]=min(hi[k],(m.jnt_range[j,1]-qbar[adr])/.3)
body=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');weight=m.body_subtreemass[body]*np.linalg.norm(m.opt.gravity);fs=np.r_[np.full(3,weight),np.full(3,weight*.1),np.full(102,max(weight*.01,1e-6))];x=np.zeros(n);x[-130:]=.15;x=np.clip(x,lo,hi);started=time.monotonic();logs=[]
def calc(x):
 mujoco.mj_resetData(m,d);d.qpos[:]=qbar;d.qpos[qi]+=x[:103]*scale[:103];d.qvel[:]=0;d.ctrl[:]=ret;d.ctrl[ids]=x[-130:];d.act[retained]=ret[retained];d.act[adrs]=x[-130:];d.qacc[:]=0;mujoco.mj_inverse(m,d);required=d.qfrc_inverse.copy();mujoco.mj_forward(m,d);return (d.qfrc_actuator-required)[:nv]/fs
# Establish a contact-bearing initialization; this is a standing seed, not a gait result.
for k in range(500):
 E=calc(x);tokens=set()
 for c in range(d.ncon):
  con=d.contact[c];g=int(con.geom2) if m.geom_bodyid[con.geom1]==0 else int(con.geom1) if m.geom_bodyid[con.geom2]==0 else -1
  if g<0:continue
  name=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,g) or ''
  for tok in ['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right']:
   if tok in name:tokens.add(tok)
 if len(tokens)>=3:break
 x[0]-=.01
 if x[0]<=lo[0]:x[0]=lo[0];break
E=calc(x);print('INITIAL',float(np.linalg.norm(E)),len(tokens),flush=True)
for it in range(100):
 J=np.empty((nv,n));h=1e-4
 for k in range(n):
  step=h if x[k]+h<=hi[k] else -h
  if x[k]+step<lo[k]:J[:,k]=0;continue
  xx=x.copy();xx[k]+=step;J[:,k]=(calc(xx)-E)/step
 lower=np.maximum(lo-x,np.r_[-.25,np.full(102,-.25),np.full(130,-1.)]);upper=np.minimum(hi-x,np.r_[.25,np.full(102,.25),np.ones(130)]);P=sparse.diags(np.r_[np.full(n,1e-6),np.ones(nv)],format='csc');A=sparse.vstack([sparse.hstack([sparse.csc_matrix(J),-sparse.eye(nv)]),sparse.hstack([sparse.eye(n),sparse.csc_matrix((n,nv))])],format='csc');qp=osqp.OSQP();qp.setup(P=P,q=np.zeros(n+nv),A=A,l=np.r_[-E,lower],u=np.r_[-E,upper],verbose=False,eps_abs=1e-7,eps_rel=1e-7,max_iter=5000);sol=qp.solve()
 if sol.x is None:break
 step=sol.x[:n];best=None
 for alpha in [1,.5,.2,.05,.01]:
  xx=np.clip(x+alpha*step,lo,hi);ee=calc(xx)
  if ee@ee<E@E and (best is None or ee@ee<best[1]@best[1]):best=(xx,ee,alpha)
 if best is None:
  print('STALLED',it+1,float(np.linalg.norm(E)),flush=True);break
 x,E,alpha=best;row=dict(iteration=it+1,force_balance_l2=float(np.linalg.norm(E)),force_balance_max=float(abs(E).max()),step_alpha=float(alpha),wall_s=time.monotonic()-started);logs.append(row);print(json.dumps(row),flush=True)
 if abs(E).max()<1e-7:break
E=calc(x);q=d.qpos.copy();u=d.ctrl.copy();act=d.act.copy();qacc=d.qacc.copy();state=np.empty(mujoco.mj_stateSize(m,mujoco.mjtState.mjSTATE_FULLPHYSICS));mujoco.mj_getState(m,d,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);torso_contact=any((m.geom_bodyid[d.contact[c].geom1]==0 and m.geom_bodyid[d.contact[c].geom2]==body) or (m.geom_bodyid[d.contact[c].geom2]==0 and m.geom_bodyid[d.contact[c].geom1]==body) for c in range(d.ncon));report=dict(force_balance_l2=float(np.linalg.norm(E)),force_balance_max=float(abs(E).max()),forward_qacc_max=float(abs(qacc[:nv]).max()),leg_pose_mean_reference_rmse_deg=float(np.sqrt(np.mean((q[qa]-qbar[qa])**2))*180/np.pi),thorax_ground_contact=bool(torso_contact),initialization_only=True,history=logs);np.savez_compressed(R/'static_equilibrium_seed.npz',initial_state=state,control=u,qpos=q,activation=act,force_balance_scaled=E);(R/'static_equilibrium_report.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps(report),flush=True)
