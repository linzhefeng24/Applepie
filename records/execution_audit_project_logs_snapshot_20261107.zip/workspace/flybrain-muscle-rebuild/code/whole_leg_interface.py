"""Model-independent activation API for all registered leg muscle categories.
A category is not automatically one fiber, MTU, or motor unit. Missing parameters
are an explicit error; no FlyMimic defaults or firing-rate conversion is inherited.
"""
import math

def step(registry, states, commands, dt, parameters):
    if not math.isfinite(dt) or dt<=0:raise ValueError('dt must be positive seconds')
    ids={r['id'] for r in registry}
    if set(commands)!=ids or set(states)!=ids:raise ValueError('Every registered category needs an explicit state and command; unknown categories are not silently dropped')
    missing=[]
    for id in ids:
        p=parameters.get(id,{})
        if p.get('model')!='first_order_explicit_assumption' or p.get('tau_activation_s') is None or p.get('tau_deactivation_s') is None or not p.get('provenance'):
            missing.append(id)
    if missing:raise ValueError('Unparameterized channels: '+','.join(sorted(missing)))
    result={}
    for id in ids:
        a,u=states[id],commands[id];p=parameters[id]
        if not math.isfinite(a) or not math.isfinite(u) or not 0<=a<=1 or not 0<=u<=1:raise ValueError('Activation/excitation must be finite within [0,1]')
        ta=p['tau_activation_s'];td=p['tau_deactivation_s']
        if not math.isfinite(ta) or not math.isfinite(td) or min(ta,td)<=0:raise ValueError('Positive finite calibrated time constants required')
        tau=ta if u>=a else td
        result[id]=u+(a-u)*math.exp(-dt/tau)
    return result

def validate_mechanics(registry, parameters):
    required=['origin_insertion_geometry','moment_arm_function','max_isometric_force_N','optimal_fiber_length_m','tendon_slack_length_m','force_length_law','force_velocity_law','passive_force_law','parameter_provenance']
    missing={};invalid={}
    for r in registry:
        p=parameters.get(r['id'],{})
        absent=[k for k in required if p.get(k) is None]
        if absent:missing[r['id']]=absent
        bad=[]
        for key in ['max_isometric_force_N','optimal_fiber_length_m','tendon_slack_length_m']:
            x=p.get(key)
            if x is not None and (not isinstance(x,(int,float)) or not math.isfinite(x) or x<0 or (key!='tendon_slack_length_m' and x==0)):
                bad.append(key)
        if bad:invalid[r['id']]=bad
    return dict(ready=not missing and not invalid,missing=missing,invalid=invalid,warning='Necessary field/number checks only; not biomechanical validation. Excitation and activation are not forces. No torque may be generated for unparameterized anatomy.')
