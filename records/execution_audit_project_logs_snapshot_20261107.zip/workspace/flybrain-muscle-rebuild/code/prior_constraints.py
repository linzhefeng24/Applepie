"""Checks admissibility under DECLARED working priors, not biological truth."""
import math,numpy as np

def check_sample(priors,sample,interval='working'):
    errors=[];volumes={k:0. for k in priors['compartments']}
    expected={m['id'] for m in priors['muscles']}
    if set(sample)!=expected:return ['sample must explicitly cover all catalog slots']
    for m in priors['muscles']:
        x=sample[m['id']];p=m['estimated'];id=m['id']
        required=['muscle_volume_m3','fiber_length_m','pennation_rad','PCSA_m2','specific_stress_Pa','F0_N']
        if any(k not in x or not math.isfinite(x[k]) for k in required):errors.append(id+': missing/nonfinite parameter');continue
        v,l,alpha,area,sigma,f=[x[k] for k in required]
        if min(v,l,area,sigma,f)<=0 or not 0<=alpha<math.pi/2:errors.append(id+': positivity/pennation');continue
        if not math.isclose(v,area*l/math.cos(alpha),rel_tol=1e-7,abs_tol=1e-25):errors.append(id+': volume/area/length inconsistent')
        if not math.isclose(f,area*sigma,rel_tol=1e-7,abs_tol=1e-18):errors.append(id+': F0 not PCSA*stress')
        volumes[m['compartment']]+=v
        for name,value in [('muscle_volume_m3',v),('optimal_fiber_length_m',l),('pennation_angle_rad',alpha),('physiological_cross_sectional_area_m2',area),('specific_stress_Pa',sigma),('max_isometric_force_N',f)]:
            bounds=p[name].get('geometry_only_envelope') if interval=='geometry' and name=='max_isometric_force_N' else p[name]['working']
            if not bounds[0]-1e-24<=value<=bounds[1]+1e-24:errors.append(id+': outside declared '+name+' prior')
    for key,v in volumes.items():
        if v>priors['compartments'][key]['muscle_volume_budget_m3'][1]*(1+1e-8):errors.append(key+': shared muscle volume budget exceeded')
    return errors

def virtual_work_error(length_function,moment_arm_function,q,eps=1e-6):
    q=np.asarray(q,float);numerical=np.empty(len(q))
    for j in range(len(q)):
        a=q.copy();b=q.copy();a[j]+=eps;b[j]-=eps
        numerical[j]=-(length_function(a)-length_function(b))/(2*eps)
    claimed=np.asarray(moment_arm_function(q),float)
    if claimed.shape!=q.shape or not np.all(np.isfinite(claimed)):raise ValueError('invalid moment arm')
    return float(np.max(np.abs(claimed-numerical)))
