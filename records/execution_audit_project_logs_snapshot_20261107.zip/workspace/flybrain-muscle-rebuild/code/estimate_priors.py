"""Working priors, NOT measured confidence intervals or immutable biological limits.
Geometry is a Flybody specimen proxy; no torque-fit objective enters this script.
All numerical heuristic choices are explicit and provenance-tagged.
"""
from pathlib import Path
import json,math,collections,copy,hashlib,xml.etree.ElementTree as E
import numpy as np,mujoco
R=Path('/workspace/flybrain-muscle-rebuild');A=Path('/workspace/flybrain-recovered');OUT=R/'priors';OUT.mkdir(exist_ok=True)
catalog=json.load(open(R/'data/all_legs_catalog.json'));rows=catalog['catalog'];modelpath=Path('/workspace/fly-walking-run/output/model/walking.mjb');m=mujoco.MjModel.from_binary_path(str(modelpath))
tokens=dict(zip(['LF','RF','LM','RM','LH','RH'],['T1_left','T1_right','T2_left','T2_right','T3_left','T3_right']))
settings=dict(tissue_density_kg_m3=dict(working=[800,1300],initial=1050,status='weak tissue-density engineering prior'),specific_stress_Pa=dict(working=[10000,60000],initial=30000,exploratory=[1000,150000],basis='jump2012 and isolated-myofibril2026 constrain order of magnitude; not measured for every leg muscle'),compartment_muscle_fraction=dict(thorax=[.01,.20],leg=[.20,.80],thorax_initial=.04,leg_initial=.50,status='engineering occupancy prior; thorax budget is ONLY extrinsic leg musculature, not flight muscles'),volume_share=dict(lower_multiplier=.2,upper_multiplier=3.,jump_upper_multiplier=8.,basis='weak anatomical allocation prior; normalized initial shares; jointly constrained, never independently all maximized'),fiber_length_fraction=dict(thorax=[.02,.40],leg=[.25,1.0],initial_thorax=.15,initial_leg=.60),model_mass_uncertainty_factor=[.5,2.],status='All working intervals are revisable model-search bounds, not claimed measured biological extrema')
comp={}
# Relative model capacity/length products supply WEAK allocation weights only.
# Their global force/length unit scale cancels in the normalization; no ambiguous
# OpenSim raw force number is imported as a measured force in newtons.
reference=json.load(open(R/'data/muscle_anatomy.json'))['model_mtus']
ref_weights={}
for c in reference:
 if c['name'].startswith('LFC_tergopleural_promotor'):
  g='tergopleural_promotor'
 elif len(c['anatomical_group_candidates'])==1:g=c['anatomical_group_candidates'][0]
 else:continue
 f=c['native_gain_parameters'][2];l=c['opensim_parameters_raw']['optimal_fiber_length']
 ref_weights[g]=ref_weights.get(g,0)+max(float(f)*float(l),0)
def compartment(row):
 seg=row['housing_segment'];proxy=False
 if seg=='thorax':name='walker/thorax';key='thorax_shared_all_six_legs'
 else:
  if seg=='trochanter':seg='coxa';proxy=True
  name='walker/'+seg+'_'+tokens[row['leg']];key=row['leg']+':'+seg
 if key not in comp:
  bid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,name)
  ids=np.flatnonzero(m.geom_bodyid==bid);geoms=[int(i) for i in ids if m.geom_type[i]==int(mujoco.mjtGeom.mjGEOM_MESH)]
  dims=max((2*np.asarray(m.geom_size[i])*0.01 for i in geoms),key=lambda x:np.prod(x));dims=np.sort(dims);L=dims[-1];r1,r2=dims[:2]/2
  ellipsoid=4*math.pi/3*r1*r2*(L/2);mass=float(m.body_mass[bid])*1e-3
  # Model mass and enclosing ellipsoid are two uncertain size proxies, not microscopy PCSA.
  vlow=min(ellipsoid,mass/1300);vhigh=min(ellipsoid,mass/800);vnom=min(ellipsoid,mass/1050)
  comp[key]=dict(id=key,body_name=name,mass_kg=mass,principal_enclosing_dimensions_m=dims.tolist(),length_m=L,minor_radius_m=float(max(r1,r2)),area_proxy_m2=math.pi*r1*r2,volume_proxy_m3=[vlow,vhigh],volume_initial_m3=vnom,source='Flybody rigid-body mesh bounds + model mass, not measured muscle segmentation',shared_tissue_budget=True)
 return key,proxy
by=collections.defaultdict(list)
for row in rows:
 key,proxy=compartment(row);by[key].append(row)
priors=[]
def known_direction(row):
 g=row['category_id']
 if g in ['tibia_flexor','accessory_tibia_flexor']:return dict(coordinate='anatomical femur-tibia flexion-positive angle',reference_pose_sign=1,status='supported flexion action',scope='near reference stance; geometry must determine full posture-dependent moment arms')
 if g=='tibia_extensor':return dict(coordinate='anatomical femur-tibia flexion-positive angle',reference_pose_sign=-1,status='supported extension action')
 if g in ['tergotrochanter_extensor','sternotrochanter_extensor','trochanter_extensor']:return dict(coordinate='anatomical coxa-trochanter flexion-positive angle',reference_pose_sign=-1,status='supported extension action')
 if g in ['trochanter_flexor','accessory_trochanter_flexor']:return dict(coordinate='anatomical coxa-trochanter flexion-positive angle',reference_pose_sign=1,status='supported flexion action')
 if g=='tarsus_depressor':return dict(coordinate='anatomical tibia-tarsus flexion-positive angle',reference_pose_sign=-1,status='supported extension action')
 if g=='tarsus_levator':return dict(coordinate='anatomical tibia-tarsus flexion-positive angle',reference_pose_sign=1,status='supported flexion action')
 if g in ['tergopleural_promotor','pleural_promotor','sternal_anterior_rotator']:return dict(coordinate='anatomical coxa anterior-promotion-positive displacement',reference_pose_sign=1,status='qualitative anterior action; not assigned to one raw simulator axis')
 if g in ['pleural_remotor_and_abductor','sternal_posterior_rotator']:return dict(coordinate='anatomical coxa anterior-promotion-positive displacement',reference_pose_sign=-1,status='qualitative posterior action; secondary/cross-axis actions retained')
 if g=='sternal_adductor':return dict(coordinate='anatomical coxa adduction-positive displacement',reference_pose_sign=1,status='qualitative medial action')
 if g in ['long_tendon_muscle_1','long_tendon_muscle_2']:return dict(coordinate='long tendon shortening',reference_pose_sign=1,status='pulls common tendon; conversion to claw/joint angles requires tendon routing')
 return dict(coordinate=None,reference_pose_sign=None,status='insufficient functional evidence; do not infer a torque sign merely from a newly assigned name')
for key,members in by.items():
 c=comp[key];thorax=key=='thorax_shared_all_six_legs';n=len(members);fill=settings['compartment_muscle_fraction']['thorax' if thorax else 'leg'];fill0=settings['compartment_muscle_fraction']['thorax_initial' if thorax else 'leg_initial'];L=c['length_m'];r=c['minor_radius_m'];lf=settings['fiber_length_fraction']['thorax' if thorax else 'leg'];lmin,lmax=lf[0]*L,lf[1]*L;l0=settings['fiber_length_fraction']['initial_thorax' if thorax else 'initial_leg']*L
 available=[ref_weights[v['category_id']] for v in members if v['category_id'] in ref_weights];fallback=float(np.median(available)) if available else 1.
 weights={v['id']:ref_weights.get(v['category_id'],fallback) for v in members}
 for v in members:
  if v['leg'] in ['LM','RM'] and v['category_id']=='tergotrochanter_extensor':weights[v['id']]*=4
 wsum=sum(weights.values())
 c['muscle_volume_budget_m3']=[c['volume_proxy_m3'][0]*fill[0],c['volume_proxy_m3'][1]*fill[1]];c['initial_muscle_volume_budget_m3']=c['volume_initial_m3']*fill0
 for row in members:
  jump=row['leg'] in ['LM','RM'] and row['category_id']=='tergotrochanter_extensor';share0=weights[row['id']]/wsum;slo=.2*share0;shi=min(3.*share0,1.);v0=c['initial_muscle_volume_budget_m3']*share0;vlo=c['muscle_volume_budget_m3'][0]*slo;vhi=c['muscle_volume_budget_m3'][1]*shi
  # PCSA and volume must be sampled JOINTLY with length/pennation. Scalar bounds
  # are envelopes of feasible combinations, not independent hyper-rectangles.
  amin=vlo*math.cos(math.pi/6)/lmax;amax=min(vhi/lmin,c['area_proxy_m2']*shi*fill[1]/math.cos(math.pi/6));a0=v0/l0
  a0=min(max(a0,amin),amax);v0=a0*l0
  if row['category_id'] in ref_weights:
   # Additional explicitly model-informed search window, not empirical bounds.
   outer_area=[amin,amax]
   amin=max(amin,a0*.5);amax=min(amax,a0*2.)
  if row['category_id'] not in ref_weights:outer_area=[amin,amax]
  fmin=10000*amin;fmax=60000*amax;f0=30000*a0
  tendonmax=L*(3 if row['category_id'] in ['long_tendon_muscle_1','long_tendon_muscle_2'] else 1.5)
  record=dict(id=row['id'],name=row['name'],leg=row['leg'],compartment=key,geometry_proxy_for_missing_trochanter= row['housing_segment']=='trochanter',epistemic_status='estimated working prior; not measured interval or proven biological limit',presence_evidence=row['presence_evidence'],confidence='low, conditional on source-specimen geometry and occupancy assumptions',direction=known_direction(row),estimated=dict(
    fiber_count=dict(status='not identifiable for all muscles; aggregate-PCSA model does not require inventing a fiber count',traced_membership_evidence='use catalog observations for matching foreleg classes; not a six-leg total'),
    muscle_volume_m3=dict(working=[vlo,vhi],initial=v0,shared_budget=key),
    optimal_fiber_length_m=dict(working=[lmin,lmax],initial=l0,basis='fraction of enclosing compartment length; revise with local attachments/tracing; NOT a measured per-muscle interval'),
    pennation_angle_rad=dict(working=[0,math.pi/6],initial=0,exploratory=[0,math.pi/3],basis='weak engineering prior, not a measured angle for this muscle'),
    physiological_cross_sectional_area_m2=dict(working=[amin,amax],initial=a0,derived='volume*cos(pennation)/fiber_length; cross-section proxy envelope is an additional working restriction'),
    specific_stress_Pa=copy.deepcopy(settings['specific_stress_Pa']),
    max_isometric_force_N=dict(working=[fmin,fmax],initial=f0,geometry_only_envelope=[10000*outer_area[0],60000*outer_area[1]],derived='PCSA*specific_stress, not an independently fitted free force scale'),
    max_isometric_force_uN=dict(working=[fmin*1e6,fmax*1e6],initial=f0*1e6),
    moment_arm_m=dict(reference_abs_working=[.02*r,r],operating_abs_working=[0,r],reference_abs_initial=.3*r,basis='local geometry-based lever-arm prior; sign from anatomical action after coordinate mapping; zero crossings at other poses allowed'),
    line_of_action_orientation_uncertainty_deg=dict(working=[10,30],initial=20,exploratory=[5,45],basis='engineering error cone around an anatomically established nominal direction, not measured angular confidence; no nominal direction fabricated for unknown functions'),
    attachment_location_uncertainty_m=dict(working_radius=[.05*L,.20*L],initial_radius=.10*L,basis='engineering localization uncertainty around a verified anatomical attachment region; no numerical attachment center fabricated'),
    tendon_slack_length_m=dict(working=[0,tendonmax],initial=.3*L,basis='rough routing-length envelope; must satisfy reference path length = fiber_projection + tendon length'),
    vmax_optimal_fiber_lengths_per_s=dict(working=[5,100],initial=30,exploratory=[1,200],basis='model-derived order of magnitude checked against15 published MTUs (8.5–92.2 Lopt/s); not experimental bounds for all muscles'),
    activation_tau_s=dict(working=[.001,.150],initial=.020,exploratory=[.0001,.5],basis='engineering neural-activation timescale prior; NOT inverse of calcium-step force-development rate'),
    deactivation_tau_s=dict(working=[.002,.300],initial=.050,exploratory=[.0001,.8],basis='engineering activation-state prior; do not force measured biphasic myofibril relaxation into one constant'),
    active_force_length_gaussian_width=dict(working=[.25,.75],initial=.5,basis='optional engineering curve family in normalized fiber length, not directly measured shape'),
    force_velocity_hill_shape=dict(working=[.1,1.],initial=.25,eccentric_force_cap_ratio=[1.1,2.],basis='optional phenomenological family; force_velocity(0)=1 and zero active shortening force at vmax'),
    passive_fiber_law=dict(slack_normalized_length=[.9,1.2],strain_to_reach_F0=[.2,.8],exponential_shape=[2,8],basis='weak engineering curve prior, to be checked against joint/whole-muscle passive force measurements'),
    tendon_compliance=dict(strain_at_F0=[.005,.10],exploratory_strain_at_F0=[.001,.30],initial=.03,basis='sensitivity prior, not inferred from whole-leg stiffness; rigid-tendon limit is a separately declared model choice'),
    fatigue_recovery=dict(status='not identifiable from present anatomy/short-rollout evidence',baseline='explicitly omit fatigue in baseline, not a claim of zero biological fatigue',optional_sensitivity_only=dict(fatigue_time_s=[.1,100],recovery_time_s=[.1,1000]),basis='scenario exploration only; no literature-calibrated range claimed'),
    mn_to_fiber_weights=dict(status='topology unresolved in places; no unique numerical estimate',constraints='nonnegative bounded capacity fractions; normalized sum if additive capacity model is explicitly chosen; no uniform rate/100 mapping',initial=None,basis='bounds from normalization and force budget, not inferred motor-unit strength from neuron count')),
    coupling_rules=['same path geometry across all timestamps','moment_arm(q)=-d path_length(q)/dq, not an independently fitted time series','F0=PCSA*specific_stress','volume=PCSA*fiber_length/cos(pennation)','all muscle volumes in compartment sum within shared budget','attachment uncertainty regions must intersect the correct anatomical segment/attachment surface, never arbitrary points outside the body','reference path length compatible with fiber and tendon lengths','force-length/velocity/passive laws share the same physical state','map anatomical directions into model coordinates separately for each leg; retain cross-axis torques','no fit-driven expansion of force/geometry bounds without recording new evidence or revised assumptions'],
    allocation_prior=dict(reference_weight=weights[row['id']],normalized_share_initial=share0,reference_type='weak relative capacity-times-length from a model; NOT direct measured per-muscle force',model_informed_window= row['category_id'] in ref_weights,window_rule='for represented categories PCSA working search restricted to0.5–2 times size-budget initial value; revisable engineering restriction'),
    evidence=['vnc2024','manc_circuits','xnh2020','xnh_tracing','soler2004','recruitment2020','swank2012','jump2026','resilin2026','diversity2026','proprioception2023','flymimic2025'])
  priors.append(record)
result=dict(schema='muscle_working_priors_v1',date='2026-11-02',scope='all126 current catalog slots; categories are not certified individual fibers/MTUs',settings=settings,geometry_model=str(modelpath),geometry_model_sha256=hashlib.sha256(modelpath.read_bytes()).hexdigest(),compartments=comp,muscles=priors,not_used_for_estimation='Recorded walking torques were NOT used to set or widen any bounds.',interpretation='Working/search intervals, not measured confidence intervals or universal biological maxima. Initial values are explicit engineering starting hypotheses. Missing absolute attachment centers and ambiguous innervation still require reconstruction/identification.')
(OUT/'parameter_priors.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
# Attach estimates as estimates; preserve original measured/selected value fields.
for row in rows:row['estimated_parameters']=next(p for p in priors if p['id']==row['id'])
catalog['parameter_estimation']=dict(file=str(OUT/'parameter_priors.json'),status='engineering and anatomical working priors; not calibrated measurements',shared_compartment_budgets=True,force_fit_used=False)
(R/'data/all_legs_catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2));b=json.load(open(A/'brain.json'));b['version']='3.2.0-six-leg-working-priors';b['date']='2026-11-02';b['muscle_table']=catalog;b['muscle_activation']['parameter_prior_file']=str(OUT/'parameter_priors.json');(R/'brain.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n');temp=A/'brain.json.new';temp.write_bytes((R/'brain.json').read_bytes());temp.replace(A/'brain.json')
print('estimated',len(priors),'slots in',len(comp),'shared compartments')
for p in priors:
 if p['leg']=='LF':print(p['name'],[round(x,2) for x in p['estimated']['max_isometric_force_uN']['working']],round(p['estimated']['max_isometric_force_uN']['initial'],2))
