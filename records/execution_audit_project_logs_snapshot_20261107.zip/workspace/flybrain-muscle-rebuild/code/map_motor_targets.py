from pathlib import Path
import csv,json,collections,math
import pyarrow.feather as feather
R=Path('/workspace/flybrain-muscle-rebuild');source=R/'sources/elife-96084-supp3-v1.csv';s=list(csv.DictReader(source.open()));s=[v for v in s if v['subclass'] in ['fl','ml','hl']]
ann=next(Path('/workspace/flybrain-recovered/downloads/malecns').glob('body-annotations*'));t=feather.read_table(ann,columns=['bodyId','mancBodyid','superclass','subclass','type','somaSide','somaNeuromere','exitNerve','status']);bridge=collections.defaultdict(list)
for v in t.to_pylist():
 x=v['mancBodyid']
 if x is not None and math.isfinite(x) and v['status']=='Traced' and v['superclass']=='vnc_motor':bridge[int(x)].append(v)
out=[]
for v in s:
 side=v['exit_nerve'].rsplit('_',1)[-1];leg={'fl':'F','ml':'M','hl':'H'}[v['subclass']]
 if side not in ['L','R']:leg_id=None
 else:leg_id=side+leg
 matches=bridge[int(v['bodyid'])]
 out.append(dict(manc_body_id=int(v['bodyid']),leg=leg_id,target_label=v['target'],type=v['type'],group=v['group'],exit_nerve=v['exit_nerve'],match_certainty=v['match_certainty(1-5)'] or None,match_notes=v['match_notes'],publication_match=v['publication_match'],target_status='unidentified beyond leg' if v['target'] in ['middle leg','hind leg'] else 'published target; identity granularity varies',male_cns_matches=matches,bridge_status='unique annotated bridge' if len(matches)==1 else 'missing bridge' if not matches else 'ambiguous bridge',source='Cheong et al. eLife96084 supp3-v1; bridge MaleCNS v1.0 annotations; not independent new anatomical validation'))
(R/'data/motor_targets_all_legs.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('rows',len(out),'legs',collections.Counter(v['leg'] for v in out),'unidentified',sum(v['target_status']=='unidentified beyond leg' for v in out),'bridges',collections.Counter(v['bridge_status'] for v in out))
