"""Independent MTU allocation in a fixed, explicitly supplied mechanical state.
No gait generator, position servo, motor-neuron rate conversion, or muscle grouping.
All torques remain in the exact loaded MuJoCo model's native units.
"""
import mujoco
import numpy as np
from scipy.optimize import lsq_linear

def torque_map(model, qpos, qvel):
    if model.nu != model.na or not np.all(model.actuator_actnum == 1):
        raise ValueError('Require one activation state for every muscle actuator')
    if not np.all(model.actuator_dyntype == int(mujoco.mjtDyn.mjDYN_MUSCLE)):
        raise ValueError('Only native muscle actuators are supported')
    qpos, qvel = np.asarray(qpos,float), np.asarray(qvel,float)
    if qpos.shape != (model.nq,) or qvel.shape != (model.nv,):
        raise ValueError('Full model state is required; no implicit joint mapping')
    if not np.all(np.isfinite(qpos)) or not np.all(np.isfinite(qvel)):
        raise ValueError('State must be finite')
    data=mujoco.MjData(model);data.qpos[:]=qpos;data.qvel[:]=qvel
    data.act[:]=0;mujoco.mj_forward(model,data);passive=data.qfrc_actuator.copy()
    A=np.empty((model.nv,model.nu))
    for i in range(model.nu):
        data.act[:]=0;data.act[model.actuator_actadr[i]]=1
        mujoco.mj_forward(model,data);A[:,i]=data.qfrc_actuator-passive
    return A,passive

def allocate(model,qpos,qvel,tau_required,dofs,previous=None,regularization=0.,lower=None,upper=None):
    """tau_required is TOTAL muscle torque AFTER other mechanical terms are accounted for.
    Caller must supply physical torque demand and explicit joint indices. Kinematics
    alone does not determine ground reaction forces. No target is inferred here.
    previous/regularization selects among solutions; zero is the default to expose
    mechanical reachability. This static solve imposes no activation dynamics.
    """
    A,p=torque_map(model,qpos,qvel);dofs=np.asarray(dofs,dtype=int)
    target=np.asarray(tau_required,float)
    if dofs.ndim!=1 or len(dofs)==0 or len(set(dofs.tolist()))!=len(dofs) or np.any(dofs<0) or np.any(dofs>=model.nv):
        raise ValueError('Invalid or duplicate DOFs')
    if target.shape!=(len(dofs),) or not np.all(np.isfinite(target)):raise ValueError('Invalid target')
    if not np.isfinite(regularization) or regularization<0:raise ValueError('Invalid regularization')
    lo=np.zeros(model.nu) if lower is None else np.asarray(lower,float)
    hi=np.ones(model.nu) if upper is None else np.asarray(upper,float)
    if lo.shape!=(model.nu,) or hi.shape!=(model.nu,) or not np.all(np.isfinite(lo)) or not np.all(np.isfinite(hi)) or np.any(lo<0) or np.any(hi>1) or np.any(lo>=hi):raise ValueError('Invalid activation bounds')
    M=A[dofs];b=target-p[dofs];scale=max(float(np.linalg.norm(M,2)),1e-12)
    lhs=M/scale;rhs=b/scale
    if regularization:
        prev=np.asarray(previous,float)
        if prev.shape!=(model.nu,) or not np.all(np.isfinite(prev)) or np.any(prev<lo) or np.any(prev>hi):raise ValueError('Invalid prior')
        lhs=np.vstack((lhs,np.sqrt(regularization)*np.eye(model.nu)))
        rhs=np.r_[rhs,np.sqrt(regularization)*prev]
    result=lsq_linear(lhs,rhs,bounds=(lo,hi),tol=1e-12,max_iter=500)
    if not result.success:raise RuntimeError(result.message)
    achieved=(A@result.x+p)[dofs];residual=achieved-target
    # Independent native forward evaluation at the allocated activation state.
    data=mujoco.MjData(model);data.qpos[:]=qpos;data.qvel[:]=qvel
    data.act[model.actuator_actadr]=result.x;mujoco.mj_forward(model,data)
    if not np.allclose(data.qfrc_actuator[dofs],achieved,rtol=1e-10,atol=1e-10):raise RuntimeError('Native forward verification failed')
    norm=float(np.linalg.norm(target))
    return dict(activation=result.x,achieved=achieved,residual=residual,
                relative_residual=None if norm<1e-12 else float(np.linalg.norm(residual)/norm),
                at_upper=np.flatnonzero(result.x>=hi-1e-6),at_lower=np.flatnonzero(result.x<=lo+1e-6),
                rank=int(np.linalg.matrix_rank(M)),regularization=regularization,
                interpretation='static model-conditioned estimate; not measured neural activation')

def advance_activation(model, activation, excitation, dt):
    """Integrate native activation dynamics only, at fixed geometry; not a body step.
    Source XML time constants are retained as MODEL parameters, not measured biology.
    """
    from scipy.integrate import solve_ivp
    a=np.asarray(activation,float);u=np.asarray(excitation,float)
    if a.shape!=(model.na,) or u.shape!=(model.nu,) or not np.all(np.isfinite(a)) or not np.all(np.isfinite(u)) or np.any(a<0) or np.any(a>1) or np.any(u<model.actuator_ctrlrange[:,0]) or np.any(u>model.actuator_ctrlrange[:,1]) or not np.isfinite(dt) or dt<=0:
        raise ValueError('Invalid activation, excitation or duration')
    if model.nu!=model.na or not np.all(model.actuator_actnum==1) or not np.all(model.actuator_dyntype==int(mujoco.mjtDyn.mjDYN_MUSCLE)):raise ValueError('Native one-state muscles required')
    prm=model.actuator_dynprm[:,:3].copy()
    def derivative(t,state):
        out=np.zeros(model.na)
        for i in range(model.nu):out[model.actuator_actadr[i]]=mujoco.mju_muscleDynamics(float(u[i]),float(state[model.actuator_actadr[i]]),prm[i])
        return out
    sol=solve_ivp(derivative,(0,float(dt)),a,rtol=1e-8,atol=1e-10)
    if not sol.success:raise RuntimeError(sol.message)
    out=sol.y[:,-1]
    if np.any(out < -1e-8) or np.any(out > 1+1e-8):raise RuntimeError('Activation left physical interval')
    return np.clip(out,0,1)
