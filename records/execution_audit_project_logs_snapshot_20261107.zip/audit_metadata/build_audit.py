from pathlib import Path
from datetime import datetime,timezone
import os,json,hashlib,zipfile,time,shutil
R=Path('/workspace/exports/execution_audit_20261107');W=Path('/workspace');start=datetime.now(timezone.utc).isoformat();core=set();data=set();inventory=[];missing=[]
roots=[W/'flybrain-activation-inverse',W/'flybrain-muscle-rebuild',W/'flybrain-recovered',W/'fly-walking-run',W/'fly-platforms',W/'vnc-walking-evidence-20261104']
text_ext={'.py','.sh','.md','.txt','.json','.jsonl','.yaml','.yml','.toml','.csv','.log','.xml','.osim','.mot','.sto','.ini','.cfg','.ipynb','.tsv'}
skip={'__pycache__','.git','.venv','node_modules','site-packages','.cache','.codex','.agents','.aws','.ssh'}
def files(root):
 if root.is_file():yield root;return
 if not root.exists():return
 for base,dirs,names in os.walk(root):
  dirs[:]=[d for d in dirs if d not in skip and not d.startswith('venv') and not (root.name=='fly-walking-run' and d=='python')]
  for name in names:
   p=Path(base)/name
   if p.is_symlink() or name in {'auth.json','credentials.json','.env'}:continue
   if p.is_file():yield p
for root in roots:
 for p in files(root):
  st=p.stat();inventory.append({'path':str(p),'bytes':st.st_size,'mtime_ns':st.st_mtime_ns})
  if p.suffix.lower() in text_ext and st.st_size<=64*1024**2:core.add(p)
# All saved files from the recent numerical and PPO experiments, including failed runs.
recent=['reference_gait_period_20261107','periodic_replay_20261107','explicit_periodic_shooting_20261107','steady_periodic_shooting_20261107','flymimic_style_ppo_20261107','flymimic_style_ppo_torque_seed_20261107','half_speed_angle_only_20261106']
for name in recent:
 for p in files(W/'flybrain-activation-inverse'/name):
  (core if p.suffix.lower() in text_ext and p.stat().st_size<=64*1024**2 else data).add(p)
# Source model/weights and the actual full reference data used in the recent work.
for root in [W/'fly-platforms/FlyMimic',W/'fly-platforms/flybody',W/'fly-platforms/NeuroMechFly-v2',W/'fly-walking-run/output/model']:
 for p in files(root):(core if p.suffix.lower() in text_ext and p.stat().st_size<=64*1024**2 else data).add(p)
for name in ['walking_6s_5000Hz.npz','walking_angles_torques.npz']:
 p=W/'fly-walking-run/output'/name
 if p.exists():data.add(p)
# Files directly cited by the biological/model evidence database.
brain=json.loads((W/'flybrain-muscle-rebuild/brain.json').read_text());cited=[]
def refs(v):
 if isinstance(v,dict):
  for z in v.values():refs(z)
 elif isinstance(v,list):
  for z in v:refs(z)
 elif isinstance(v,str) and v.startswith('/workspace/'):
  q=Path(v.split('#')[0])
  if q.is_file() and not any(s in q.parts for s in skip):cited.append(q)
refs(brain)
original=W/'uploads/b1d50512-37b8-49fb-b31d-ba9acaa2b635.jsonl'
for p in cited:
 if p==original:continue
 if p.suffix.lower() in text_ext and p.stat().st_size<=64*1024**2:core.add(p)
 else:data.add(p)
# Exact uploaded/extracted texts reviewed in the current discussion.
for p in [W/'attachments/0b6ecc9a-c2b4-4f5d-b2bb-b2221b5b825e/已粘贴的文本.txt',Path('/tmp/flymimic_paper_review.txt')]:
 if p.exists():core.add(p)
p=W/'flybrain-recovered/downloads/papers/637976c19dda-2509.06426'
if p.exists():data.add(p)
for p in [W/'exports/本次对话工作摘要_20261107.md',W/'exports/本次对话工作摘要_20261107.txt']:
 if p.exists():core.add(p)
data-=core
(R/'workspace_file_inventory.json').write_text(json.dumps({'captured_at_utc':start,'files':inventory,'note':'Inventory lists project files; not all listed binary files are included in the archives.'},ensure_ascii=False,indent=2))
commands='''# 可核实的近期执行命令（不是完整历史 shell 录制）
# 以下入口曾在本会话中实际执行。重定向日志与脚本一并提供。
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/reference_gait_period_20261107/analyze.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/reference_gait_period_20261107/close_cycle.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/reference_gait_period_20261107/render_loop.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/periodic_replay_20261107/probe.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/periodic_replay_20261107/solve.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/periodic_replay_20261107/refine_shooting.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/periodic_replay_20261107/validate.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/explicit_periodic_shooting_20261107/solver.py
REUSE_FULL_JACOBIAN_ONCE=1 /workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/explicit_periodic_shooting_20261107/solver.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/explicit_periodic_shooting_20261107/verify_activation_projection.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/explicit_periodic_shooting_20261107/check_directional_derivative.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/explicit_periodic_shooting_20261107/check_repeatability.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/steady_periodic_shooting_20261107/prepare.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/steady_periodic_shooting_20261107/solver.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/steady_periodic_shooting_20261107/static_seed.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/steady_periodic_shooting_20261107/refine_static_seed.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/steady_periodic_shooting_20261107/relax_static_seed.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/flymimic_style_ppo_20261107/environment.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/flymimic_style_ppo_20261107/train.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/flymimic_style_ppo_20261107/replay_recorded.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/flymimic_style_ppo_20261107/torque_seed_search.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/flymimic_style_ppo_torque_seed_20261107/train.py
/workspace/fly-platforms/reproduction/venv-flymimic/bin/python /workspace/flybrain-activation-inverse/flymimic_style_ppo_torque_seed_20261107/time_constant_ablation.py
python /workspace/vnc-walking-evidence-20261104/validate_brain_evidence.py
pdftotext -layout /workspace/flybrain-recovered/downloads/papers/637976c19dda-2509.06426 /tmp/flymimic_paper_review.txt
'''
(R/'confirmed_recent_commands.txt').write_text(commands)
(R/'decision_rationale.md').write_text('''# 工作决策依据摘要

这是可核查的工作理由摘要，不是内部逐字思考记录。

- 参考周期从六腿运动轨迹及支撑记录估计，选取近似重复的一段；平滑修改使参考角度与速度闭合。参考闭合与自由身体闭合需分别验证。
- 激励 u 与内部激活 a 不同。给定周期输入可求周期激活响应，但这不自动使关节、身体和接触状态闭合。
- 早期搜索只用了少量组合方向，且加权总损失曾接受关节误差恶化的更新；因此不能据此推断模型无解。相关失败记录保留。
- 随后采用包含全部分段输入的多重打靶，建立相邻段和周期状态等式。优化节点在动力学缺陷未消除前不视为有效自由轨迹。
- 周期激活投影需要与线性子问题的激活约束一致；曾修正子问题允许激活残差而候选又进行周期投影的问题。
- 独立方向导数检查仍发现线性预测不可靠。重复仿真与扰动/求解精度测试记录已保留；没有将这一结果宣称为全局不可行证明。
- FlyMimic 主要验证前腿运动重现；其 OpenSim 参数标定使用 SO/FD 与 NSGA-II，MuJoCo 控制阶段使用 PPO。其验证规模与六腿带接触行走不同。
- PPO 方法用真实仿真采样更新策略，不需要对接触过程求解析导数。第一轮 32768 步未走起来；随后改进肌肉初始输入并继续训练。
- 力矩分配初值搜索没有增大肌肉力量。另做的时间常数诊断只修改明确标为未知的工程先验，并与固定模型训练分开记录。
- FlyGM 文献按计算控制模型存档；网络隐状态/PCA 强度不当作实验放电率，默认 59 执行器控制不当作解剖肌肉验证。
''')
coverage={'snapshot_started_utc':start,'scope':'Available project execution audit; not a complete verbatim conversation export','missing_or_unavailable':['Complete current ChatGPT/Codex message and tool-call export is not exposed by available tools.','Internal hidden chain-of-thought is not provided; a decision-rationale summary is included.','Commands/stdout not saved in project files cannot be reconstructed as an exact complete historical transcript.'],'original_user_archive':{'path':str(original),'bytes':original.stat().st_size,'url':'https://github.com/linzhefeng24/Applepie/releases/download/data_v2/b1d50512-37b8-49fb-b31d-ba9acaa2b635.jsonl','included_in_new_archives':False,'reason':'Original user-provided historical archive, separately available; not the current conversation.'},'core_files_selected':len(core),'data_files_selected':len(data),'core_bytes_selected':sum(p.stat().st_size for p in core),'data_bytes_selected':sum(p.stat().st_size for p in data),'source_files_referenced_by_brain':len(set(cited))}
(R/'coverage_and_limits.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2));print(json.dumps(coverage,ensure_ascii=False),flush=True)
(R/'README_请先阅读.md').write_text('''# 可取得的执行审计记录

本包提供实际项目文件，不是完整聊天逐字导出。

## 内容

1. `01_code_logs_and_review.zip`：现有脚本、日志、配置、brain.json、阅读记录、命令入口及范围说明。
2. `02_recent_data_models_and_weights.zip`：近期完整实验目录的二进制数据、轨迹、模型、权重、原始参考与 brain.json 直接引用的可取得证据文件。
3. `file_manifest.json`：逐文件原路径、归档位置、字节数和 SHA-256。
4. `workspace_file_inventory.json`：项目目录文件清单。清单存在不代表所有未引用的大型下载资产都已打包。
5. `confirmed_recent_commands.txt`：可核实的近期执行入口；不是伪造的完整 shell 历史。
6. `decision_rationale.md`：工作理由与证据摘要。
7. `coverage_and_limits.json`：范围、缺失项和最初历史 JSONL 的原始下载地址。

## 边界

当前环境没有完整会话原始消息/逐次工具调用的导出接口。内部逐字思考不提供。未保存的历史命令和输出没有伪造补全。

保留失败、中断、修复、校验不通过及未能行走的记录。优化节点、运动学参考、反馈回放和无反馈回放不可混同。PPO 奖励改善不代表严格周期闭环或正常行走。

归档保持项目路径层级，未重写源代码中的绝对路径。文件按读取时间做稳定性检查；活跃训练的不同文件可能来自本次打包时间区间内不同瞬间，不是运行进程内存快照。
''')
# Capture stable bytes; avoid silently archiving a half-written live checkpoint.
manifest=[]
def arcname(p):
 if p.is_relative_to(W):return 'workspace/'+str(p.relative_to(W))
 return 'extracted_reviews/'+p.name

def add(z,p):
 for attempt in range(4):
  before=p.stat();blob=p.read_bytes();after=p.stat()
  if before.st_size==after.st_size==len(blob) and before.st_mtime_ns==after.st_mtime_ns:break
  time.sleep(.2)
 else:missing.append({'path':str(p),'reason':'File changed repeatedly while capturing snapshot'});return
 arc=arcname(p);compression=zipfile.ZIP_DEFLATED if p.suffix.lower() in text_ext or p.suffix.lower() in {'.obj','.npy'} else zipfile.ZIP_STORED;z.writestr(arc,blob,compress_type=compression,compresslevel=3 if compression==zipfile.ZIP_DEFLATED else None);manifest.append({'source':str(p),'archive':Path(z.filename).name,'member':arc,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'source_mtime_ns':after.st_mtime_ns})
for filename,paths in [('01_code_logs_and_review.zip',core),('02_recent_data_models_and_weights.zip',data)]:
 with zipfile.ZipFile(R/filename,'w',allowZip64=True) as z:
  for i,p in enumerate(sorted(paths)):
   try:add(z,p)
   except (OSError,ValueError) as e:missing.append({'path':str(p),'reason':str(e)})
   if i%250==0:print(filename,'captured',i,'of',len(paths),flush=True)
  if filename.startswith('01_'):
   for p in R.iterdir():
    if p.is_file() and p.suffix in {'.md','.txt','.json'}:z.write(p,'audit_metadata/'+p.name,compress_type=zipfile.ZIP_DEFLATED,compresslevel=3)
 print('ARCHIVE_DONE',filename,(R/filename).stat().st_size,flush=True)
(R/'file_manifest.json').write_text(json.dumps({'snapshot_started_utc':start,'snapshot_finished_utc':datetime.now(timezone.utc).isoformat(),'files':manifest,'capture_failures':missing},ensure_ascii=False,indent=2))
checks=[]
for name in ['01_code_logs_and_review.zip','02_recent_data_models_and_weights.zip']:
 p=R/name;h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 checks.append(h.hexdigest()+'  '+name)
(R/'SHA256SUMS.txt').write_text('\n'.join(checks)+'\n');print('FINISHED',len(manifest),'files','capture_failures',len(missing),flush=True)
