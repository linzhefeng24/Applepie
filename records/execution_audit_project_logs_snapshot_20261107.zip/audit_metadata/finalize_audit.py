from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,zipfile,os
R=Path(__file__).resolve().parent;W=Path('/workspace');M=json.loads((R/'file_manifest.json').read_text());entries=M['files'];by_source={e['source']:e for e in entries};exts={'.py','.sh','.md','.txt','.json','.jsonl','.yaml','.yml','.toml','.csv','.log','.xml','.osim','.mot','.sto','.ini','.cfg','.ipynb','.tsv'};new=[]
archives={n:zipfile.ZipFile(R/n,'a',allowZip64=True) for n in ['01_code_logs_and_review.zip','02_recent_data_models_and_weights.zip']}
for name in ['flymimic_style_ppo_20261107','flymimic_style_ppo_torque_seed_20261107']:
 root=W/'flybrain-activation-inverse'/name
 for p in root.rglob('*'):
  if not p.is_file() or '__pycache__' in p.parts:continue
  old=by_source.get(str(p));st=p.stat()
  if old and old['source_mtime_ns']==st.st_mtime_ns and old['bytes']==st.st_size:continue
  blob=p.read_bytes();h=hashlib.sha256(blob).hexdigest()
  if old and old['sha256']==h:continue
  archive='01_code_logs_and_review.zip' if p.suffix.lower() in exts else '02_recent_data_models_and_weights.zip';arc=('post_snapshot_updates/' if old else '')+'workspace/'+str(p.relative_to(W));z=archives[archive];assert arc not in z.namelist();z.writestr(arc,blob,compress_type=zipfile.ZIP_DEFLATED if archive.startswith('01_') else zipfile.ZIP_STORED,compresslevel=3 if archive.startswith('01_') else None);row=dict(source=str(p),archive=archive,member=arc,bytes=len(blob),sha256=h,source_mtime_ns=st.st_mtime_ns,capture='post_training_update');entries.append(row);new.append(row)
M['snapshot_finished_utc']=datetime.now(timezone.utc).isoformat();M['post_snapshot_update_count']=len(new);(R/'file_manifest.json').write_text(json.dumps(M,ensure_ascii=False,indent=2));(R/'post_training_updates.json').write_text(json.dumps(new,ensure_ascii=False,indent=2))
status={}
for name in ['flymimic_style_ppo_20261107','flymimic_style_ppo_torque_seed_20261107']:
 p=W/'flybrain-activation-inverse'/name/'training_summary.json';status[name]=json.loads(p.read_text()) if p.exists() else {'status':'No completed training summary captured'}
(R/'latest_training_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2))
inventory=json.loads((R/'workspace_file_inventory.json').read_text())['files'];included={e['source'] for e in entries};omitted=[x for x in inventory if x['path'] not in included];(R/'project_files_not_in_archives.json').write_text(json.dumps({'note':'Explicit inventory of other project files not included; mostly old binary experiments and downloaded assets. This export is not a complete workspace or chat export.','files':omitted},ensure_ascii=False,indent=2))
z=archives['01_code_logs_and_review.zip']
for name in ['build_audit.py','finalize_audit.py','file_manifest.json','runtime_versions.json','latest_training_status.json','post_training_updates.json','project_files_not_in_archives.json']:
 z.write(R/name,'audit_metadata/'+name,compress_type=zipfile.ZIP_DEFLATED,compresslevel=3)
for z in archives.values():z.close()
# One streaming pass verifies ZIP CRCs and every manifest payload SHA-256.
lookup={(e['archive'],e['member']):e for e in entries};verified=0;members=0
for name in archives:
 with zipfile.ZipFile(R/name) as z:
  for info in z.infolist():
   h=hashlib.sha256()
   with z.open(info) as f:
    for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
   expected=lookup.get((name,info.filename))
   if expected:
    assert h.hexdigest()==expected['sha256'],info.filename;verified+=1
   members+=1
 print('VERIFIED',name,'members',len(z.infolist()),flush=True)
checks=[]
for name in archives:
 h=hashlib.sha256()
 with (R/name).open('rb') as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
 checks.append(h.hexdigest()+'  '+name)
(R/'SHA256SUMS.txt').write_text('\n'.join(checks)+'\n');(R/'verification_report.json').write_text(json.dumps(dict(archive_members_crc_verified=members,payload_sha256_verified=verified,manifest_payload_files=len(entries),post_training_updates=len(new),all_payload_hashes_match=verified==len(entries),completed_utc=datetime.now(timezone.utc).isoformat()),indent=2));print('FINISHED',members,verified,'late updates',len(new),flush=True)
