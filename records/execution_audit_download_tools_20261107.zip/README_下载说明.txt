执行审计资料下载工具

Windows：解压此工具包后，按需要双击：
- download_code_only_windows.cmd：原始完整代码、日志及阅读记录ZIP，约184MiB。
- download_data_only_windows.cmd：原始数据、模型、权重ZIP，约2.9GiB。
- download_all_windows.cmd：以上两份都下载。

Windows脚本使用自带curl.exe和PowerShell，不需要安装Python。文件会下载到工具所在目录，按32MiB块校验SHA-256，再自动合并为原始ZIP。请等待“Merged and verified”提示再解压。网络中断后可重新运行，已正确下载的块会跳过。

其他平台：在终端运行 python download_audit.py；只下载代码可运行 python download_audit.py --only code。

合并时需要同时保存分块和输出ZIP，全部资料建议预留至少7GB空间。合并完成后可以删除.audit_chunks目录节省空间。

这是2026-11-07 16:34–16:38（北京时间）的项目资料快照，不是当前聊天的完整逐字记录。包含实际保存的代码、日志、实验资料；没有内部逐字思考，也没有补造未保存的消息/工具调用。快照之后的试验不自动包含在内。
