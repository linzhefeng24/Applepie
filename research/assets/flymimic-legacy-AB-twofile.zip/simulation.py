"""旧A/B完整模型的双文件接口：只读取同目录parameters.yaml。

YAML的mjcf树定义骨架、关节位置/轴/限位、惯性、肌肉附着/路径/常数、
接触、黏附和求解参数；原始OBJ压缩内嵌并逐文件校验，无外部模型依赖。
A/B的原始初态、warmstart及141通道控制曲线也在YAML，运行不读取旧NPZ。

方程：L=L(q), v=J(q)qdot；F=gain(L,v)*a+bias(L)；tau=J.T F；
adot=muscleDynamics(u,a,parameters)；M(q)qacc=qfrc_smooth+qfrc_constraint。
MuJoCo执行原生肌肉、刚体、接触/关节约束及积分，不换成简化模型。
11条非肌肉通道保留各自原生驱动/滤波/黏附类型，不能统一套用肌肉方程。
step_excitation保留激活动力学；step_activation仅为显式a(t)实验，不能混称。

默认恢复旧A初态。replay_ab('A'/'B')精确执行存档全部141通道输入，不求解，
不调参，不加支撑/救援力矩。恢复0.4秒短轨迹不证明长期稳定行走。

示例：
    sim = Simulation('parameters.yaml')
    a = sim.replay_ab('A')
    b = sim.replay_ab('B')
    sim.render_ab_video('AB.mp4', results={'A': a, 'B': b})
    sim.reset('A')
    sim.step_excitation({sim.muscle_ids[0]: 0.2})
    terms = sim.equation_terms()  # 工作副本上计算，保持实际积分状态

CLI: python simulation.py --inspect
     python simulation.py --replay A --output A.npz
     MUJOCO_GL=egl python simulation.py --render-ab AB.mp4
代码中的索引/数学常数用于运算；模型数值、初态、曲线与运行默认值来自YAML。
"""
from __future__ import annotations
import argparse,base64,copy,hashlib,json,subprocess,xml.etree.ElementTree as ET,zlib
from pathlib import Path
import numpy as np
import mujoco
import yaml

def _load(path):
    with Path(path).open() as f:return yaml.load(f,Loader=getattr(yaml,'CSafeLoader',yaml.SafeLoader))

def _text(value):
    if isinstance(value,bool):return str(value).lower()
    if isinstance(value,(list,tuple)):return ' '.join(_text(v) for v in value)
    return str(value)

def _element(record):
    node=ET.Element(record['tag'],{k:_text(v) for k,v in record.get('attributes',{}).items() if v is not None})
    if 'text' in record:node.text=record['text']
    for child in record.get('children',[]):node.append(_element(child))
    return node

def _table(record):
    return np.fromstring(record['values'],sep=' ',dtype=np.dtype(record['dtype'])).reshape(record['shape'])

def build_model(config):
    """从可编辑MJCF数值和原始资产重编译，不用失效的二进制模型缓存。"""
    if mujoco.__version__!=config['dependencies']['mujoco']:
        raise RuntimeError('Exact archived replay requires MuJoCo '+config['dependencies']['mujoco'])
    assets={}
    for name,record in config['assets'].items():
        raw=zlib.decompress(base64.b64decode(record['payload']))
        if len(raw)!=record['uncompressed_bytes'] or hashlib.sha256(raw).hexdigest()!=record['sha256']:
            raise ValueError('Embedded asset checksum mismatch: '+name)
        assets[name]=raw
    return mujoco.MjModel.from_xml_string(ET.tostring(_element(config['mjcf']),encoding='unicode'),assets=assets)

class Simulation:
    def __init__(self,parameters=None,profile=None,case=None):
        self.parameters=Path(parameters) if parameters else Path(__file__).with_name('parameters.yaml')
        self.config=_load(self.parameters);self.profile=profile or self.config['interface']['default_profile']
        if self.profile not in self.config['profiles']:raise ValueError('Available profile: '+', '.join(self.config['profiles']))
        self.model=build_model(self.config);self.data=mujoco.MjData(self.model)
        self.actuator_names=tuple(self.model.actuator(i).name for i in range(self.model.nu))
        self.joint_names=tuple(self.model.joint(i).name for i in range(self.model.njnt))
        self._act_index={n:i for i,n in enumerate(self.actuator_names)};self._joint_index={n:i for i,n in enumerate(self.joint_names)}
        self.muscle_indices=np.array([r['actuator_index'] for r in self.config['muscle_catalog']],dtype=int)
        self.muscle_ids=tuple(r['id'] for r in self.config['muscle_catalog']);self._muscle_index={n:int(i) for n,i in zip(self.muscle_ids,self.muscle_indices)}
        self.muscle_names=tuple(self.actuator_names[i] for i in self.muscle_indices);self._muscle_index.update({n:int(i) for n,i in zip(self.muscle_names,self.muscle_indices)})
        self.nonmuscle_indices=np.array([r['actuator_index'] for r in self.config['nonmuscle_controls']],dtype=int)
        self.activation_addresses=self.model.actuator_actadr[self.muscle_indices];self.leg_indices={}
        for row in self.config['muscle_catalog']:self.leg_indices.setdefault(row['leg'],[]).append(row['actuator_index'])
        self._cases={};self._renderer=None;self.reset(case or self.config['interface']['default_case'])

    def describe(self):
        m=self.model
        return {'profile':self.profile,'case':self.case,'nq':m.nq,'nv':m.nv,'nu':m.nu,'na':m.na,'muscles':len(self.muscle_indices),'retained_nonmuscle_controls':len(self.nonmuscle_indices),'timestep_s':float(m.opt.timestep),'gravity_native':m.opt.gravity.tolist(),'cases':list(self.config['cases']),'source_model_sha256':self.config['provenance']['model_source_sha256'],'scope':self.config['provenance']['model_scope']}

    def load_ab(self,case):
        """返回保存的完整输入与初态；head/abdomen/adhesion不能丢弃。"""
        if case not in self.config['cases']:raise ValueError('Unknown A/B case: '+str(case))
        if case not in self._cases:
            row=self.config['cases'][case]
            self._cases[case]={'initial_state':_table(row['initial_state']),'initial_warmstart':_table(row['initial_warmstart']),'controls':_table(row['controls_all_141']),'sample_stride':row['sample_stride_physics_steps']}
        return {k:v.copy() if isinstance(v,np.ndarray) else v for k,v in self._cases[case].items()}

    def reset(self,case=None):
        """精确恢复旧初态和warmstart；不做姿态矫正或预平衡。"""
        self.case=case or getattr(self,'case',self.config['interface']['default_case']);z=self.load_ab(self.case)
        mujoco.mj_resetData(self.model,self.data);mujoco.mj_setState(self.model,self.data,z['initial_state'],mujoco.mjtState.mjSTATE_FULLPHYSICS)
        self.data.qacc_warmstart[:]=z['initial_warmstart'];self.data.ctrl[:]=z['controls'][0]
        # 此处不额外forward，严格复现旧回放的初始化调用顺序。
        return self.observe()

    def _controls(self,values):
        vector=self.data.ctrl.copy()
        if isinstance(values,dict):
            for name,value in values.items():
                idx=self._act_index.get(name,self._muscle_index.get(name))
                if idx is None:raise KeyError(name)
                vector[idx]=value
        else:
            a=np.asarray(values,dtype=float)
            if a.shape==(len(self.muscle_indices),):vector[self.muscle_indices]=a
            elif a.shape==(self.model.nu,):vector=a.copy()
            else:raise ValueError('Expected130 muscle inputs or141 complete controls')
        if not np.isfinite(vector).all():raise ValueError('Nonfinite control')
        limited=self.model.actuator_ctrllimited.astype(bool);bounds=self.model.actuator_ctrlrange
        if np.any(vector[limited]<bounds[limited,0]) or np.any(vector[limited]>bounds[limited,1]):raise ValueError('Control exceeds archived actuator range')
        return vector

    def _muscle_activation(self,values):
        vector=self.data.act[self.activation_addresses].copy()
        if isinstance(values,dict):
            positions={int(i):j for j,i in enumerate(self.muscle_indices)}
            for name,value in values.items():
                if name not in self._muscle_index:raise KeyError('Not a muscle: '+name)
                vector[positions[self._muscle_index[name]]]=value
        else:vector=np.asarray(values,dtype=float)
        lo,hi=self.config['interface']['normalized_muscle_bounds']
        if vector.shape!=(len(self.muscle_indices),) or not np.isfinite(vector).all() or np.any(vector<lo) or np.any(vector>hi):raise ValueError('Expected130 normalized muscle activations')
        return vector

    def _steps(self,interval_s):
        dt=self.model.opt.timestep;duration=self.config['interface']['control_interval_s'] if interval_s is None else interval_s;ratio=duration/dt;steps=round(ratio)
        if steps<1 or abs(ratio-steps)>self.config['interface']['time_ratio_tolerance']:raise ValueError('Interval must be a positive integer multiple of physics timestep')
        return steps

    def step_excitation(self,values,interval_s=None):
        """输入u；130向量保留其余控制，141向量包含全部旧控制。"""
        self.data.ctrl[:]=self._controls(values)
        for _ in range(self._steps(interval_s)):mujoco.mj_step(self.model,self.data)
        if not np.isfinite(self.data.qpos).all():raise FloatingPointError('Nonfinite physics state')
        return self.observe()

    def set_activation(self,values):
        """只设置130肌肉a，不覆盖11个非肌肉滤波状态；不执行积分。"""
        self.data.act[self.activation_addresses]=self._muscle_activation(values)
        return self.observe()

    def step_activation(self,values,interval_s=None):
        """显式a(t)实验，绕过肌肉激活动力学；A/B恢复不使用此模式。"""
        a=self._muscle_activation(values);self.data.ctrl[self.muscle_indices]=a
        for _ in range(self._steps(interval_s)):
            self.data.act[self.activation_addresses]=a;mujoco.mj_step(self.model,self.data)
        self.data.act[self.activation_addresses]=a
        return self.observe()

    def observe(self,data=None):
        d=self.data if data is None else data
        return {'time_s':float(d.time),'qpos_native':d.qpos.copy(),'qvel_native':d.qvel.copy(),'activation':d.act[self.activation_addresses].copy(),'all_activation':d.act.copy(),'excitation':d.ctrl[self.muscle_indices].copy(),'all_controls':d.ctrl.copy(),'actuator_force_native':d.actuator_force.copy(),'muscle_force_native':d.actuator_force[self.muscle_indices].copy(),'generalized_actuator_force_native':d.qfrc_actuator.copy()}

    def evaluate(self,activation=None):
        """固定当前q/v的工作副本上计算，不改变真实积分状态。"""
        w=copy.copy(self.data)
        if activation is not None:w.act[self.activation_addresses]=self._muscle_activation(activation)
        mujoco.mj_forward(self.model,w)
        return self.observe(w)

    def equation_terms(self):
        """完整原生力学项；只对130肌肉调用muscle函数，其余保留原类型。"""
        m=self.model;d=copy.copy(self.data);mujoco.mj_forward(m,d);J=np.zeros((m.nu,m.nv));mujoco.mju_sparse2dense(J,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind);M=np.empty((m.nv,m.nv));mujoco.mj_fullM(m,M,d.qM);gain=[];bias=[];adot=[]
        for i in self.muscle_indices:
            gain.append(mujoco.mju_muscleGain(d.actuator_length[i],d.actuator_velocity[i],m.actuator_lengthrange[i],m.actuator_acc0[i],m.actuator_gainprm[i,:9]));bias.append(mujoco.mju_muscleBias(d.actuator_length[i],m.actuator_lengthrange[i],m.actuator_acc0[i],m.actuator_biasprm[i,:9]));u=np.clip(d.ctrl[i],*m.actuator_ctrlrange[i]) if m.actuator_ctrllimited[i] else d.ctrl[i];adot.append(mujoco.mju_muscleDynamics(u,d.act[m.actuator_actadr[i]],m.actuator_dynprm[i,:3]))
        force=np.asarray(gain)*d.act[self.activation_addresses]+np.asarray(bias);rhs=d.qfrc_smooth+d.qfrc_constraint
        return {'mass_matrix_native':M,'transmission_jacobian':J,'muscle_gain_native':np.asarray(gain),'muscle_passive_bias_native':np.asarray(bias),'muscle_activation_derivative':np.asarray(adot),'muscle_force_formula_native':force,'muscle_force_engine_native':d.actuator_force[self.muscle_indices].copy(),'muscle_generalized_force_native':J[self.muscle_indices].T@force,'all_generalized_actuator_force_native':d.qfrc_actuator.copy(),'qfrc_smooth_native':d.qfrc_smooth.copy(),'qfrc_constraint_native':d.qfrc_constraint.copy(),'qacc_native':d.qacc.copy(),'dynamics_residual_native':M@d.qacc-rhs}

    def ground_contacts(self):
        """读取引擎真实接触；足端包括旧claw刚体，不添加任何支撑力。"""
        m=self.model;d=copy.copy(self.data);mujoco.mj_forward(m,d);ground=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_GEOM,'groundplane');foot=other=0.;details=[];f=np.zeros(6)
        for k in range(d.ncon):
            c=d.contact[k];a,b=map(int,c.geom)
            if ground not in (a,b):continue
            g=b if a==ground else a;body=mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,int(m.geom_bodyid[g])) or '';mujoco.mj_contactForce(m,d,k,f);world=c.frame.reshape(3,3).T@f[:3];vertical=float(world[2] if a==ground else -world[2]);isfoot=body.startswith('walker/claw_T')
            if isfoot:foot+=vertical
            else:other+=vertical
            details.append({'body':body,'foot':isfoot,'vertical_force_native':vertical})
        weight=float(m.body_mass.sum()*np.linalg.norm(m.opt.gravity));return {'foot_support_native':foot,'nonfoot_support_native':other,'weight_native':weight,'details':details}

    def replay_ab(self,case=None,output=None):
        """直接执行旧输入，逐物理步积分，无调参、重置或额外控制。"""
        case=case or self.config['interface']['default_case'];z=self.load_ab(case);self.reset(case);m=self.model;d=self.data;states=[];q=[];v=[];a=[];times=[]
        for k,control in enumerate(z['controls']):
            d.ctrl[:]=control;mujoco.mj_step(m,d)
            if np.any(d.qfrc_applied) or np.any(d.xfrc_applied):raise RuntimeError('Unexpected external applied forces')
            if (k+1)%z['sample_stride']==0:
                st=np.empty(mujoco.mj_stateSize(m,mujoco.mjtState.mjSTATE_FULLPHYSICS));mujoco.mj_getState(m,d,st,mujoco.mjtState.mjSTATE_FULLPHYSICS);states.append(st);q.append(d.qpos.copy());v.append(d.qvel.copy());a.append(d.act.copy());times.append(d.time)
        q=np.array(q);qa=np.asarray(self.config['reference']['joint_qpos_indices']);target=_table(self.config['reference']['joint_angles'])[1:];error=np.rad2deg(q[:,qa]-target);root0=z['initial_state'][1:4];bid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');w=mujoco.MjData(m);up=[]
        for pose in q:w.qpos[:]=pose;mujoco.mj_kinematics(m,w);up.append(float(w.xmat[bid].reshape(3,3)[2,2]))
        metrics={'case':case,'duration_s':float(d.time),'path_angle_rmse_deg':float(np.sqrt(np.mean(error**2))),'terminal_angle_rmse_deg':float(np.sqrt(np.mean(error[-1]**2))),'max_terminal_error_deg':float(abs(error[-1]).max()),'root_displacement_mm':((q[-1,:3]-root0)*self.config['units']['native_length_to_mm']).tolist(),'min_body_up_z':min(up),'extra_applied_forces':False,'model_parameters_refit':False,'long_term_stable_walking_established':False}
        result={'case':case,'metrics':metrics,'time_s':np.array(times),'full_state':np.array(states),'qpos':q,'qvel':np.array(v),'all_activation':np.array(a),'activation':np.array(a)[:,self.activation_addresses],'all_control_10000Hz':z['controls'],'initial_state':z['initial_state'],'initial_warmstart':z['initial_warmstart'],'joint_names':np.array(self.config['reference']['joint_names']),'joint_angle_error_deg':error}
        if output:
            output=Path(output);np.savez_compressed(output,**{k:v for k,v in result.items() if k not in ['case','metrics']});output.with_suffix('.json').write_text(json.dumps(metrics,indent=2,ensure_ascii=False))
        return result

    def _image(self,state):
        m=self.model;w=mujoco.MjData(m);mujoco.mj_setState(m,w,state,mujoco.mjtState.mjSTATE_FULLPHYSICS);mujoco.mj_forward(m,w);cfg=self.config['rendering']
        if self._renderer is None:self._renderer=mujoco.Renderer(m,height=cfg['height'],width=cfg['panel_width'])
        opt=mujoco.MjvOption();opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False;opt.sitegroup[:]=0
        hidden=[i for i in range(m.ngeom) if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith(cfg['hide_geom_prefix'])];colors=m.geom_rgba[hidden].copy()
        try:
            m.geom_rgba[hidden,3]=0.;self._renderer.update_scene(w,camera=cfg['camera_id'],scene_option=opt)
        finally:m.geom_rgba[hidden]=colors
        return self._renderer.render().copy()

    def render(self):
        st=np.empty(mujoco.mj_stateSize(self.model,mujoco.mjtState.mjSTATE_FULLPHYSICS));mujoco.mj_getState(self.model,self.data,st,mujoco.mjtState.mjSTATE_FULLPHYSICS);return self._image(st)

    def render_ab_video(self,output,results=None):
        """A/B真实全程并排视频；独立跟随相机，不改姿态、不裁掉失败片段。"""
        from PIL import Image,ImageDraw
        results=results or {c:self.replay_ab(c) for c in self.config['cases']};cfg=self.config['rendering'];cases=list(results);width=cfg['panel_width']*len(cases);height=cfg['height'];output=Path(output);duration=max(v['metrics']['duration_s'] for v in results.values());proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',str(width)+'x'+str(height),'-r',str(cfg['fps']),'-i','-','-an','-c:v','libx264','-crf','20','-pix_fmt','yuv420p',str(output)],stdin=subprocess.PIPE)
        try:
            for frame,t in enumerate(np.linspace(0,duration,cfg['frames'])):
                panels=[]
                for case in cases:
                    z=results[case];state=z['initial_state'] if frame==0 else z['full_state'][int(np.argmin(abs(z['time_s']-t)))];im=Image.fromarray(self._image(state));draw=ImageDraw.Draw(im);draw.rectangle((0,0,cfg['panel_width'],62),fill='black');draw.text((8,6),'Restored original '+case+' | all 141 controls',fill='white');draw.text((8,25),f't={t:.3f}s | playback {cfg["playback_speed"]}x',fill='white');draw.text((8,44),'Native muscles + gravity + contacts + adhesion',fill='white');panels.append(np.asarray(im))
                proc.stdin.write(np.concatenate(panels,axis=1).tobytes())
                if frame in [0,cfg['frames']//2,cfg['frames']-1]:Image.fromarray(np.concatenate(panels,axis=1)).save(output.with_name(output.stem+f'_frame_{frame:03d}.png'))
                if frame%(cfg['frames']//4)==0:print('Rendered',frame,'/',cfg['frames'],flush=True)
        finally:proc.stdin.close()
        if proc.wait()!=0:raise RuntimeError('ffmpeg failed')
        return str(output)

    def close(self):
        if self._renderer is not None:self._renderer.close();self._renderer=None
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--parameters',type=Path);p.add_argument('--inspect',action='store_true');p.add_argument('--replay',choices=['A','B']);p.add_argument('--output',type=Path);p.add_argument('--render-ab',type=Path);args=p.parse_args()
    with Simulation(args.parameters) as sim:
        if args.inspect or not (args.replay or args.render_ab):print(json.dumps(sim.describe(),ensure_ascii=False,indent=2))
        if args.replay:print(json.dumps(sim.replay_ab(args.replay,args.output)['metrics'],ensure_ascii=False,indent=2))
        if args.render_ab:print(sim.render_ab_video(args.render_ab))
if __name__=='__main__':main()
