# MeanFlow mid-term presentation — 林哲锋 / Zhefeng Lin, 2024010961

Main presentation: slides 1–8. Slides 9–10 are backup only. Target delivery: 4:30–4:50; rehearse before the 5-minute cutoff.

## Slide 1

My project studies Mean Flows for One-step Generative Modeling. I chose this paper because it connects an exact dynamical identity to fast generative modeling. My proposed research asks whether its interval normalization is also a good choice for optimization, especially when the training target uses stop-gradient.

---

## Slide 2

I chose MeanFlow for three reasons. First, reducing network evaluations addresses the practical cost of image generation. Second, the method has a clear mathematical basis: an average-velocity identity becomes a training target. Third, it gives me a precise research question: does its normalization help optimization, or could another choice work better? The paper reports strong one-step image generation, motivating this question.

---

## Slide 3

Its connection to machine learning is concrete. A neural network learns to transport noise into the data distribution. Flow Matching predicts local velocity, while MeanFlow predicts average velocity for a finite interval. This changes the learning target and uses Jacobian-vector products and stopped targets during optimization. My project examines how this representation choice affects training and generation quality, rather than only changing model size.

---

## Slide 4

The average velocity is the trajectory displacement divided by the interval length. Holding the starting time fixed and differentiating gives instantaneous velocity equal to average velocity plus interval length times its total derivative. MeanFlow turns this identity into a regression target and stops gradients through that target. The derivative is computed by a Jacobian-vector product. The ground-truth identity concerns marginal trajectories; training substitutes the available conditional velocity, epsilon minus x.

---

## Slide 5

My extension replaces division by h with division by a chosen function f of h. The physical displacement remains unchanged: it is f times the network output. Differentiation now gives f prime times w plus f times its total derivative equal to velocity. I will use smooth functions that vanish at zero, have positive derivatives, and preserve a finite local limit. At inference, multiplying the prediction by f directly gives displacement, with no additional network evaluations.

---

## Slide 6

For a positive f prime, I can solve the identity for a regression target, just as in MeanFlow. Because that target is stopped, changing f changes the actual update, not just the written definition. My hypothesis is that suitable normalization could improve optimization. But there is a critical alternative explanation: the improvement may only come from reweighting time intervals. I have derived a matched-weight control to distinguish these effects. This is a research hypothesis, not an established improvement.

---

## Slide 7

I will use the same real-image benchmark as the paper: CIFAR-ten, with its approximately fifty-five-million-parameter U-Net in pixel space. I will reproduce the paper recipe, then compare normalization functions under matched architectures and budgets. The primary metric is FID on fifty thousand generated images at one network evaluation, with three seeds and training-cost measurements. A squared-loss ablation will isolate reweighting. ImageNet with the paper’s transformer backbone is an optional scale-up, subject to available compute.

---

## Slide 8

So far, I have checked the paper, derived the generalized identity and matched-update relation, and verified them in analytic numerical checks. I have not trained the neural models yet. Next I will test automatic differentiation, reproduce the baseline, and run controlled comparisons. If a gain disappears under matched reweighting, I will report that explanation rather than claim a new mechanism. The final goal is to understand when normalization matters, supported by both derivation and reproducible experiments.

---

## Slide 9

Backup: the stopped-target gradient is two lambda over f prime times the output Jacobian transposed times the identity residual. When the original model is explicitly parameterized as u equals f over h times w, choosing lambda equal to f times f prime over h matches its semi-gradient. This statement assumes the same sample, parameterization and squared-loss setting; it is not a claim about arbitrary architectures or adaptive weights.

---

## Slide 10

References and limitations. The source paper is the uploaded first version of MeanFlow. The extension is a proposed investigation, not a verified novelty or a performance claim. Current checks concern analytic formulas, not automatic JVP or neural training.
