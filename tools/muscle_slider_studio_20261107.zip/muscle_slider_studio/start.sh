#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")"
if [ ! -x .venv/bin/python ]; then
  studio_python=""
  for candidate in python3.11 python3.12 python3.10 python3; do
    if command -v "$candidate" >/dev/null && "$candidate" -c 'import sys; assert (3,10) <= sys.version_info[:2] <= (3,12)' 2>/dev/null; then
      studio_python="$candidate"
      break
    fi
  done
  if [ -z "$studio_python" ]; then
    echo 'Please install Python 3.11 or 3.12 first.'
    exit 1
  fi
  "$studio_python" -m venv .venv
fi
if ! .venv/bin/python -c "import mujoco,numpy,imageio,imageio_ffmpeg,PIL; assert mujoco.__version__=='3.3.2'" 2>/dev/null; then
  .venv/bin/python -m pip install -r requirements.txt
fi
exec .venv/bin/python server.py "$@"
