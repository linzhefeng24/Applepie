"""Meaningful checks for editing, history propagation, restoration and export."""
import json,tempfile,unittest,zipfile,io
from pathlib import Path
import numpy as np,mujoco
from mujoco import rollout
from core import Editor,adjust_input
ROOT=Path(__file__).resolve().parent

class EditorTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.editor=Editor(ROOT/'data',self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def test_formula_and_nonaccumulating_drag(self):
        u=np.array([0.,.2,.7,1.]);np.testing.assert_array_equal(adjust_input(u,0),u)
        np.testing.assert_allclose(adjust_input(u,1),1);np.testing.assert_array_equal(adjust_input(u,-1),np.zeros(4))
        np.testing.assert_allclose(adjust_input(u,.25),[.25,.4,.775,1]);np.testing.assert_allclose(adjust_input(u,-.25),[0,.15,.525,.75])
        e=self.editor;e.edit('A',[dict(segment=0,muscle=0,value=.2)]);e.edit('A',[dict(segment=0,muscle=0,value=.3)])
        snap=e.snapshot('A');base=e.bases['A'];aid=base['muscle_indices'][0]
        np.testing.assert_allclose(snap.controls[:200,aid],adjust_input(base['controls'][:200,aid],.3))
        np.testing.assert_array_equal(snap.controls[200:],base['controls'][200:])
    def test_portable_baseline_exact_native_replay(self):
        e=self.editor;states=e.simulate(e.snapshot('A'))
        source=Path('/workspace/flybrain-activation-inverse/hindleg_correction_20261106/optimized_rollout.npz')
        if source.exists():np.testing.assert_array_equal(states[2::2],np.load(source)['full_state'])
        self.assertAlmostEqual(float(states[-1,0]),.4,places=10)
    def test_earlier_edit_propagates_and_project_restores(self):
        e=self.editor;mi=e.bases['A']['muscle_ids'].tolist().index('RH:trochanter_flexor')
        baseline=e.simulate(e.snapshot('A'),end_step=400).copy()
        e.edit('A',[dict(segment=0,muscle=mi,value=.35)])
        prefix=e.simulate(e.snapshot('A'),end_step=200).copy()
        e.edit('A',[dict(segment=1,muscle=mi,value=-.15)])
        snapshot=e.snapshot('A');states=e.simulate(snapshot,end_step=400)
        # The first modified interval is preserved exactly, including internal a/v.
        np.testing.assert_array_equal(prefix,states[:201]);self.assertGreater(float(abs(states[-1]-baseline[-1]).max()),1e-5)
        base=e.bases['A'];native,_=rollout.rollout(e.model,mujoco.MjData(e.model),base['initial_state'][None],snapshot.controls[None,:400],initial_warmstart=base['initial_warmstart'][None])
        np.testing.assert_array_equal(states[1:],native[0])
        restored=Editor(ROOT/'data',self.temp.name);np.testing.assert_array_equal(restored.snapshot('A').controls,snapshot.controls)
        with tempfile.TemporaryDirectory() as other:
            imported=Editor(ROOT/'data',other);imported.restore(e.document('A'));np.testing.assert_array_equal(imported.snapshot('A').controls,snapshot.controls)
        e.undo('A');self.assertEqual(e.state('A')['coefficients'][0][mi],.35);self.assertEqual(e.state('A')['coefficients'][1][mi],0.)
    def test_export_contains_real_activation_and_all_controls(self):
        e=self.editor;e.edit('B',[dict(segment=0,muscle=4,value=.1)]);snap=e.snapshot('B');S=e.simulate(snap);path=Path(self.temp.name)/'result.zip';e.export(snap,S,path)
        with zipfile.ZipFile(path) as archive:
            z=np.load(io.BytesIO(archive.read('trajectories.npz')),allow_pickle=False);ids=e.bases['B']['muscle_indices'];off=1+e.model.nq+e.model.nv
            np.testing.assert_array_equal(z['activation'],S[:,off:][:,e.model.actuator_actadr[ids]])
            np.testing.assert_array_equal(z['excitation'],snap.controls[:,ids]);self.assertEqual(z['activation'].shape,(4001,130));self.assertEqual(z['all_controls'].shape,(4000,141))
            self.assertEqual(json.loads(archive.read('project.json'))['coefficients'][0][4],.1)
    def test_rejects_mismatched_or_invalid_project(self):
        with self.assertRaises(ValueError):self.editor.restore([])
        doc=self.editor.document('A');doc['model_sha256']='wrong'
        with self.assertRaises(ValueError):self.editor.restore(doc)
        with self.assertRaises(ValueError):self.editor.edit('A',[dict(segment=0,muscle=0,value=float('nan'))])
        with self.assertRaises(ValueError):self.editor.edit('A',[dict(segment=-1,muscle=0,value=.1)])

if __name__=='__main__':unittest.main(verbosity=2)
