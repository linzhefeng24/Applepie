"""Local browser application. Run with Python 3.10-3.12."""
import os,sys
if sys.platform.startswith('linux') and not os.environ.get('DISPLAY'):os.environ.setdefault('MUJOCO_GL','egl')
os.environ.setdefault('OMP_NUM_THREADS','1');os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
from pathlib import Path
import argparse,json,mimetypes,re,threading,urllib.parse,webbrowser
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from core import Editor
from engine import Engine
ROOT=Path(__file__).resolve().parent

def make_server(editor,engine,host,port):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,fmt,*args):
            if args and str(args[0]).startswith('GET /api/job'):return
            super().log_message(fmt,*args)
        def json(self,value,status=200):
            data=json.dumps(value,ensure_ascii=False,allow_nan=False).encode();self.send_response(status)
            self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)))
            self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
        def file(self,path,attachment=False,download_name=None):
            if not path.is_file():return self.json({'error':'文件不存在'},404)
            size=path.stat().st_size;first=0;last=size-1;status=200
            requested=self.headers.get('Range')
            if requested:
                match=re.fullmatch(r'bytes=(\d+)-(\d*)',requested)
                if not match:return self.json({'error':'Range格式错误'},416)
                first=int(match.group(1));last=min(last,int(match.group(2))) if match.group(2) else last;status=206
                if first>last:return self.json({'error':'Range超出范围'},416)
            self.send_response(status);self.send_header('Content-Type',mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
            self.send_header('Content-Length',str(last-first+1));self.send_header('Accept-Ranges','bytes')
            if status==206:self.send_header('Content-Range',f'bytes {first}-{last}/{size}')
            if attachment:self.send_header('Content-Disposition',f'attachment; filename="{download_name or path.name}"')
            self.end_headers()
            try:
                with path.open('rb') as f:
                    f.seek(first);remaining=last-first+1
                    while remaining:
                        chunk=f.read(min(1024*1024,remaining))
                        if not chunk:break
                        self.wfile.write(chunk);remaining-=len(chunk)
            except (BrokenPipeError,ConnectionResetError):pass
        def do_GET(self):
            try:
                url=urllib.parse.urlparse(self.path);query=urllib.parse.parse_qs(url.query);path=url.path
                if path in ['/','/app.js','/style.css']:
                    return self.file(ROOT/'static'/('index.html' if path=='/' else path[1:]))
                if path=='/favicon.ico':self.send_response(204);self.end_headers();return
                if path=='/api/state':return self.json(editor.state(query.get('preset',['A'])[0]))
                if path=='/api/project':return self.json(editor.document(query.get('preset',['A'])[0]))
                if path=='/api/job':return self.json(engine.status(query['id'][0]))
                if path.startswith(('/media/','/downloads/')):
                    name=path.rsplit('/',1)[-1]
                    if not re.fullmatch(r'[a-f0-9]{32}\.(mp4|zip)',name):return self.json({'error':'文件名无效'},404)
                    download_name=None
                    if path.startswith('/downloads/'):
                        try:
                            job=engine.status(name.split('.')[0]);download_name=f'muscle_{job["preset"]}_r{job["revision"]}.zip'
                        except ValueError:pass  # Old exported files outlive the short in-memory job history.
                    return self.file(engine.output/name,attachment=path.startswith('/downloads/'),download_name=download_name)
                return self.json({'error':'不存在的地址'},404)
            except (ValueError,KeyError) as exc:return self.json({'error':str(exc)},400)
        def do_POST(self):
            try:
                origin=self.headers.get('Origin')
                if origin and urllib.parse.urlparse(origin).netloc!=self.headers.get('Host'):return self.json({'error':'不允许跨站请求'},403)
                if not self.headers.get('Content-Type','').startswith('application/json'):return self.json({'error':'需要JSON请求'},415)
                length=int(self.headers.get('Content-Length','0'))
                if length>2*1024*1024:return self.json({'error':'项目文件过大'},413)
                body=json.loads(self.rfile.read(length));path=urllib.parse.urlparse(self.path).path
                if not isinstance(body,dict):raise ValueError('请求必须是JSON对象')
                key=body.get('preset','A')
                if key not in editor.presets and path!='/api/import':raise ValueError('未知基准轨迹')
                if path=='/api/edits':return self.json(editor.edit(key,body['edits']))
                if path=='/api/undo':return self.json(editor.undo(key,body.get('redo',False)))
                if path=='/api/reset':return self.json(editor.reset(key,body.get('segment')))
                if path=='/api/import':return self.json(editor.restore(body['project']))
                if path in ['/api/preview','/api/export']:
                    return self.json(engine.submit(key,body.get('segment',0),body.get('view','segment'),body.get('slowdown',20),body.get('camera','native'),export=path=='/api/export'))
                return self.json({'error':'不存在的地址'},404)
            except (ValueError,KeyError,TypeError) as exc:return self.json({'error':str(exc)},400)
    return ThreadingHTTPServer((host,port),Handler)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8765);parser.add_argument('--host',default='127.0.0.1')
    parser.add_argument('--workspace',type=Path,default=ROOT/'user_data');parser.add_argument('--segment-ms',type=float,default=20)
    parser.add_argument('--no-browser',action='store_true');args=parser.parse_args()
    editor=Editor(ROOT/'data',args.workspace/'projects',segment_ms=args.segment_ms);engine=Engine(editor,args.workspace/'outputs')
    server=make_server(editor,engine,args.host,args.port);address=f'http://{args.host}:{server.server_port}'
    print('Muscle Slider Studio: '+address,flush=True);print('Projects and exports: '+str(args.workspace),flush=True)
    if not args.no_browser:threading.Timer(.8,lambda:webbrowser.open(address)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
if __name__=='__main__':main()
