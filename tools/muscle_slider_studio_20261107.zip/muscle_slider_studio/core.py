"""Muscle input editing and deterministic, uninterrupted physical replay."""
from __future__ import annotations
import csv,hashlib,io,json,math,threading,zipfile
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import mujoco
from mujoco import rollout

def adjust_input(u, slider):
    """Absolute slider relative to this project's baseline, never cumulative drags."""
    u=np.asarray(u,dtype=np.float64);s=np.asarray(slider,dtype=np.float64)
    if not np.isfinite(s).all() or np.any(abs(s)>1):raise ValueError('滑块必须在 -1 到 1 之间')
    return np.where(s>=0,u+s*(1-u),u*(1+s))

@dataclass(frozen=True)
class Snapshot:
    preset: str
    revision: int
    coefficients: np.ndarray
    controls: np.ndarray

class Editor:
    def __init__(self,data_dir,work_dir,segment_ms=20):
        self.data_dir=Path(data_dir);self.work_dir=Path(work_dir);self.work_dir.mkdir(parents=True,exist_ok=True)
        self.manifest=json.loads((self.data_dir/'manifest.json').read_text())
        self.model_path=self.data_dir/self.manifest['model'];self.model=mujoco.MjModel.from_xml_path(str(self.model_path))
        actual=hashlib.sha256(self.model_path.read_bytes()).hexdigest()
        if actual!=self.manifest['model_sha256']:raise ValueError('模型文件校验失败')
        self.reference=dict(np.load(self.data_dir/self.manifest['reference'],allow_pickle=False))
        self.lock=threading.RLock();self.segment_ms=float(segment_ms);self.projects={};self.cache={}
        self.presets={x['id']:x for x in self.manifest['presets']};self.bases={}
        for key,preset in self.presets.items():
            path=self.data_dir/preset['file']
            if hashlib.sha256(path.read_bytes()).hexdigest()!=preset['sha256']:raise ValueError('基准轨迹校验失败：'+key)
            base=dict(np.load(path,allow_pickle=False));self.bases[key]=base
            controls=base['controls'];ids=base['muscle_indices'];n=len(controls);dt=self.model.opt.timestep
            block=int(round(self.segment_ms/1000/dt))
            if block<=0 or abs(block*dt-self.segment_ms/1000)>1e-10:raise ValueError('时间段必须是物理步长的整数倍')
            if controls.shape!=(n,self.model.nu) or not np.isfinite(controls).all():raise ValueError('基准控制形状或数值错误')
            if np.any((controls[:,ids]<0)|(controls[:,ids]>1)):raise ValueError('肌肉基准输入越界')
            segments=math.ceil(n/block);self.block_steps=block
            self.projects[key]={'revision':0,'coefficients':np.zeros((segments,len(ids))), 'undo':[], 'redo':[]}
            saved=self.work_dir/(key+'.json')
            if saved.exists():self._restore(key,json.loads(saved.read_text()),record=False)
    def _document(self,key):
        p=self.projects[key]
        return dict(schema='muscle-slider-project-v1',preset=key,revision=p['revision'],
            model_sha256=self.manifest['model_sha256'],baseline_sha256=self.presets[key]['sha256'],
            segment_ms=self.segment_ms,muscle_ids=self.bases[key]['muscle_ids'].tolist(),
            coefficients=p['coefficients'].tolist(),formula='s>=0: u=u0+s*(1-u0); s<0: u=u0*(1+s)')
    def document(self,key):
        with self.lock:return self._document(key)
    def revision(self,key):
        with self.lock:return self.projects[key]['revision']
    def _persist(self,key):
        path=self.work_dir/(key+'.json');temp=path.with_suffix('.tmp')
        temp.write_text(json.dumps(self._document(key),ensure_ascii=False,indent=2)+'\n');temp.replace(path)
    def _changed(self,key,old):
        p=self.projects[key];p['undo'].append(old);p['undo']=p['undo'][-100:];p['redo']=[];p['revision']+=1
        self.cache.pop(key,None);self._persist(key)
    def edit(self,key,edits):
        with self.lock:
            p=self.projects[key];new=p['coefficients'].copy()
            for edit in edits:
                seg=edit['segment'];muscle=edit['muscle'];value=float(edit['value'])
                if type(seg) is not int or type(muscle) is not int:raise ValueError('肌肉和时间段索引必须是整数')
                if not 0<=seg<len(new) or not 0<=muscle<new.shape[1]:raise ValueError('肌肉或时间段不存在')
                if not math.isfinite(value) or abs(value)>1:raise ValueError('滑块范围为 -100% 到 +100%')
                new[seg,muscle]=value
            if not np.array_equal(new,p['coefficients']):
                old=p['coefficients'];p['coefficients']=new;self._changed(key,old)
            return self.state(key)
    def undo(self,key,redo=False):
        with self.lock:
            p=self.projects[key];source=p['redo'] if redo else p['undo'];target=p['undo'] if redo else p['redo']
            if source:
                target.append(p['coefficients'].copy());p['coefficients']=source.pop();p['revision']+=1;self.cache.pop(key,None);self._persist(key)
            return self.state(key)
    def reset(self,key,segment=None):
        with self.lock:
            p=self.projects[key];old=p['coefficients'].copy();new=old.copy()
            if segment is None:new[:]=0
            elif type(segment) is int and 0<=segment<len(new):new[segment]=0
            else:raise ValueError('时间段不存在')
            if not np.array_equal(new,old):p['coefficients']=new;self._changed(key,old)
            return self.state(key)
    def _restore(self,key,doc,record=True):
        if doc.get('schema')!='muscle-slider-project-v1' or doc.get('preset')!=key:raise ValueError('项目格式或基准版本不匹配')
        if doc.get('model_sha256')!=self.manifest['model_sha256'] or doc.get('baseline_sha256')!=self.presets[key]['sha256']:raise ValueError('项目引用的模型/基准轨迹与当前程序不一致')
        if doc.get('segment_ms')!=self.segment_ms or doc.get('muscle_ids')!=self.bases[key]['muscle_ids'].tolist():raise ValueError('项目的时间分段或肌肉顺序不一致')
        new=np.asarray(doc['coefficients'],dtype=float);p=self.projects[key]
        if new.shape!=p['coefficients'].shape or not np.isfinite(new).all() or np.any(abs(new)>1):raise ValueError('项目滑块数据错误')
        old=p['coefficients'].copy();p['coefficients']=new.copy()
        if record:self._changed(key,old)
        else:p['revision']=int(doc.get('revision',0))
    def restore(self,doc):
        with self.lock:
            if not isinstance(doc,dict):raise ValueError('项目JSON必须是对象')
            key=doc.get('preset')
            if key not in self.presets:raise ValueError('未知基准轨迹')
            self._restore(key,doc);return self.state(key)
    def state(self,key):
        with self.lock:
            if key not in self.presets:raise ValueError('未知基准轨迹')
            p=self.projects[key];base=self.bases[key];ids=base['muscle_indices'];C=base['controls'];dt=self.model.opt.timestep;stats=[]
            for segment in range(len(p['coefficients'])):
                block=C[segment*self.block_steps:min(len(C),(segment+1)*self.block_steps)][:,ids]
                stats.append(dict(mean=block.mean(axis=0).tolist(),minimum=block.min(axis=0).tolist(),maximum=block.max(axis=0).tolist()))
            return dict(preset=key,presets=[dict(id=k,label=v['label']) for k,v in self.presets.items()],
                revision=p['revision'],coefficients=p['coefficients'].tolist(),baseline_stats=stats,
                muscle_ids=base['muscle_ids'].tolist(),segments=len(p['coefficients']),segment_ms=self.segment_ms,
                duration_s=len(C)*dt,dt_s=dt,can_undo=bool(p['undo']),can_redo=bool(p['redo']))
    def snapshot(self,key):
        with self.lock:
            base=self.bases[key];p=self.projects[key];C=base['controls'].copy();ids=base['muscle_indices'];S=p['coefficients'].copy()
            for segment,slider in enumerate(S):
                rows=np.arange(segment*self.block_steps,min(len(C),(segment+1)*self.block_steps))
                C[np.ix_(rows,ids)]=adjust_input(C[np.ix_(rows,ids)],slider)
            return Snapshot(key,p['revision'],S,C)
    def simulate(self,snapshot,end_step=None):
        """Always start from the original initial state and warmstart, never reset segments."""
        steps=len(snapshot.controls) if end_step is None else int(end_step)
        if not 1<=steps<=len(snapshot.controls):raise ValueError('回放终点无效')
        with self.lock:
            cached=self.cache.get(snapshot.preset)
            if cached is not None and cached[0]==snapshot.revision and len(cached[1])>=steps+1:return cached[1][:steps+1]
        base=self.bases[snapshot.preset]
        states,_=rollout.rollout(self.model,mujoco.MjData(self.model),base['initial_state'][None],snapshot.controls[None,:steps],
            initial_warmstart=base['initial_warmstart'][None])
        states=np.vstack([base['initial_state'],states[0]])
        expected=np.arange(len(states))*self.model.opt.timestep
        if not np.isfinite(states).all() or not np.allclose(states[:,0],expected,atol=1e-9,rtol=0):raise RuntimeError('仿真未完整完成，不能作为有效回放')
        off=1+self.model.nq+self.model.nv;activation=states[:,off:][:,self.model.actuator_actadr[base['muscle_indices']]]
        if activation.min() < -1e-9 or activation.max()>1+1e-9:raise RuntimeError('实际肌肉激活越界')
        with self.lock:
            if self.projects[snapshot.preset]['revision']==snapshot.revision:self.cache[snapshot.preset]=(snapshot.revision,states)
        return states
    def reference_at(self,time_s):
        ref=self.reference;times=ref['time_s'];k=int(np.searchsorted(times,time_s,side='right')-1);k=max(0,min(k,len(times)-2))
        fraction=float(np.clip((time_s-times[k])/(times[k+1]-times[k]),0,1));a=ref['qpos'][k];b=ref['qpos'][k+1];q=a*(1-fraction)+b*fraction
        for kind,adr in zip(self.model.jnt_type,self.model.jnt_qposadr):
            if kind==int(mujoco.mjtJoint.mjJNT_FREE):adr+=3
            elif kind!=int(mujoco.mjtJoint.mjJNT_BALL):continue
            x=a[adr:adr+4];y=b[adr:adr+4]
            if x@y<0:y=-y
            quat=x*(1-fraction)+y*fraction;q[adr:adr+4]=quat/np.linalg.norm(quat)
        return q
    def metrics(self,states,start_s,end_s):
        dt=self.model.opt.timestep;first=int(round(start_s/dt));last=min(len(states)-1,int(round(end_s/dt)));qa=self.reference['joint_qpos_indices']
        indices=np.arange(first,last+1);target=np.array([self.reference_at(i*dt)[qa] for i in indices]);actual=states[indices,1:1+self.model.nq][:,qa];e=np.rad2deg(actual-target)
        return dict(path_rmse_deg=float(np.sqrt(np.mean(e**2))),terminal_rmse_deg=float(np.sqrt(np.mean(e[-1]**2))),
            max_terminal_error_deg=float(abs(e[-1]).max()),start_s=start_s,end_s=end_s)
    def export(self,snapshot,states,path):
        base=self.bases[snapshot.preset];ids=base['muscle_indices'];adrs=self.model.actuator_actadr[ids];off=1+self.model.nq+self.model.nv
        A=states[:,off:][:,adrs];U=snapshot.controls[:,ids];t=np.arange(len(states))*self.model.opt.timestep;tu=t[:-1]
        doc=dict(schema='muscle-slider-project-v1',preset=snapshot.preset,revision=snapshot.revision,
            coefficients=snapshot.coefficients.tolist(),model_sha256=self.manifest['model_sha256'],baseline_sha256=self.presets[snapshot.preset]['sha256'],
            muscle_ids=base['muscle_ids'].tolist(),segment_ms=self.segment_ms,formula='s>=0: u=u0+s*(1-u0); s<0: u=u0*(1+s)')
        buffer=io.BytesIO();np.savez_compressed(buffer,time_s=t,activation=A,excitation_time_s=tu,excitation=U,all_controls=snapshot.controls,
            full_state=states,initial_state=base['initial_state'],initial_warmstart=base['initial_warmstart'],muscle_ids=base['muscle_ids'],
            actuator_indices=ids,activation_indices=adrs,joint_names=self.reference['joint_names'],joint_qpos_indices=self.reference['joint_qpos_indices'],
            joint_dof_indices=self.reference['joint_dof_indices'],reference_time_s=self.reference['time_s'],reference_qpos=self.reference['qpos'],reference_qvel=self.reference['qvel'])
        with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
            archive.writestr('trajectories.npz',buffer.getvalue());archive.writestr('project.json',json.dumps(doc,ensure_ascii=False,indent=2))
            for name,times,values in [('activation_a_10000Hz.csv',t,A),('excitation_u_10000Hz.csv',tu,U)]:
                text=io.StringIO();writer=csv.writer(text);writer.writerow(['time_s','source_reference_time_s',*base['muscle_ids'].tolist()])
                for ti,row in zip(times,values):writer.writerow([format(ti,'.17g'),format(.5*ti,'.17g'),*[format(float(v),'.17g') for v in row]])
                archive.writestr(name,text.getvalue())
            archive.writestr('README.txt','This export contains the full physical trial replayed continuously from the original initial state using every edited interval. No intermediate state resets. activation_a is the actual muscle activation state; excitation_u is the commanded input for the following physics interval. project.json restores all sliders with the same bundled preset/model. All 141 control channels and initial warmstart are included in trajectories.npz.\n')
