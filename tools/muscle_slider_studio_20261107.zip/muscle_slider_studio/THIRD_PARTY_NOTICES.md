# Source acknowledgements

- The application uses MuJoCo (https://github.com/google-deepmind/mujoco), NumPy, ImageIO, imageio-ffmpeg and Pillow. Their packages retain their own licenses when installed.
- Body geometry and the original walking model derive from flybody, https://github.com/TuragaLab/flybody , source snapshot d015e9bfe441bd90ae431bac24c55cb74bdbce26. The upstream Apache-2.0 license is included under licenses/.
- Muscle-model templates derive in part from FlyMimic, https://github.com/gizemozd/FlyMimic , snapshot 9ea1131626cd76f7203b74076ef8f0e9cab30bef. Its Apache-2.0 license is included under licenses/.
- The six-leg working model and fitted input presets are project-specific estimates and adaptations, not unmodified releases of those papers. data/manifest.json preserves their provenance and hashes. The reference is simulated motion, not a recorded animal video.
- Mesh paths have been made portable. Muscle parameters, inertial properties and the existing nonmuscle inputs have not been changed by this application.
