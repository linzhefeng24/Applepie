"""Single GL-owning worker for video previews and full-trajectory exports."""
import json,queue,threading,time,uuid
from pathlib import Path
import numpy as np,mujoco

class Engine:
    def __init__(self,editor,output):
        self.editor=editor;self.output=Path(output);self.output.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock();self.jobs={};self.queue=queue.Queue();self.latest_preview=None
        self.renderer=None;self.thread=threading.Thread(target=self._run,daemon=True);self.thread.start()
    def submit(self,key,segment,view='segment',slowdown=20,camera='native',export=False):
        state=self.editor.state(key)
        if type(segment) is not int or not 0<=segment<state['segments']:raise ValueError('时间段不存在')
        if view not in ['segment','prefix','full'] or camera not in ['native','left','right','top']:raise ValueError('回放选项无效')
        slowdown=float(slowdown)
        if slowdown not in [1,2,5,10,20,40,80]:raise ValueError('慢放倍数无效')
        snapshot=self.editor.snapshot(key);identifier=uuid.uuid4().hex
        job=dict(id=identifier,preset=key,revision=snapshot.revision,segment=segment,view=view,slowdown=slowdown,
            camera=camera,kind='export' if export else 'preview',state='queued',created=time.time())
        with self.lock:
            if len(self.jobs)>100:
                for k in list(self.jobs):
                    if self.jobs[k]['state'] in ['done','error','superseded']:self.jobs.pop(k)
                    if len(self.jobs)<=60:break
            self.jobs[identifier]=job
            if not export:self.latest_preview=identifier
        self.queue.put((identifier,snapshot));return job.copy()
    def status(self,identifier):
        with self.lock:
            if identifier not in self.jobs:raise ValueError('回放任务不存在')
            return self.jobs[identifier].copy()
    def _set(self,identifier,**kw):
        with self.lock:self.jobs[identifier].update(kw)
    def _obsolete(self,job):
        return job['kind']=='preview' and (job['id']!=self.latest_preview or self.editor.revision(job['preset'])!=job['revision'])
    def _run(self):
        while True:
            identifier,snapshot=self.queue.get()
            try:
                job=self.status(identifier)
                if self._obsolete(job):self._set(identifier,state='superseded');continue
                self._set(identifier,state='simulating')
                dt=self.editor.model.opt.timestep;N=len(snapshot.controls);block=self.editor.block_steps
                first=job['segment']*block;last=min(N,(job['segment']+1)*block)
                if job['view']=='prefix':first=0
                if job['view']=='full' or job['kind']=='export':first=0;last=N
                states=self.editor.simulate(snapshot,end_step=last)
                if self._obsolete(job):self._set(identifier,state='superseded');continue
                metrics=self.editor.metrics(states,first*dt,last*dt)
                qa=self.editor.reference['joint_qpos_indices'];end=states[last,1:1+self.editor.model.nq][qa]
                error=np.rad2deg(end-self.editor.reference_at(last*dt)[qa]);names=self.editor.reference['joint_names']
                order=np.argsort(abs(error))[::-1][:8]
                joint_errors=[dict(joint=str(names[i]),error_deg=float(error[i])) for i in order]
                if job['kind']=='export':
                    filename=identifier+'.zip';self._set(identifier,state='exporting')
                    self.editor.export(snapshot,states,self.output/filename)
                    self._set(identifier,state='done',download='/downloads/'+filename,metrics=metrics,joint_errors=joint_errors)
                else:
                    filename=identifier+'.mp4';self._set(identifier,state='rendering')
                    complete=self._video(snapshot,states,first,last,job,self.output/filename)
                    if not complete:self._set(identifier,state='superseded');continue
                    self._set(identifier,state='done',video='/media/'+filename,metrics=metrics,joint_errors=joint_errors)
            except Exception as exc:self._set(identifier,state='error',error=str(exc))
            finally:self.queue.task_done()
    def _video(self,snapshot,states,first,last,job,path):
        import imageio.v2 as imageio
        from PIL import Image,ImageDraw
        m=self.editor.model
        if self.renderer is None:
            m.vis.quality.offsamples=0;m.vis.quality.shadowsize=512
            self.renderer=mujoco.Renderer(m,height=300,width=400)
            for i in range(m.ngeom):
                if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,i) or '').startswith('ghost/'):m.geom_rgba[i,3]=0
        renderer=self.renderer;d=mujoco.MjData(m);opt=mujoco.MjvOption();opt.sitegroup[:]=0
        opt.flags[mujoco.mjtVisFlag.mjVIS_TENDON]=False
        body=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'walker/thorax');dt=m.opt.timestep
        display=(last-first)*dt*job['slowdown'];fps=25;count=max(2,int(round(display*fps)))
        if count>1200:fps=max(5,int(1200/display));count=max(2,int(round(display*fps)))
        frames=np.rint(np.linspace(first,last,count)).astype(int)
        with imageio.get_writer(path,fps=fps,codec='libx264',quality=7,macro_block_size=2) as writer:
            for index in frames:
                if self._obsolete(job):return False
                panels=[];target=self.editor.reference_at(index*dt)
                for reference in [True,False]:
                    mujoco.mj_setState(m,d,states[index],mujoco.mjtState.mjSTATE_FULLPHYSICS)
                    if reference:d.qpos[:]=target
                    mujoco.mj_fwdPosition(m,d)
                    if job['camera']=='native':camera=min(1,m.ncam-1)
                    else:
                        camera=mujoco.MjvCamera();camera.type=mujoco.mjtCamera.mjCAMERA_FREE
                        camera.lookat[:]=d.xpos[body];camera.distance=.55
                        camera.azimuth=90 if job['camera'] in ['left','top'] else 270
                        camera.elevation=-85 if job['camera']=='top' else -20
                    renderer.update_scene(d,camera=camera,scene_option=opt)
                    renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW]=False;renderer.scene.flags[mujoco.mjtRndFlag.mjRND_REFLECTION]=False
                    im=Image.fromarray(renderer.render());draw=ImageDraw.Draw(im);draw.rectangle((0,0,400,47),fill='black')
                    label='Reference (kinematic)' if reference else f'Edited {snapshot.preset} | r{snapshot.revision}'
                    draw.text((7,6),label,fill='white');draw.text((7,25),f't={index*dt:.4f}s | {job["slowdown"]:g}x slow',fill='white');panels.append(np.asarray(im))
                writer.append_data(np.concatenate(panels,axis=1))
        return True
