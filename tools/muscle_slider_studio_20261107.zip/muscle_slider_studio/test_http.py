"""Ensure saved exports remain downloadable after in-memory job entries expire."""
import tempfile,threading,urllib.request,unittest
from pathlib import Path
from server import make_server
class FakeEngine:
    def __init__(self,path):self.output=Path(path)
    def status(self,key):raise ValueError('expired')
class HttpTests(unittest.TestCase):
    def test_expired_job_file_and_video_range(self):
        with tempfile.TemporaryDirectory() as folder:
            name='a'*32;data=b'0123456789';(Path(folder)/(name+'.zip')).write_bytes(data);(Path(folder)/(name+'.mp4')).write_bytes(data)
            server=make_server(None,FakeEngine(folder),'127.0.0.1',0);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            try:
                base=f'http://127.0.0.1:{server.server_port}'
                with urllib.request.urlopen(base+'/downloads/'+name+'.zip') as response:self.assertEqual(response.read(),data)
                req=urllib.request.Request(base+'/media/'+name+'.mp4',headers={'Range':'bytes=2-5'})
                with urllib.request.urlopen(req) as response:self.assertEqual(response.status,206);self.assertEqual(response.read(),b'2345')
            finally:server.shutdown();server.server_close();thread.join()
if __name__=='__main__':unittest.main(verbosity=2)
