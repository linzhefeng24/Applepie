Windows UTF-8编码修复补丁 v1.0.1

1. 关闭原程序命令窗口。
2. 将本补丁中的core.py和start_windows.cmd复制到原程序目录，覆盖同名文件。
   目标是包含server.py、data文件夹、.venv文件夹的那个目录。
3. 再次双击start_windows.cmd。

无需重新安装依赖，也无需重新下载模型。补丁不包含data或user_data文件夹，不会覆盖已保存的项目和轨迹。

临时启动命令（在原程序目录的终端运行）：
.\.venv\Scripts\python.exe -X utf8 server.py
