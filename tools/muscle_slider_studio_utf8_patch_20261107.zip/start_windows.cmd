@echo off
setlocal
cd /d "%~dp0"
set "STUDIO_PYTHON_CMD="
if exist ".venv\Scripts\python.exe" goto :dependencies
for %%V in (3.11 3.12 3.10) do (
  py -%%V -c "import sys" >nul 2>&1
  if not errorlevel 1 if not defined STUDIO_PYTHON_CMD set "STUDIO_PYTHON_CMD=py -%%V"
)
if not defined STUDIO_PYTHON_CMD (
  python -c "import sys; assert (3,10) <= sys.version_info[:2] <= (3,12)" >nul 2>&1
  if not errorlevel 1 set "STUDIO_PYTHON_CMD=python"
)
if not defined STUDIO_PYTHON_CMD (
  echo Please install Python 3.11 or 3.12 from python.org first.
  echo During installation enable the Python launcher or Add Python to PATH.
  pause
  exit /b 1
)
echo Creating a local Python environment...
call %STUDIO_PYTHON_CMD% -m venv .venv
if errorlevel 1 goto :failed
:dependencies
".venv\Scripts\python.exe" -X utf8 -c "import mujoco,numpy,imageio,imageio_ffmpeg,PIL; assert mujoco.__version__=='3.3.2'" >nul 2>&1
if not errorlevel 1 goto :run
echo Installing simulation and video dependencies. Internet is needed on first launch.
".venv\Scripts\python.exe" -X utf8 -m pip install -r requirements.txt
if errorlevel 1 goto :failed
:run
echo Opening Muscle Slider Studio. Keep this window open while editing.
".venv\Scripts\python.exe" -X utf8 server.py
if errorlevel 1 goto :failed
exit /b 0
:failed
echo The program could not start. Please keep the error text above for diagnosis.
pause
exit /b 1
