"""Reproduce Windows GBK defaults without depending on the host's locale."""
import io,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from core import Editor
ROOT=Path(__file__).resolve().parent

class EncodingTests(unittest.TestCase):
    def test_gbk_default_manifest_and_project_roundtrip(self):
        original=Path.open;calls=[]
        def gbk_open(file,mode='r',buffering=-1,encoding=None,errors=None,newline=None):
            if 'b' not in mode:
                calls.append((str(file),mode,encoding))
                if encoding in [None,'locale']:encoding='gbk'
            return original(file,mode,buffering,encoding,errors,newline)
        def windows_text_encoding(encoding,stacklevel=2):return 'locale' if encoding is None else encoding
        with tempfile.TemporaryDirectory() as temp,patch.object(Path,'open',new=gbk_open),patch('io.text_encoding',side_effect=windows_text_encoding):
            # The pre-fix read fails for the actual bundled manifest under GBK.
            with self.assertRaises(UnicodeDecodeError):(ROOT/'data/manifest.json').read_text()
            work=Path(temp)/'中文项目'
            editor=Editor(ROOT/'data',work)
            self.assertEqual(editor.presets['A']['label'],'后腿修正版 A')
            editor.edit('A',[dict(segment=0,muscle=0,value=.25)])
            expected=editor.snapshot('A').controls.copy()
            restored=Editor(ROOT/'data',work)
            np.testing.assert_array_equal(restored.snapshot('A').controls,expected)
            self.assertTrue(any(mode.startswith('w') and encoding=='utf-8' for _,mode,encoding in calls))
            self.assertTrue(any(mode.startswith('r') and encoding=='utf-8-sig' for _,mode,encoding in calls))
    def test_bom_in_saved_project(self):
        with tempfile.TemporaryDirectory() as temp:
            editor=Editor(ROOT/'data',temp);editor.edit('B',[dict(segment=1,muscle=3,value=-.2)])
            path=Path(temp)/'B.json';path.write_bytes(b'\xef\xbb\xbf'+path.read_bytes())
            restored=Editor(ROOT/'data',temp)
            self.assertEqual(restored.state('B')['coefficients'][1][3],-.2)

if __name__=='__main__':unittest.main(verbosity=2)
